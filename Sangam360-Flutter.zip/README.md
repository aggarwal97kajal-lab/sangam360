# Sangam360 — Flutter app

The Sangam360 app (societies, schools and companies), rebuilt in Flutter. Every feature of the old app is kept, and it
uses the same backend: Firebase project `my-building-326a9` (Firestore, Realtime Database, Auth) and the payments
server `https://sangam360-payments.onrender.com`. The data shapes and server calls are unchanged, so the old app and
this app can run side by side on the same data.

## Build the APK on GitHub (no computer setup needed)

1. Create a new **private** repository on GitHub and upload everything in this folder (keep the folder structure:
   `lib/`, `android/`, `assets/`, `.github/`, `pubspec.yaml` …).
2. In the repository: **Settings → Secrets and variables → Actions → New repository secret**, add:
   - `KEYSTORE_BASE64` — your existing `sangam360.keystore` as base64 (the same secret the old app used)
   - `KEYSTORE_PASSWORD` — its password
   With the same key the new APK installs over the old app and "Continue with Google" keeps working.
3. Open **Actions → Build Android APK (Flutter) → Run workflow** (it also runs on every push to `main`).
4. When it finishes (about 10–15 minutes), download **Sangam360** under *Artifacts*: it contains `Sangam360.apk`.

If a build fails, open the run, expand **Check the code** and **Build APK**, and send the log.

## Project layout

- `lib/core` — session, Firestore helpers, listeners, payments API, files, PDFs, push, live location, plans
- `lib/ui` — theme (light minimal, dark mode), buttons, cards, fields, sheets, animations, media
- `lib/screens` — boot / login / join / create, home (hero), services, communication (notices, chat, DMs),
  finance (bills, payments, payouts, history, plan), people & profile, add-on tools (society, school, company,
  school bus, drivers), maps, support assistant
- `android/` — native parts: push notifications (reply from notification), background live location for bus trips,
  file saving; app id `com.sangam360.app`
