-keepattributes *Annotation*
-dontwarn com.razorpay.**
-keep class com.razorpay.** {*;}
-optimizations !method/inlining/
-keepclasseswithmembers class * {
  public void onPayment*(...);
}
-keep class com.sangam360.app.** { *; }
-keep class io.flutter.** { *; }
-dontwarn io.flutter.embedding.**
