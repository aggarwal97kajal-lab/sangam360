package com.sangam360.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Keeps "Share live location" going when the app is in the background, closed from recents, or the phone is locked.
 * It runs as a foreground service (Android shows a notification while it is on) and writes the position straight to
 * Firestore with the signed-in user's own token, into the same place the web app writes:
 *   community chat -> societies/{sid}/presence/{uid}   field live
 *   private chat   -> societies/{sid}/dmchats/{cid}    field live.{uid}
 *   school bus trip -> societies/{sid}/buses/{bus}     field live, and arr.{key} the first time the bus is within
 *                      120 m of a student's pickup point (or the school gate) and is not just driving past.
 *                      "geo" = "k1abc,lat,lng;k9xyz,lat,lng;sch,lat,lng", "gn" = {"k1abc":"Aarav",...} for the
 *                      notification, which then reads "Next pickup: Aarav · 650 m".
 * It stops by itself when the chosen time is over, or when the person taps Stop.
 */
public class LiveLocationService extends Service implements LocationListener {
    static final String PREF = "live_location";
    static final String[] KEYS = { "project", "apiKey", "sid", "uid", "cid", "bus", "geo", "gn", "gl", "lid", "idToken", "refreshToken", "pay" };
    private static final float NEAR_M = 120f, MAX_ACC_M = 150f, SLOW_MS = 4.2f;
    private static final String CH = "live_location";
    private static final int NID = 7301;
    private static final long MIN_GAP = 12000, KEEP_ALIVE = 60000, TICK = 15000, TOKEN_LIFE = 45L * 60 * 1000;

    private LocationManager lm;
    private Handler h;
    private ExecutorService ex;
    private PowerManager.WakeLock wl;
    private volatile Location last;
    private Location sent;
    private long lastSent = 0;
    private boolean running = false, finishing = false;
    private int ended = 0;
    private String lastNote = "";
    private volatile long lastAt = 0;   // when the newest position came in; none for 20 s = the bus is standing

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (finishing) return;
            long now = System.currentTimeMillis();
            if (now >= prefs().getLong("until", 0)) { finish(true); return; }
            Location l = last;
            if (l != null && now - lastSent >= MIN_GAP && (l != sent || now - lastSent >= KEEP_ALIVE || reached(l).size() > 0)) push(l, 0);
            h.postDelayed(this, TICK);
        }
    };

    private SharedPreferences prefs() { return getSharedPreferences(PREF, MODE_PRIVATE); }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        h = new Handler(Looper.getMainLooper());
        ex = Executors.newSingleThreadExecutor();
    }

    @Override
    public int onStartCommand(Intent in, int flags, int startId) {
        SharedPreferences sp = prefs();
        String act = in == null ? null : in.getAction();
        if (in != null && "start".equals(act) && in.hasExtra("lid")) {
            SharedPreferences.Editor e = sp.edit();
            for (String k : KEYS) { String v = in.getStringExtra(k); e.putString(k, v == null ? "" : v); }
            e.putLong("until", in.getLongExtra("until", 0));
            e.putLong("tokenAt", System.currentTimeMillis());
            e.putString("arr", "");
            e.apply();
            last = null; sent = null; lastSent = 0; finishing = false; ended = 0; lastAt = 0;
        }
        long until = sp.getLong("until", 0);
        // a service started with startForegroundService must show its notification straight away
        if (!foreground(until)) { stopSelf(); return START_NOT_STICKY; }
        if ("stop".equals(act)) { finish(true); return START_NOT_STICKY; }
        if (sp.getString("lid", "").length() == 0 || until <= System.currentTimeMillis()) { finish(sp.getString("lid", "").length() > 0); return START_NOT_STICKY; }
        begin(until);
        return START_STICKY;
    }

    private boolean foreground(long until) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26 && nm != null) {
                NotificationChannel ch = new NotificationChannel(CH, "Live location", NotificationManager.IMPORTANCE_LOW);
                ch.setDescription("Shown while you are sharing your live location");
                nm.createNotificationChannel(ch);
            }
            lastNote = "";
            Notification n = note(until, null);
            if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            else startForeground(NID, n);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** The ongoing notification; "line" replaces the usual text (bus trip: the next pickup). */
    private Notification note(long until, String line) {
        int pf = Build.VERSION.SDK_INT >= 23 ? (PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE) : PendingIntent.FLAG_UPDATE_CURRENT;
        Intent stop = new Intent(this, LiveLocationService.class);
        stop.setAction("stop");
        PendingIntent pStop = PendingIntent.getService(this, 1, stop, pf);
        Intent open = getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent pOpen = open == null ? null : PendingIntent.getActivity(this, 2, open, pf);
        String text = line != null ? line : until > 0 ? "Sharing until " + DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(until)) + ". Tap Stop to end it now." : "Sharing your live location";
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        b.setContentTitle(line != null ? "Bus trip is on" : "Live location is on").setContentText(text).setSmallIcon(android.R.drawable.ic_menu_mylocation).setOngoing(true).setOnlyAlertOnce(true);
        if (pOpen != null) b.setContentIntent(pOpen);
        b.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", pStop);
        return b.build();
    }

    /** Bus trip: show the nearest pickup point that has not been reached yet in the notification. */
    private void nextPickup(Location l) {
        try {
            SharedPreferences sp = prefs();
            String geo = sp.getString("geo", "");
            if (l == null || geo.length() == 0 || sp.getString("bus", "").length() == 0) return;
            String done = ";" + sp.getString("arr", "") + ";", best = null;
            float bd = Float.MAX_VALUE;
            int all = 0;
            float[] d = new float[1];
            for (String g : geo.split(";")) {
                String[] p = g.split(",");
                if (p.length != 3 || "sch".equals(p[0])) continue;
                all++;
                if (done.contains(";" + p[0] + ";")) continue;
                Location.distanceBetween(l.getLatitude(), l.getLongitude(), Double.parseDouble(p[1]), Double.parseDouble(p[2]), d);
                if (d[0] < bd) { bd = d[0]; best = p[0]; }
            }
            if (all == 0) return;
            String label = sp.getString("gl", ""), line;
            if (label.length() == 0) label = "Next pickup";
            if (best == null) line = "All " + all + " points reached. End the trip in the app when you are done.";
            else {
                String name = "";
                try { name = new JSONObject(sp.getString("gn", "{}")).optString(best, ""); } catch (Exception ignored) { }
                String far = bd < 1000 ? (Math.max(10, Math.round(bd / 10f) * 10)) + " m" : (Math.round(bd / 100f) / 10f) + " km";
                line = label + ": " + (name.length() > 0 ? name : "student") + " · " + far;
            }
            if (line.equals(lastNote)) return;
            lastNote = line;
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NID, note(sp.getLong("until", 0), line));
        } catch (Exception ignored) { }
    }

    private void begin(long until) {
        if (running) return;
        running = true;
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sangam360:live");
                wl.setReferenceCounted(false);
                wl.acquire(Math.max(60000, until - System.currentTimeMillis()) + 60000);
            }
        } catch (Exception ignored) { }
        try {
            lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (lm != null) {
                if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10000, 5f, this, Looper.getMainLooper());
                if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10000, 5f, this, Looper.getMainLooper());
            }
        } catch (SecurityException ignored) {
        } catch (Exception ignored) { }
        h.removeCallbacks(tick);
        h.postDelayed(tick, TICK);
    }

    @Override
    public void onLocationChanged(Location l) {
        if (l == null || finishing) return;
        // prefer the more accurate fix when two providers report at nearly the same time
        Location p = last;
        if (p != null && l.getTime() - p.getTime() < 8000 && l.hasAccuracy() && p.hasAccuracy() && l.getAccuracy() > p.getAccuracy() * 2) return;
        last = l;
        lastAt = System.currentTimeMillis();
        nextPickup(l);
        // a pickup point has just been reached: say so straight away
        if (System.currentTimeMillis() - lastSent >= MIN_GAP || reached(l).size() > 0) push(l, 0);
    }

    private boolean standing() { return lastAt > 0 && System.currentTimeMillis() - lastAt >= 20000; }

    /** Bus trip only: the pickup points (keys) this position is at and that have not been reported yet. */
    private java.util.ArrayList<String> reached(Location l) {
        java.util.ArrayList<String> out = new java.util.ArrayList<String>();
        try {
            SharedPreferences sp = prefs();
            String geo = sp.getString("geo", "");
            if (l == null || geo.length() == 0 || sp.getString("bus", "").length() == 0) return out;
            if (l.hasAccuracy() && l.getAccuracy() > MAX_ACC_M) return out;
            if (l.hasSpeed() && l.getSpeed() > SLOW_MS && !standing()) return out;   // only passing by
            String done = ";" + sp.getString("arr", "") + ";";
            float[] d = new float[1];
            for (String g : geo.split(";")) {
                String[] p = g.split(",");
                if (p.length != 3 || !p[0].matches("[a-z0-9]{1,8}") || done.contains(";" + p[0] + ";")) continue;
                Location.distanceBetween(l.getLatitude(), l.getLongitude(), Double.parseDouble(p[1]), Double.parseDouble(p[2]), d);
                if (d[0] <= NEAR_M) out.add(p[0]);
            }
        } catch (Exception ignored) { }
        return out;
    }

    @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
    @Override public void onProviderEnabled(String provider) { }
    @Override public void onProviderDisabled(String provider) { }

    private void push(final Location l, final long end) {
        lastSent = System.currentTimeMillis();
        sent = l;
        ex.execute(new Runnable() {
            @Override public void run() { try { send(l, end); } catch (Exception ignored) { } }
        });
    }

    /** Tell the chat that sharing has ended (if asked), then shut down. */
    private void finish(final boolean tellChat) {
        if (finishing) return;
        finishing = true;
        h.removeCallbacks(tick);
        try { if (lm != null) lm.removeUpdates(this); } catch (Exception ignored) { }
        final Location l = last;
        ex.execute(new Runnable() {
            @Override public void run() {
                try { if (tellChat) send(l, System.currentTimeMillis()); } catch (Exception ignored) { }
                prefs().edit().putString("lid", "").putString("idToken", "").putString("refreshToken", "").apply();
                h.post(new Runnable() { @Override public void run() { shutdown(); } });
            }
        });
    }

    private void shutdown() {
        running = false;
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) { }
        try { stopForeground(true); } catch (Exception ignored) { }
        stopSelf();
    }

    @Override
    public void onDestroy() {
        try { if (lm != null) lm.removeUpdates(this); } catch (Exception ignored) { }
        try { if (h != null) h.removeCallbacks(tick); } catch (Exception ignored) { }
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) { }
        try { if (ex != null) ex.shutdown(); } catch (Exception ignored) { }
        super.onDestroy();
    }

    /* ------------------------------------------------------------------ network ------------------------------------------------------------------ */

    /** The school (or the driver on another phone) ended this trip, or started a new one: stop sharing here too. */
    private void watchTrip(HttpURLConnection c, String lid) {
        try {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            java.io.InputStream in = c.getInputStream();
            byte[] buf = new byte[2048];
            int n;
            while ((n = in.read(buf)) > 0 && bo.size() < 65536) bo.write(buf, 0, n);
            in.close();
            JSONObject fl = new JSONObject(bo.toString("UTF-8")).optJSONObject("fields");
            if (fl == null) return;
            JSONObject on = fl.optJSONObject("on"), li = fl.optJSONObject("lid");
            String cur = li == null ? "" : li.optString("stringValue", "");
            boolean off = (on != null && !on.optBoolean("booleanValue", true) && cur.equals(lid)) || (cur.length() > 0 && !cur.equals(lid));
            ended = off ? ended + 1 : 0;
            if (ended >= 2) h.post(new Runnable() { @Override public void run() { finish(false); } });
        } catch (Exception ignored) { }
    }

    private static String enc(String s) throws Exception { return URLEncoder.encode(s, "UTF-8").replace("+", "%20"); }
    private static JSONObject iv(long v) throws Exception { return new JSONObject().put("integerValue", String.valueOf(v)); }
    private static JSONObject dv(double v) throws Exception { return new JSONObject().put("doubleValue", v); }
    private static JSONObject sv(String v) throws Exception { return new JSONObject().put("stringValue", v); }
    private static JSONObject map(JSONObject fields) throws Exception { return new JSONObject().put("mapValue", new JSONObject().put("fields", fields)); }

    private void send(Location l, long end) throws Exception {
        SharedPreferences sp = prefs();
        String lid = sp.getString("lid", ""), sid = sp.getString("sid", ""), uid = sp.getString("uid", ""), cid = sp.getString("cid", ""), project = sp.getString("project", "");
        if (lid.length() == 0 || sid.length() == 0 || uid.length() == 0 || project.length() == 0) return;
        String tok = token(sp);
        if (tok == null || tok.length() == 0) return;
        String bus = sp.getString("bus", "");
        boolean bb = bus.length() > 0, dm = !bb && cid.length() > 0;
        String doc = "https://firestore.googleapis.com/v1/projects/" + enc(project) + "/databases/(default)/documents/societies/" + enc(sid) + (bb ? "/buses/" + enc(bus) : dm ? "/dmchats/" + enc(cid) : "/presence/" + enc(uid));
        String base = dm ? "live.`" + uid + "`." : "live.";
        long now = System.currentTimeMillis();
        JSONObject f = new JSONObject();
        f.put("lid", sv(lid));
        f.put("until", iv(sp.getLong("until", 0)));
        f.put("end", iv(end));
        f.put("ts", iv(now));
        if (bb) f.put("spd", dv(l == null ? -1 : standing() ? 0 : l.hasSpeed() ? Math.round(l.getSpeed() * 10) / 10.0 : -1));
        if (l != null) {
            f.put("lat", dv(Math.round(l.getLatitude() * 1e6) / 1e6));
            f.put("lng", dv(Math.round(l.getLongitude() * 1e6) / 1e6));
            f.put("acc", iv(Math.round(l.hasAccuracy() ? l.getAccuracy() : 0)));
        }
        StringBuilder q = new StringBuilder();
        java.util.Iterator<String> it = f.keys();
        while (it.hasNext()) q.append(q.length() == 0 ? "?" : "&").append("updateMask.fieldPaths=").append(enc(base + it.next()));
        JSONObject fields = new JSONObject().put("live", dm ? map(new JSONObject().put(uid, map(f))) : map(f));
        java.util.ArrayList<String> hit = bb && end == 0 ? reached(l) : new java.util.ArrayList<String>();
        if (hit.size() > 0) {
            JSONObject a = new JSONObject();
            for (String k : hit) { a.put(k, iv(now)); q.append("&updateMask.fieldPaths=").append(enc("arr." + k)); }
            fields.put("arr", map(a));
        }
        // sharing of a bus trip has ended here (Stop in the notification, time over, log-out): the trip ends with it
        if (bb && end > 0 && ended == 0) {
            fields.put("on", new JSONObject().put("booleanValue", false));
            fields.put("endTs", iv(end));
            q.append("&updateMask.fieldPaths=on&updateMask.fieldPaths=endTs");
        }
        // the answer then carries just these two fields: enough to notice that the trip was ended from another phone
        if (bb) q.append("&mask.fieldPaths=on&mask.fieldPaths=lid");
        byte[] body = new JSONObject().put("fields", fields).toString().getBytes("UTF-8");

        HttpURLConnection c = (HttpURLConnection) new URL(doc + q).openConnection();
        try {
            c.setConnectTimeout(15000);
            c.setReadTimeout(15000);
            try { c.setRequestMethod("PATCH"); }
            catch (Exception pe) { c.setRequestMethod("POST"); c.setRequestProperty("X-HTTP-Method-Override", "PATCH"); }
            c.setRequestProperty("Authorization", "Bearer " + tok);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            c.setDoOutput(true);
            OutputStream os = c.getOutputStream();
            os.write(body);
            os.close();
            int code = c.getResponseCode();
            if (code == 401) sp.edit().putLong("tokenAt", 0).apply();   // token expired early: get a new one next time
            if (code == 200 && bb) {
                if (hit.size() > 0) {
                    StringBuilder d = new StringBuilder(sp.getString("arr", ""));
                    for (String k : hit) d.append(d.length() == 0 ? "" : ";").append(k);
                    sp.edit().putString("arr", d.toString()).apply();
                }
                if (end == 0) watchTrip(c, lid);
                notifyServer(sp, tok, sid, bus, hit.size() > 0 || end > 0);
            }
        } finally {
            c.disconnect();
        }
    }

    /** School bus: name the bus to the Sangam360 server (at most every 20 s, at once on an arrival or the end),
     *  which then sends the parents their "bus is near / has arrived" notifications, also to closed apps. */
    private volatile long lastPing = 0;
    private void notifyServer(SharedPreferences sp, final String tok, final String sid, final String bus, boolean now) {
        final String pay = sp.getString("pay", "").replaceAll("/+$", "");
        if (pay.length() == 0 || !pay.startsWith("https://")) return;
        long t = System.currentTimeMillis();
        if (!now && t - lastPing < 20000) return;
        lastPing = t;
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection c = null;
                try {
                    JSONObject b = new JSONObject().put("sid", sid).put("paths", new org.json.JSONArray().put("societies/" + sid + "/buses/" + bus));
                    c = (HttpURLConnection) new URL(pay + "/v1/push/event").openConnection();
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(90000);   // the free server may need a minute to wake up
                    c.setRequestMethod("POST");
                    c.setRequestProperty("Authorization", "Bearer " + tok);
                    c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    c.setDoOutput(true);
                    OutputStream os = c.getOutputStream();
                    os.write(b.toString().getBytes("UTF-8"));
                    os.close();
                    c.getResponseCode();
                } catch (Exception ignored) {
                } finally {
                    if (c != null) c.disconnect();
                }
            }
        }).start();
    }

    /** The sign-in token lasts one hour. The phone's own Firebase sign-in renews it (the Flutter app and this service share it);
     *  the refresh token is only a fallback for an app that did not hand it over. */
    private String token(SharedPreferences sp) {
        try {
            com.google.firebase.auth.FirebaseUser u = com.google.firebase.auth.FirebaseAuth.getInstance().getCurrentUser();
            if (u != null && u.getUid().equals(sp.getString("uid", ""))) {
                com.google.firebase.auth.GetTokenResult r = com.google.android.gms.tasks.Tasks.await(u.getIdToken(System.currentTimeMillis() - sp.getLong("tokenAt", 0) >= TOKEN_LIFE), 20, java.util.concurrent.TimeUnit.SECONDS);
                String t = r == null ? null : r.getToken();
                if (t != null && t.length() > 0) {
                    sp.edit().putString("idToken", t).putLong("tokenAt", System.currentTimeMillis()).apply();
                    return t;
                }
            }
        } catch (Exception ignored) { }
        String tok = sp.getString("idToken", "");
        if (tok.length() > 0 && System.currentTimeMillis() - sp.getLong("tokenAt", 0) < TOKEN_LIFE) return tok;
        String rt = sp.getString("refreshToken", ""), key = sp.getString("apiKey", "");
        if (rt.length() == 0 || key.length() == 0) return tok;
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL("https://securetoken.googleapis.com/v1/token?key=" + enc(key)).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(15000);
            c.setRequestMethod("POST");
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            c.setDoOutput(true);
            OutputStream os = c.getOutputStream();
            os.write(("grant_type=refresh_token&refresh_token=" + enc(rt)).getBytes("UTF-8"));
            os.close();
            if (c.getResponseCode() != 200) return tok;
            InputStream is = c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
            is.close();
            JSONObject j = new JSONObject(new String(bo.toByteArray(), "UTF-8"));
            String nt = j.optString("id_token", ""), nr = j.optString("refresh_token", "");
            if (nt.length() == 0) return tok;
            SharedPreferences.Editor e = sp.edit().putString("idToken", nt).putLong("tokenAt", System.currentTimeMillis());
            if (nr.length() > 0) e.putString("refreshToken", nr);
            e.apply();
            return nt;
        } catch (Exception e) {
            return tok;
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
