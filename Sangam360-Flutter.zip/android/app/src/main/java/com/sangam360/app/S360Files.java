package com.sangam360.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * "Download": the file is written into the phone's own Downloads folder (Download/Sangam360), where the Files app and
 * every PDF reader find it.
 *   - Android 10 and newer: through the system's Downloads collection. No permission is asked.
 *   - Android 9 and older:  straight into the public Download folder (the storage permission is asked by the app first).
 */
final class S360Files {
    private static final String FOLDER = "Sangam360";
    private static final String CH = "s360_downloads";
    private static int nextId = 7400;

    private S360Files() { }

    private static String clean(String name) {
        String n = name == null ? "" : name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]+", "_").trim();
        while (n.startsWith(".")) n = n.substring(1);
        if (n.length() > 120) n = n.substring(n.length() - 120);
        return n.length() == 0 ? "download" : n;
    }

    /** "Receipt.pdf", then "Receipt (1).pdf", "Receipt (2).pdf" ... */
    private static File free(File dir, String name) {
        File f = new File(dir, name);
        if (!f.exists()) return f;
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name, ext = dot > 0 ? name.substring(dot) : "";
        for (int i = 1; i < 500; i++) {
            f = new File(dir, base + " (" + i + ")" + ext);
            if (!f.exists()) return f;
        }
        return new File(dir, base + " " + System.currentTimeMillis() + ext);
    }

    /** -> { uri, name, folder } ; throws when the file could not be written */
    static Map<String, Object> save(Context ctx, String name0, byte[] bytes, String mime0) throws Exception {
        final String name = clean(name0);
        final String mime = mime0 == null || mime0.length() == 0 ? "application/octet-stream" : mime0;
        Uri uri = null;
        String shown = name;
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver cr = ctx.getContentResolver();
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + FOLDER);
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new Exception("The file could not be created");
            try {
                OutputStream os = cr.openOutputStream(uri);
                if (os == null) throw new Exception("The file could not be opened");
                try { os.write(bytes); os.flush(); } finally { os.close(); }
            } catch (Exception e) {
                try { cr.delete(uri, null, null); } catch (Exception ignored) { }
                throw e;
            }
            ContentValues ready = new ContentValues();
            ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
            cr.update(uri, ready, null, null);
            Cursor c = null;
            try {
                c = cr.query(uri, new String[] { MediaStore.MediaColumns.DISPLAY_NAME }, null, null, null);
                if (c != null && c.moveToFirst()) {
                    String real = c.getString(0);
                    if (real != null && real.length() > 0) shown = real;
                }
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.close();
            }
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), FOLDER);
            if (!dir.exists() && !dir.mkdirs() && !dir.exists()) throw new Exception("The Downloads folder could not be used");
            File f = free(dir, name);
            FileOutputStream os = new FileOutputStream(f);
            try { os.write(bytes); os.flush(); } finally { os.close(); }
            try { MediaScannerConnection.scanFile(ctx, new String[] { f.getAbsolutePath() }, new String[] { mime }, null); } catch (Exception ignored) { }
            shown = f.getName();
            try { uri = FileProvider.getUriForFile(ctx, ctx.getPackageName() + ".s360files", f); } catch (Exception ignored) { }
        }
        if (uri != null) announce(ctx, uri, mime, shown);
        Map<String, Object> r = new HashMap<>();
        r.put("uri", uri == null ? "" : uri.toString());
        r.put("name", shown);
        r.put("folder", "Download/" + FOLDER);
        return r;
    }

    private static Intent viewer(Uri uri, String mime) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(uri, mime == null || mime.length() == 0 ? "*/*" : mime);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        return i;
    }

    static void open(Context ctx, String uri, String mime) {
        ctx.startActivity(viewer(Uri.parse(uri), mime));
    }

    /** "Download complete" in the notification bar; a tap opens the file. Skipped silently when notifications are off. */
    private static void announce(Context ctx, Uri uri, String mime, String name) {
        try {
            if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) return;
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(new NotificationChannel(CH, "Downloads", NotificationManager.IMPORTANCE_LOW));
            }
            int id = nextId++;
            int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
            PendingIntent tap = PendingIntent.getActivity(ctx, id, viewer(uri, mime), flags);
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx, CH) : new Notification.Builder(ctx);
            b.setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle(name)
                .setContentText("Download complete · tap to open")
                .setContentIntent(tap)
                .setAutoCancel(true);
            nm.notify(id, b.build());
        } catch (Exception ignored) {
        }
    }
}
