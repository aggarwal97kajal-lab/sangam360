package com.sangam360.app;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

/** Every push from the Sangam360 server arrives here, also when the app is closed. */
public class S360MessagingService extends FirebaseMessagingService {

    @Override
    public void onNewToken(String token) {
        // the app sends the new token to the server the next time it is opened
        S360Notifier.prefs(this).edit().putString("token", token).apply();
    }

    @Override
    public void onMessageReceived(RemoteMessage message) {
        Map<String, String> d = message.getData();
        if (d == null || d.isEmpty()) return;
        // the app is open on screen: it shows its own alert, so nothing is shown twice (a test from "Check notifications" is shown anyway)
        if (S360Notifier.foreground && !"1".equals(d.get("force"))) return;
        S360Notifier.show(this, d);
    }
}
