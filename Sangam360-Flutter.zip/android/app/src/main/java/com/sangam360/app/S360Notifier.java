package com.sangam360.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.app.Person;
import androidx.core.app.RemoteInput;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Map;

/**
 * How a push looks on the phone (same as the earlier app). The server sends (all strings):
 *   k kind (chat, ann, sos, bill, comp, gate, leave, join, gen, bus) · t title · b text · org organisation name
 *   tag one notification per tag (a chat: "d:<chat>" or "g:<org>:<room>") · open the screen to open · sid
 *   reply "1" = a chat that can be answered from the notification · frm sender · grp name of a group chat
 */
final class S360Notifier {
    static final String PREF = "s360push";
    static final String EXTRA_OPEN = "s360open", EXTRA_SID = "s360sid", EXTRA_TAG = "s360tag";
    static final String REPLY_KEY = "s360reply";
    private static final String CH_CHAT = "s360_chat", CH_ALERT = "s360_alerts", CH_INFO = "s360_updates", CH_BUS = "s360_bus";
    private static final int ACCENT = Color.parseColor("#5B3DF5");
    private static final int KEEP = 8;   // messages kept in a chat notification

    /** true while the app is on screen: it shows its own alert, so nothing is shown twice */
    static volatile boolean foreground = false;

    private S360Notifier() { }

    static SharedPreferences prefs(Context ctx) { return ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE); }

    private static int idOf(String tag) { return 0x5300000 + ((tag == null ? "" : tag).hashCode() & 0xFFFFF); }

    private static String s(Map<String, String> d, String k) { String v = d.get(k); return v == null ? "" : v; }

    private static void channels(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel chat = new NotificationChannel(CH_CHAT, "Chats", NotificationManager.IMPORTANCE_HIGH);
        chat.setDescription("Community chat and private messages");
        NotificationChannel alert = new NotificationChannel(CH_ALERT, "SOS & emergency alerts", NotificationManager.IMPORTANCE_HIGH);
        alert.setDescription("SOS and emergency notices");
        alert.enableVibration(true);
        NotificationChannel info = new NotificationChannel(CH_INFO, "Updates", NotificationManager.IMPORTANCE_DEFAULT);
        info.setDescription("Notices, visitors, parcels, bills, complaints, leave and other updates");
        nm.createNotificationChannel(chat);
        nm.createNotificationChannel(alert);
        nm.createNotificationChannel(info);
        NotificationChannel bus = new NotificationChannel(CH_BUS, "School bus", NotificationManager.IMPORTANCE_HIGH);
        bus.setDescription("The bus has started, is near, has arrived; reached school");
        bus.enableVibration(true);
        nm.createNotificationChannel(bus);
    }

    private static int smallIcon(Context ctx) {
        int id = ctx.getResources().getIdentifier("ic_stat_s360", "drawable", ctx.getPackageName());
        if (id == 0) id = ctx.getApplicationInfo().icon;
        return id != 0 ? id : android.R.drawable.ic_dialog_info;
    }

    private static Bitmap logo(Context ctx) {
        try {
            int id = ctx.getResources().getIdentifier("ic_launcher", "mipmap", ctx.getPackageName());
            return id == 0 ? null : BitmapFactory.decodeResource(ctx.getResources(), id);
        } catch (Exception e) { return null; }
    }

    /** tapping the notification opens the app on the right screen */
    private static PendingIntent tap(Context ctx, String open, String sid, int id) {
        Intent i = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
        if (i == null) i = new Intent();
        i.setPackage(ctx.getPackageName());
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        i.putExtra(EXTRA_OPEN, open);
        i.putExtra(EXTRA_SID, sid);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getActivity(ctx, id, i, fl);
    }

    static boolean allowed(Context ctx) {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) return false;
        return NotificationManagerCompat.from(ctx).areNotificationsEnabled();
    }

    private static void post(Context ctx, int id, NotificationCompat.Builder b) {
        try { NotificationManagerCompat.from(ctx).notify(id, b.build()); } catch (SecurityException ignored) { }
    }

    static void show(Context ctx, Map<String, String> d) {
        if (!allowed(ctx)) return;
        channels(ctx);
        String kind = s(d, "k"), tag = s(d, "tag"), sid = s(d, "sid");
        if (tag.length() == 0) tag = kind + ":" + s(d, "ts");
        if ("1".equals(s(d, "reply"))) {
            JSONArray h = history(ctx, tag);
            try {
                JSONObject m = new JSONObject();
                m.put("f", s(d, "frm").length() > 0 ? s(d, "frm") : s(d, "t"));
                m.put("b", s(d, "b"));
                m.put("ts", System.currentTimeMillis());
                h.put(m);
            } catch (Exception ignored) { }
            JSONObject meta = new JSONObject();
            try {
                meta.put("open", s(d, "open")); meta.put("sid", sid); meta.put("org", s(d, "org")); meta.put("grp", s(d, "grp"));
                meta.put("men", s(d, "men"));
            } catch (Exception ignored) { }
            save(ctx, tag, trim(h), meta);
            chat(ctx, tag, false, null);
            return;
        }
        boolean busK = "bus".equals(kind);
        String ch = "sos".equals(kind) ? CH_ALERT : busK ? CH_BUS : CH_INFO;
        NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, ch)
            .setSmallIcon(smallIcon(ctx))
            .setColor(ACCENT)
            .setLargeIcon(logo(ctx))
            .setContentTitle(s(d, "t"))
            .setContentText(s(d, "b"))
            .setStyle(new NotificationCompat.BigTextStyle().bigText(s(d, "b")))
            .setSubText(s(d, "org"))
            .setAutoCancel(true)
            .setPriority("sos".equals(kind) ? NotificationCompat.PRIORITY_MAX : busK ? NotificationCompat.PRIORITY_HIGH : NotificationCompat.PRIORITY_DEFAULT)
            .setCategory("sos".equals(kind) ? NotificationCompat.CATEGORY_ALARM : NotificationCompat.CATEGORY_EVENT)
            .setContentIntent(tap(ctx, s(d, "open"), sid, idOf(tag)));
        post(ctx, idOf(tag), b);
    }

    /* ---------------- a chat: one notification per conversation, like WhatsApp ---------------- */

    private static JSONArray history(Context ctx, String tag) {
        try { return new JSONArray(prefs(ctx).getString("h:" + tag, "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    private static JSONObject meta(Context ctx, String tag) {
        try { return new JSONObject(prefs(ctx).getString("m:" + tag, "{}")); } catch (Exception e) { return new JSONObject(); }
    }

    private static JSONArray trim(JSONArray h) {
        if (h.length() <= KEEP) return h;
        JSONArray out = new JSONArray();
        for (int i = h.length() - KEEP; i < h.length(); i++) out.put(h.opt(i));
        return out;
    }

    private static void save(Context ctx, String tag, JSONArray h, JSONObject meta) {
        SharedPreferences.Editor e = prefs(ctx).edit().putString("h:" + tag, h.toString());
        if (meta != null) e.putString("m:" + tag, meta.toString());
        e.apply();
    }

    /** builds (or rebuilds) the conversation's notification from what is kept for it */
    private static void chat(Context ctx, String tag, boolean quiet, String note) {
        JSONArray h = history(ctx, tag);
        JSONObject meta = meta(ctx, tag);
        if (h.length() == 0) return;
        String myName = prefs(ctx).getString("name", "");
        Person me = new Person.Builder().setName("You").setKey("me").build();
        NotificationCompat.MessagingStyle st = new NotificationCompat.MessagingStyle(me);
        String grp = meta.optString("grp", "");
        boolean group = tag.startsWith("g:");
        if (group) {
            st.setConversationTitle(grp.length() > 0 ? grp : meta.optString("org", ""));
            st.setGroupConversation(true);
        }
        String last = "", lastFrom = "";
        int theirs = 0;
        for (int i = 0; i < h.length(); i++) {
            JSONObject m = h.optJSONObject(i);
            if (m == null) continue;
            boolean mine = m.optBoolean("me", false);
            Person p = mine ? null : new Person.Builder().setName(m.optString("f", "Message")).setKey("p:" + m.optString("f", "")).build();
            st.addMessage(m.optString("b", ""), m.optLong("ts", System.currentTimeMillis()), p);
            if (!mine) { theirs++; last = m.optString("b", ""); lastFrom = m.optString("f", ""); }
        }
        if (note != null) st.addMessage(note, System.currentTimeMillis(), (Person) null);
        int id = idOf(tag);
        String sid = meta.optString("sid", "");
        RemoteInput ri = new RemoteInput.Builder(REPLY_KEY).setLabel("Reply" + (myName.length() > 0 ? " as " + myName : "")).build();
        Intent ri2 = new Intent(ctx, S360ReplyReceiver.class);
        ri2.setPackage(ctx.getPackageName());
        ri2.putExtra(EXTRA_TAG, tag);
        ri2.putExtra(EXTRA_SID, sid);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
        PendingIntent rp = PendingIntent.getBroadcast(ctx, id, ri2, fl);
        int replyIcon = ctx.getResources().getIdentifier("ic_stat_s360", "drawable", ctx.getPackageName());
        NotificationCompat.Action reply = new NotificationCompat.Action.Builder(replyIcon != 0 ? replyIcon : android.R.drawable.ic_menu_send, "Reply", rp)
            .addRemoteInput(ri)
            .setAllowGeneratedReplies(true)
            .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_REPLY)
            .setShowsUserInterface(false)
            .build();
        NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, CH_CHAT)
            .setSmallIcon(smallIcon(ctx))
            .setColor(ACCENT)
            .setLargeIcon(logo(ctx))
            .setStyle(st)
            .setContentTitle(group ? (grp.length() > 0 ? grp : meta.optString("org", "")) : lastFrom)
            .setContentText(group && lastFrom.length() > 0 ? lastFrom + ": " + last : last)
            .setSubText(meta.optString("org", ""))
            .setNumber(theirs)
            .setAutoCancel(true)
            .setOnlyAlertOnce(quiet)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setContentIntent(tap(ctx, meta.optString("open", ""), sid, id))
            .addAction(reply);
        if (quiet) b.setSilent(true);
        post(ctx, id, b);
    }

    /** the reply went through: it is shown in the conversation as "You", without a new sound */
    static void addOwn(Context ctx, String tag, String text) {
        JSONArray h = history(ctx, tag);
        try { JSONObject m = new JSONObject(); m.put("f", "You"); m.put("b", text); m.put("ts", System.currentTimeMillis()); m.put("me", true); h.put(m); } catch (Exception ignored) { }
        save(ctx, tag, trim(h), null);
        chat(ctx, tag, true, null);
    }

    /** the reply did not go through: the conversation says so, and the text is not lost (it is shown) */
    static void failed(Context ctx, String tag, String text, String why) {
        chat(ctx, tag, true, "⚠️ Not sent: \"" + text + "\" · " + why);
    }

    /** an empty reply: the spinner of the Reply box stops */
    static void refresh(Context ctx, String tag) { chat(ctx, tag, true, null); }

    static void cancel(Context ctx, String tag) {
        if (tag == null || tag.length() == 0) return;
        try { NotificationManagerCompat.from(ctx).cancel(idOf(tag)); } catch (Exception ignored) { }
        prefs(ctx).edit().remove("h:" + tag).remove("m:" + tag).apply();
    }

    static void cancelAll(Context ctx) {
        try { NotificationManagerCompat.from(ctx).cancelAll(); } catch (Exception ignored) { }
        SharedPreferences sp = prefs(ctx);
        SharedPreferences.Editor e = sp.edit();
        for (String k : sp.getAll().keySet()) if (k.startsWith("h:") || k.startsWith("m:")) e.remove(k);
        e.apply();
    }
}
