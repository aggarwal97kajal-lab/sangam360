package com.sangam360.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.core.app.RemoteInput;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** "Reply" typed in a chat notification: sent to the server, which writes it as this person's message. */
public class S360ReplyReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(final Context ctx, Intent intent) {
        Bundle res = RemoteInput.getResultsFromIntent(intent);
        final CharSequence typed = res == null ? null : res.getCharSequence(S360Notifier.REPLY_KEY);
        final String tag = intent.getStringExtra(S360Notifier.EXTRA_TAG), sid = intent.getStringExtra(S360Notifier.EXTRA_SID);
        if (typed == null || tag == null) return;
        final String text = typed.toString().trim();
        if (text.length() == 0) { S360Notifier.refresh(ctx, tag); return; }
        final PendingResult pending = goAsync();
        new Thread(new Runnable() {
            @Override
            public void run() {
                String err = null;
                try { err = send(ctx, sid, tag, text); }
                catch (Exception e) { err = "Not sent. Check your internet and reply again."; }
                finally {
                    try {
                        if (err == null) S360Notifier.addOwn(ctx, tag, text);
                        else S360Notifier.failed(ctx, tag, text, err);
                    } catch (Exception ignored) { }
                    pending.finish();
                }
            }
        }).start();
    }

    /** null when the server took the message, otherwise what to tell the person */
    private static String send(Context ctx, String sid, String tag, String text) throws Exception {
        SharedPreferences sp = S360Notifier.prefs(ctx);
        String server = sp.getString("server", ""), device = sp.getString("device", ""), key = sp.getString("key", "");
        if (server.length() == 0 || device.length() == 0 || key.length() == 0) return "Open the app once to reply from here.";
        JSONObject body = new JSONObject();
        body.put("device", device);
        body.put("key", key);
        body.put("sid", sid == null || sid.length() == 0 ? sp.getString("sid", "") : sid);
        body.put("to", tag);
        body.put("text", text);
        HttpURLConnection c = (HttpURLConnection) new URL(server.replaceAll("/+$", "") + "/v1/push/reply").openConnection();
        try {
            c.setConnectTimeout(20000);
            c.setReadTimeout(25000);
            c.setRequestMethod("POST");
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            c.setDoOutput(true);
            OutputStream os = c.getOutputStream();
            os.write(body.toString().getBytes("UTF-8"));
            os.close();
            int code = c.getResponseCode();
            if (code >= 200 && code < 300) return null;
            InputStream is = c.getErrorStream();
            String msg = "";
            if (is != null) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
                is.close();
                try { msg = new JSONObject(new String(bo.toByteArray(), "UTF-8")).getJSONObject("error").optString("message", ""); } catch (Exception ignored) { }
            }
            return msg.length() > 0 ? msg : "Not sent. Open the app and try again.";
        } finally {
            c.disconnect();
        }
    }
}
