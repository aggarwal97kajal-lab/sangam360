package com.sangam360.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.ContactsContract
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.messaging.FirebaseMessaging
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

/**
 * The native parts the Flutter app talks to (the same ones the earlier app had):
 *   s360/push    push notifications: permission, token, the key for replying from a notification, the screen to open
 *   s360/live    "Share live location" / school bus trip: a foreground service that keeps sending in the background
 *   s360/native  contact picker, saving a file into Downloads/Sangam360, opening it, battery settings
 */
class MainActivity : FlutterActivity() {
    private var pushCh: MethodChannel? = null
    private var pendingPush: MethodChannel.Result? = null
    private var pendingContact: MethodChannel.Result? = null
    private val main = Handler(Looper.getMainLooper())

    companion object {
        private const val REQ_PUSH = 7310
        private const val REQ_CONTACT = 7311
        private const val REQ_LIVE_NOTE = 7302
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val m = flutterEngine.dartExecutor.binaryMessenger
        val p = MethodChannel(m, "s360/push")
        p.setMethodCallHandler { c, r -> push(c, r) }
        pushCh = p
        MethodChannel(m, "s360/live").setMethodCallHandler { c, r -> live(c, r) }
        MethodChannel(m, "s360/native").setMethodCallHandler { c, r -> native(c, r) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        keepOpen(intent)
    }

    override fun onResume() {
        super.onResume()
        S360Notifier.foreground = true
    }

    override fun onPause() {
        super.onPause()
        S360Notifier.foreground = false
    }

    override fun onDestroy() {
        S360Notifier.foreground = false
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (keepOpen(intent)) {
            val sp = S360Notifier.prefs(this)
            val o = HashMap<String, String>()
            o["open"] = sp.getString("open", "") ?: ""
            o["sid"] = sp.getString("openSid", "") ?: ""
            try { pushCh?.invokeMethod("open", o) } catch (e: Exception) { }
        }
    }

    /** a notification was tapped: remember where it should take the person */
    private fun keepOpen(i: Intent?): Boolean {
        if (i == null || !i.hasExtra(S360Notifier.EXTRA_OPEN)) return false
        val open = i.getStringExtra(S360Notifier.EXTRA_OPEN) ?: ""
        val sid = i.getStringExtra(S360Notifier.EXTRA_SID) ?: ""
        i.removeExtra(S360Notifier.EXTRA_OPEN)
        S360Notifier.prefs(this).edit().putString("open", open).putString("openSid", sid).apply()
        return true
    }

    private fun granted(perm: String): Boolean =
        Build.VERSION.SDK_INT < 23 || checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

    /* ------------------------------------------------ push ------------------------------------------------ */

    private fun push(c: MethodCall, r: MethodChannel.Result) {
        when (c.method) {
            "register" -> {
                if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
                    pendingPush?.let { try { it.error("replaced", "Asked again", null) } catch (e: Exception) { } }
                    pendingPush = r
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_PUSH)
                } else {
                    token(r, true)
                }
            }
            "setAuth" -> {
                S360Notifier.prefs(this).edit()
                    .putString("server", c.argument<String>("server") ?: "")
                    .putString("device", c.argument<String>("device") ?: "")
                    .putString("key", c.argument<String>("key") ?: "")
                    .putString("sid", c.argument<String>("sid") ?: "")
                    .putString("uid", c.argument<String>("uid") ?: "")
                    .putString("name", c.argument<String>("name") ?: "")
                    .apply()
                r.success(null)
            }
            "clearAuth" -> {
                S360Notifier.prefs(this).edit().remove("device").remove("key").remove("uid").remove("name").apply()
                S360Notifier.cancelAll(this)
                r.success(null)
            }
            "takeOpen" -> {
                val sp = S360Notifier.prefs(this)
                val o = HashMap<String, String>()
                o["open"] = sp.getString("open", "") ?: ""
                o["sid"] = sp.getString("openSid", "") ?: ""
                sp.edit().remove("open").remove("openSid").apply()
                r.success(o)
            }
            "status" -> {
                val sp = S360Notifier.prefs(this)
                val o = HashMap<String, Any>()
                o["granted"] = Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS)
                var on = true
                try { on = NotificationManagerCompat.from(this).areNotificationsEnabled() } catch (e: Exception) { }
                o["enabled"] = on
                o["token"] = (sp.getString("token", "") ?: "").isNotEmpty()
                o["auth"] = (sp.getString("key", "") ?: "").isNotEmpty()
                r.success(o)
            }
            "clear" -> {
                S360Notifier.cancel(this, c.argument<String>("tag") ?: "")
                r.success(null)
            }
            else -> r.notImplemented()
        }
    }

    private fun token(r: MethodChannel.Result, ok: Boolean) {
        try {
            FirebaseMessaging.getInstance().token.addOnCompleteListener { t ->
                val tok = if (t.isSuccessful) t.result else null
                if (tok == null || tok.isEmpty()) {
                    r.error("no_token", "No push token on this phone right now", null)
                } else {
                    S360Notifier.prefs(this).edit().putString("token", tok).apply()
                    val o = HashMap<String, Any>()
                    o["token"] = tok
                    o["granted"] = ok
                    r.success(o)
                }
            }
        } catch (e: Exception) {
            r.error("unavailable", "Push notifications are not available in this build", null)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PUSH) {
            val r = pendingPush
            pendingPush = null
            if (r != null) token(r, grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)
        }
    }

    /* ------------------------------------------------ live location ------------------------------------------------ */

    private fun live(c: MethodCall, r: MethodChannel.Result) {
        when (c.method) {
            "start" -> {
                try {
                    if (!granted(Manifest.permission.ACCESS_FINE_LOCATION) && !granted(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                        r.error("perm", "Location permission is not granted", null)
                        return
                    }
                    val lid = c.argument<String>("lid") ?: ""
                    val until = (c.argument<String>("until") ?: "0").toLongOrNull() ?: 0L
                    if (lid.isEmpty() || until <= System.currentTimeMillis()) {
                        r.error("nothing", "Nothing to share", null)
                        return
                    }
                    val i = Intent(this, LiveLocationService::class.java)
                    i.action = "start"
                    for (k in LiveLocationService.KEYS) i.putExtra(k, c.argument<String>(k) ?: "")
                    i.putExtra("until", until)
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                    if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
                        try { requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_LIVE_NOTE) } catch (e: Exception) { }
                    }
                    val o = HashMap<String, Any>()
                    o["started"] = true
                    r.success(o)
                } catch (e: Exception) {
                    r.error("fail", e.message ?: "Could not start live location", null)
                }
            }
            "stop" -> {
                try {
                    val sp = getSharedPreferences(LiveLocationService.PREF, Context.MODE_PRIVATE)
                    if ((sp.getString("lid", "") ?: "").isNotEmpty()) {
                        val i = Intent(this, LiveLocationService::class.java)
                        i.action = "stop"
                        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                    }
                    r.success(null)
                } catch (e: Exception) {
                    r.error("fail", e.message ?: "Could not stop live location", null)
                }
            }
            "status" -> {
                val o = HashMap<String, Any>()
                var lid = ""
                var free = true
                try {
                    val sp = getSharedPreferences(LiveLocationService.PREF, Context.MODE_PRIVATE)
                    if (sp.getLong("until", 0) > System.currentTimeMillis()) lid = sp.getString("lid", "") ?: ""
                    if (Build.VERSION.SDK_INT >= 23) {
                        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager?
                        free = pm == null || pm.isIgnoringBatteryOptimizations(packageName)
                    }
                } catch (e: Exception) { }
                o["lid"] = lid
                o["unrestricted"] = free
                o["v"] = 2
                r.success(o)
            }
            "openSettings" -> {
                openAppSettings()
                r.success(null)
            }
            else -> r.notImplemented()
        }
    }

    private fun openAppSettings() {
        try {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) { }
    }

    /* ------------------------------------------------ contacts, files ------------------------------------------------ */

    private fun native(c: MethodCall, r: MethodChannel.Result) {
        when (c.method) {
            "pickContact" -> {
                try {
                    pendingContact?.let { try { it.success(hashMapOf("cancelled" to true)) } catch (e: Exception) { } }
                    pendingContact = r
                    startActivityForResult(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI), REQ_CONTACT)
                } catch (e: Exception) {
                    pendingContact = null
                    r.error("none", "No contacts app found", null)
                }
            }
            "saveFile" -> {
                val name = c.argument<String>("name") ?: "download"
                val mime = c.argument<String>("mime") ?: ""
                val bytes = c.argument<ByteArray>("bytes") ?: ByteArray(0)
                val ctx = applicationContext
                Thread {
                    try {
                        val res = S360Files.save(ctx, name, bytes, mime)
                        main.post { r.success(res) }
                    } catch (e: Exception) {
                        main.post { r.error("save", "The file could not be saved: " + (e.message ?: ""), null) }
                    }
                }.start()
            }
            "openFile" -> {
                try {
                    S360Files.open(this, c.argument<String>("uri") ?: "", c.argument<String>("mime") ?: "")
                    r.success(true)
                } catch (e: Exception) {
                    r.error("open", "No app on this phone can open this file", null)
                }
            }
            "openAppSettings" -> {
                openAppSettings()
                r.success(null)
            }
            "sdk" -> r.success(Build.VERSION.SDK_INT)
            else -> r.notImplemented()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CONTACT) return
        val r = pendingContact ?: return
        pendingContact = null
        val uri = data?.data
        if (resultCode != Activity.RESULT_OK || uri == null) {
            r.success(hashMapOf("cancelled" to true))
            return
        }
        var cur: Cursor? = null
        try {
            val cols = arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER)
            cur = contentResolver.query(uri, cols, null, null, null)
            var name = ""
            var phone = ""
            if (cur != null && cur.moveToFirst()) {
                name = cur.getString(0) ?: ""
                phone = cur.getString(1) ?: ""
            }
            r.success(hashMapOf("name" to name, "phone" to phone))
        } catch (e: Exception) {
            r.error("read", "Could not read the contact", null)
        } finally {
            try { cur?.close() } catch (e: Exception) { }
        }
    }
}
