import 'dart:async';
import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:http/http.dart' as http;

import 'kinds.dart';

/// An error the person can read (shown as a hint, not as a crash).
class AppError implements Exception {
  final String message;
  final String code;
  final int http;
  final bool net;
  final Map<String, dynamic> info;
  final bool soft;
  AppError(this.message, {this.code = '', this.http = 0, this.net = false, this.info = const {}, this.soft = true});
  @override
  String toString() => message;
}

AppError fxBad(String m) => AppError(m);

String apiBase() => payApi.replaceAll(RegExp(r'/+$'), '');

/// POST to the Sangam360 server with the signed-in person's token. A sleeping server can need a minute to answer.
Future<Map<String, dynamic>> api(String path, [Map<String, dynamic>? body, int ms = 90000]) async {
  if (payApi.isEmpty) throw AppError('Online payments are not switched on yet.');
  http.Response r;
  try {
    final u = FirebaseAuth.instance.currentUser;
    if (u == null) throw AppError('Please sign in again and try once more.');
    final t = await u.getIdToken();
    r = await http
        .post(Uri.parse(apiBase() + path), headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $t'}, body: jsonEncode(body ?? {}))
        .timeout(Duration(milliseconds: ms));
  } on AppError {
    rethrow;
  } catch (e) {
    throw AppError('Check your internet connection and try again.', net: true);
  }
  Map<String, dynamic>? j;
  try {
    final d = jsonDecode(utf8.decode(r.bodyBytes));
    if (d is Map<String, dynamic>) j = d;
  } catch (_) {}
  if (r.statusCode < 200 || r.statusCode >= 300 || j == null) {
    final er = (j?['error'] is Map) ? Map<String, dynamic>.from(j!['error'] as Map) : <String, dynamic>{};
    throw AppError((er['message'] ?? 'Something went wrong. Please try again.').toString(), code: (er['code'] ?? '').toString(), http: r.statusCode, info: er);
  }
  return j;
}

/// POST without a sign-in (forgot password)
Future<http.Response> apiOpen(String path, Map<String, dynamic> body) =>
    http.post(Uri.parse(apiBase() + path), headers: {'Content-Type': 'application/json'}, body: jsonEncode(body)).timeout(const Duration(seconds: 90));

/* On a small hosting plan the server sleeps when nobody uses it; it is nudged quietly so it is awake when someone taps Pay. */
int _warmAt = 0;
void payWarm() {
  final n = DateTime.now().millisecondsSinceEpoch;
  if (payApi.isEmpty || n - _warmAt < 240000) return;
  _warmAt = n;
  http.get(Uri.parse('${apiBase()}/healthz')).timeout(const Duration(seconds: 90)).catchError((_) {
    _warmAt = 0;
    return http.Response('', 0);
  });
}

/// a friendly message for any error
String fr(Object? e) {
  if (e is AppError) return e.message;
  if (e is FirebaseAuthException) {
    const m = {
      'invalid-credential': 'Wrong email or password.',
      'wrong-password': 'Wrong email or password.',
      'user-not-found': 'Wrong email or password.',
      'email-already-in-use': 'This email is already registered. Log in with it under the same type (society / corporate / school) you signed up with, or use a different email.',
      'weak-password': 'Password must be at least 6 characters.',
      'invalid-email': 'Please enter a valid email.',
      'too-many-requests': 'Too many tries. Wait a bit.',
      'network-request-failed': 'No internet connection. Please check and try again.',
    };
    return m[e.code] ?? (e.message ?? 'Something went wrong. Please try again.');
  }
  if (e is FirebaseException) {
    if (e.code == 'permission-denied') return 'Not allowed. Check the code or your permissions.';
    if (e.code == 'unavailable') return 'No internet connection. Please check and try again.';
    return e.message ?? 'Something went wrong. Please try again.';
  }
  if (e is TimeoutException) return 'This is taking too long. Check your internet and try again.';
  final s = e?.toString() ?? '';
  if (s.startsWith('Exception: ')) {
    final x = s.substring(11);
    if (x.length < 140) return x;
  }
  return s.isNotEmpty && s.length < 120 && !s.contains('Instance of') ? s : 'Something went wrong. Please try again.';
}

String errCode(Object? e) {
  if (e is AppError) return e.code;
  if (e is FirebaseException) return e.code;
  return '';
}
