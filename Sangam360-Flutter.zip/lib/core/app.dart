import 'dart:async';
import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';

import 'api.dart';
import 'files.dart';
import 'fs.dart';
import 'kinds.dart';
import 'listen.dart';
import 'live.dart';
import 'nav.dart';
import 'plan.dart';
import 'prefs.dart';
import 'push.dart';
import 'session.dart';
import 'store.dart';
import 'toast.dart';
import 'util.dart';

/// Signing in, finding the organisation and the member record, starting the main screen (boot of the earlier app).
class App {
  static StreamSubscription<User?>? _auth;
  static int _bootN = 0;
  static bool ggHold = false; // a Google sign-in is being checked: do not open the app yet
  static User? ggHeld;

  /// called when the main screen should (re)start: the shell listens to this
  static final List<void Function()> onStart = [];

  static void init() {
    _auth = FirebaseAuth.instance.authStateChanges().listen((u) {
      if (u == null) {
        bootDrop();
        Live.natStop();
        _waitOff();
        Kids.off();
        Listen.stop();
        S.user = null;
        S.uid = null;
        S.reset();
        if (S.authMsg.isNotEmpty) {
          S.go(Phase.auth);
        } else {
          S.go(Phase.land);
        }
        return;
      }
      if (ggHold) {
        ggHeld = u;
        return;
      }
      S.user = u;
      S.uid = u.uid;
      boot();
    });
    _acl = Timer.periodic(const Duration(seconds: 6), (_) => syncAcl());
    _pres = Timer.periodic(const Duration(seconds: 60), (_) {
      if (S.me != null && _fg) pset({});
    });
  }

  static Timer? _acl, _pres;
  static bool _fg = true;
  static void foreground(bool on) {
    _fg = on;
    pset({'seen': on ? now() : 0, 'typing': 0});
  }

  /* ---------- fast start ----------
     After a successful start the phone keeps the organisation and the member record (s360-boot). The next start opens
     the dashboard straight from it while the same records are read again in the background. */
  static dynamic _safe(dynamic v) {
    if (v == null || v is num || v is String || v is bool) return v;
    if (v is Map) return v.map((k, x) => MapEntry(k.toString(), _safe(x)));
    if (v is List) return v.map(_safe).toList();
    if (v is Timestamp) return v.millisecondsSinceEpoch;
    return null;
  }

  static Doc? bootGet() {
    final j = Prefs.json('s360-boot');
    return j is Map ? Map<String, dynamic>.from(j) : null;
  }

  static void bootSave() {
    try {
      if (S.uid != null && S.sid != null && S.soc != null && (S.prim ?? S.me) != null) {
        Prefs.set('s360-boot', jsonEncode(_safe({'uid': S.uid, 'sid': S.sid, 'me': S.prim ?? S.me, 'soc': S.soc, 'kids': S.kids, 'ts': now()})));
      }
    } catch (_) {}
  }

  static void bootDrop() => Prefs.del('s360-boot');

  static bool bootFast() {
    final c = bootGet();
    if (c == null || c['uid'] != S.uid || c['sid'] == null || c['me'] == null || c['soc'] == null || mapv(c['me'])['status'] != 'approved' || mapv(c['soc'])['active'] == false || S.loginKind != null || ggHold) return false;
    try {
      S.sid = str(c['sid']);
      S.soc = mapv(c['soc']);
      S.me = mapv(c['me']);
      S.prim = S.me;
      S.pid = S.uid;
      S.kids = listv(c['kids']).map(mapv).toList();
      if (str(S.soc!['type']) == 'school') {
        final want = Prefs.get('sh-pid-${S.sid}-${S.uid}');
        final k = S.kids.where((x) => x['id'] == want && x['status'] == 'approved');
        if (k.isNotEmpty) {
          S.me = {...k.first};
          S.pid = str(k.first['id']);
        }
      }
      S.setKind(str(S.soc!['type']).isEmpty ? 'society' : str(S.soc!['type']));
      checkSuper();
      startApp();
      Future.delayed(const Duration(milliseconds: 50), () => bootVerify(c));
      return true;
    } catch (_) {
      return false;
    }
  }

  static Future<void> bootVerify(Doc c) async {
    try {
      final r = await Future.wait([
        fs.collection('deletedUsers').doc(S.uid).get(),
        fs.collection('userSociety').doc(S.uid).get(),
        memRef(S.uid!, str(c['sid'])).get(),
        socRef(str(c['sid'])).get(),
      ]);
      if (S.sid != c['sid']) return;
      final tb = r[0], us = r[1], m = r[2], s = r[3];
      final md = m.exists ? m.data()! : null, sd = s.exists ? s.data()! : null;
      final cme = mapv(c['me']), csoc = mapv(c['soc']);
      final bad = tb.exists ||
          !us.exists ||
          us.data()!['societyId'] != c['sid'] ||
          md == null ||
          md['status'] != 'approved' ||
          sd == null ||
          sd['active'] == false ||
          (str(sd['type']).isEmpty ? 'society' : str(sd['type'])) != (str(csoc['type']).isEmpty ? 'society' : str(csoc['type'])) ||
          md['role'] != cme['role'] ||
          md['flat'] != cme['flat'];
      if (bad) {
        bootDrop();
        Listen.stop();
        S.reset();
        _bootN = 1;
        await boot();
        return;
      }
      (S.prim ?? S.me)!.addAll(md);
      S.soc!.addAll(sd);
      await Kids.load(keep: true);
      bootSave();
      S.touch();
    } catch (_) {/* offline */}
  }

  static Future<void> boot() async {
    _waitOff();
    if (++_bootN == 1 && bootFast()) return;
    try {
      S.waitTitle = 'Loading…';
      S.waitText = '';
      S.waitRetry = false;
      S.waitSwitch = false;
      S.go(Phase.wait);
      final r = await Future.wait([fs.collection('deletedUsers').doc(S.uid).get(), fs.collection('userSociety').doc(S.uid).get()]);
      final tb = r[0], us = r[1];
      if (tb.exists) {
        await fs.collection('userSociety').doc(S.uid).delete().catchError((_) {});
        try {
          await FirebaseAuth.instance.currentUser?.delete();
        } catch (_) {
          await FirebaseAuth.instance.signOut();
          toast('ℹ️', 'Account removed by admin', 'Please log in once more to finish, or sign up again.');
          return;
        }
        S.go(Phase.land);
        toast('🗑️', 'Account deleted by admin', 'You can no longer log in. Please sign up again to join.');
        return;
      }
      if (!us.exists || str(us.data()!['societyId']).isEmpty) {
        S.waitRetry = true;
        S.go(Phase.choice);
        return;
      }
      S.sid = str(us.data()!['societyId']);
      final sP = socRef(S.sid).get();
      final m = await memRef(S.uid!, S.sid).get();
      if (!m.exists) {
        S.go(Phase.choice);
        return;
      }
      S.me = m.data();
      socIds().then((x) {
        S.waitSwitch = x.$2.length >= 2 && S.me?['status'] != 'approved';
        S.touch();
      }).catchError((_) {});
      if (S.me!['status'] != 'approved' && S.loginKind != null) {
        try {
          final s0 = await sP;
          if (s0.exists && await kindGuard(str(s0.data()!['type']))) {
            S.me = null;
            S.sid = null;
            return;
          }
        } catch (_) {}
      }
      if (S.me!['status'] != 'approved') {
        final rej = S.me!['status'] == 'rejected';
        S.waitTitle = rej ? 'Request not approved' : 'Waiting for approval';
        S.waitText = rej ? 'Please contact your society admin.' : "Your society admin has been notified. You'll get access as soon as you're approved.";
        S.waitRetry = true;
        S.go(Phase.wait);
        _waitWatch();
        return;
      }
      final s = await sP;
      S.soc = s.data();
      if (S.soc == null) throw AppError("Couldn't load");
      if (await kindGuard(str(S.soc!['type']))) {
        S.me = null;
        S.soc = null;
        S.sid = null;
        return;
      }
      S.loginKind = null;
      S.setKind(str(S.soc!['type']).isEmpty ? 'society' : str(S.soc!['type']));
      checkSuper();
      if (S.soc!['active'] == false) {
        S.waitTitle = 'Society inactive';
        S.waitText = 'This society is currently suspended. Please contact support.';
        S.go(Phase.wait);
        return;
      }
      await Kids.load();
      bootSave();
      startApp();
    } catch (e) {
      S.waitTitle = "Couldn't load";
      S.waitText = 'Check your internet and tap Check again.';
      S.waitRetry = true;
      S.go(Phase.wait);
    }
  }

  /// One email can be used in only one of society / corporate / school.
  static Future<bool> kindGuard(String t) async {
    if (t.isEmpty) t = 'society';
    if (S.loginKind == null || t == S.loginKind || !kinds.containsKey(t)) return false;
    final w = kinds[t]!;
    S.authMsg = 'This email is already registered with a ${w.word} (${w.person} account). Please log in from "${w.card}". One email can be used in only one of society / corporate / school.';
    S.loginKind = null;
    await FirebaseAuth.instance.signOut();
    return true;
  }

  static Future<String> memCheck(String sid, String name) async {
    try {
      final m = await memRef(S.uid!, sid).get();
      if (!m.exists) return '';
      final st = m.data()!['status'];
      if (st == 'approved') return 'You are already a member of $name.';
      if (st == 'pending') return 'Your request to join $name is already pending. Please wait for the admin to approve you.';
    } catch (_) {}
    return '';
  }

  /* ---------- waiting for approval: the screen moves on by itself the moment the admin decides ---------- */
  static StreamSubscription? _wait;
  static void _waitOff() {
    _wait?.cancel();
    _wait = null;
  }

  static void _waitWatch() {
    _waitOff();
    if (S.sid == null || S.uid == null || S.me == null) return;
    final sid = S.sid, uid = S.uid, st0 = S.me!['status'];
    _wait = memRef(uid!, sid).snapshots().listen((s) {
      final st = s.exists ? s.data()!['status'] : '';
      if (st == st0 || S.sid != sid || S.uid != uid) return;
      _waitOff();
      if (S.phase != Phase.wait) return;
      if (st == 'approved') toast('✅', 'You are approved', 'Opening $brand…');
      boot();
    }, onError: (_) {});
  }

  /* ---------- multiple workspaces ---------- */
  static Future<(Doc, List<String>)> socIds() async {
    final us = await fs.collection('userSociety').doc(S.uid).get();
    final d = us.exists ? us.data()! : <String, dynamic>{};
    final ids = <String>{...strList(d['list']), if (str(d['societyId']).isNotEmpty) str(d['societyId'])}.toList();
    return (d, ids);
  }

  static Future<void> switchTo(String id) async {
    final wr = setDoc(fs.collection('userSociety').doc(S.uid), {'societyId': id}, merge: true);
    final r = await Future.wait([memRef(S.uid!, id).get(), socRef(id).get()]);
    final m = r[0], s = r[1];
    if (!m.exists || !s.exists) {
      wr.catchError((_) {});
      throw AppError("That workspace isn't available any more.");
    }
    final me = m.data()!, soc = s.data()!;
    Live.stop();
    Listen.stop();
    D.clearAll();
    nav.reset();
    if (me['status'] != 'approved' || soc['active'] == false) {
      await wr.catchError((_) {});
      S.reset();
      _bootN = 1;
      await boot();
      return;
    }
    wr.catchError((_) {});
    S.sid = id;
    S.me = me;
    S.soc = soc;
    S.loginKind = null;
    S.setKind(str(soc['type']).isEmpty ? 'society' : str(soc['type']));
    checkSuper();
    S.prim = null;
    await Kids.load();
    startApp();
    toast('✅', 'Switched to ${str(soc['name'])}');
  }

  static Future<void> checkSuper() async {
    try {
      S.isSuper = (await fs.collection('superadmins').doc(S.uid).get()).exists;
    } catch (_) {
      S.isSuper = false;
    }
  }

  /// who may switch schools: in a school only a Principal (or a Principal of another school)
  static String _swKey = '';
  static Future<void> swCheck() async {
    final k = '${S.sid}|${S.uid}';
    if (_swKey == k || S.sid == null || S.uid == null) return;
    _swKey = k;
    S.swAdm = false;
    if (!S.sch || S.isOwner) return;
    try {
      final ids = (await socIds()).$2.where((i) => i != S.sid).toList();
      if (ids.isEmpty) return;
      final R = await Future.wait(ids.map((i) => memRef(S.uid!, i).get().then((m) => m.exists ? m.data() : null).catchError((_) => null)));
      if (_swKey == k && R.any((m) => m != null && m['role'] == 'SOCIETY_ADMIN')) {
        S.swAdm = true;
        S.touch();
      }
    } catch (_) {}
  }

  /* ---------- start the main screen ---------- */
  /// the app came back to the screen
  static final List<void Function()> onResumeCbs = [];
  static void onResume() {
    if (S.me == null) return;
    Push.take();
    payWarm();
    for (final f in onResumeCbs) {
      try {
        f();
      } catch (_) {}
    }
  }

  static void startApp() {
    S.startN++;
    nav.reset();
    nav.homeAt = now();
    Listen.all();
    Kids.watch();
    for (final f in onStart) {
      try {
        f();
      } catch (_) {}
    }
    S.go(Phase.main);
    syncDirPhoto();
    ensureTCode();
    swCheck();
    PlanSt.ensure(() => D.bump('soc'));
    payWarm();
    pset({});
    Live.resume();
    Future.delayed(const Duration(milliseconds: 2500), () {
      Push.setup();
      Push.take();
    });
    if (S.kind == 'company' && S.isAdm && S.socGst().isEmpty) {
      Future.delayed(const Duration(milliseconds: 2500), () => toast('🧾', 'Add your GST number', 'Finance → GST number. It is printed on every invoice.'));
    }
  }

  /// my picture into the directory everyone reads (copied once from the sign-up photo)
  static Future<void> syncDirPhoto() async {
    if (S.pid != null && S.pid != S.uid) return;
    final ref = dref('directory', S.uid!);
    final o = <String, dynamic>{'uid': S.uid, 'name': S.me!['name'], 'flat': S.me!['flat'], 'role': S.me!['role']};
    try {
      var has = false;
      try {
        final d0 = await ref.get();
        has = d0.exists && okImg(d0.data()!['photo']);
      } catch (_) {}
      final ph = str(S.me!['photoUrl']);
      if (!has && isR(ph)) {
        try {
          final b = await refBytes(ph);
          o['photo'] = await up(b.$1, 'avatars', 'a.jpg');
        } catch (_) {}
      } else if (!has && okImg(ph)) {
        o['photo'] = ph;
      }
      await setDoc(ref, o, merge: true);
    } catch (_) {}
  }

  /// a teacher gets their own class code for students
  static Future<void> ensureTCode() async {
    if (!S.isTeacher || str(S.me!['code']).isNotEmpty) return;
    final cls = S.myCls;
    if (cls.isEmpty || cls == 'Teacher') return;
    for (var k = 0; k < 4; k++) {
      final code = genCode();
      try {
        final r = fs.collection('joinCodes').doc(code);
        if ((await r.get()).exists) continue;
        await setDoc(r, {
          'societyId': S.sid,
          'name': S.soc!['name'],
          'towers': [
            {'name': cls, 'floors': 1, 'perFloor': 1}
          ],
          'type': 'school',
          'teacherUid': S.uid,
          'teacherName': S.me!['name'],
          'cls': cls,
        });
        await updateDoc(memRef(S.uid!), {'code': code});
        S.me!['code'] = code;
        S.touch();
        return;
      } catch (_) {}
    }
  }

  /// presence: last seen, typing, poll votes, live location, birthday
  static void pset(Map<String, dynamic> o) {
    if (S.sid == null || S.uid == null || S.me == null) return;
    setDoc(dref('presence', S.uid!), {'uid': S.uid, 'name': S.me!['name'], 'seen': now(), ...o}, merge: true).catchError((_) {});
  }

  /* admin-managed access list so the database rules can limit who reads what */
  static String _aclSig = '';
  static bool _aclBusy = false;
  static Future<void> syncAcl() async {
    if (S.me == null || S.sid == null || !S.isMgr || _aclBusy) return;
    final ms = D['mem'].values.toList();
    if (ms.isEmpty) return;
    final sig = (ms.map((x) => '${x['id']}${x['role']}${x['status']}').toList()..sort()).join('|');
    if (sig == _aclSig) return;
    _aclBusy = true;
    try {
      final base = 'soc/${S.sid}';
      final db = rtdb;
      final oo = await db.ref('$base/owner').get();
      if (!oo.exists) {
        if (S.soc?['adminUid'] == S.uid) {
          await db.ref('$base/owner').set(S.uid);
        } else {
          return;
        }
      } else if (oo.value != S.uid) {
        return;
      }
      final r = await Future.wait([db.ref('$base/members').get(), db.ref('$base/admins').get()]);
      final mo = r[0].value is Map ? Map<String, dynamic>.from(r[0].value as Map) : <String, dynamic>{};
      final ao = r[1].value is Map ? Map<String, dynamic>.from(r[1].value as Map) : <String, dynamic>{};
      final wm = <String, bool>{}, wa = <String, bool>{}, upd = <String, Object?>{};
      for (final x in ms) {
        final id = str(x['id']);
        if (x['status'] == 'approved') {
          wm[id] = true;
          if (x['role'] == 'COMMITTEE_MEMBER' || x['role'] == 'SOCIETY_ADMIN') wa[id] = true;
        }
      }
      wm[S.uid!] = true;
      wa[S.uid!] = true;
      for (final k in {...mo.keys, ...wm.keys}) {
        if ((mo[k] == true) != (wm[k] == true)) upd['members/$k'] = wm[k] == true ? true : null;
      }
      for (final k in {...ao.keys, ...wa.keys}) {
        if ((ao[k] == true) != (wa[k] == true)) upd['admins/$k'] = wa[k] == true ? true : null;
      }
      if (upd.isNotEmpty) await db.ref(base).update(upd);
      _aclSig = sig;
    } catch (_) {
    } finally {
      _aclBusy = false;
    }
  }

  static Future<void> logout() async {
    try {
      await Push.off();
    } catch (_) {}
    try {
      await Live.stopAndWait();
    } catch (_) {}
    Listen.stop();
    D.clearAll();
    nav.reset();
    await FirebaseAuth.instance.signOut();
  }

  static void dispose() {
    _auth?.cancel();
    _acl?.cancel();
    _pres?.cancel();
  }
}

/* ---------- families: several students on one login (school) ---------- */
class Kids {
  static final List<StreamSubscription> _u = [];

  static Future<void> load({bool keep = false}) async {
    S.prim = S.prim != null && keep ? S.prim : S.me;
    if (!keep) {
      S.pid = S.uid;
      S.kids = [];
    }
    try {
      if (!(str(S.soc?['type']) == 'school' && S.isStu(S.prim))) return;
      final us = await fs.collection('userSociety').doc(S.uid).get();
      final ids = strList(mapv(us.exists ? us.data()!['kids'] : null)[S.sid]);
      final docs = await Future.wait(ids.map((id) => memRef(id).get().then<DocumentSnapshot<Map<String, dynamic>>?>((v) => v).catchError((_) => null)));
      S.kids = docs.where((d) => d != null && d.exists).map((d) => {...d!.data()!, 'id': d.id}).toList();
      if (!keep) {
        final want = Prefs.get('sh-pid-${S.sid}-${S.uid}');
        final k = S.kids.where((x) => x['id'] == want && x['status'] == 'approved');
        if (k.isNotEmpty) {
          S.me = {...k.first};
          S.pid = str(k.first['id']);
        }
      }
    } catch (_) {}
  }

  static void off() {
    for (final s in _u) {
      s.cancel();
    }
    _u.clear();
  }

  /// a student who is waiting for the class teacher becomes "approved" here the moment it happens
  static void watch() {
    off();
    if (!(S.sid != null && S.uid != null && S.soc != null && S.sch && S.prim != null && S.isStu(S.prim))) return;
    final sid = S.sid, uid = S.uid;
    for (final k0 in List.of(S.kids)) {
      final id = str(k0['id']);
      _u.add(memRef(id).snapshots().listen((s) {
        if (S.sid != sid || S.uid != uid) return;
        final i = S.kids.indexWhere((x) => x['id'] == id);
        if (i < 0) return;
        final was = S.kids[i];
        if (!s.exists) {
          S.kids.removeAt(i);
          if (S.pidv == id) {
            switchKid(uid!);
          } else {
            S.touch();
          }
          return;
        }
        final n = {...s.data()!, 'id': id};
        S.kids[i] = n;
        if (S.pidv == id && n['status'] != 'approved') {
          switchKid(uid!);
          return;
        }
        if (was['status'] == n['status'] && was['name'] == n['name'] && was['flat'] == n['flat'] && was['photoUrl'] == n['photoUrl']) return;
        if (was['status'] != n['status'] && n['status'] == 'approved') toast('✅', '${str(n['name']).isEmpty ? 'Student' : str(n['name'])} is approved', 'You can switch to this student now.', false);
        if (was['status'] != n['status'] && n['status'] == 'rejected') toast('⛔', '${str(n['name']).isEmpty ? 'Student' : str(n['name'])} was not approved', 'Please contact the class teacher.', false);
        S.touch();
      }, onError: (_) {}));
    }
  }

  static void switchKid(String id) {
    final k = id == S.uid ? S.prim : S.kids.where((x) => x['id'] == id).firstOrNull;
    if (k == null || k['status'] != 'approved' || id == S.pidv) return;
    Prefs.set('sh-pid-${S.sid}-${S.uid}', id);
    Listen.stop();
    D.clearAll();
    final me = {...k}..remove('id');
    S.me = me;
    S.pid = id;
    App.startApp();
    toast('✅', 'Switched to ${str(k['name'])}', str(k['flat']));
  }
}

/// Realtime Database root (kept for older records)
DatabaseReference rtRef(String p) => rtdb.ref(p);
