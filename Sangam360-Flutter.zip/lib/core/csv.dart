import 'dart:convert';
import 'dart:typed_data';

import 'files.dart';
import 'util.dart';

/// a spreadsheet file (CSV, opens in Excel / Google Sheets) saved into Downloads › Sangam360
Future<void> exportCSV(String name, List<String> head, List<List<dynamic>> rows, {bool raw = false}) async {
  String q(dynamic x) => '"${(x == null ? '' : x.toString()).replaceAll('"', '""')}"';
  final csv = [head, ...rows].map((r) => r.map(q).join(',')).join('\n');
  final bytes = Uint8List.fromList([0xEF, 0xBB, 0xBF, ...utf8.encode(csv)]);
  await saveBytes('$name${raw ? '' : '-${td()}'}.csv', bytes, 'text/csv');
}

/// "5 Oct 2026, 09:30 am" for spreadsheets
String csvTime(dynamic t) => intv(t) > 0 ? dtm(t) : '';
