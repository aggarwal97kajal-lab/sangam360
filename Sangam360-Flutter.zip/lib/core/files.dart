import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

import 'api.dart';
import 'img.dart';
import 'kinds.dart';
import 'native.dart';
import 'session.dart';
import 'toast.dart';
import 'util.dart';
import '../l10n/l10n.dart';

/* ===== file storage =====
   Files are kept in Cloudflare R2. The app never holds the R2 keys: it sends a file to the server (/v1/files/upload),
   which checks it and stores it, and writes "r2:<place>" into Firestore. To open a file it asks the server for a
   short-lived link (several files in one request). Older files say "rtdb:<place>": they were kept in the Realtime
   Database. While the server has no R2 set up, new files still go to the Realtime Database, so nothing stops. */

FirebaseDatabase get rtdb => FirebaseDatabase.instanceFor(app: Firebase.app(), databaseURL: rtdbUrl);

bool isR(String? p) => p != null && (p.startsWith('rtdb:') || p.startsWith('r2:'));
bool okU(String? p) => p != null && (p.startsWith('https://firebasestorage.googleapis.com/') || p.startsWith('rtdb:files/') || p.startsWith('rtdb:idfiles/') || p.startsWith('r2:files/') || p.startsWith('r2:idfiles/'));
bool okImg(dynamic p) => p is String && (p.startsWith('data:image/') || okU(p));
bool okAud(dynamic p) => p is String && (p.startsWith('data:audio/') || okU(p));
bool okData(dynamic p) => p is String && p.startsWith('data:');

class Up {
  /// the upload in progress, for a status line ("Uploading… 42%")
  static final ValueNotifierInt progress = ValueNotifierInt();
}

class ValueNotifierInt {
  final List<void Function(String label, int pct)> _l = [];
  void listen(void Function(String, int) f) => _l.add(f);
  void unlisten(void Function(String, int) f) => _l.remove(f);
  void emit(String label, int pct) {
    for (final f in List.of(_l)) {
      f(label, pct);
    }
  }
}

bool _r2Off = false;
void _r2Pause() {
  _r2Off = true;
  Timer(const Duration(minutes: 10), () => _r2Off = false);
}

/// sends one file to the server with real progress; resolves to "r2:<place>"
Future<String> _r2Put(String path, Uint8List bytes, String mime, String? name, void Function(int)? onp) async {
  final u = FirebaseAuth.instance.currentUser;
  final tok = u == null ? null : await u.getIdToken();
  if (tok == null) throw AppError(tr('Please sign in again and try once more.'));
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 60);
  try {
    final req = await client.postUrl(Uri.parse('${apiBase()}/v1/files/upload?path=${Uri.encodeComponent(path)}'));
    req.headers.set('Authorization', 'Bearer $tok');
    req.headers.set('Content-Type', mime.isEmpty ? 'application/octet-stream' : mime);
    if (name != null && name.isNotEmpty) req.headers.set('X-File-Name', Uri.encodeComponent(cut(name, 100)));
    req.contentLength = bytes.length;
    const chunk = 32 * 1024;
    for (var i = 0; i < bytes.length; i += chunk) {
      req.add(bytes.sublist(i, i + chunk > bytes.length ? bytes.length : i + chunk));
      await req.flush().timeout(const Duration(seconds: 75), onTimeout: () => throw AppError(tr('Upload stopped: the internet is too slow or was lost. Please try again on a better connection.')));
      onp?.call(((i + chunk) / bytes.length * 100).clamp(0, 99).round());
    }
    final res = await req.close().timeout(const Duration(seconds: 150));
    final text = await res.transform(utf8.decoder).join();
    Map<String, dynamic>? j;
    try {
      final d = jsonDecode(text);
      if (d is Map<String, dynamic>) j = d;
    } catch (_) {}
    if (res.statusCode >= 200 && res.statusCode < 300 && j != null && j['ref'] != null) {
      onp?.call(100);
      return j['ref'].toString();
    }
    final er = j?['error'] is Map ? Map<String, dynamic>.from(j!['error'] as Map) : <String, dynamic>{};
    if ((res.statusCode == 412 && er['code'] == 'storage-not-configured') || (res.statusCode == 404 && er['code'] == 'not-found')) {
      throw AppError(str(er['message']).isEmpty ? tr('No file storage') : str(er['message']), code: 'r2off');
    }
    throw AppError(str(er['message']).isEmpty ? trf('Upload failed ({0}). Please try again.', [res.statusCode]) : str(er['message']));
  } on SocketException {
    throw AppError(tr('Upload failed: check your internet connection and try again.'));
  } on TimeoutException {
    throw AppError(tr('Upload timed out — please check your internet and try again.'));
  } finally {
    client.close(force: false);
  }
}

/// puts a file in its place: Cloudflare R2, or the Realtime Database while the server has no R2
Future<String> storeFile(String path, Uint8List bytes, String mime, {String label = 'Uploading', String? name}) async {
  void onp(int p) => Up.progress.emit(label, p);
  if (payApi.isNotEmpty && !_r2Off) {
    payWarm();
    onp(0);
    try {
      final r = await _r2Put(path, bytes, mime, name, onp);
      Up.progress.emit('', -1);
      return r;
    } on AppError catch (e) {
      Up.progress.emit('', -1);
      if (e.code != 'r2off') rethrow;
      _r2Pause();
    }
  }
  try {
    onp(10);
    await rtdb.ref(path).set(toDataUrl(bytes, mime)).timeout(Duration(milliseconds: 60000 + (bytes.length ~/ 1000000) * 45000));
    Up.progress.emit('', -1);
  } catch (e) {
    Up.progress.emit('', -1);
    final m = e.toString();
    if (RegExp('PERMISSION_DENIED|permission', caseSensitive: false).hasMatch(m)) {
      throw AppError(tr('Upload not allowed yet. If you were just approved, ask your admin to open the app once, then try again.'));
    }
    if (e is TimeoutException) throw AppError(tr('Upload timed out — please check your internet and try again.'));
    rethrow;
  }
  return 'rtdb:$path';
}

/// a file of the app: images are made smaller first; kind = avatars, chat, docs, voice, billdocs, helpers, classifieds, drv
Future<String> up(Uint8List bytes, String kind, String name, {bool raw = false, String? mime}) async {
  if (S.sid == null || S.uid == null) throw AppError(tr('Please sign in to a society first.'));
  var b = bytes;
  var mt = mime ?? mimeOf(name, b);
  if (!raw && mt.startsWith('image/') && (b.length > 200 * 1024 || kind == 'avatars')) {
    try {
      b = await shrink(b, kind == 'avatars' ? 320 : kind == 'helpers' ? 480 : 1024, .7);
      mt = 'image/jpeg';
    } catch (_) {}
  }
  final isImg = mt.startsWith('image/');
  final cap = kind == 'voice'
      ? 2 * 1048576
      : (kind == 'docs' || kind == 'billdocs' || kind == 'drv')
          ? 5 * 1048576
          : 480 * 1024;
  if (b.length > cap) throw AppError(isImg ? tr('This photo is too large. Please choose a smaller one.') : trf('File is too large (max {0} MB).', [cap ~/ 1048576]));
  final path = 'files/${S.sid}/$kind/${S.uid}/${DateTime.now().millisecondsSinceEpoch.toRadixString(36)}${rid().substring(rid().length - 6)}';
  return storeFile(path, b, mt, label: kind == 'voice' ? tr('Sending voice note') : tr('Uploading'), name: name);
}

/// ID proof / photo of a person joining (idfiles/<sid>/<uid>/proof|photo[_k2])
Future<String> upID(String sid, Uint8List bytes, String name, String kind, {bool sq = false, String sfx = ''}) async {
  final pdf = sniff(bytes) == 'pdf' || name.toLowerCase().endsWith('.pdf');
  Uint8List d;
  String mt;
  if (pdf) {
    if (bytes.length > 5 * 1048576) throw AppError(tr('PDF is too large (max 5 MB). Please upload a photo of the ID instead.'));
    d = bytes;
    mt = 'application/pdf';
  } else {
    try {
      if (kind == 'idproofs') {
        d = await imgToPdf(bytes, maxSide: 1100, q: .65);
        mt = 'application/pdf';
      } else {
        d = await shrink(bytes, sq ? 400 : 1100, sq ? .7 : .65, sq: sq);
        mt = 'image/jpeg';
      }
    } catch (_) {
      throw AppError(tr("Couldn't read this image. Please use a JPG/PNG photo or a PDF."));
    }
  }
  if (d.length > (sq ? 290000 : 5200000)) throw AppError(tr('File is too large. Please choose a smaller one.'));
  final path = 'idfiles/$sid/${S.uid}/${kind == 'idphotos' ? 'photo' : 'proof'}$sfx';
  return storeFile(path, d, mt, label: sq ? tr('Uploading photo') : tr('Uploading ID'));
}

/* ---------- opening files ---------- */
class FileLink {
  final String? url;
  final Uint8List? bytes;
  final String type;
  final int until;
  const FileLink({this.url, this.bytes, this.type = '', this.until = 0});
}

final Map<String, FileLink> _rc = {};
final Map<String, Future<FileLink>> _rp = {};
final Map<String, List<Completer<Map<String, dynamic>?>>> _rxQ = {};
Timer? _rxT;

Future<Map<String, dynamic>?> _r2Link(String p) {
  final c = Completer<Map<String, dynamic>?>();
  (_rxQ[p] ??= []).add(c);
  _rxT ??= Timer(const Duration(milliseconds: 25), _rxFlush);
  return c.future;
}

Future<void> _rxFlush() async {
  _rxT = null;
  final q = Map.of(_rxQ);
  _rxQ.clear();
  final refs = q.keys.toList();
  for (var i = 0; i < refs.length; i += 40) {
    final part = refs.sublist(i, i + 40 > refs.length ? refs.length : i + 40);
    Map<String, dynamic>? r;
    Object? err;
    try {
      r = await api('/v1/files/url', {'refs': part}, 90000);
    } catch (e) {
      err = e;
      if (e is AppError && (e.code == 'storage-not-configured' || (e.http == 404 && e.code == 'not-found'))) _r2Pause();
    }
    for (final p in part) {
      final a = r == null ? null : mapv(mapv(r['files'])[p]);
      for (final c in q[p]!) {
        if (a != null && a.isNotEmpty) {
          c.complete(a);
        } else {
          c.completeError(err ?? AppError(tr('File not found')));
        }
      }
    }
  }
}

Future<FileLink?> _rtFile(String p) async {
  final v = (await rtdb.ref(p.substring(5)).get()).value;
  if (v is! String) return null;
  final b = fromDataUrl(v);
  if (b == null) return null;
  return FileLink(bytes: b, type: dataUrlMime(v));
}

Future<FileLink> _rsv0(String p) async {
  final r2 = p.startsWith('r2:');
  if (payApi.isNotEmpty && (r2 || !_r2Off)) {
    final link = _r2Link(p);
    Map<String, dynamic>? a;
    if (!r2) {
      // an old file: if the server is slow to wake, the Realtime Database is tried meanwhile
      final first = await Future.any<Object?>([link.then<Object?>((v) => v).catchError((_) => null), Future<Object?>.delayed(const Duration(seconds: 8), () => 0)]);
      if (first == 0) {
        final x = await _rtFile(p).catchError((_) => null);
        if (x != null) return x;
        a = await link.catchError((_) => null);
      } else {
        a = first is Map<String, dynamic> ? first : null;
      }
    } else {
      a = await link;
    }
    if (a != null && a['url'] != null) return FileLink(url: str(a['url']), type: str(a['type']), until: intv(a['until']));
    if (r2) throw AppError(a != null && a['error'] == 'forbidden' ? tr('You cannot open this file.') : tr('File not found'));
  }
  if (r2) throw AppError(tr('File not available right now. Please try again.'));
  final x = await _rtFile(p);
  if (x == null) throw AppError(tr('File not found'));
  return x;
}

/// the link (or the bytes) of a stored file; data: and https: addresses are passed through
Future<FileLink> resolveRef(String p) {
  if (p.startsWith('data:')) return Future.value(FileLink(bytes: fromDataUrl(p), type: dataUrlMime(p)));
  if (!isR(p)) return Future.value(FileLink(url: p));
  final c = _rc[p];
  if (c != null && (c.until == 0 || c.until > DateTime.now().millisecondsSinceEpoch + 120000)) return Future.value(c);
  final w = _rp[p];
  if (w != null) return w;
  final f = _rsv0(p).then((x) {
    _rc[p] = x;
    _rp.remove(p);
    return x;
  }).catchError((Object e) {
    _rp.remove(p);
    throw e;
  });
  _rp[p] = f;
  return f;
}

/// the bytes of a stored file
Future<(Uint8List, String)> refBytes(String p) async {
  final l = await resolveRef(p);
  if (l.bytes != null) return (l.bytes!, l.type);
  final r = await http.get(Uri.parse(l.url!)).timeout(const Duration(seconds: 90));
  if (r.statusCode != 200) throw AppError(tr("Couldn't open file"));
  return (r.bodyBytes, l.type.isNotEmpty ? l.type : (r.headers['content-type'] ?? ''));
}

/// deletes a file wherever it is: the server checks that it is the uploader's own (or that an admin asks)
void dropFile(dynamic p) {
  if (p is! String || !isR(p)) return;
  if (payApi.isNotEmpty) api('/v1/files/delete', {'ref': p}).catchError((_) => <String, dynamic>{});
  if (p.startsWith('rtdb:')) rtdb.ref(p.substring(5)).remove().catchError((_) {});
}

void rmFile(dynamic p) {
  if (p is String && isR(p) && RegExp(r'^(rtdb|r2):files/').hasMatch(p)) dropFile(p);
}

/* ---------- saving into Downloads/Sangam360 ---------- */
Future<void> saveBytes(String name, Uint8List bytes, String mime, {bool quiet = false}) async {
  try {
    if (await Native.sdk() < 29) {
      final st = await Permission.storage.request();
      if (!st.isGranted) {
        toast('⚠️', tr('Storage access is needed'), tr('Allow it to save files on this phone.'));
        return;
      }
    }
    final r = await Native.saveFile(name, bytes, mime);
    if (r != null) {
      final uri = str(r['uri']);
      toast('✅', tr('Download complete'), trf('{0} · Downloads › Sangam360', [str(r['name'])]));
      if (uri.isNotEmpty) {
        Toasts.I.stickLast(() => Native.openFile(uri, mime).catchError((_) => toast('⚠️', tr('No app can open this file'), tr('Install a PDF or file viewer and try again.'))), 8000);
      }
    }
  } catch (e) {
    fail(e, tr('Could not save the file'));
  }
}

/// a temporary file (for sharing to another app)
Future<File> tempFile(String name, Uint8List bytes) async {
  final d = await getTemporaryDirectory();
  final f = File('${d.path}/${name.replaceAll(RegExp(r'[\\/:*?"<>|]+'), '_')}');
  await f.writeAsBytes(bytes, flush: true);
  return f;
}
