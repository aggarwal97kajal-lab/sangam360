import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';

import 'api.dart';
import 'session.dart';
import 'store.dart';

final fs = FirebaseFirestore.instance;
typedef DocRef = DocumentReference<Map<String, dynamic>>;
typedef ColRef = CollectionReference<Map<String, dynamic>>;
typedef Q = Query<Map<String, dynamic>>;

ColRef col(String n) => fs.collection('societies').doc(S.sid).collection(n);
DocRef dref(String n, String id) => col(n).doc(id);
DocRef socRef([String? sid]) => fs.collection('societies').doc(sid ?? S.sid);
DocRef memRef(String id, [String? sid]) => fs.collection('societies').doc(sid ?? S.sid).collection('members').doc(id);

Doc withId(DocumentSnapshot<Map<String, dynamic>> d) => {...?d.data(), 'id': d.id};
List<Doc> docsOf(QuerySnapshot<Map<String, dynamic>> s) => s.docs.map((d) => {...d.data(), 'id': d.id}).toList();

/* ===== push notifications =====
   After the app writes something other people should hear about (a chat message, a notice, a visitor at the gate,
   a bill ...), it names that record to the server (/v1/push/event). The server reads the record itself, decides who is
   told and sends the notification through Firebase Cloud Messaging, also to phones where the app is closed. */
final _pushC = RegExp(r'^societies/[^/]+/(messages|announcements|alerts|complaints|gcomplaints|visitors|deliveries|bills|members|leaves|holidays|vehicles|tasks|payslips|drvmsg|buses|busmap|busissues|businc|busveh)/[^/]+$|^societies/[^/]+/dmchats/[^/]+/messages/[^/]+$');
final List<String> _pushQ = [];
Timer? _pushT;
final Map<String, int> _busPT = {};
final Map<String, Timer?> _busPW = {};

void pushPing(String? p) {
  if (p == null || !_pushC.hasMatch(p)) return;
  if (p.contains('/buses/')) {
    final n = DateTime.now().millisecondsSinceEpoch, t = _busPT[p];
    if (t != null && n - t < 20000) {
      _busPW[p] ??= Timer(Duration(milliseconds: 20000 - (n - t)), () {
        _busPW[p] = null;
        pushPing(p);
      });
      return;
    }
    _busPT[p] = n;
  }
  _pushQ.add(p);
  _pushT ??= Timer(const Duration(milliseconds: 500), _pushFlush);
}

void _pushFlush() {
  _pushT = null;
  final q = _pushQ.toSet().toList();
  _pushQ.clear();
  final by = <String, List<String>>{};
  for (final p in q) {
    (by[p.split('/')[1]] ??= []).add(p);
  }
  by.forEach((sid, l) {
    for (var i = 0; i < l.length; i += 25) {
      api('/v1/push/event', {'sid': sid, 'paths': l.sublist(i, i + 25 > l.length ? l.length : i + 25)}, 90000).catchError((_) => <String, dynamic>{});
    }
  });
}

Future<DocRef> addDoc(ColRef c, Map<String, dynamic> data) async {
  final r = await c.add(data);
  pushPing(r.path);
  return r;
}

Future<void> setDoc(DocRef r, Map<String, dynamic> data, {bool merge = false}) async {
  await r.set(data, merge ? SetOptions(merge: true) : null);
  pushPing(r.path);
}

Future<void> updateDoc(DocRef r, Map<String, dynamic> data) async {
  await r.update(data);
  pushPing(r.path);
}

Future<void> delDoc(DocRef r) => r.delete();

/// a batch that names its records to the push server after it is written
class Batch {
  final WriteBatch _b = fs.batch();
  final List<String> _p = [];
  void set(DocRef r, Map<String, dynamic> d, {bool merge = false}) {
    _p.add(r.path);
    _b.set(r, d, merge ? SetOptions(merge: true) : null);
  }

  void update(DocRef r, Map<String, dynamic> d) {
    _p.add(r.path);
    _b.update(r, d);
  }

  void delete(DocRef r) => _b.delete(r);
  Future<void> commit() async {
    await _b.commit();
    _p.forEach(pushPing);
  }
}

/// save without hanging forever: rejects on real errors, continues after 8 s if only the network is slow
/// (the write is queued on the phone and syncs later). onQueued is told when that happens.
Future<DocRef> saveDoc(ColRef c, Map<String, dynamic> data, {void Function()? onQueued}) async {
  final r = c.doc();
  final f = r.set(data).then((_) => pushPing(r.path));
  try {
    await f.timeout(const Duration(seconds: 8));
  } on TimeoutException {
    onQueued?.call();
  }
  return r;
}
