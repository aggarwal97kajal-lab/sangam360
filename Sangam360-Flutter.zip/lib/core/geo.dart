import 'dart:async';
import 'dart:convert';

import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

import 'api.dart';
import 'perms.dart';
import 'prefs.dart';
import 'store.dart';
import 'util.dart';

/* ===== places, distances and the school bus helpers ===== */

const busKmh = 22; // average city speed used for "minutes away"
const busZnear = 1.0, busZappr = .4, busZarr = .12, busSlow = 4.2; // zones in km; "arrived" needs the bus to be slow (m/s) or to stay

double busKm(num a, num b, num c, num d) => haversineKm(a.toDouble(), b.toDouble(), c.toDouble(), d.toDouble());

/// "28.7041, 77.1025" or a Google Maps link -> (lat, lng)
({double lat, double lng})? busParse(String s) {
  final res = [RegExp(r'!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)'), RegExp(r'[?&](?:q|ll|query|destination)=(-?\d+\.\d+)(?:,|%2C)\s*(-?\d+\.\d+)', caseSensitive: false), RegExp(r'@(-?\d+\.\d+),(-?\d+\.\d+)'), RegExp(r'^\s*(-?\d+(?:\.\d+)?)\s*[, ]\s*(-?\d+(?:\.\d+)?)\s*$')];
  for (final re in res) {
    final m = re.firstMatch(s);
    if (m != null) {
      final lat = double.parse(m.group(1)!), lng = double.parse(m.group(2)!);
      if (lat.abs() <= 90 && lng.abs() <= 180 && (lat != 0 || lng != 0)) return (lat: fix6(lat), lng: fix6(lng));
      return null;
    }
  }
  return null;
}

/// the live position of a running bus trip (null when not live)
Doc? busLive(Doc? x) {
  if (x == null) return null;
  final l = mapv(x['live']);
  return x['on'] == true && intv(x['until']) > now() && l.isNotEmpty && l['lid'] == x['lid'] && intv(l['end']) == 0 && l['lat'] != null ? l : null;
}

bool busOn(Doc? x) => x != null && x['on'] == true && intv(x['until']) > now();
String busDirL(String? d) => d == 'pm' ? 'Evening · from school' : 'Morning · to school';
String busFmt(double km) => km < 1 ? '${((km * 100).round() * 10).clamp(10, 1000)} m' : '${km.toStringAsFixed(1)} km';
int busEta(double km) => (km / busKmh * 60).round().clamp(1, 100000);
int busArr(Doc? x, String k) {
  final t = intv(mapv(x?['arr'])[k]);
  return t >= intv(x?['startTs']) ? t : 0;
}

String busPkTxt(Doc? p) => p != null && p['lat'] != null ? '${str(p['a']).isNotEmpty ? '${str(p['a'])} · ' : ''}${numv(p['lat']).toStringAsFixed(4)}, ${numv(p['lng']).toStringAsFixed(4)}' : '';
int busDur(Doc t) {
  final e = intv(t['end']) > 0 ? intv(t['end']) : (intv(t['until']) > 0 && intv(t['until']) < now() ? intv(t['until']) : 0);
  return e > 0 ? (e - intv(t['start'])).clamp(0, 1 << 40) : 0;
}

String busHrs(int ms) {
  final m = (ms / 60000).round();
  return '${m ~/ 60} h ${(m % 60).toString().padLeft(2, '0')} min';
}

/// my position: [fresh] = not one the phone kept from earlier
Future<Position> here({bool fresh = false}) async {
  if (!await Geolocator.isLocationServiceEnabled()) throw AppError("Couldn't get your location. Turn on GPS and try again.");
  if (!await askPerm('loc')) throw AppError('Location permission is needed for this.');
  try {
    if (!fresh) {
      final l = await Geolocator.getLastKnownPosition();
      if (l != null && now() - l.timestamp.millisecondsSinceEpoch < 15000) return l;
    }
    return await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 20)));
  } catch (_) {
    if (fresh) return here();
    throw AppError("Couldn't get your location. Turn on GPS and try again.");
  }
}

/* ---------- places: search, nearby, the address of a point (Photon, then Nominatim) ---------- */
class Place {
  final String name, sub;
  final double lat, lng;
  double? km;
  int i = 0;
  Place(this.name, this.sub, this.lat, this.lng, {this.km});
  Map<String, dynamic> toJson() => {'name': name, 'sub': sub, 'lat': lat, 'lng': lng};
}

Future<dynamic> _get(String u) async {
  final r = await http.get(Uri.parse(u), headers: {'Accept': 'application/json', 'User-Agent': 'Sangam360-app/2.0 (com.sangam360.app)'}).timeout(const Duration(seconds: 9));
  if (r.statusCode != 200) throw Exception('search ${r.statusCode}');
  return jsonDecode(utf8.decode(r.bodyBytes));
}

Place? _prop(dynamic f) {
  final p = mapv(mapv(f)['properties']);
  final g = listv(mapv(mapv(f)['geometry'])['coordinates']);
  if (g.length < 2) return null;
  var n = str(p['name']);
  if (n.isEmpty) n = [str(p['housenumber']), str(p['street'])].where((x) => x.isNotEmpty).join(' ');
  if (n.isEmpty) n = str(p['locality'] ?? p['district'] ?? p['city']);
  final parts = <String>[];
  for (final x in [p['street'] != n ? str(p['street']) : '', str(p['locality']), str(p['district']), p['city'] != n ? str(p['city']) : '', str(p['state'])]) {
    if (x.isNotEmpty && x != n && !parts.contains(x)) parts.add(x);
  }
  return Place(n, parts.take(4).join(', '), numv(g[1]).toDouble(), numv(g[0]).toDouble());
}

Future<List<Place>> lpkFind(String q, {({double lat, double lng})? near}) async {
  var out = <Place>[];
  try {
    final j = await _get('https://photon.komoot.io/api/?limit=8&lang=en&q=${Uri.encodeComponent(q)}${near != null ? '&lat=${near.lat}&lon=${near.lng}&zoom=12&location_bias_scale=0.1' : ''}');
    out = listv(mapv(j)['features']).map(_prop).whereType<Place>().where((r) => r.name.isNotEmpty).toList();
  } catch (_) {}
  if (out.isEmpty) {
    try {
      final j = await _get('https://nominatim.openstreetmap.org/search?format=jsonv2&limit=8&q=${Uri.encodeComponent(q)}${near != null ? '&viewbox=${near.lng - .4},${near.lat + .4},${near.lng + .4},${near.lat - .4}' : ''}');
      out = listv(j).map((r0) {
        final r = mapv(r0);
        final d = str(r['display_name']).split(',').map((s) => s.trim()).toList();
        return Place(str(r['name']).isNotEmpty ? str(r['name']) : d.first, d.skip(1).take(3).join(', '), numv(r['lat']).toDouble(), numv(r['lon']).toDouble());
      }).where((r) => r.name.isNotEmpty).toList();
    } catch (_) {}
  }
  if (near != null) {
    for (var i = 0; i < out.length; i++) {
      out[i].km = busKm(near.lat, near.lng, out[i].lat, out[i].lng);
      out[i].i = i;
    }
    double key(Place r) => r.km! <= 3 ? r.km! : 1000 + r.i.toDouble();
    out.sort((a, b) => key(a).compareTo(key(b)));
  }
  return out;
}

final Map<String, List<Place>> _nc = {};
Future<List<Place>> lpkNear(double lat, double lng) async {
  final k = '${lat.toStringAsFixed(4)},${lng.toStringAsFixed(4)}';
  if (_nc[k] != null) return _nc[k]!;
  var out = <Place>[];
  try {
    final j = await _get('https://photon.komoot.io/reverse?lang=en&limit=12&radius=0.4&lat=$lat&lon=$lng');
    final seen = <String>{};
    out = listv(mapv(j)['features']).map(_prop).whereType<Place>().where((r) => r.name.isNotEmpty && seen.add(r.name.toLowerCase())).toList();
    for (final r in out) {
      r.km = busKm(lat, lng, r.lat, r.lng);
    }
    out = out.where((r) => r.km! <= .45).toList()..sort((a, b) => a.km!.compareTo(b.km!));
    out = out.take(8).toList();
  } catch (_) {}
  if (out.isNotEmpty) _nc[k] = out;
  return out;
}

final Map<String, Place?> _rc = {};
Future<Place?> lpkRev(double lat, double lng) async {
  final k = '${lat.toStringAsFixed(4)},${lng.toStringAsFixed(4)}';
  if (_rc.containsKey(k)) return _rc[k];
  Place? r;
  try {
    final j = await _get('https://photon.komoot.io/reverse?lang=en&limit=1&lat=$lat&lon=$lng');
    final f = listv(mapv(j)['features']);
    if (f.isNotEmpty) {
      final v = _prop(f.first);
      if (v != null && v.name.isNotEmpty) r = Place(v.name, v.sub, lat, lng);
    }
  } catch (_) {}
  if (r == null) {
    try {
      final j = mapv(await _get('https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=18&lat=$lat&lon=$lng'));
      if (str(j['display_name']).isNotEmpty) {
        final d = str(j['display_name']).split(',').map((s) => s.trim()).toList();
        r = Place(str(j['name']).isNotEmpty ? str(j['name']) : d.first, d.skip(1).take(3).join(', '), lat, lng);
      }
    } catch (_) {}
  }
  if (r != null) _rc[k] = r;
  return r;
}

/// places chosen before, kept on this phone only
List<Place> lpkRecent() {
  final a = Prefs.json('sh-places');
  if (a is! List) return [];
  return a.map(mapv).where((p) => str(p['name']).isNotEmpty && p['lat'] != null).map((p) => Place(str(p['name']), str(p['sub']), numv(p['lat']).toDouble(), numv(p['lng']).toDouble())).toList();
}

void lpkRemember(Place p) {
  if (p.name.isEmpty) return;
  final a = lpkRecent().where((q) => busKm(q.lat, q.lng, p.lat, p.lng) > .05).toList();
  a.insert(0, p);
  Prefs.setJson('sh-places', a.take(6).map((x) => x.toJson()).toList());
}
