import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/services.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

/* ---------- pictures: smaller, square, as a one-page PDF ---------- */

Future<ui.Image> decodeImg(Uint8List b) async {
  final c = await ui.instantiateImageCodec(b);
  final f = await c.getNextFrame();
  return f.image;
}

Future<Uint8List> _jpeg(Uint8List src, int minW, int minH, int q) async {
  final r = await FlutterImageCompress.compressWithList(src, minWidth: max(1, minW), minHeight: max(1, minH), quality: q, format: CompressFormat.jpeg);
  return r;
}

/// a JPEG whose sides are about [maxSide] at most; [sq] cuts the middle square out first
Future<Uint8List> shrink(Uint8List bytes, int maxSide, double q, {bool sq = false}) async {
  final quality = (q * 100).round().clamp(10, 100);
  if (!sq) {
    try {
      final im = await decodeImg(bytes);
      final w = im.width, h = im.height;
      im.dispose();
      final s = min(1.0, maxSide / max(w, h));
      final tw = (w * s).round(), th = (h * s).round();
      // the plugin keeps the ratio and makes both sides at least minW x minH
      return await _jpeg(bytes, tw, th, quality);
    } catch (_) {
      return await _jpeg(bytes, maxSide, maxSide, quality);
    }
  }
  final im = await decodeImg(bytes);
  final m = min(im.width, im.height);
  final sx = (im.width - m) / 2, sy = (im.height - m) / 2;
  final out = min(maxSide, m);
  final rec = ui.PictureRecorder();
  final cv = ui.Canvas(rec);
  cv.drawImageRect(im, ui.Rect.fromLTWH(sx, sy, m.toDouble(), m.toDouble()), ui.Rect.fromLTWH(0, 0, out.toDouble(), out.toDouble()), ui.Paint()..filterQuality = ui.FilterQuality.high);
  final pic = rec.endRecording();
  final img = await pic.toImage(out, out);
  final png = await img.toByteData(format: ui.ImageByteFormat.png);
  im.dispose();
  img.dispose();
  return await _jpeg(png!.buffer.asUint8List(), out, out, quality);
}

/// a picture drawn by code (a canvas) as a JPEG
Future<Uint8List> imageToJpeg(ui.Image img, {int q = 90}) async {
  final png = await img.toByteData(format: ui.ImageByteFormat.png);
  return _jpeg(png!.buffer.asUint8List(), img.width, img.height, q);
}

/// one PDF page made from a photo (an ID proof photographed by the phone is kept as a PDF)
Future<Uint8List> imgToPdf(Uint8List bytes, {int maxSide = 1100, double q = .65}) async {
  final jpg = await shrink(bytes, maxSide, q);
  final im = await decodeImg(jpg);
  final w = im.width.toDouble(), h = im.height.toDouble();
  im.dispose();
  const pw0 = 595.28;
  final ph = (pw0 * h / w * 100).round() / 100;
  final doc = pw.Document();
  doc.addPage(pw.Page(pageFormat: PdfPageFormat(pw0, ph, marginAll: 0), build: (_) => pw.Image(pw.MemoryImage(jpg), fit: pw.BoxFit.fill, width: pw0, height: ph)));
  return await doc.save();
}

/// first bytes of a file -> what it really is
String sniff(Uint8List b) {
  bool is_(List<int> s) => b.length >= s.length && List.generate(s.length, (i) => b[i] == s[i]).every((x) => x);
  if (is_([255, 216, 255])) return 'jpg';
  if (is_([137, 80, 78, 71])) return 'png';
  if (is_([37, 80, 68, 70])) return 'pdf';
  if (is_([26, 69, 223, 163])) return 'webm';
  if (b.length >= 12 && String.fromCharCodes(b.sublist(4, 8)) == 'ftyp') {
    final br = String.fromCharCodes(b.sublist(8, 12));
    return RegExp(r'^(heic|heix|hevc|mif1|msf1|heim|heis|avif)').hasMatch(br) ? 'heic' : 'mp4';
  }
  return '';
}

String mimeOf(String name, Uint8List b) {
  switch (sniff(b)) {
    case 'jpg':
      return 'image/jpeg';
    case 'png':
      return 'image/png';
    case 'pdf':
      return 'application/pdf';
    case 'webm':
      return 'video/webm';
    case 'mp4':
      return name.toLowerCase().endsWith('.m4a') ? 'audio/mp4' : 'video/mp4';
  }
  final e = name.split('.').last.toLowerCase();
  const m = {
    'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'png': 'image/png', 'webp': 'image/webp', 'gif': 'image/gif', 'pdf': 'application/pdf', 'doc': 'application/msword',
    'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'xls': 'application/vnd.ms-excel', 'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'ppt': 'application/vnd.ms-powerpoint', 'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'txt': 'text/plain', 'csv': 'text/csv', 'zip': 'application/zip',
    'm4a': 'audio/mp4', 'aac': 'audio/aac', 'mp3': 'audio/mpeg', 'mp4': 'video/mp4', 'mov': 'video/quicktime',
  };
  return m[e] ?? 'application/octet-stream';
}

String toDataUrl(Uint8List b, String mime) => 'data:$mime;base64,${base64Encode(b)}';

Uint8List? fromDataUrl(String d) {
  final i = d.indexOf(',');
  if (!d.startsWith('data:') || i < 0) return null;
  final head = d.substring(0, i);
  try {
    if (head.contains(';base64')) return base64Decode(d.substring(i + 1));
    return Uint8List.fromList(utf8.encode(Uri.decodeComponent(d.substring(i + 1))));
  } catch (_) {
    return null;
  }
}

String dataUrlMime(String d) {
  final m = RegExp(r'^data:([^;,]+)').firstMatch(d);
  return m?.group(1) ?? 'application/octet-stream';
}

Future<Uint8List> assetBytes(String p) async => (await rootBundle.load(p)).buffer.asUint8List();
