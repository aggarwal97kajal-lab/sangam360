import 'package:flutter/material.dart';
import '../l10n/l10n.dart';

/* ===================== the three kinds of workspace and the fixed lists of the app ===================== */

const brand = 'Sangam360';
const tagline = 'One Platform. Every Community.';
const payApi = 'https://sangam360-payments.onrender.com';
const linkPreviewApi = 'https://api.microlink.io/?url=';
const supportEmail = 'ksuraj.th@gmail.com';
const rtdbUrl = 'https://my-building-326a9-default-rtdb.firebaseio.com';
const firebaseProject = 'my-building-326a9';
const firebaseAndroidKey = 'AIzaSyCKqAeTydTSMrbPNeVaCXIPjZgvDxgv3bY';
const googleWebClient = '164811130650-17j46gemu6dq3f2jf62vp5psidtg9l24.apps.googleusercontent.com';
/// CARTO basemaps key (the maps inside the app). Empty = OpenStreetMap tiles.
const cartoKey = 'cb1_4gl8_1_bd234e3ec19013765e408360';

const trialDays = 14;
const trialDaysS = '14';

/// Legal pages: fill these in. Anything left empty stays as a [PLACEHOLDER] in the page.
const legal = {'entity': '', 'address': '', 'city': '', 'support': '', 'privacy': '', 'legal': '', 'grievance': ''};

class GrpCfg {
  /// English (kept as written here); the getters below give the user's language
  final String tE, oneE, sE, phE, jlE, idpE;
  final List<String> pre;
  const GrpCfg({required String t, required String one, required String s, required String ph, required this.pre, required String jl, required String idp})
      : tE = t,
        oneE = one,
        sE = s,
        phE = ph,
        jlE = jl,
        idpE = idp;
  String get t => tr(tE);
  String get one => tr(oneE);
  String get s => tr(sE);
  String get ph => tr(phE);
  String get jl => tr(jlE);
  String get idp => tr(idpE);
}

class ExtraField {
  final String label, kind; // kind: sel | txt
  final List<String> opts;
  const ExtraField(this.label, this.kind, [this.opts = const []]);
}

class KindCfg {
  final String key, ico;

  /// English labels (kept as written below); the getters further down give the user's language
  final String cardE, cardSE, tagE, wordE, unitE, personE, feeE, createTE, createSE, joinTE, joinSE;
  final Color c1, c2, rc;
  final GrpCfg? grp;
  final List<ExtraField> x;
  final Map<String, List<String>> nav;
  final List<String> subList;
  final Map<String, String> subs;
  final List<List<String>> skin;
  const KindCfg({
    required this.key,
    required this.ico,
    required String card,
    required String cardS,
    required String tag,
    required this.c1,
    required this.c2,
    required this.rc,
    required String word,
    required String unit,
    required String person,
    required String fee,
    required String createT,
    required String createS,
    required String joinT,
    required String joinS,
    this.grp,
    this.x = const [],
    this.nav = const {},
    this.subList = const [],
    this.subs = const {},
    this.skin = const [],
  })  : cardE = card,
        cardSE = cardS,
        tagE = tag,
        wordE = word,
        unitE = unit,
        personE = person,
        feeE = fee,
        createTE = createT,
        createSE = createS,
        joinTE = joinT,
        joinSE = joinS;

  String get card => tr(cardE);
  String get cardS => tr(cardSE);
  String get tag => tr(tagE);
  String get word => tr(wordE);
  String get unit => tr(unitE);
  String get person => tr(personE);
  String get fee => tr(feeE);
  String get createT => tr(createTE);
  String get createS => tr(createSE);
  String get joinT => tr(joinTE);
  String get joinS => tr(joinSE);
}

const kinds = <String, KindCfg>{
  'society': KindCfg(
    key: 'society',
    ico: '🏘️',
    card: 'For Societies',
    cardS: 'Residents, visitors, bills & community',
    tag: tagline,
    c1: Color(0xFF5B3DF5),
    c2: Color(0xFF8A4DFF),
    rc: Color(0xFF3B5BFD),
    word: 'society',
    unit: 'Flat',
    person: 'Resident',
    fee: 'maintenance',
    createT: '🏢 Create my society',
    createS: 'Set up a new building or complex as its admin',
    joinT: '🔑 Join my society',
    joinS: 'Use the code or link from your society',
  ),
  'company': KindCfg(
    key: 'company',
    ico: '🏢',
    card: 'For Corporates',
    cardS: 'Employees, attendance, visitors & billing',
    tag: tagline,
    c1: Color(0xFF0F766E),
    c2: Color(0xFF2563EB),
    rc: Color(0xFF2563EB),
    word: 'company',
    unit: 'Desk',
    person: 'Employee',
    fee: 'billing',
    createT: '🏢 Create my company',
    createS: 'Set up your company as its admin',
    joinT: '🔑 Join my company',
    joinS: 'Use the code from your company admin',
    grp: GrpCfg(t: 'Departments', one: 'department', s: 'Add the departments or teams. Employees pick theirs when they join.', ph: 'Department name', pre: ['Engineering', 'HR', 'Sales'], jl: 'Choose your department and tell us who you are.', idp: 'Employee ID (e.g. EMP-104)'),
    x: [
      ExtraField('Industry', 'sel', ['IT / Software', 'Manufacturing', 'Finance / Banking', 'Retail', 'Healthcare', 'Other']),
      ExtraField('Employee strength', 'sel', ['1-10', '11-50', '51-200', '200+']),
      ExtraField('GST number', 'txt'),
    ],
    nav: {'svc': ['💼', 'Work'], 'comm': ['💬', 'Team'], 'fin': ['🧾', 'Billing']},
    subList: ['att', 'leave', 'room', 'hol', 'comp', 'gc', 'vis', 'del', 'park'],
    subs: {'comp': 'Helpdesk', 'del': 'Couriers'},
    skin: [
      ['Societies', 'Companies'], ['societies', 'companies'], ['Society', 'Company'], ['society', 'company'], ['Residents', 'Employees'], ['residents', 'employees'], ['Resident', 'Employee'], ['resident', 'employee'],
      ['Flats', 'Desks'], ['flats', 'desks'], ['Flat', 'Desk'], ['flat', 'desk'], ['Towers', 'Offices'], ['towers', 'offices'], ['Tower', 'Office'], ['tower', 'office'], ['Maintenance', 'Billing'], ['maintenance', 'billing'],
      ['Committee member', 'Manager'], ['committee member', 'manager'], ['Tenant', 'Contractor'], ['tenant', 'contractor'],
    ],
  ),
  'school': KindCfg(
    key: 'school',
    ico: '🎓',
    card: 'For Schools',
    cardS: 'Students, staff attendance, fees & notices',
    tag: tagline,
    c1: Color(0xFFC2410C),
    c2: Color(0xFFD97706),
    rc: Color(0xFFD97706),
    word: 'school',
    unit: 'Class',
    person: 'Student',
    fee: 'fees',
    createT: '🏫 Create my school',
    createS: 'Principal: set up your school and get the code for your teachers',
    joinT: '🎓 Join as a student',
    joinS: 'Use the class code from your class teacher',
    grp: GrpCfg(t: 'Classes', one: 'class', s: 'Add classes or sections, e.g. Class 5-A. Students pick theirs when they join.', ph: 'Class / section', pre: ['Class 1', 'Class 2', 'Class 3'], jl: 'Choose your class and tell us who you are.', idp: 'Roll / admission no.'),
    x: [
      ExtraField('Board', 'sel', ['CBSE', 'ICSE', 'State board', 'IB / Cambridge', 'Other']),
      ExtraField('School level', 'sel', ['Primary', 'Secondary', 'Senior secondary', 'K-12']),
      ExtraField('Affiliation no. (optional)', 'txt'),
    ],
    nav: {'svc': ['🏫', 'Campus'], 'comm': ['💬', 'Community'], 'fin': ['💳', 'Fees']},
    subList: ['att', 'tt', 'hw', 'leave', 'hol', 'comp', 'gc', 'vis', 'del'],
    subs: {'comp': 'Complaints', 'del': 'Parcels'},
    skin: [
      ['Societies', 'Schools'], ['societies', 'schools'], ['Society', 'School'], ['society', 'school'], ['Residents', 'Students'], ['residents', 'students'], ['Resident', 'Student'], ['resident', 'student'],
      ['Flats', 'Classes'], ['flats', 'classes'], ['Flat', 'Class'], ['flat', 'class'], ['Towers', 'Blocks'], ['towers', 'blocks'], ['Tower', 'Block'], ['tower', 'block'], ['Maintenance', 'Fee'], ['maintenance', 'fee'],
      ['Committee member', 'Teacher'], ['committee member', 'teacher'], ['Tenant', 'Parent'], ['tenant', 'parent'],
    ],
  ),
};

const compRaw = {
  'society': '''Lift|Not working,Door issue,Noise,Other
Water|No supply,Low pressure,Leakage,Quality
Electricity|Power cut,Common-area lights,Meter issue,Other
Cleaning|Common areas,Stairs,Washrooms,Other
Parking|Wrong parking,Allocation,Blocked vehicle,Other
Security|Guard issue,CCTV,Unauthorized entry,Other
Noise|Neighbour,Construction,Event,Other
Plumbing|Leakage,Drainage,Tap / pipe,Other
Civil Work|Wall / ceiling,Flooring,Door / window,Other
Internet|Connectivity,Cabling,Other
Garbage|Collection,Segregation,Smell,Other
Other|General complaint,Suggestion,Other issue''',
  'company': '''IT & Technology|Laptop/Desktop,Monitor,Keyboard/Mouse,Software issue,Email/Office 365,Internet/Wi-Fi,VPN,Printer/Scanner,Network issue,Access/Login issue
Electrical|Lights,Fan/AC,Power socket,Power failure,UPS,Generator,Other electrical issue
HVAC / Air Conditioning|AC not cooling,AC leakage,Temperature issue,Ventilation,Noise from AC
Housekeeping & Cleanliness|Desk/workstation cleaning,Floor cleaning,Washroom cleaning,Garbage collection,Pantry cleaning,Pest control
Facilities & Maintenance|Furniture,Chair/Table,Door/Lock,Ceiling,Flooring,Plumbing,Water leakage,Building maintenance
Security|Access card,CCTV,Security guard,Visitor management,Unauthorized access,Emergency/safety concern
Pantry & Cafeteria|Food quality,Water dispenser,Coffee/Tea machine,Refrigerator,Microwave,Pantry cleanliness
Meeting Rooms|Projector,Display/TV,Video conferencing,Speaker/Microphone,Room booking issue,Furniture
Parking & Transport|Parking allocation,Parking access,EV charging,Company transport,Cab issue,Shuttle/bus issue
HR & Employee Services|ID card,Employee documentation,Attendance,Leave-related issue,Workplace facilities,General HR support
Safety & Emergency|Fire extinguisher,Fire alarm,Emergency exit,First-aid,Safety hazard,Emergency lighting
Admin|Office supplies,Stationery,Courier,Printing,Documentation,General administration
Other / Suggestion|Other complaint,Suggestion,Feedback''',
  'school': '''Classroom / Infrastructure|Classroom furniture,Fan / AC,Lights,Smart board / projector,Doors/windows,Classroom cleanliness
Washroom & Hygiene|Washroom cleanliness,Water supply,Plumbing,Handwash facilities,Hygiene issue
Electrical|Power failure,Lights,Fans,Switch/socket,Other electrical issue
Water & Plumbing|Drinking water,Water leakage,Tap/faucet,Drainage,Water cooler
IT & Technology|Wi-Fi,Computer,Smart board,Projector,School app/portal,Printer
Security & Safety|CCTV,Security guard,Unauthorized access,Fire safety,Emergency equipment,Safety hazard
Transport|School bus,Driver/conductor,Bus timing,Bus cleanliness,Route issue
Library|Book availability,Damaged book,Library facilities,Library timing
Sports & Activities|Sports equipment,Playground,Activity room,Equipment damage
Canteen / Food|Food quality,Cleanliness,Drinking water,Pricing,Staff behaviour
Academic|Timetable,Study material,Examination,Homework/assignment,Academic support
Teacher / Staff|Teacher-related concern,Staff behaviour,Communication issue,Administrative support
Student Welfare|Bullying,Counselling,Medical assistance,Special assistance,Student safety
Fees & Administration|Fee payment,Receipt,Admission,Certificate/document,ID card,General administration
Other|General complaint,Suggestion,Other issue''',
};

Map<String, List<String>> compTree(String kind) {
  final t = <String, List<String>>{};
  for (final l in (compRaw[kind] ?? compRaw['society']!).split('\n')) {
    final q = l.split('|');
    t[q[0]] = q[1].split(',');
  }
  return t;
}

const compLoc = {
  'society': ['My flat', 'Tower / block', 'Lobby / stairs', 'Parking', 'Garden / play area', 'Clubhouse / amenity', 'Lift', 'Terrace', 'Other'],
  'company': ['Workstation / floor', 'Meeting room', 'Pantry / cafeteria', 'Washroom', 'Reception / lobby', 'Parking', 'Server / IT room', 'Other'],
  'school': ['Classroom', 'Block / floor', 'Washroom', 'Playground', 'Library', 'Canteen', 'Lab', 'School bus', 'Staff room', 'Other'],
};

const cst = ['Open', 'Assigned', 'In Progress', 'On Hold', 'Resolved', 'Closed'];
const annTypes = ['General', 'Emergency', 'Maintenance', 'Water shutdown', 'Power shutdown', 'Meeting', 'Event', 'Security'];
const incCats = ['Maintenance', 'Parking', 'Amenity', 'Penalty', 'Other'];
const expCats = ['Electricity', 'Water', 'Security', 'Housekeeping', 'Lift', 'Repairs', 'Staff', 'Vendor', 'Other'];
const vTypes = ['Guest', 'Cab', 'Food delivery', 'Courier', 'Service provider', 'Other'];
const couriers = ['Amazon', 'Flipkart', 'Swiggy', 'Zomato', 'Blinkit', 'India Post', 'Other'];
final gstRe = RegExp(r'^\d{2}[A-Z]{5}\d{4}[A-Z][A-Z\d]Z[A-Z\d]$');
final vpaRe = RegExp(r'^[A-Za-z0-9][A-Za-z0-9._-]{1,254}@[A-Za-z][A-Za-z0-9.]{1,63}$');
final ifscRe = RegExp(r'^[A-Z]{4}0[A-Z0-9]{6}$');

/// kinds of alerts that can be muted one by one
const muteK = [
  ['chat', '💬', 'Chat messages', 'Community chat and private messages'],
  ['ann', '📢', 'Notices & announcements', ''],
  ['bill', '🧾', 'Bills & payments', 'New bills, reminders and payment confirmations'],
  ['comp', '🛠️', 'Complaints', ''],
  ['gate', '🚪', 'Visitors & parcels', ''],
  ['leave', '🏖️', 'Leave & holidays', ''],
  ['join', '🙋', 'New join requests', ''],
  ['sos', '🚨', 'SOS & emergency alerts', ''],
];

const staffRoles = ['SOCIETY_ADMIN', 'COMMITTEE_MEMBER', 'ACCOUNTANT', 'SECURITY_GUARD', 'STAFF'];

const staffJobs = [
  'Bus driver', 'Bus conductor / attendant', 'Security guard', 'Peon / office attendant', 'Sweeper / housekeeping', 'Gardener', 'Ayah / caretaker', 'Cook / canteen staff', 'Lab assistant', 'Librarian',
  'Receptionist / front office', 'Clerk / office staff', 'Accountant / fee clerk', 'Nurse / medical room', 'Electrician / maintenance', 'IT / computer support', 'Sports coach', 'Store keeper', 'Hostel warden', 'Other',
];
String staffWant(String j) => RegExp('security', caseSensitive: false).hasMatch(j)
    ? 'SECURITY_GUARD'
    : RegExp('accountant', caseSensitive: false).hasMatch(j)
        ? 'ACCOUNTANT'
        : 'STAFF';

const hTypes = ['Maid', 'Cook', 'Driver', 'Nanny', 'Gardener', 'Other'];
const mktTypes = ['Sell', 'Buy', 'Give away'];
const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const gcs = ['Open', 'In review', 'Resolved', 'Dismissed'];
const btypes = [['maintenance', 'Monthly maintenance'], ['event', 'Event fee'], ['other', 'One-time charge']];

/* ----- plans (what the app SHOWS; the server decides what is charged) ----- */
class Plan {
  final String id, nameE;
  final double max;
  final int m, y;
  final bool cu;

  /// features, in English as written below
  final List<String> fE;
  const Plan(this.id, this.nameE, this.max, this.m, this.y, this.fE, {this.cu = false});
  String get name => tr(nameE);
  List<String> get f => [for (final x in fE) tr(x)];
}

const plansSoc = [
  Plan('free', 'Starter', 25, 0, 0, ['1–25 flats', 'Visitors & parcels', 'Complaints & notices', 'Community & private chat', 'Shows ads']),
  Plan('p100', 'Growth', 100, 499, 5000, ['26–100 flats', 'No ads', 'Photos, voice notes & documents in chat', 'Finance reports', 'Amenity booking & polls']),
  Plan('p150', 'Plus', 150, 799, 9000, ['101–150 flats', 'Everything in Growth', 'Staff directory & document vault', 'Priority email support']),
  Plan('p200', 'Pro', 200, 1099, 12500, ['151–200 flats', 'Everything in Plus', 'Committee roles & accountant access', 'Priority support']),
  Plan('ent', 'Enterprise', 1e9, 2499, 25000, ['Above 200 flats', 'Everything in Pro', 'Dedicated onboarding', 'Phone support']),
];
const planOrg = {
  'company': [
    Plan('c_start', 'Starter', 25, 0, 0, ['Up to 25 employees', 'Employee directory', 'Notices & announcements', 'Basic visitor management', 'Events', 'Shows ads']),
    Plan('c_growth', 'Growth', 100, 499, 5000, ['26–100 employees', 'No ads', 'Attendance', 'Leave requests', 'Events', 'Complaints / helpdesk']),
    Plan('c_biz', 'Business', 250, 999, 10000, ['101–250 employees', 'Everything in Growth', 'Approvals & departments', 'Documents', 'Reports']),
    Plan('c_ent', 'Enterprise', 500, 1999, 20000, ['251–500 employees', 'Advanced reports', 'Admin controls', 'Integrations', 'Priority support']),
    Plan('c_corp', 'Corporate', 1e9, 0, 0, ['500+ employees', 'Dedicated support', 'API & SSO', 'Custom branding'], cu: true),
  ],
  'school': [
    Plan('s_basic', 'Basic', 100, 0, 0, ['Up to 100 users', 'Notices & announcements', 'Directory', 'Events', 'Shows ads']),
    Plan('s_std', 'Standard', 500, 999, 10000, ['101–500 users', 'Attendance', 'Parent communication', 'Leave', 'Complaints']),
    Plan('s_pro', 'Professional', 1000, 1999, 20000, ['501–1,000 users', 'Fee reminders', 'Homework & timetable', 'Reports', 'Transport']),
    Plan('s_prem', 'Premium', 2500, 3999, 40000, ['1,001–2,500 users', 'Advanced analytics', 'Multiple admins', 'Visitor management']),
    Plan('s_ent', 'Enterprise', 1e9, 0, 0, ['2,500+ users', 'Multi-campus', 'API & SSO', 'Custom branding', 'Dedicated support'], cu: true),
  ],
};

/// payment methods offered in Razorpay for a plan
const payMethods = [
  ['upi', '📲', 'UPI', 'GPay, PhonePe, Paytm, BHIM & all UPI apps', 'upi'],
  ['card', '💳', 'Credit / Debit card', 'Visa, Mastercard, RuPay, Amex', 'card'],
  ['nb', '🏦', 'Net banking / bank account', 'All major Indian banks', 'netbanking'],
  ['wallet', '👛', 'Wallets', 'Paytm, PhonePe, Amazon Pay & more', 'wallet'],
  ['all', '✨', 'All options', 'Let Razorpay show every method', ''],
];

/// the badge follows the price: bronze, silver, gold, diamond; custom plans wear the crown
const ptier = [
  ['🥉', Color(0xFFB45309)],
  ['🥈', Color(0xFF64748B)],
  ['🥇', Color(0xFFD97706)],
  ['💎', Color(0xFF0284C7)],
  ['👑', Color(0xFF7C3AED)],
];

String payMeth(dynamic m) {
  const t = {'upi': 'UPI', 'bank': 'Bank transfer', 'card': 'Card', 'netbanking': 'Net banking', 'wallet': 'Wallet', 'emi': 'EMI', 'paylater': 'Pay later'};
  final s = m == null ? '' : m.toString();
  return t[s] ?? s;
}

/* ----- side-bar add-ons ----- */
const fxListByKind = {
  'society': ['lf', 'ven', 'meet', 'exr'],
  'school': ['res', 'gp', 'ptm', 'bus', 'pay', 'bday'],
  'company': ['task', 'shift', 'pay', 'asset', 'claim', 'bday'],
};
const vcats = ['Plumber', 'Electrician', 'Carpenter', 'Painter', 'AC / Appliance repair', 'Pest control', 'Cleaning', 'Laundry', 'Milk / Newspaper', 'Cab / Driver', 'Internet / Cable', 'Other'];
const shiftNames = {'M': 'Morning', 'E': 'Evening', 'N': 'Night', 'G': 'General', 'O': 'Off'};
const payKinds = ['Payslip', 'Offer letter', 'Appointment letter', 'Appraisal letter', 'Form 16', 'Experience letter', 'Other'];
const assetKinds = ['Laptop', 'Phone', 'SIM card', 'ID / access card', 'Vehicle', 'Furniture', 'Other'];
const claimKinds = ['Travel', 'Food', 'Stay', 'Fuel', 'Office supplies', 'Internet / Phone', 'Client meeting', 'Other'];
const drvIss = [['brake', '🔧', 'Brake issue'], ['tyre', '🛞', 'Tyre issue'], ['ac', '❄️', 'AC issue'], ['battery', '🔋', 'Battery issue'], ['engine', '🚌', 'Engine issue'], ['other', '🛠️', 'Something else']];
const drvInc = [['student', '🧒', 'Student issue'], ['accident', '💥', 'Accident'], ['traffic', '🚦', 'Traffic'], ['breakdown', '🛑', 'Bus breakdown'], ['parent', '🚪', 'Parent unavailable'], ['absent', '❌', 'Student absent'], ['medical', '🩺', 'Medical issue'], ['other', '📝', 'Other']];
const fxMonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

const fxCols = [Color(0xFF6D5DFC), Color(0xFFF59E0B), Color(0xFF10B981), Color(0xFFEF4444), Color(0xFF0EA5E9), Color(0xFFFF6B9D), Color(0xFF8B5CF6), Color(0xFF14B8A6), Color(0xFFF97316), Color(0xFF64748B), Color(0xFF84CC16), Color(0xFFE11D48)];

/* ----- chat ----- */
const emoji = [
  ['😀', '😀 😃 😄 😁 😆 😅 😂 🤣 🙂 😉 😊 😇 🥰 😍 🤩 😘 😋 😜 🤪 😎 🤓 🥳 😏 😒 😞 😔 😟 🙁 😢 😭 😤 😠 😡 🤯 😳 🥺 😱 😰 🤗 🤔 🤭 🤫 🙄 😬 😴 🤒 🤕 🤢 🥵 🥶'],
  ['👍', '👍 👎 👌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 👋 🤚 ✋ 👏 🙌 👐 🤝 🙏 💪 ✍️ 💅 🧠 👀 👂 👃 👄 👶 👦 👧 👨 👩 👴 👵'],
  ['🐶', '🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧 🐦 🦉 🐴 🦄 🐝 🦋 🐢 🐍 🐬 🐳 🌸 🌹 🌻 🌳 🌴 🌞 🌙 ⭐ 🔥 🌈 ⛄'],
  ['🍎', '🍎 🍌 🍇 🍉 🍓 🍒 🍑 🥭 🍍 🥥 🥑 🍅 🥕 🌽 🍞 🧀 🍗 🍔 🍟 🍕 🌮 🍜 🍛 🍣 🍩 🍪 🎂 🍫 ☕ 🍵 🥤 🍺'],
  ['⚽', '⚽ 🏀 🏏 🏸 🎾 🏐 🏓 🥊 🎯 🎮 🎲 🎨 🎵 🎤 🎧 🎬 🏆 🥇 🎉 🎊 🎈 🎁 🪁 🚴 🏊 🧘'],
  ['🚗', '🚗 🚕 🚌 🏍️ 🚲 ✈️ 🚀 🚂 🏠 🏢 🏫 🏥 🏪 🌆 🌃 🗺️ ⛺ 🏖️ 🏔️ 🗼'],
  ['💡', '📱 💻 📷 📺 🔑 🔒 💡 🔦 📦 💰 💳 📌 📎 ✏️ 📚 🎒 🛒 🧹 🧺 🔔 🕐 ⚠️ 🚨 🩺 💊'],
  ['❤️', '❤️ 🧡 💛 💚 💙 💜 🖤 💔 💕 💯 ✅ ❌ ❓ ❗ ➕ ✨ 💥 💫 💤 🔴 🟢 🔵 ⚪'],
];
const stickers = ['😂', '😍', '🥳', '😎', '😭', '🤩', '😴', '🤔', '🙏', '👍', '👏', '🎉', '❤️', '🔥', '💯', '🎂', '🌹', '☕', '🏏', '🍕', '🙌', '🤗', '😡', '🤝', '🥰', '😜', '🤯', '🫡'];

/// private chat themes: [key, name, wall, dark?, my bubble, my text, other bubble, other text]
class ChatTheme {
  final String key, nameE;
  String get name => tr(nameE);
  final Color wall, mine, mineText, other, otherText;
  final Gradient? mineGrad;
  final bool dark;
  const ChatTheme(this.key, this.nameE, this.wall, this.dark, this.mine, this.mineText, this.other, this.otherText, [this.mineGrad]);
}

const chatThemes = [
  ChatTheme('wa', 'WhatsApp', Color(0xFFEFEAE2), false, Color(0xFFD9FDD3), Color(0xFF111B21), Colors.white, Color(0xFF111B21)),
  ChatTheme('wadark', 'WA Dark', Color(0xFF0B141A), true, Color(0xFF005C4B), Color(0xFFE9EDEF), Color(0xFF202C33), Color(0xFFE9EDEF)),
  ChatTheme('ocean', 'Ocean', Color(0xFFDCEFFF), false, Color(0xFF0277BD), Colors.white, Colors.white, Color(0xFF0F172A)),
  ChatTheme('mint', 'Mint', Color(0xFFDFF5EA), false, Color(0xFF0F9D6B), Colors.white, Colors.white, Color(0xFF0F172A)),
  ChatTheme('classic', 'Classic', Color(0xFFE5DDD5), false, Color(0xFFDCF8C6), Color(0xFF111B21), Colors.white, Color(0xFF111B21)),
  ChatTheme('sunset', 'Sunset', Color(0xFFFFE9DC), false, Color(0xFFF97316), Colors.white, Colors.white, Color(0xFF1F2937), LinearGradient(colors: [Color(0xFFF97316), Color(0xFFEC4899)])),
  ChatTheme('lavender', 'Lavender', Color(0xFFEEE8FF), false, Color(0xFF7C3AED), Colors.white, Colors.white, Color(0xFF1F2937)),
  ChatTheme('rose', 'Rose', Color(0xFFFDE6EC), false, Color(0xFFE11D48), Colors.white, Colors.white, Color(0xFF1F2937)),
  ChatTheme('sand', 'Sand', Color(0xFFF4EAD5), false, Color(0xFFB45309), Colors.white, Color(0xFFFFFAF0), Color(0xFF292524)),
  ChatTheme('sky', 'Sky', Color(0xFFE3F4FD), false, Color(0xFF38BDF8), Colors.white, Colors.white, Color(0xFF0F172A), LinearGradient(colors: [Color(0xFF38BDF8), Color(0xFF6366F1)])),
  ChatTheme('peach', 'Peach', Color(0xFFFFEEE4), false, Color(0xFFFB7185), Colors.white, Colors.white, Color(0xFF1F2937)),
  ChatTheme('candy', 'Candy', Color(0xFFFBEAF6), false, Color(0xFFEC4899), Colors.white, Colors.white, Color(0xFF1F2937), LinearGradient(colors: [Color(0xFFEC4899), Color(0xFF8B5CF6)])),
  ChatTheme('forest', 'Forest', Color(0xFF0F2A1F), true, Color(0xFF16A34A), Colors.white, Color(0xFF1C3B2E), Color(0xFFE8F5EE)),
  ChatTheme('midnight', 'Midnight', Color(0xFF0B1026), true, Color(0xFF6366F1), Colors.white, Color(0xFF1B2142), Color(0xFFE6E8FF)),
  ChatTheme('charcoal', 'Charcoal', Color(0xFF18181B), true, Color(0xFF0A84FF), Colors.white, Color(0xFF2C2C2E), Color(0xFFF4F4F5)),
  ChatTheme('coffee', 'Coffee', Color(0xFF2A201A), true, Color(0xFFA16207), Colors.white, Color(0xFF3B2E26), Color(0xFFF5EDE6)),
  ChatTheme('ember', 'Ember', Color(0xFF1F1012), true, Color(0xFFEF4444), Colors.white, Color(0xFF36191C), Color(0xFFFDE8E8), LinearGradient(colors: [Color(0xFFEF4444), Color(0xFFF59E0B)])),
];

const docColors = {
  'pdf': Color(0xFFDC2626), 'doc': Color(0xFF2563EB), 'docx': Color(0xFF2563EB), 'xls': Color(0xFF16A34A), 'xlsx': Color(0xFF16A34A), 'csv': Color(0xFF16A34A),
  'ppt': Color(0xFFEA580C), 'pptx': Color(0xFFEA580C), 'zip': Color(0xFF64748B), 'txt': Color(0xFF475569),
};

/// a public web address of the app for invitation links (empty: invitations carry the code only)
const webAppUrl = '';
String inviteLink(String code) => webAppUrl.isEmpty ? '' : '$webAppUrl?join=$code';

/// the text of an invitation (WhatsApp / copy)
String inviteText(String code, {String? org, bool teacher = false, bool cls = false}) {
  final l = inviteLink(code);
  final how = trf('Install {0}, choose {1} and enter the code', [brand, (cls ? tr('Join as a student') : teacher ? tr('Join as a teacher') : 'Join')]);
  if (teacher) return trf('Join {0} on {1} as a teacher{2}  (Principal\'s code: {3}). {4}.', [(org ?? ''), brand, (l.isEmpty ? '' : ': $l'), code, how]);
  return trf('Join {0} on {1}{2}  (code: {3}). {4}.', [(org == null ? 'us' : org), brand, (l.isEmpty ? '' : ': $l'), code, how]);
}
