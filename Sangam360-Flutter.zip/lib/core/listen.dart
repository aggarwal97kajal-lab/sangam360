import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';

import 'fs.dart';
import 'nav.dart';
import 'session.dart';
import 'store.dart';
import 'toast.dart';
import 'util.dart';

/// Everything the main screen listens to. Each list keeps its records in D[key]; new records may give a pop-up.
class Listen {
  static final List<StreamSubscription> subs = [];
  static final List<void Function()> offs = [];

  /// called by the chat to know whether it is on screen
  static bool Function() chatOpen = () => false;

  /// mentions are announced by the chat module
  static bool Function(Doc d) mentionHit = (_) => false;

  static void stop() {
    for (final s in subs) {
      s.cancel();
    }
    subs.clear();
    for (final f in offs) {
      try {
        f();
      } catch (_) {}
    }
    offs.clear();
  }

  /// w(query, key, after, onNew): like the earlier app. The first answer (and answers from the phone's cache) never give a pop-up.
  static void w(Q q, String key, {void Function()? after, void Function(Doc d, DocumentChangeType t)? onNew, Map<String, Doc> Function(Map<String, Doc>)? filter, void Function(Object e)? onErr}) {
    var first = true;
    subs.add(q.snapshots().listen((s) {
      var o = <String, Doc>{for (final d in s.docs) d.id: {...d.data(), 'id': d.id}};
      if (filter != null) o = filter(o);
      final quiet = first || s.metadata.isFromCache;
      if (!s.metadata.isFromCache) first = false;
      D.set(key, o);
      if (!quiet && onNew != null) {
        for (final c in s.docChanges) {
          if (c.type != DocumentChangeType.removed && !c.doc.metadata.hasPendingWrites) {
            final d = {...?c.doc.data(), 'id': c.doc.id};
            if (filter == null || o.containsKey(c.doc.id)) onNew(d, c.type);
          }
        }
      }
      after?.call();
    }, onError: (Object e) {
      if (onErr != null) onErr(e);
      if (e is FirebaseException && e.code == 'permission-denied') return;
      toast('⚠️', 'Could not load $key', 'Check your connection.');
    }));
  }

  static void all() {
    stop();
    final uid = S.uid!, me = S.me!;
    Q L(String n, int k) => col(n).orderBy('ts', descending: true).limit(k);
    Q F(String n) => col(n).where('flat', isEqualTo: me['flat']).limit(60);
    final added = DocumentChangeType.added, modified = DocumentChangeType.modified;

    w(S.isAdm ? L('complaints', S.isTeacher ? 150 : 50) : col('complaints').where('uid', isEqualTo: uid).limit(50), 'comp',
        filter: S.isTeacher ? (o) => {for (final e in o.entries) if (e.value['uid'] == uid || S.clsOf(e.value) == S.myCls) e.key: e.value} : null, onNew: (d, t) {
      if (t == added && S.isAdm && d['uid'] != uid && (!S.isTeacher || S.clsOf(d) == S.myCls)) toast('🛠️', 'New complaint', str(d['title']), false, 'comp');
    });

    w(L('announcements', S.sch ? 120 : 30), 'ann', filter: S.sch ? (o) => {for (final e in o.entries) if (S.annVis(e.value)) e.key: e.value} : null, onNew: (d, t) {
      if (t == added && d['uid'] != uid && S.annVis(d)) toast(d['type'] == 'Emergency' ? '🚨' : '📢', str(d['title']), str(d['type']), false, d['type'] == 'Emergency' ? 'sos' : 'ann');
    });

    if (!S.sch) {
      w(L('messages', 80), 'msg', onNew: (d, t) {
        if (t == added && d['uid'] != uid && mentionHit(d)) return;
        if (t == added && d['uid'] != uid && !chatOpen()) toast('💬', str(d['name']), msgLabel(d), false, 'chat');
      });
    }

    w(col('dmchats').where('users', arrayContains: uid).limit(100), 'dmc', onNew: (d, t) {
      final open = nav.dmc != null && nav.dmc!.cid == d['id'];
      if (str(d['lastFrom']).isNotEmpty && d['lastFrom'] != uid && isUn(d) && _dmT[d['id']] != d['lastTs'] && !open) {
        _dmT[str(d['id'])] = intv(d['lastTs']);
        final pu = strList(d['users']).firstWhere((u) => u != uid, orElse: () => '');
        final w0 = mapv(mapv(d['who'])[pu]);
        final n = str(w0['n']).isNotEmpty ? str(w0['n']) : str(D['dir'][pu]?['name'] ?? mapv(d['names'])[pu] ?? 'Member');
        toast('✉️', n, str(d['last']), false, 'chat');
      }
    });
    w(col('directory').limit(300), 'dir');

    if (S.canFin) {
      w(L('contributions', 100), 'inc');
      w(L('expenses', 100), 'exp');
    } else if (!S.isGuard && str(me['flat']).isNotEmpty) {
      w(col('contributions').where('flat', isEqualTo: me['flat']).limit(100), 'inc');
    }

    if (S.isAdm) {
      w(col('members').limit(S.sch ? 1000 : 300), 'mem', filter: S.isTeacher ? (o) => {for (final e in o.entries) if (S.memVis(e.value)) e.key: e.value} : null, onNew: (d, t) {
        if (t == added && d['status'] == 'pending' && S.memVis(d)) {
          toast('🙋', d['want'] == 'COMMITTEE_MEMBER' ? 'New teacher request' : d['want'] != null ? 'New staff request' : 'New resident request', '${str(d['name'])} · ${str(d['flat'])}', false, 'join');
        }
      });
      w(L('reports', 50), 'rep');
    }

    w(S.staff ? L('visitors', 100) : F('visitors'), 'vis', onNew: (d, t) {
      if (S.isGuard) {
        if (t == modified && (d['status'] == 'Approved' || d['status'] == 'Denied')) toast(d['status'] == 'Approved' ? '✅' : '⛔', '${str(d['flat'])} ${str(d['status']).toLowerCase()} ${str(d['name'])}', 'Visitor decision', false, 'gate');
      } else {
        if (t == added && d['status'] == 'Waiting') toast('🚪', 'Visitor at the gate', '${str(d['name'])} wants to visit — please approve or deny', false, 'gate');
        if (t == modified && d['status'] == 'Inside') toast('🚪', 'Visitor arrived', '${str(d['name'])} has entered', false, 'gate');
      }
    });
    w(S.staff ? L('deliveries', 100) : F('deliveries'), 'del', onNew: (d, t) {
      if (t == added && !S.staff) toast('📦', 'Parcel received', 'Your ${str(d['courier'])} parcel is at the security desk', false, 'gate');
    });
    w(S.staff ? col('vehicles').limit(300) : col('vehicles').where('uid', isEqualTo: uid).limit(20), 'veh', onNew: (d, t) {
      if (t == added && !S.staff && d['uid'] == uid) toast('🚗', 'Vehicle added', '${str(d['number'])} · added by your admin', false);
    });
    w(col('parking').limit(200), 'park');

    if (S.kind != 'society') {
      w(S.isAdm ? col('leaves').limit(300) : col('leaves').where('uid', isEqualTo: uid).limit(300), 'lv', onNew: (d, t) {
        if (S.isAdm) {
          if (t == added && d['status'] == 'Pending' && d['uid'] != uid) toast('🏖️', 'New leave request', '${str(d['name'])} · ${str(d['from'])} → ${str(d['to'])}', false, 'leave');
        } else if (t == modified && d['uid'] == uid && str(d['status']).isNotEmpty && d['status'] != 'Pending') {
          toast(d['status'] == 'Approved' ? '✅' : '⛔', 'Leave ${str(d['status']).toLowerCase()}', '${str(d['type'])} · ${str(d['from'])} → ${str(d['to'])}', false, 'leave');
        }
      });
      w(S.isOwner ? col('gcomplaints').limit(300) : col('gcomplaints').where('uid', isEqualTo: uid).limit(100), 'gc', onNew: (d, t) {
        if (S.isOwner) {
          if (t == added && d['uid'] != uid) toast('📣', 'New complaint', '${d['anon'] == true ? 'Anonymous student' : str(d['name'])} → ${str(d['againstName'])}', false, 'comp');
        } else if (t == modified && d['uid'] == uid && d['status'] != null) {
          toast('📣', 'Complaint ${str(d['status']).toLowerCase()}', str(d['title']), false, 'comp');
        }
      });
      w(col('holidays').limit(200), 'hol', onNew: (d, t) {
        if (t == added && d['uid'] != uid) toast('🎉', 'New holiday added', '${str(d['title'])} · ${str(d['date'])}', false, 'leave');
      });
    }

    // phase 3: SOS alerts, presence, amenities, bookings, polls, documents, staff, emergency contacts
    w(L('alerts', 20), 'alr', onNew: (d, t) {
      if (t == added && d['uid'] != uid && (S.isAdm || S.isGuard)) toast('🚨', S.kind == 'society' ? 'SOS from ${str(d['flat'])}' : 'SOS from ${str(d['name'])}', S.kind == 'society' ? '${str(d['name'])} needs help!' : '${str(d['flat']).isEmpty ? 'Needs' : '${str(d['flat'])} · needs'} help!', false, 'sos');
    });
    w(col('presence').limit(300), 'pres');
    for (final p in const [['amenities', 'amn'], ['bookings', 'bk'], ['polls', 'pol'], ['documents', 'docu'], ['staff', 'stf'], ['sos', 'sos']]) {
      w(L(p[0], 100), p[1]);
    }

    // phase 4: bills, older online payments, the organisation itself, domestic help, classifieds
    if (!S.isGuard) {
      w(S.isAdm ? col('bills').limit(600) : col('bills').where('flat', isEqualTo: me['flat']).limit(60), 'bills', onNew: (d, t) {
        final n = now();
        if (t == modified && !S.isAdm && d['status'] == 'Unpaid' && d['remindedAt'] != null && n - intv(d['remindedAt']) < 120000) toast('⏰', 'Maintenance reminder', '${billTitle(d)} · ${rs(d['amount'])} is overdue', false, 'bill');
        if (t == added && !S.isAdm && d['status'] == 'Unpaid') toast('🧾', 'New maintenance bill', '${billTitle(d)} · ${rs(d['amount'])}', false, 'bill');
        if (t == modified && !S.isAdm && d['status'] == 'Paid') toast('✅', 'Payment confirmed', 'Receipt ${str(d['receiptNo'])}', false, 'bill');
        if (t == modified && S.isAdm && d['status'] == 'Pending' && d['paidByUid'] != uid && n - intv(d['reportedAt']) < 120000) toast('💸', 'Payment to confirm', '${str(d['flat'])} · ${billTitle(d)} · ${rs(d['amount'])}', false, 'bill');
        if (t == modified && !S.isAdm && d['status'] == 'Unpaid' && d['rejectedAt'] != null && n - intv(d['rejectedAt']) < 120000) {
          toast('⚠️', 'Payment not confirmed', '${billTitle(d)} · ${str(d['rejectNote']).isEmpty ? 'Please check the reference number and report it again' : str(d['rejectNote'])}', false, 'bill');
        }
      });
      w(S.canFin ? col('payments').orderBy('createdAt', descending: true).limit(500) : col('payments').where('userId', isEqualTo: uid).limit(200), 'pay');
    }
    subs.add(socRef().snapshots().listen((s) {
      if (!s.exists || S.soc == null) return;
      final d = s.data()!;
      S.soc!['payout'] = d['payout'];
      if (d['subscription'] != null) S.soc!['subscription'] = d['subscription'];
      if (d['trial'] != null) S.soc!['trial'] = d['trial'];
      if (d['gstin'] != null) S.soc!['gstin'] = d['gstin'];
      D.bump('soc');
    }, onError: (_) {}));
    w(S.staff ? col('helpers').limit(300) : col('helpers').where('uid', isEqualTo: uid).limit(20), 'help');
    w(col('classifieds').limit(150), 'cls');
  }

  static final Map<String, int> _dmT = {};
}

bool isUn(Doc? c) => c != null && str(c['lastFrom']).isNotEmpty && c['lastFrom'] != S.uid && intv(c['lastTs']) > intv(mapv(c['reads'])[S.uid]);

String msgLabel(Doc m) {
  final t = str(m['text']);
  if (t.isNotEmpty) return t;
  final poll = mapv(m['poll']), loc = mapv(m['loc']), file = mapv(m['file']), con = mapv(m['contact']);
  if (m['poll'] != null) return '📊 ${str(poll['q']).isEmpty ? 'Poll' : str(poll['q'])}';
  if (m['loc'] != null && loc['live'] == true) return '📍 Live location';
  if (str(m['voice']).isNotEmpty) return '🎤 Voice message';
  if (m['file'] != null) return '📄 ${str(file['name']).isEmpty ? 'Document' : str(file['name'])}';
  if (m['loc'] != null) return '📍 Location';
  if (m['contact'] != null) return '👤 ${str(con['name']).isEmpty ? 'Contact' : str(con['name'])}';
  if (str(m['img']).isNotEmpty) return '📷 Photo';
  return str(m['stk']).isNotEmpty ? str(m['stk']) : 'Message';
}

String billTitle(Doc? b) {
  final t = str(b?['title']).trim();
  if (t.isNotEmpty) return t;
  final m = str(b?['month']);
  return '${m.isNotEmpty ? '${mname(m)} ' : ''}${S.K.fee}';
}
