import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:geolocator/geolocator.dart';

import 'app.dart';
import 'fs.dart';
import 'kinds.dart';
import 'native.dart';
import 'prefs.dart';
import 'session.dart';
import 'store.dart';
import 'toast.dart';
import 'util.dart';

/// one sharing of a live location: in a chat (cid = private chat, else the community chat) or a school bus trip
class LiveS {
  String lid;
  int until;
  String? cid, bus, trip, geo, gn, gl;
  int t0;
  bool nat;
  LiveS({required this.lid, required this.until, this.cid, this.bus, this.trip, this.geo, this.gn, this.gl, this.t0 = 0, this.nat = false});
  Map<String, dynamic> toJson() => {'lid': lid, 'until': until, 'cid': cid, 'bus': bus, 'trip': trip, 'geo': geo, 'gn': gn, 'gl': gl, 't0': t0, 'nat': nat};
  static LiveS? fromJson(dynamic j) {
    if (j is! Map) return null;
    final m = Map<String, dynamic>.from(j);
    if (str(m['lid']).isEmpty) return null;
    return LiveS(
      lid: str(m['lid']),
      until: intv(m['until']),
      cid: m['cid'] as String?,
      bus: m['bus'] as String?,
      trip: m['trip'] as String?,
      geo: m['geo'] as String?,
      gn: m['gn'] as String?,
      gl: m['gl'] as String?,
      t0: intv(m['t0']),
      nat: m['nat'] == true,
    );
  }
}

/// "Share live location": the Android service does the sending, so it carries on in the background, when the app is
/// closed from recents and when the phone is locked. Without it, this app sends while it is open.
class Live {
  static LiveS? s;
  static StreamSubscription<Position>? _w;
  static Timer? _t;
  static Position? pos, _sent;
  static int _last = 0;

  /// the school bus module tells which bus documents it sees (to notice a trip that was ended on another phone)
  static Doc? Function(String id) busSelf = (_) => null;

  /// shown once: many phones pause background apps unless battery use is set to unrestricted
  static Future<void> Function()? batteryPrompt;

  static String get _key => 'sh-live-${S.sid}-${S.uid}';
  static void _save() {
    if (s != null) Prefs.setJson(_key, s!.toJson());
  }

  static void _drop() => Prefs.del(_key);

  static Future<bool> natStart(LiveS x) async {
    final u = FirebaseAuth.instance.currentUser;
    if (u == null) return false;
    try {
      String tok = '';
      try {
        tok = await u.getIdToken(true) ?? '';
      } catch (_) {
        tok = await u.getIdToken() ?? '';
      }
      if (x.bus != null) {
        final st = await Native.liveStatus().timeout(const Duration(seconds: 4));
        if (st == null || intv(st['v']) < 2) return false;
      }
      await Native.liveStart({
        'project': firebaseProject,
        'apiKey': firebaseAndroidKey,
        'sid': S.sid,
        'uid': S.uid,
        'cid': x.cid ?? '',
        'bus': x.bus ?? '',
        'geo': x.geo ?? '',
        'gn': x.gn ?? '',
        'gl': x.gl ?? '',
        'lid': x.lid,
        'until': '${x.until}',
        'idToken': tok,
        'refreshToken': '',
        'pay': x.bus != null ? payApi : '',
      }).timeout(const Duration(seconds: 6));
      return true;
    } catch (_) {
      return false;
    }
  }

  static void natStop() {
    Native.liveStop().catchError((_) {});
  }

  static Future<void> _battery() async {
    if (Prefs.get('sh-live-bat').isNotEmpty) return;
    try {
      final r = await Native.liveStatus().timeout(const Duration(seconds: 4));
      if (r == null || r['unrestricted'] != false) return;
      Prefs.set('sh-live-bat', '1');
      await Future.delayed(const Duration(milliseconds: 700));
      await batteryPrompt?.call();
    } catch (_) {}
  }

  static void write(Map<String, dynamic> o) {
    final x = s;
    if (x == null || S.sid == null) return;
    final d = {'lid': x.lid, 'until': x.until, 'end': 0, ...o};
    if (x.bus != null) {
      setDoc(dref('buses', x.bus!), {'live': d, if (intv(o['end']) > 0) 'on': false, if (intv(o['end']) > 0) 'endTs': o['end']}, merge: true).catchError((_) {});
      if (intv(o['end']) > 0 && x.trip != null) updateDoc(dref('bustrips', x.trip!), {'end': o['end']}).catchError((_) {});
    } else if (x.cid != null) {
      setDoc(dref('dmchats', x.cid!), {
        'live': {S.uid!: d}
      }, merge: true)
          .catchError((_) {});
    } else {
      App.pset({'live': d});
    }
  }

  /// the newest position is kept and sent at most every 12 seconds
  static void _flush() {
    final x = s;
    if (x == null) return;
    if (now() >= x.until) {
      stop();
      return;
    }
    if (x.bus != null) {
      final bx = busSelf(x.bus!);
      if (bx != null && ((bx['lid'] == x.lid && bx['on'] != true) || (bx['lid'] != x.lid && intv(bx['startTs']) > x.t0))) {
        stop(silent: true);
        natStop();
        return;
      }
    }
    final src = x.bus != null
        ? mapv(busSelf(x.bus!)?['live'])
        : x.cid != null
            ? mapv(mapv(D['dmc'][x.cid]?['live'])[S.uid])
            : mapv(D['pres'][S.uid]?['live']);
    if (src['lid'] == x.lid && intv(src['end']) > 0) {
      stop();
      return;
    }
    final p = pos;
    if (x.nat || p == null || identical(p, _sent) || now() - _last < 12000) return;
    _last = now();
    _sent = p;
    write({'lat': fix6(p.latitude), 'lng': fix6(p.longitude), 'acc': p.accuracy.round(), 'ts': now(), if (x.bus != null) 'spd': p.speed >= 0 ? double.parse(p.speed.toStringAsFixed(1)) : -1});
  }

  static void _watch() {
    _w?.cancel();
    _w = Geolocator.getPositionStream(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 5)).listen((g) {
      pos = g;
      _flush();
    }, onError: (_) {});
  }

  static void _go(bool first) {
    final x = s;
    if (x == null) return;
    _t?.cancel();
    _t = Timer.periodic(const Duration(seconds: 4), (_) => _flush());
    natStart(x).then((ok) {
      if (!identical(s, x)) return;
      x.nat = ok;
      _save();
      if (ok) {
        _w?.cancel();
        _w = null;
        if (first) _battery();
      } else {
        natStop();
        _watch();
      }
    });
  }

  static void start(LiveS x, Position c) {
    final cur = s;
    if (cur != null && cur.bus != null && x.bus == null && now() < cur.until) {
      toast('ℹ️', 'A bus trip is running', 'Your bus keeps sharing its location. Live location in a chat is not available during a trip.');
      return;
    }
    if (cur != null && '${cur.cid ?? ''}|${cur.bus ?? ''}' != '${x.cid ?? ''}|${x.bus ?? ''}') write({'end': now(), 'ts': now()});
    stop(silent: true);
    s = x;
    _save();
    _last = now();
    pos = c;
    _sent = c;
    write({'lat': fix6(c.latitude), 'lng': fix6(c.longitude), 'acc': c.accuracy.round(), 'ts': now()});
    _go(true);
  }

  static void stop({bool silent = false}) {
    _w?.cancel();
    _w = null;
    _t?.cancel();
    _t = null;
    if (s != null && !silent) {
      write({'end': now(), 'ts': now()});
      natStop();
    }
    s = null;
    pos = null;
    _sent = null;
    _drop();
  }

  static Future<void> stopAndWait() async {
    if (s != null) {
      stop();
      await Future.delayed(const Duration(milliseconds: 700));
    } else {
      natStop();
    }
  }

  static void resume() {
    final x = LiveS.fromJson(Prefs.json(_key));
    if (x == null || x.until <= now()) {
      _drop();
      return;
    }
    void go() {
      if (s != null) return;
      s = x;
      _last = 0;
      _go(false);
    }

    if (x.nat) {
      Native.liveStatus().timeout(const Duration(seconds: 4)).then((r) {
        if (r != null && r['lid'] == x.lid) {
          go();
        } else {
          _drop();
        }
      }).catchError((_) => go());
    } else {
      go();
    }
  }
}
