import 'dart:typed_data';

import 'package:flutter/services.dart';

/// The small native Android parts (MainActivity.kt + the Java services).
class Native {
  static const push = MethodChannel('s360/push');
  static const live = MethodChannel('s360/live');
  static const native = MethodChannel('s360/native');

  static Future<Map<String, dynamic>?> _m(MethodChannel c, String m, [Map<String, dynamic>? a]) async {
    final r = await c.invokeMethod<dynamic>(m, a);
    if (r is Map) return r.map((k, v) => MapEntry(k.toString(), v));
    return null;
  }

  /* contact picker: {name, phone} or {cancelled: true} */
  static Future<Map<String, dynamic>?> pickContact() => _m(native, 'pickContact');

  /* saves into Download/Sangam360 -> {uri, name, folder} */
  static Future<Map<String, dynamic>?> saveFile(String name, Uint8List bytes, String mime) => _m(native, 'saveFile', {'name': name, 'bytes': bytes, 'mime': mime});
  static Future<void> openFile(String uri, String mime) async => native.invokeMethod('openFile', {'uri': uri, 'mime': mime});
  static Future<void> openAppSettings() async => native.invokeMethod('openAppSettings');
  static Future<int> sdk() async => (await native.invokeMethod<int>('sdk')) ?? 33;

  /* push */
  static Future<Map<String, dynamic>?> pushRegister() => _m(push, 'register');
  static Future<void> pushSetAuth(Map<String, dynamic> a) async => push.invokeMethod('setAuth', a);
  static Future<void> pushClearAuth() async => push.invokeMethod('clearAuth');
  static Future<Map<String, dynamic>?> pushTakeOpen() => _m(push, 'takeOpen');
  static Future<Map<String, dynamic>?> pushStatus() => _m(push, 'status');
  static Future<void> pushClear(String tag) async => push.invokeMethod('clear', {'tag': tag});

  /* live location service */
  static Future<Map<String, dynamic>?> liveStart(Map<String, dynamic> a) => _m(live, 'start', a);
  static Future<void> liveStop() async => live.invokeMethod('stop', {});
  static Future<Map<String, dynamic>?> liveStatus() => _m(live, 'status', {});
  static Future<void> liveOpenSettings() async => live.invokeMethod('openSettings', {});
}
