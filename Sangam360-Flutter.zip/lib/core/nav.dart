import 'package:flutter/material.dart';

import 'plan.dart';
import 'session.dart';
import 'store.dart';
import 'toast.dart';

/// An open private chat.
class Dm {
  final String cid, peer;
  String name;
  final Map<String, dynamic> sc;
  final Doc seed;
  Dm(this.cid, this.peer, this.name, this.sc, this.seed);
}

/// Which tab / page of the main screen is showing (go("svc:vis"), go("comm") ...).
class Nav extends ChangeNotifier {
  static final Nav I = Nav._();
  Nav._();

  String tab = 'home';
  String sub = 'comp';
  String comm = 'ann'; // ann | chat | inbox
  Dm? dmc;
  String dmFrom = 'inbox';
  int homeAt = 0;

  /// set by the main shell: opens an add-on page ("fx:bus")
  void Function(String key)? openFx;

  List<(String, IconData, String)> navCfg() {
    final K = S.K;
    if (S.isDrv) {
      return [('home', Icons.home_rounded, 'Home'), ('fx:bus', Icons.directions_bus_rounded, 'My bus'), ('fx:veh', Icons.airport_shuttle_rounded, 'Vehicle'), ('svc', Icons.event_available_rounded, 'Duty'), ('more', Icons.person_rounded, 'Me')];
    }
    if (S.isGuard) {
      return [('home', Icons.home_rounded, 'Home'), ('svc:vis', Icons.door_front_door_rounded, 'Visitors'), ('svc:del', Icons.inventory_2_rounded, 'Parcels'), ('svc:veh', Icons.directions_car_rounded, 'Vehicles'), ('svc:help', Icons.cleaning_services_rounded, 'Help'), ('more', Icons.person_rounded, 'Me')];
    }
    String l(String k, String d) => K.nav[k]?[1] ?? d;
    return [
      ('home', Icons.home_rounded, 'Home'),
      ('svc', S.kind == 'school' ? Icons.school_rounded : S.kind == 'company' ? Icons.work_rounded : Icons.handyman_rounded, l('svc', 'Services')),
      ('comm', Icons.forum_rounded, l('comm', 'Community')),
      ('fin', S.kind == 'society' ? Icons.account_balance_wallet_rounded : Icons.receipt_long_rounded, l('fin', 'Finance')),
      ('more', S.isAdm ? Icons.groups_rounded : Icons.person_rounded, S.isAdm ? 'People' : 'Me'),
      if (S.isMgr) ('sub', Icons.workspace_premium_rounded, 'Plan'),
    ];
  }

  static const subsBase = {'comp': 'Complaints', 'vis': 'Visitors', 'del': 'Parcels', 'veh': 'Vehicles', 'park': 'Parking', 'help': 'Domestic help', 'mkt': 'Classifieds'};
  Map<String, String> subsK() => {
        'att': 'Attendance',
        'leave': 'Leave',
        'room': 'Meetings',
        'tt': 'Timetable',
        'hol': 'Holidays',
        'hw': 'Homework',
        'gc': S.kind == 'school' ? 'Conduct' : 'Grievances',
        ...subsBase,
        ...S.K.subs,
      };
  List<String> subList() {
    if (S.isDrv) return ['att', 'leave', 'hol'];
    if (S.isGuard) return ['vis', 'del', 'veh', 'help'];
    if (S.kind != 'society') return S.K.subList;
    return ['comp', 'vis', 'del', 'veh', 'park', 'help', 'mkt'];
  }

  void go(String key) {
    final k = key.split(':');
    if (k[0] == 'fx') {
      if (PlanSt.locked) {
        PlanSt.lockNudge();
        return;
      }
      openFx?.call(k[1]);
      return;
    }
    if (k.length > 1) sub = k[1];
    goTab(k[0]);
  }

  void goTab(String t) {
    if (PlanSt.locked && t != 'home' && !(t == 'sub' && S.isMgr)) {
      if (t != tab) PlanSt.lockNudge();
      t = 'home';
    }
    if (t == 'sub' && !S.isMgr) t = 'home';
    if (t == 'home') homeAt = DateTime.now().millisecondsSinceEpoch;
    tab = t;
    if (t == 'svc' && !subList().contains(sub)) sub = subList().first;
    notifyListeners();
  }

  void setSub(String s) {
    sub = subList().contains(s) ? s : subList().first;
    notifyListeners();
  }

  void setComm(String v) {
    comm = v;
    notifyListeners();
  }

  void touch() => notifyListeners();

  void reset() {
    tab = 'home';
    sub = 'comp';
    comm = 'ann';
    dmc = null;
  }
}

final nav = Nav.I;

/// a pop-up that says "locked" and a tap that opens the plan
void stickPlan() => Toasts.I.stickLast(() => nav.go('sub'));
