import 'dart:typed_data';

import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import 'kinds.dart';
import 'listen.dart';
import 'plan.dart';
import 'session.dart';
import 'store.dart';
import 'util.dart';

/* ===== receipts and invoices as PDF (border, watermark, gradient header, amount box with a stamp, table, boxes) ===== */

pw.Font? _f4, _f5, _f6, _f7, _f8;
Uint8List? _logo;

Future<void> _fonts() async {
  if (_f4 != null) return;
  Future<pw.Font> l(String w) async => pw.Font.ttf(await rootBundle.load('assets/fonts/PlusJakartaSans-$w.ttf'));
  _f4 = await l('400');
  _f5 = await l('500');
  _f6 = await l('600');
  _f7 = await l('700');
  _f8 = await l('800');
  try {
    _logo = (await rootBundle.load('assets/images/mark.png')).buffer.asUint8List();
  } catch (_) {}
}

PdfColor _pc(int argb) => PdfColor.fromInt(argb);

class PdfDoc {
  final Uint8List bytes;
  final String name;
  const PdfDoc(this.bytes, this.name);
}

/// The name of a receipt / invoice file is made only from its own number (never from an attached bill document).
String pdfName(String base, [Doc? b]) {
  String cl(String x) => x.replaceAll(RegExp(r'\.[A-Za-z0-9]{1,5}$'), '').replaceAll(RegExp(r'[^\w-]+'), '-').replaceAll(RegExp(r'^-+|-+$'), '');
  var n = cl('$base.pdf');
  if (n.isEmpty) n = 'document';
  final bill = b != null && b['id'] != null ? D['bills'][b['id']] : null;
  final dn = cl(str(b?['docName'] ?? bill?['docName']));
  if (dn.isNotEmpty && dn.toLowerCase() == n.toLowerCase()) n += '-paid';
  return '$n.pdf';
}

String invNo(Doc b) {
  final id = str(b['id'] ?? b['flat']).replaceAll(RegExp('[^A-Za-z0-9]'), '');
  return 'INV-${str(b['month']).replaceAll('-', '')}-${(id.length > 8 ? id.substring(id.length - 8) : id).toUpperCase()}';
}

class InvOpt {
  final String no;
  final bool paid, brand;
  final List<List<String>> rows;
  final String desc;
  const InvOpt({required this.no, required this.paid, required this.rows, this.brand = false, this.desc = ''});
}

InvOpt billInv(Doc b) {
  final mem = D['mem'].values.where((x) => x['flat'] == b['flat'] && x['status'] == 'approved');
  final who = str(b['paidBy']).isNotEmpty
      ? str(b['paidBy'])
      : mem.isNotEmpty
          ? str(mem.first['name'])
          : (S.me?['flat'] == b['flat'] ? str(S.me?['name']) : '');
  final rows = [
    ['Invoice no.', invNo(b)],
    ['Invoice date', bdate(intv(b['ts']) > 0 ? b['ts'] : now())],
    ['Billed to', who.isNotEmpty ? '$who · ${str(b['flat'])}' : str(b['flat'])],
    ['Description', billTitle(b)],
    ['Amount', rs(b['amount'])],
    ['Due date', bdate(b['due'])],
  ];
  if (S.socGst().isNotEmpty) rows.add(['Supplier GSTIN', S.socGst()]);
  rows.add([
    'Status',
    b['status'] == 'Paid'
        ? 'Paid on ${bdate(b['paidAt'])}'
        : b['status'] == 'Pending'
            ? 'Awaiting confirmation'
            : 'Unpaid'
  ]);
  return InvOpt(no: invNo(b), paid: b['status'] == 'Paid', rows: rows);
}

/// the invoice for a Sangam360 plan (v = a plan payment as the payment server returns it)
InvOpt planInv(Doc v) {
  final d = dtOf(intv(v['paidAt']) > 0 ? v['paidAt'] : (intv(v['createdAt']) > 0 ? v['createdAt'] : now()));
  final pid = str(v['paymentId']);
  final no = str(v['invoiceId']).isNotEmpty ? str(v['invoiceId']) : 'S360-${d.year}${p2(d.month)}${p2(d.day)}-${(pid.length > 6 ? pid.substring(pid.length - 6) : pid).toUpperCase()}';
  final pl = PlanSt.list().where((p) => p.id == v['plan']);
  final nm = str(v['planName']).isNotEmpty ? str(v['planName']) : (pl.isNotEmpty ? pl.first.name : '');
  final cy = v['cycle'] == 'y'
      ? '1 year'
      : v['cycle'] == 'm'
          ? '30 days'
          : '';
  final desc = nm.isNotEmpty ? '$brand $nm plan${cy.isNotEmpty ? ' · $cy' : ''}' : (str(v['description']).isNotEmpty ? str(v['description']) : '$brand plan');
  final cf = intv(v['carriedDays']) > 0 && intv(v['days']) > 0;
  final rows = <List<String>>[
    ['Invoice no.', no],
    ['Invoice date', bdate(d.millisecondsSinceEpoch)],
    cf ? ['Validity', '${v['days']} new days + ${v['carriedDays']} carried forward = ${intv(v['days']) + intv(v['carriedDays'])} days'] : ['Billed to', str(v['organisationName']).isNotEmpty ? str(v['organisationName']) : str(S.soc?['name'])],
    ['Description', desc],
  ];
  if (intv(v['periodStart']) > 0 && intv(v['periodEnd']) > 0) rows.add(['Plan valid', '${bdate(v['periodStart'])} – ${bdate(v['periodEnd'])}']);
  rows.addAll([
    ['Amount paid', rs(v['amount'])],
    ['Payment method', payMeth(v['paymentMethod']).isNotEmpty ? payMeth(v['paymentMethod']) : 'Online (Razorpay)'],
    ['Razorpay payment ID', str(v['razorpayPaymentId'])],
  ]);
  return InvOpt(no: no, paid: true, rows: rows, brand: true, desc: desc);
}

/// a receipt of a paid bill (inv == null) or an invoice
Future<PdfDoc> receiptPdf(Doc b, [InvOpt? inv]) async {
  await _fonts();
  final iv = inv != null, br = inv?.brand == true;
  final K = S.K, soc = S.soc ?? {};
  final pur = _pc(K.c1.value), blu = _pc(K.rc.value);
  final org = S.isOrg && !br;
  final hb = org ? (str(soc['name']).isEmpty ? brand : str(soc['name'])) : brand;
  final ht = org ? [str(soc['city']), str(soc['state'])].where((x) => x.isNotEmpty).join(', ') : K.tag;
  final rows = iv
      ? inv!.rows
      : [
          ['Receipt no.', str(b['receiptNo'])],
          ['Date of payment', bdate(b['paidAt'])],
          [K.unit, str(b['flat'])],
          ['${K.person} name', str(b['paidBy']).isNotEmpty ? str(b['paidBy']) : (S.me?['flat'] == b['flat'] ? str(S.me?['name']) : '')],
          ['Payment for', billTitle(b)],
          ['Amount paid', rs(b['amount'])],
          if (b['gateway'] == 'razorpay') ...[
            ['Payment method', payMeth(b['payMethod'])],
            ['Online payment ID', str(b['utr'])],
          ] else ...[
            ['Reference no. (UTR)', [str(b['utr']), payMeth(b['payMethod'])].where((x) => x.isNotEmpty).join(' · ')],
            ['Confirmed by', str(b['confirmedBy'])],
          ],
        ];
  final unpaid = iv && !inv!.paid;
  final stampC = unpaid ? _pc(0xFFDC2626) : _pc(0xFF16A34A);
  const ink = PdfColor.fromInt(0xFF1B1740), mut = PdfColor.fromInt(0xFF6B6890), lav = PdfColor.fromInt(0xFFD9D5F5);
  pw.TextStyle t(pw.Font f, double s, PdfColor c) => pw.TextStyle(font: f, fontSize: s, color: c);
  final addr = [str(soc['address']), str(soc['city']), str(soc['state']), str(soc['pin'])].where((x) => x.isNotEmpty).join(', ');
  final doc = pw.Document(title: iv ? 'Invoice ${inv!.no}' : 'Payment receipt ${str(b['receiptNo'])}', author: brand);
  final logoImg = _logo == null ? null : pw.MemoryImage(_logo!);
  doc.addPage(pw.Page(
    pageFormat: PdfPageFormat.a4,
    margin: pw.EdgeInsets.zero,
    build: (ctx) => pw.Stack(children: [
      pw.Positioned.fill(child: pw.Container(margin: const pw.EdgeInsets.all(14), decoration: pw.BoxDecoration(border: pw.Border.all(color: pur, width: 3)))),
      pw.Positioned.fill(child: pw.Container(margin: const pw.EdgeInsets.all(22), decoration: pw.BoxDecoration(border: pw.Border.all(color: const PdfColor.fromInt(0xFFCFC8F7), width: 1)))),
      pw.Positioned.fill(
        child: pw.Center(
          child: pw.Transform.rotate(
            angle: 0.6,
            child: pw.Opacity(
              opacity: .07,
              child: pw.Column(mainAxisSize: pw.MainAxisSize.min, children: [
                pw.Text(hb.toUpperCase(), style: t(_f8!, hb.length > 14 ? 40 : 70, pur)),
                pw.SizedBox(height: 16),
                pw.Text(iv ? (br ? 'INVOICE' : 'TAX INVOICE') : 'OFFICIAL PAYMENT RECEIPT', style: t(_f6!, 26, pur)),
              ]),
            ),
          ),
        ),
      ),
      pw.Padding(
        padding: const pw.EdgeInsets.all(22),
        child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.stretch, children: [
          pw.Container(
            height: 102,
            padding: const pw.EdgeInsets.symmetric(horizontal: 22),
            decoration: pw.BoxDecoration(gradient: pw.LinearGradient(colors: [pur, blu])),
            child: pw.Row(children: [
              org || logoImg == null
                  ? pw.Container(width: 58, height: 58, decoration: pw.BoxDecoration(color: PdfColors.white, borderRadius: pw.BorderRadius.circular(12)), alignment: pw.Alignment.center, child: pw.Text(hb.trim().isEmpty ? '•' : hb.trim()[0].toUpperCase(), style: t(_f8!, 34, pur)))
                  : pw.ClipRRect(horizontalRadius: 12, verticalRadius: 12, child: pw.Image(logoImg, width: 58, height: 58)),
              pw.SizedBox(width: 14),
              pw.Expanded(
                child: pw.Column(mainAxisAlignment: pw.MainAxisAlignment.center, crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                  pw.Text(hb, maxLines: 1, style: t(_f8!, 24, PdfColors.white)),
                  pw.SizedBox(height: 3),
                  pw.Text(ht, maxLines: 1, style: t(_f5!, 11, const PdfColor(1, 1, 1, .9))),
                ]),
              ),
              pw.Column(mainAxisAlignment: pw.MainAxisAlignment.center, crossAxisAlignment: pw.CrossAxisAlignment.end, children: [
                pw.Text(iv ? 'INVOICE' : 'PAYMENT RECEIPT', style: t(_f7!, 17, PdfColors.white)),
                pw.SizedBox(height: 6),
                pw.Text(iv ? 'Invoice no. ${inv!.no}' : 'No. ${str(b['receiptNo']).isEmpty ? '—' : str(b['receiptNo'])}', style: t(_f5!, 11, PdfColors.white)),
              ]),
            ]),
          ),
          pw.Padding(
            padding: const pw.EdgeInsets.fromLTRB(22, 18, 22, 0),
            child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              if (br) pw.Text('BILLED TO', style: t(_f6!, 9.5, mut)),
              pw.Text(cut(str(soc['name']), 38), style: t(_f7!, 20, ink)),
              pw.SizedBox(height: 3),
              pw.Text(cut(addr, 80), style: t(_f5!, 11, mut)),
              if (S.socGst().isNotEmpty) pw.Padding(padding: const pw.EdgeInsets.only(top: 3), child: pw.Text('GSTIN: ${S.socGst()}', style: t(_f7!, 11, ink))),
              pw.SizedBox(height: 14),
              pw.Container(
                height: 76,
                padding: const pw.EdgeInsets.symmetric(horizontal: 18),
                decoration: pw.BoxDecoration(color: const PdfColor.fromInt(0xFFF3F1FF), borderRadius: pw.BorderRadius.circular(10), border: pw.Border.all(color: lav)),
                child: pw.Row(children: [
                  pw.Expanded(
                    child: pw.Column(mainAxisAlignment: pw.MainAxisAlignment.center, crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                      pw.Text(iv ? 'INVOICE AMOUNT' : 'AMOUNT RECEIVED', style: t(_f6!, 11, mut)),
                      pw.Text(rs(b['amount']), style: t(_f8!, 34, pur)),
                    ]),
                  ),
                  pw.Transform.rotate(
                    angle: .18,
                    child: pw.Container(
                      padding: const pw.EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                      decoration: pw.BoxDecoration(border: pw.Border.all(color: stampC, width: 3), borderRadius: pw.BorderRadius.circular(7)),
                      child: pw.Text(unpaid ? 'UNPAID' : 'PAID', style: t(_f8!, unpaid ? 22 : 26, stampC)),
                    ),
                  ),
                  pw.SizedBox(width: 14),
                ]),
              ),
              pw.SizedBox(height: 20),
              pw.Table(
                border: pw.TableBorder.all(color: lav, width: 1),
                columnWidths: const {0: pw.FixedColumnWidth(170), 1: pw.FlexColumnWidth()},
                children: [
                  for (final r in rows)
                    pw.TableRow(children: [
                      pw.Container(color: const PdfColor.fromInt(0xFFF7F6FD), padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: rows.length > 9 ? 9 : 12), child: pw.Text(r[0], style: t(_f6!, 11, mut))),
                      pw.Container(padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: rows.length > 9 ? 9 : 12), child: pw.Text(r[1].isEmpty ? '—' : r[1], style: t(_f7!, 12, ink))),
                    ]),
                ],
              ),
              pw.SizedBox(height: 18),
              pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                for (final (i, x) in ['Remarks / Notes', br ? 'For $brand · authorised signatory' : 'Authorised signatory & ${K.word} stamp'].indexed) ...[
                  if (i == 1) pw.SizedBox(width: 16),
                  pw.Expanded(
                    child: pw.Container(
                      height: rows.length > 7 ? 86 : 104,
                      padding: const pw.EdgeInsets.all(10),
                      decoration: pw.BoxDecoration(border: pw.Border.all(color: const PdfColor.fromInt(0xFF9D93EE), width: 1.2), borderRadius: pw.BorderRadius.circular(8)),
                      child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, mainAxisAlignment: pw.MainAxisAlignment.end, children: [
                        if (i == 0)
                          pw.Expanded(
                            child: pw.Column(mainAxisAlignment: pw.MainAxisAlignment.spaceEvenly, children: [
                              for (var k = 0; k < (rows.length > 7 ? 2 : 3); k++) pw.Container(height: .7, color: const PdfColor.fromInt(0xFFE4E0FA)),
                            ]),
                          ),
                        pw.Text(x, style: t(_f6!, 9.5, mut)),
                      ]),
                    ),
                  ),
                ],
              ]),
            ]),
          ),
          pw.Spacer(),
          pw.Center(child: pw.Text('This is a computer-generated ${iv ? 'invoice' : 'receipt'} and is valid without a physical signature.', style: t(_f5!, 9.5, mut))),
          pw.SizedBox(height: 4),
          pw.Center(child: pw.Text(org ? hb : 'Generated with $brand', style: t(_f7!, 9.5, pur))),
          pw.SizedBox(height: 14),
        ]),
      ),
    ]),
  ));
  final bytes = await doc.save();
  return PdfDoc(bytes, pdfName(iv ? 'Invoice-${inv!.no.isEmpty ? 'bill' : inv!.no}' : 'Payment-Receipt-${str(b['receiptNo']).isEmpty ? 'payment' : str(b['receiptNo'])}', b));
}

/// a plain table report (CSV-like) as a PDF — used for exports that people want to print
Future<Uint8List> tablePdf(String title, List<String> head, List<List<String>> rows) async {
  await _fonts();
  final doc = pw.Document(title: title, author: brand);
  doc.addPage(pw.MultiPage(
    pageFormat: PdfPageFormat.a4.landscape,
    margin: const pw.EdgeInsets.all(24),
    build: (_) => [
      pw.Text(title, style: pw.TextStyle(font: _f8, fontSize: 16)),
      pw.SizedBox(height: 8),
      pw.TableHelper.fromTextArray(headers: head, data: rows, headerStyle: pw.TextStyle(font: _f7, fontSize: 9), cellStyle: pw.TextStyle(font: _f4, fontSize: 8.5), headerDecoration: const pw.BoxDecoration(color: PdfColor.fromInt(0xFFF1F0FB))),
    ],
  ));
  return doc.save();
}

/// fonts for other PDF makers (report cards)
Future<(pw.Font, pw.Font, pw.Font, pw.Font)> pdfFonts() async {
  await _fonts();
  return (_f5!, _f6!, _f7!, _f8!);
}

Uint8List? pdfLogo() => _logo;
