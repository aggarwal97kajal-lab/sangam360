import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import '../ui/kit.dart';
import '../ui/sheets.dart';
import '../ui/theme.dart';
import 'kinds.dart';
import 'prefs.dart';
import 'session.dart';
import 'toast.dart';
import '../l10n/l10n.dart';

/* ===== permissions: a first-run list + asking again only when a feature needs it ===== */
class PermInfo {
  final String ico, nameE, whyE;
  final Permission p;
  const PermInfo(this.ico, this.nameE, this.whyE, this.p);
  String get name => tr(nameE);
  String get why => tr(whyE);
}

final perms = <String, PermInfo>{
  'mic': PermInfo('🎤', 'Microphone', 'Send voice notes in chat', Permission.microphone),
  'cam': PermInfo('📷', 'Camera', 'Scan visitor QR codes and take photos', Permission.camera),
  'loc': PermInfo('📍', 'Location', 'Share your location in chat', Permission.locationWhenInUse),
  'note': PermInfo('🔔', 'Notifications', 'Get alerts for visitors, chats, bills and SOS', Permission.notification),
};

bool pHint(String k) => Prefs.get('sh-perm-$k') == '1';

Future<bool> askPerm(String k) async {
  final P = perms[k]!;
  var st = await P.p.status;
  if (st.isGranted || st.isLimited) {
    Prefs.set('sh-perm-$k', '1');
    return true;
  }
  if (st.isPermanentlyDenied) {
    await _blocked(P);
    return false;
  }
  st = await P.p.request();
  if (st.isGranted || st.isLimited) {
    Prefs.set('sh-perm-$k', '1');
    return true;
  }
  Prefs.set('sh-perm-$k', '0');
  if (st.isPermanentlyDenied) {
    await _blocked(P);
  } else {
    toast('ℹ️', trf('{0} not allowed', [P.name]), tr('You can allow it any time you use this feature.'));
  }
  return false;
}

Future<void> _blocked(PermInfo P) async {
  final c = rootCtx;
  if (c == null) return;
  final go = await confirmDlg(c, trf('This app is not allowed to use the {0}. To {1}, open the app settings → Permissions, set {2} to Allow, then try again.', [P.name.toLowerCase(), P.why.toLowerCase(), P.name]), ok: tr('Open settings'), title: trf('{0} {1} is blocked', [P.ico, P.name]));
  if (go) await openAppSettings();
}

/// shown once after the first sign-in
Future<void> firstRunPerms(BuildContext context) async {
  if (Prefs.get('sh-perm-asked') == '1') return;
  Prefs.set('sh-perm-asked', '1');
  await sheet(context, (ctx) => const _PermList());
}

class _PermList extends StatefulWidget {
  const _PermList();
  @override
  State<_PermList> createState() => _PermListState();
}

class _PermListState extends State<_PermList> {
  final Map<String, bool> ok = {};
  @override
  void initState() {
    super.initState();
    for (final k in perms.keys) {
      perms[k]!.p.status.then((s) {
        if (mounted) setState(() => ok[k] = s.isGranted);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
       SheetTitle('Permissions', sub: trf(S.skE('{0} works best with these. You can skip any of them — we ask again only when a feature needs it.'), [brand])),
      for (final e in perms.entries)
        Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: p.card2, borderRadius: BorderRadius.circular(16)),
          child: Row(children: [
            Text(e.value.ico, style: const TextStyle(fontSize: 24)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(e.value.name, style: h3()), Text(e.value.why, style: meta())])),
            ok[e.key] == true
                ? Text(tr('✅ Allowed'), style: TextStyle(color: p.green, fontWeight: FontWeight.w700, fontSize: 13))
                : mini(tr('Allow'), () async {
                    final r = await askPerm(e.key);
                    if (mounted) setState(() => ok[e.key] = r);
                  }),
          ]),
        ),
      const SizedBox(height: 6),
      Row2(
        Btn.o(tr('Not now'), onTap: () => Navigator.pop(context)),
        Btn(tr('Allow all'), onTap: () async {
          for (final k in perms.keys) {
            if (ok[k] != true) {
              final r = await askPerm(k);
              if (mounted) setState(() => ok[k] = r);
            }
          }
          if (mounted) Navigator.pop(context);
        }),
      ),
    ]);
  }
}
