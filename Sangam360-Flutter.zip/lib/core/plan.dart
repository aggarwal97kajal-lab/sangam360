import 'package:flutter/material.dart';

import 'api.dart';
import 'kinds.dart';
import 'prefs.dart';
import 'session.dart';
import 'store.dart';
import 'toast.dart';
import 'util.dart';

/// the state of the organisation's plan: a paid plan, the 14-day free trial, or locked.
/// The trial dates are written by the server into societies/{sid}.trial (counted from the day the creator signed up).
class PlanState {
  final String kind; // paid | trial | locked | unknown
  final Plan? p;
  final int until, left;
  final String why; // expired | trial
  const PlanState(this.kind, {this.p, this.until = 0, this.left = 0, this.why = ''});
}

class PlanSt {
  static List<Plan> list() => planOrg[S.kind] ?? plansSoc;
  static List<Plan> paid() => list().where((p) => p.m > 0 || p.cu).toList();

  /// plan and billing cycle of the organisation (as recorded by the server)
  static (Doc, Plan?, String?) info() {
    final soc = S.soc ?? {};
    final sub = mapv(soc['subscription']);
    final ls = Prefs.json('sh-plan-${S.sid}');
    final lsm = ls is Map ? Map<String, dynamic>.from(ls) : <String, dynamic>{};
    final pid = str(sub['plan'] ?? sub['planId'] ?? sub['planName'] ?? soc['plan'] ?? lsm['plan']).toLowerCase();
    Plan? p;
    for (final x in list()) {
      if (x.id == pid || x.name.toLowerCase() == pid) p = x;
    }
    String? cy;
    final raw = str(sub['cycle'] ?? sub['billing'] ?? sub['interval'] ?? sub['period'] ?? sub['term'] ?? soc['planCycle'] ?? soc['cycle']).toLowerCase();
    if (RegExp(r'^(y|annual|year)').hasMatch(raw)) {
      cy = 'y';
    } else if (RegExp(r'^(m|month)').hasMatch(raw)) {
      cy = 'm';
    }
    if (cy == null && numv(sub['days']) > 0) cy = numv(sub['days']) >= 300 ? 'y' : 'm';
    if (cy == null) {
      final st = intv(sub['start'] ?? sub['since'] ?? sub['startedAt'] ?? sub['paidAt'] ?? sub['lastPaid'] ?? 0);
      if (st > 0 && sub['until'] != null) cy = (intv(sub['until']) - st) / dayMs >= 300 ? 'y' : 'm';
    }
    if (cy == null && lsm['cycle'] != null && p != null && lsm['plan'] == p.id) cy = str(lsm['cycle']);
    return (sub, p, cy);
  }

  static PlanState state() {
    final soc = S.soc ?? {};
    final sub = mapv(soc['subscription']);
    final tr = soc['trial'] is Map ? mapv(soc['trial']) : null;
    final n = now(), until = intv(sub['until']);
    Plan? p;
    try {
      p = info().$2;
    } catch (_) {}
    if (until > n) return PlanState('paid', p: p != null && (p.m > 0 || p.cu) ? p : null, until: until, left: ((until - n) / dayMs).ceil());
    final te = tr == null ? 0 : intv(tr['endsAt']);
    if (te > n) return PlanState('trial', until: te, left: ((te - n) / dayMs).ceil());
    if (te > 0) return PlanState('locked', why: until > 0 ? 'expired' : 'trial', until: te > until ? te : until);
    return const PlanState('unknown');
  }

  static bool get locked {
    try {
      return S.me != null && S.soc != null && state().kind == 'locked';
    } catch (_) {
      return false;
    }
  }

  static String name() {
    try {
      final st = state();
      return st.kind == 'paid' ? (st.p?.name ?? 'Active') : st.kind == 'locked' ? (st.why == 'expired' ? 'Plan expired' : 'Trial ended') : 'Free trial';
    } catch (_) {
      return 'Free trial';
    }
  }

  static (String, Color) tier(Plan? p) {
    if (p == null) return ('⭐', S.K.c1);
    if (p.cu) return (ptier[4][0] as String, ptier[4][1] as Color);
    final l = list().where((x) => x.m > 0).toList()..sort((a, b) => a.m.compareTo(b.m));
    final i = l.indexWhere((x) => x.id == p.id);
    final t = ptier[i < 0 ? 0 : (i > 3 ? 3 : i)];
    return (t[0] as String, t[1] as Color);
  }

  static void lockNudge() {
    final st = state();
    toast('🔒', st.why == 'expired' ? 'Your plan has expired' : 'Your trial period has ended', S.isMgr ? 'Kindly upgrade to continue.' : 'Kindly ask your admin to upgrade.');
  }

  /// asks the server once per organisation to record when its free trial started
  static String _trialAsk = '';
  static Future<void> ensure(VoidCallback changed) async {
    if (payApi.isEmpty || S.sid == null || S.soc == null) return;
    final tr = mapv(S.soc!['trial']);
    if (tr['by'] == 'server' && tr['v'] == 2 && intv(tr['endsAt']) > 0) return;
    if (_trialAsk == S.sid) return;
    _trialAsk = S.sid!;
    final sid = S.sid;
    try {
      final r = await api('/v1/orgs/trial', {'sid': sid});
      if (S.sid != sid || S.soc == null || r['trial'] == null) return;
      S.soc!['trial'] = r['trial'];
      changed();
    } catch (_) {
      _trialAsk = '';
    }
  }

  static int unitsN() {
    if (S.isOrg) {
      final n = D['mem'].values.where((x) => x['status'] == 'approved').length;
      return n == 0 ? 1 : n;
    }
    return flats().length;
  }
}

/// the flats of a society ("Tower A · Flat 203" or "Flat 203")
List<String> flats() {
  final tw = listv(S.soc?['towers']).map(mapv).toList();
  final one = tw.length == 1, r = <String>[];
  for (final t in tw) {
    for (final l in gF(t, one)) {
      r.add('${one ? '' : '${str(t['name'])} · '}Flat $l');
    }
  }
  return r;
}

/// flat numbers of a tower: floor 2, flat 3 -> 203
List<String> gF(Map<String, dynamic> t, bool one) {
  final r = <String>[];
  final floors = intv(t['floors']), per = intv(t['perFloor']);
  for (var f = 1; f <= floors; f++) {
    for (var n = 1; n <= per; n++) {
      final l = '$f${n.toString().padLeft(2, '0')}';
      r.add(one ? l : '${str(t['name'])}-$l');
    }
  }
  return r;
}
