import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

/// What the earlier app kept in localStorage: kept on this phone only.
class Prefs {
  static late SharedPreferences _p;
  static Future<void> init() async {
    _p = await SharedPreferences.getInstance();
  }

  static String get(String k, [String d = '']) {
    try {
      return _p.getString(k) ?? d;
    } catch (_) {
      return d;
    }
  }

  static void set(String k, String v) {
    try {
      _p.setString(k, v);
    } catch (_) {}
  }

  static void del(String k) {
    try {
      _p.remove(k);
    } catch (_) {}
  }

  static bool has(String k) {
    try {
      return _p.containsKey(k);
    } catch (_) {
      return false;
    }
  }

  static dynamic json(String k) {
    final s = get(k);
    if (s.isEmpty) return null;
    try {
      return jsonDecode(s);
    } catch (_) {
      return null;
    }
  }

  static void setJson(String k, dynamic v) => set(k, jsonEncode(v));

  static Iterable<String> keys() {
    try {
      return _p.getKeys();
    } catch (_) {
      return const [];
    }
  }
}
