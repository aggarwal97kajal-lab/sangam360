import 'package:flutter/services.dart';

import 'api.dart';
import 'kinds.dart';
import 'native.dart';
import 'session.dart';
import 'toast.dart';
import 'util.dart';

/* The Android app's notifications. The server is told this phone's push token and what is muted on it; the phone
   keeps a key with which "Reply" in a chat notification can send the answer. */
class Push {
  static String _reg = '', token = '';
  static bool _lis = false;
  static void Function(String open, String sid)? onOpen;

  static String get _key => '${S.sid}|${S.uid}|${Mute.all ? 1 : 0}|${(Mute.kinds.toList()..sort()).join(',')}';

  static Future<void> setup({bool force = false}) async {
    if (payApi.isEmpty || S.me == null || S.sid == null || S.uid == null) return;
    final k = _key;
    if (!force && _reg == k) return;
    _reg = k;
    if (!_lis) {
      _lis = true;
      Native.push.setMethodCallHandler((c) async {
        if (c.method == 'open') {
          final a = c.arguments is Map ? Map<String, dynamic>.from(c.arguments as Map) : <String, dynamic>{};
          onOpen?.call(str(a['open']), str(a['sid']));
        }
        return null;
      });
    }
    try {
      final t = await Native.pushRegister();
      if (t == null || str(t['token']).isEmpty) {
        _reg = '';
        return;
      }
      token = str(t['token']);
      final r = await api('/v1/push/register', {'sid': S.sid, 'token': token, 'mute': {'all': Mute.all, 'kinds': Mute.kinds.toList()}, 'name': str(S.me?['name'])}, 90000);
      await Native.pushSetAuth({'server': payApi, 'device': str(r['device']), 'key': str(r['key']), 'sid': S.sid, 'uid': S.uid, 'name': str(S.me?['name'])});
    } on PlatformException catch (_) {
      _reg = '';
    } catch (_) {
      _reg = '';
    }
  }

  /// on log-out this phone stops getting the person's notifications
  static Future<void> off() async {
    try {
      if (token.isNotEmpty && payApi.isNotEmpty) await api('/v1/push/unregister', {'token': token}, 8000);
    } catch (_) {}
    try {
      await Native.pushClearAuth();
    } catch (_) {}
    _reg = '';
  }

  /// a tapped notification opens its screen
  static Future<void> take() async {
    if (S.me == null) return;
    try {
      final o = await Native.pushTakeOpen();
      if (o != null && str(o['open']).isNotEmpty) onOpen?.call(str(o['open']), str(o['sid']));
    } catch (_) {}
  }

  static String _clr = '';

  /// the conversation is on screen: its notification goes
  static void clear(String tag) {
    if (tag.isEmpty || _clr == tag) return;
    _clr = tag;
    Future.delayed(const Duration(seconds: 4), () {
      if (_clr == tag) _clr = '';
    });
    Native.pushClear(tag).catchError((_) {});
  }
}
