import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'kinds.dart';
import 'prefs.dart';
import 'store.dart';
import 'util.dart';
import '../l10n/l10n.dart';

enum Phase { splash, land, auth, choice, create, join, wait, main }

/// S: who is signed in, the organisation (soc) and the member record in use (me).
class Session extends ChangeNotifier {
  static final Session I = Session._();
  Session._() {
    final k = Prefs.get('sh-kind');
    kind = kinds.containsKey(k) ? k : 'society';
  }

  Phase phase = Phase.splash;
  User? user;
  String? uid;
  String? sid;
  Doc? soc;
  Doc? me;

  /// the login's own (first) profile, when a parent uses the profile of a 2nd / 3rd student
  Doc? prim;

  /// the profile in use (uid, or uid_k2 ...)
  String? pid;
  List<Doc> kids = [];
  String kind = 'society';
  bool isSuper = false;

  /// counts the starts of the main screen (a new start rebuilds it)
  int startN = 0;

  /* the waiting screen */
  String waitTitle = 'Loading…';
  String waitText = '';
  bool waitRetry = false;
  bool waitSwitch = false;

  /* sign-in */
  String? loginKind;
  String authMsg = '';
  bool addMode = false; // "Create / Join another" from inside the app

  void go(Phase p) {
    phase = p;
    notifyListeners();
  }

  void touch() => notifyListeners();

  KindCfg get K => kinds[kind] ?? kinds['society']!;

  void setKind(String k) {
    if (!kinds.containsKey(k)) k = 'society';
    kind = k;
    Prefs.set('sh-kind', k);
    _skin = null;
    notifyListeners();
  }

  /* ---------- roles ---------- */
  String get role => str(me?['role']);
  bool get isOwner => role == 'SOCIETY_ADMIN';
  bool get isGuard => role == 'SECURITY_GUARD';
  bool get isAdm => role == 'SOCIETY_ADMIN' || role == 'COMMITTEE_MEMBER';
  bool get canFin => isAdm || role == 'ACCOUNTANT';
  bool get staff => isGuard || isAdm;
  bool get isMgr => isOwner;
  bool get isCreator => soc != null && str(soc!['adminUid']).isNotEmpty && soc!['adminUid'] == uid;
  bool get sch => kind == 'school';
  bool get isOrg => kind != 'society';
  bool get isTeacher => sch && role == 'COMMITTEE_MEMBER';
  bool isStu(Doc? x) => !staffRoles.contains(str(x?['role']));
  String clsOf(Doc? x) => str(x?['flat']).split(' · ').first;
  String get myCls => clsOf(me);
  bool get isAccountant => role == 'ACCOUNTANT';

  /// support staff do not take part in the discussion chat (notices stay)
  bool get noChat => role == 'STAFF';
  bool isBusJob(Doc? x) => RegExp(r'bus (driver|conductor)', caseSensitive: false).hasMatch(str(x?['job'] ?? x?['flat']));
  bool get isDrv => me != null && sch && !isAdm && role == 'STAFF' && isBusJob(me);

  String get pidv => pid ?? uid ?? '';
  static String auid(String id) => id.replaceAll(RegExp(r'_k\d+$'), '');

  bool memVis(Doc x) => !isTeacher || str(x['uid'] ?? x['id']) == uid || (isStu(x) && x['want'] == null && clsOf(x) == myCls);

  List<Doc> allPpl() => [...D['dir'].values, ...D['mem'].values];

  /// names of the class teachers of a class
  String tOf(String c) {
    final n = <String>[];
    for (final p in allPpl()) {
      if (p['role'] == 'COMMITTEE_MEMBER' && clsOf(p) == c && str(p['name']).isNotEmpty && !n.contains(p['name'])) n.add(str(p['name']));
    }
    return n.join(', ');
  }

  List<String> schClasses() {
    final n = (listv(soc?['towers'])).map((t) => str(mapv(t)['name'])).toList();
    for (final p in allPpl()) {
      if (p['role'] == 'COMMITTEE_MEMBER' && (p['status'] == null || p['status'] == 'approved')) {
        final c = clsOf(p);
        if (c.isNotEmpty && c != 'Teacher' && !n.contains(c)) n.add(c);
      }
    }
    n.sort(natCmp);
    return n;
  }

  bool annVis(Doc a) {
    if (!sch || isOwner || a['uid'] == uid) return true;
    final aud = str(a['aud']);
    return aud.isEmpty || aud == 'all' || (aud == 'teachers' && isTeacher) || (aud == 'students' && (isStu(me) || isTeacher)) || (aud == 'class' && a['cls'] == myCls);
  }

  String roleLbl(dynamic r) {
    final sk = {for (final p in K.skin) p[0]: p[1]};
    final m = {
      'RESIDENT': K.person,
      'TENANT': sk['Tenant'] ?? 'Tenant',
      'COMMITTEE_MEMBER': sk['Committee member'] ?? 'Committee member',
      'ACCOUNTANT': 'Accountant',
      'SECURITY_GUARD': 'Security guard',
      'STAFF': 'Staff',
      'SOCIETY_ADMIN': sch ? 'Principal' : 'Admin',
    };
    final s = str(r);
    return tr(m[s] ?? s.replaceFirst('_', ' '));
  }

  /// role names in chat badges
  String? roleChip(dynamic r) {
    if (r == 'SOCIETY_ADMIN') return tr(sch ? 'Principal' : 'Admin');
    if (r == 'COMMITTEE_MEMBER') return tr(sch ? 'Teacher' : kind == 'company' ? 'Manager' : 'Committee');
    return null;
  }

  String socGst() {
    final s = soc;
    if (s == null) return '';
    // only the number an admin saved in Billing → GST number (never guessed)
    return str(s['gstin']).toUpperCase();
  }

  /* ---------- families ---------- */
  List<Doc> myProfiles() => [
        {...(prim ?? me ?? {}), 'id': uid},
        ...kids,
      ];
  bool get kidMany => sch && prim != null && isStu(prim) && myProfiles().length > 1;

  /* ---------- switching workspaces ---------- */
  bool swAdm = false;
  bool get swCan => !sch || isOwner || me == null || me!['status'] != 'approved' || swAdm;

  /* ---------- skin: "Society" -> "School" etc. in the labels of the app ---------- */
  RegExp? _skin;
  Map<String, String> _skinT = {};
  /// the app's label for this kind of workspace ("Society" -> "Company"), in the user's language
  String sk(String t) => tr(skE(t));

  /// only the English word swap of [sk] (the text is translated afterwards)
  String skE(String t) {
    if (K.skin.isEmpty) return t;
    if (_skin == null) {
      _skinT = {for (final p in K.skin) p[0]: p[1]};
      _skin = RegExp('\\b(${K.skin.map((x) => RegExp.escape(x[0])).join('|')})\\b');
    }
    return t.replaceAllMapped(_skin!, (m) => _skinT[m.group(0)] ?? m.group(0)!);
  }

  String get fee => K.fee;

  void reset() {
    sid = null;
    soc = null;
    me = null;
    prim = null;
    pid = null;
    kids = [];
    isSuper = false;
    swAdm = false;
  }
}

final S = Session.I;
