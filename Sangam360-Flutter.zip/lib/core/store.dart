import 'package:flutter/foundation.dart';

typedef Doc = Map<String, dynamic>;

/// D: the records that are listened to, by name ("comp", "vis", "msg" ...), each a map id -> record (with "id").
class Store {
  static final Store I = Store._();
  Store._();

  final Map<String, Map<String, Doc>> _c = {};
  final Map<String, ValueNotifier<int>> _rev = {};

  Map<String, Doc> operator [](String k) => _c[k] ??= <String, Doc>{};

  void set(String k, Map<String, Doc> v) {
    _c[k] = v;
    bump(k);
  }

  void bump(String k) {
    final n = _rev[k] ??= ValueNotifier<int>(0);
    n.value++;
    any.value++;
    _slowArm();
  }

  /// like [any], but at most about 3 times a second (big screens such as Home listen to this)
  final ValueNotifier<int> anySlow = ValueNotifier<int>(0);
  bool _slowWait = false;
  void _slowArm() {
    if (_slowWait) return;
    _slowWait = true;
    Future.delayed(const Duration(milliseconds: 300), () {
      _slowWait = false;
      anySlow.value++;
    });
  }

  /// changes whenever any record changes
  final ValueNotifier<int> any = ValueNotifier<int>(0);

  ValueNotifier<int> rev(String k) => _rev[k] ??= ValueNotifier<int>(0);

  /// a Listenable for the given names (widgets rebuild only when one of them changes)
  Listenable on(List<String> keys) => Listenable.merge(keys.map(rev).toList());

  List<Doc> list(String k) => this[k].values.toList();

  void clearAll() {
    for (final k in _c.keys.toList()) {
      _c[k] = {};
      bump(k);
    }
  }
}

final D = Store.I;
