/* ===== the help assistant: who is asking (so the answers name the right tabs and buttons) ===== */

const spMT = '☰ menu → More tools → ';

class SupportCtx {
  final String k, card, org, per, Per, unit, fee, svc, comm, fin, me, boss, nav, planRows;
  final Map<String, String> sub;
  final bool adm, own, grd, soc, com, sch, tch, stu, drv, acc, payOn;
  final List<String> tools;
  const SupportCtx({
    required this.k,
    required this.card,
    required this.org,
    required this.per,
    // ignore: non_constant_identifier_names
    required this.Per,
    required this.unit,
    required this.fee,
    required this.svc,
    required this.comm,
    required this.fin,
    required this.me,
    required this.boss,
    required this.nav,
    required this.planRows,
    required this.sub,
    required this.adm,
    required this.own,
    required this.grd,
    required this.soc,
    required this.com,
    required this.sch,
    required this.tch,
    required this.stu,
    required this.drv,
    required this.acc,
    required this.payOn,
    required this.tools,
  });

  /// the name of a Services page in this workspace ("Complaints", "Helpdesk" ...)
  String sb(String key) => sub[key] ?? '';
}

class KbEntry {
  final String t;
  final List<String> k;
  final String Function(SupportCtx c) a;
  final bool Function(SupportCtx c)? on;
  final bool m;
  const KbEntry(this.t, this.k, this.a, {this.on, this.m = false});
}

String spNorm(String s) => s.toLowerCase().replaceAll(RegExp("[’']"), '').replaceAll(RegExp(r'[^a-z0-9ऀ-ॿ]+'), ' ').trim();

double spScore(String q, KbEntry e) {
  final nq = ' ${spNorm(q)} ';
  final tk = nq.trim().split(' ');
  var sc = 0.0;
  for (final w in [...e.k, e.t]) {
    final n = spNorm(w);
    if (n.isEmpty) continue;
    if (n.contains(' ')) {
      if (nq.contains(' $n ')) sc += 4;
      continue;
    }
    for (final t in tk) {
      if (t == n) {
        sc += 2;
      } else if (n.length >= 4 && t.length >= 4 && (t.startsWith(n) || n.startsWith(t))) {
        sc += 1.2;
      }
    }
  }
  return sc;
}

final hingRe = RegExp(r'\b(kaise|kese|kaisey|kya|nahi|nhi|karna|karu|kare|karo|hai|hain|mujhe|mera|meri|kaha|kahan|kyu|kyun|chahiye|batao|bataiye|dikha|hota|hoga)\b');
