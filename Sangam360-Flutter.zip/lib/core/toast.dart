import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../ui/theme.dart';
import 'api.dart';
import 'prefs.dart';

/* ---------- notifications (toasts) ----------
   toast(icon, title, text, quiet, kind): a card slides in at the top of the screen. Its look follows the icon:
   ✅ done · ℹ️ information · ⚠️ warning · ⛔ refused · 🚨 emergency. Any other icon keeps its own emoji.
   It leaves by itself (a longer text stays longer), can be swiped away, and waits while a finger rests on it.
   The same message twice in a row does not pile up. At most three are shown. Not quiet = also into the bell. */

final navKey = GlobalKey<NavigatorState>();
final overlayKey = GlobalKey<OverlayState>();

class Mute {
  static bool all = Prefs.get('sh-mute') == '1';
  static Set<String> kinds = {
    for (final k in (Prefs.json('sh-mute-k') is List ? (Prefs.json('sh-mute-k') as List) : const [])) k.toString(),
  };
  static bool isMuted(String? k) => all || (k != null && kinds.contains(k));
  static void save() {
    Prefs.set('sh-mute', all ? '1' : '0');
    Prefs.setJson('sh-mute-k', kinds.toList());
  }
}

class Bell extends ChangeNotifier {
  static final Bell I = Bell._();
  Bell._();
  final List<Map<String, dynamic>> items = [];
  int unread = 0;
  void add(String ic, String t, String x) {
    items.insert(0, {'ic': ic, 't': t, 'x': x, 'ts': DateTime.now().millisecondsSinceEpoch});
    if (items.length > 25) items.removeRange(25, items.length);
    unread++;
    notifyListeners();
  }

  void seen() {
    unread = 0;
    notifyListeners();
  }
}

class _T {
  final String ic, title, text;
  final int id;
  VoidCallback? onTap;
  int ms;
  _T(this.id, this.ic, this.title, this.text, this.ms);
}

class Toasts extends ChangeNotifier {
  static final Toasts I = Toasts._();
  Toasts._();
  final List<_T> list = [];
  final Map<int, Timer> _tm = {};
  int _n = 0;

  _T show(String ic, String t, String x) {
    final msg = t + x;
    for (final e in list) {
      if (e.ic == ic && e.title + e.text == msg) {
        _arm(e);
        notifyListeners();
        return e;
      }
    }
    while (list.length >= 3) {
      close(list.first.id);
    }
    final e = _T(++_n, ic, t, x, (2400 + msg.length * 45).clamp(4500, 8000).toInt());
    list.add(e);
    _arm(e);
    notifyListeners();
    return e;
  }

  void _arm(_T e) {
    _tm[e.id]?.cancel();
    _tm[e.id] = Timer(Duration(milliseconds: e.ms), () => close(e.id));
  }

  void hold(int id) => _tm[id]?.cancel();
  void go(int id) {
    final e = list.where((x) => x.id == id);
    if (e.isNotEmpty) _arm(e.first);
  }

  void close(int id) {
    _tm.remove(id)?.cancel();
    list.removeWhere((x) => x.id == id);
    notifyListeners();
  }

  /// an important one: it stays longer and a tap opens what it is about
  void stickLast(VoidCallback fn, [int ms = 9000]) {
    if (list.isEmpty) return;
    final e = list.last;
    e.onTap = fn;
    e.ms = ms;
    _arm(e);
    notifyListeners();
  }
}

void beep() {
  try {
    SystemSound.play(SystemSoundType.click);
    HapticFeedback.lightImpact();
  } catch (_) {}
}

/// quiet = the person did it themselves: no sound and not into the bell
void toast(String ic, String t, [String x = '', bool quiet = true, String? kind]) {
  if (!quiet && Mute.isMuted(kind)) return;
  if (!quiet) {
    Bell.I.add(ic, t, x);
    beep();
  }
  Toasts.I.show(ic, t, x);
}

void fail(Object? e, [String? m]) {
  if (e is AppError && e.soft) {
    toast('ℹ️', e.message);
    return;
  }
  debugPrint('error: $e');
  final c = errCode(e);
  toast('⚠️', m ?? 'Something went wrong', fr(e) + (c.isNotEmpty && e is! AppError ? ' [$c]' : ''));
}

/// the layer the toasts are drawn in (above every page)
class ToastLayer extends StatelessWidget {
  final Widget child;
  const ToastLayer({super.key, required this.child});
  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      child,
      Positioned(
        left: 0,
        right: 0,
        top: 0,
        child: SafeArea(
          child: ListenableBuilder(
            listenable: Toasts.I,
            builder: (_, __) => Column(mainAxisSize: MainAxisSize.min, children: [for (final e in Toasts.I.list) _ToastCard(key: ValueKey(e.id), e: e)]),
          ),
        ),
      ),
    ]);
  }
}

class _ToastCard extends StatefulWidget {
  final _T e;
  const _ToastCard({super.key, required this.e});
  @override
  State<_ToastCard> createState() => _ToastCardState();
}

class _ToastCardState extends State<_ToastCard> with SingleTickerProviderStateMixin {
  late final AnimationController _a = AnimationController(vsync: this, duration: const Duration(milliseconds: 380))..forward();
  double _dx = 0, _dy = 0;

  @override
  void dispose() {
    _a.dispose();
    super.dispose();
  }

  (Color, IconData?) _look() {
    final p = pal;
    switch (widget.e.ic) {
      case '✅':
      case '🎉':
      case '🏆':
        return (p.green, widget.e.ic == '✅' ? Icons.check_rounded : null);
      case 'ℹ️':
        return (p.a, Icons.info_outline_rounded);
      case '⚠️':
      case '⏰':
        return (p.amber, widget.e.ic == '⚠️' ? Icons.warning_amber_rounded : null);
      case '⛔':
        return (p.red, Icons.block_rounded);
      case '🚨':
        return (p.red, Icons.notifications_active_rounded);
      case '🗑️':
      case '🗑':
        return (p.muted, Icons.delete_outline_rounded);
      case '🔒':
        return (p.muted, Icons.lock_outline_rounded);
    }
    return (p.a, null);
  }

  @override
  Widget build(BuildContext context) {
    final p = pal, e = widget.e;
    final (c, ic) = _look();
    return AnimatedBuilder(
      animation: _a,
      builder: (_, child) {
        final t = Curves.easeOutBack.transform(_a.value.clamp(0.0, 1.0));
        return Opacity(opacity: (1 - (_dx.abs() / 300) - (-_dy / 120)).clamp(0.2, 1.0) * _a.value.clamp(0.0, 1.0), child: Transform.translate(offset: Offset(_dx, _dy + (1 - t) * -40), child: child));
      },
      child: GestureDetector(
        onTap: () {
          if (e.onTap != null) {
            final f = e.onTap!;
            Toasts.I.close(e.id);
            f();
          }
        },
        onPanDown: (_) => Toasts.I.hold(e.id),
        onPanUpdate: (d) => setState(() {
          _dx += d.delta.dx;
          _dy = (_dy + d.delta.dy).clamp(-200.0, 0.0);
        }),
        onPanEnd: (_) {
          if (_dx.abs() > 70 || _dy < -34) {
            Toasts.I.close(e.id);
          } else {
            setState(() {
              _dx = 0;
              _dy = 0;
            });
            Toasts.I.go(e.id);
          }
        },
        onPanCancel: () => Toasts.I.go(e.id),
        child: Container(
          margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
          constraints: const BoxConstraints(maxWidth: 480),
          padding: const EdgeInsets.fromLTRB(12, 12, 6, 12),
          decoration: BoxDecoration(
            color: p.card,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: p.line),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(.12), blurRadius: 30, offset: const Offset(0, 12))],
          ),
          child: Material(
            color: Colors.transparent,
            child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(color: c.withOpacity(.13), borderRadius: BorderRadius.circular(13)),
                alignment: Alignment.center,
                child: ic != null ? Icon(ic, color: c, size: 22) : Text(e.ic, style: const TextStyle(fontSize: 20)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                  Text(e.title, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14, color: p.text)),
                  if (e.text.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 2), child: Text(e.text, style: meta(), maxLines: 4, overflow: TextOverflow.ellipsis)),
                  if (e.onTap != null) Padding(padding: const EdgeInsets.only(top: 4), child: Text('Tap to open ›', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: p.a))),
                ]),
              ),
              IconButton(onPressed: () => Toasts.I.close(e.id), icon: Icon(Icons.close_rounded, size: 18, color: p.muted), visualDensity: VisualDensity.compact),
            ]),
          ),
        ),
      ),
    );
  }
}
