import 'dart:math';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

/* ---------- small helpers used everywhere (same behaviour as the earlier web app) ---------- */

String str(dynamic v) => v == null ? '' : v.toString();
num numv(dynamic v) {
  if (v is num) return v;
  if (v == null) return 0;
  return num.tryParse(v.toString()) ?? 0;
}

int intv(dynamic v) => numv(v).toInt();
bool boolv(dynamic v) => v == true;
Map<String, dynamic> mapv(dynamic v) {
  if (v is Map<String, dynamic>) return v;
  if (v is Map) return v.map((k, val) => MapEntry(k.toString(), val));
  return <String, dynamic>{};
}

List<dynamic> listv(dynamic v) => v is List ? v : const [];
List<String> strList(dynamic v) => listv(v).map((e) => str(e)).toList();

int now() => DateTime.now().millisecondsSinceEpoch;
const int dayMs = 86400000;

final _inr = NumberFormat('#,##,##0.##', 'en_IN');
String rs(dynamic n) => '₹${_inr.format(numv(n))}';

DateTime dtOf(dynamic t) => DateTime.fromMillisecondsSinceEpoch(intv(t));
String dt(dynamic t) => DateFormat('d MMM').format(dtOf(t));
String tm(dynamic t) => DateFormat('hh:mm a').format(dtOf(t)).toLowerCase();
String td() => ymd(DateTime.now());
String ymd(DateTime d) => '${d.year}-${_p2(d.month)}-${_p2(d.day)}';
String _p2(int n) => n.toString().padLeft(2, '0');
String p2(int n) => _p2(n);
String bdate(dynamic t) => DateFormat('d MMM yyyy').format(dtOf(t));
String dtm(dynamic t) => '${bdate(t)}, ${tm(t)}';
String mKey(DateTime d) => '${d.year}-${_p2(d.month)}';
String mname(String k) {
  final p = k.split('-');
  if (p.length < 2) return k;
  final y = int.tryParse(p[0]) ?? 2000, m = int.tryParse(p[1]) ?? 1;
  return DateFormat('MMMM yyyy').format(DateTime(y, m, 1));
}

DateTime? parseYmd(String s) {
  final m = RegExp(r'^(\d{4})-(\d{2})-(\d{2})$').firstMatch(s);
  if (m == null) return null;
  return DateTime(int.parse(m.group(1)!), int.parse(m.group(2)!), int.parse(m.group(3)!));
}

/// "Mon, 5 Oct 2026"
String fxDate(String s) {
  final d = parseYmd(s);
  return d == null ? s : DateFormat('EEE, d MMM yyyy').format(d);
}

/// "09:30" -> "9:30 AM"
String fxT12(String t) {
  final m = RegExp(r'^(\d{1,2}):(\d{2})').firstMatch(t);
  if (m == null) return t;
  final h = int.parse(m.group(1)!);
  return '${(h + 11) % 12 + 1}:${m.group(2)}${h < 12 ? ' AM' : ' PM'}';
}

String dayLbl(dynamic t) {
  final d = dtOf(t), n = DateTime.now();
  bool same(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;
  if (same(d, n)) return 'Today';
  if (same(d, n.subtract(const Duration(days: 1)))) return 'Yesterday';
  return DateFormat('d MMMM').format(d);
}

String ago(dynamic t) {
  final s = max(0, ((now() - intv(t)) / 1000).round());
  if (s < 45) return 'just now';
  if (s < 3600) return '${(s / 60).round()} min ago';
  return '${(s / 3600).round()} h ago';
}

/// whole calendar days from today to the day of t (0 = today)
int dayGap(dynamic t) {
  final a = dtOf(t), b = DateTime.now();
  return DateTime(a.year, a.month, a.day).difference(DateTime(b.year, b.month, b.day)).inHours ~/ 24;
}

String fsz(num n) => n < 1024 ? '${n.round()} B' : n < 1048576 ? '${(n / 1024).round()} KB' : '${(n / 1048576).toStringAsFixed(1)} MB';
String fd(num s) {
  final x = s.round();
  return '${x ~/ 60}:${(x % 60).toString().padLeft(2, '0')}';
}

String fuSize(num n) => n >= 1048576 ? '${(n / 1048576).toStringAsFixed(n >= 10485760 ? 0 : 1)} MB' : '${max(1, (n / 1024).round())} KB';

/* ---------- hashes that must give the same answer as the web app (shared keys in the database) ---------- */

int _i32(int x) => x.toSigned(32);

/// colour of a name (avatars)
const avatarCols = [Color(0xFF6D5DFC), Color(0xFFFF6B9D), Color(0xFF00A8E8), Color(0xFFF59E0B), Color(0xFF10B981), Color(0xFFEF4444), Color(0xFF8B5CF6), Color(0xFF0EA5E9)];
Color colOf(String? n) {
  var h = 0;
  for (final c in (n == null || n.isEmpty ? '?' : n).codeUnits) {
    h = _i32(h * 31 + c);
  }
  return avatarCols[h.abs() % avatarCols.length];
}

/// colour of a sender's name in group chat
const nameCols = [Color(0xFFE0457B), Color(0xFF128C7E), Color(0xFFD97706), Color(0xFF7C3AED), Color(0xFF0284C7), Color(0xFF16A34A), Color(0xFFDC2626), Color(0xFF9333EA), Color(0xFF0D9488), Color(0xFFC2410C), Color(0xFF4F46E5), Color(0xFFBE185D), Color(0xFF65A30D), Color(0xFF0891B2), Color(0xFFB45309), Color(0xFF7E22CE)];
Color ucol(String? s) {
  var h = 0;
  for (final c in (s == null || s.isEmpty ? '?' : s).codeUnits) {
    h = _i32(h * 31 + c);
  }
  return nameCols[h.abs() % nameCols.length];
}

/// the key of a student inside buses/{id}.arr (FNV-1a, as the web app and the Android service)
String busK(String pid) {
  var h = 2166136261;
  for (final c in pid.codeUnits) {
    h = (h ^ c) & 0xFFFFFFFF;
    h = (h * 16777619) & 0xFFFFFFFF;
  }
  return 'k${h.toRadixString(36)}';
}

/// private chats of a second student of a login in another class get "_c<hash of class>"
String dmHash(String s) {
  var h = 5381;
  for (final cp in s.runes) {
    h = (((h * 33) & 0xFFFFFFFF) ^ cp) & 0xFFFFFFFF;
  }
  return h.toRadixString(36);
}

final _rnd = Random();
String rid() => DateTime.now().millisecondsSinceEpoch.toRadixString(36) + List.generate(6, (_) => '0123456789abcdefghijklmnopqrstuvwxyz'[_rnd.nextInt(36)]).join();
String genCode() {
  const c = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  return List.generate(6, (_) => c[_rnd.nextInt(c.length)]).join();
}

String code6() => (100000 + _rnd.nextInt(900000)).toString();
int rndInt(int n) => _rnd.nextInt(n);

/// numeric-aware compare ("Flat 2" < "Flat 10")
int natCmp(String a, String b) {
  final re = RegExp(r'(\d+)|(\D+)');
  final x = re.allMatches(a.toLowerCase()).map((m) => m.group(0)!).toList();
  final y = re.allMatches(b.toLowerCase()).map((m) => m.group(0)!).toList();
  for (var i = 0; i < min(x.length, y.length); i++) {
    final p = int.tryParse(x[i]), q = int.tryParse(y[i]);
    final c = (p != null && q != null) ? p.compareTo(q) : x[i].compareTo(y[i]);
    if (c != 0) return c;
  }
  return x.length.compareTo(y.length);
}

String nv(String s) => s.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');
String firstName(String? s) => str(s).trim().split(RegExp(r'\s+')).first;
String cleanPh(String s) {
  final x = s.replaceAll(RegExp(r'[^\d+\-\s()]'), '').trim();
  return x.length > 18 ? x.substring(0, 18) : x;
}

String cleanName(String s) {
  final x = s.replaceAll(RegExp(r'[<>]'), '').trim();
  return x.length > 40 ? x.substring(0, 40) : x;
}

String cut(String s, int n) => s.length > n ? s.substring(0, n) : s;
String telOf(String s) => 'tel:${s.replaceAll(RegExp(r'[^\d+]'), '')}';
String wa91(String mobile) {
  final d = mobile.replaceAll(RegExp(r'\D'), '');
  return d.isEmpty ? '' : '91${d.length > 10 ? d.substring(d.length - 10) : d}';
}

/// "98765 43210" while typing a phone number
String flPhone(String d0) {
  var d = d0.replaceAll(RegExp(r'\D'), '');
  if (d.length > 10 && d.startsWith('91')) return '+91 ${flPhone(d.substring(2))}';
  if (d.length > 10 && d.startsWith('0')) d = d.substring(1);
  if (d.length <= 5) return d;
  return '${d.substring(0, 5)} ${d.substring(5, min(10, d.length))}${d.length > 10 ? ' ${d.substring(10)}' : ''}';
}

double haversineKm(double a, double b, double c, double d) {
  const r = 6371.0;
  double rad(double x) => x * pi / 180;
  final x = pow(sin(rad(c - a) / 2), 2) + cos(rad(a)) * cos(rad(c)) * pow(sin(rad(d - b) / 2), 2);
  return 2 * r * asin(sqrt(x));
}

double fix6(double n) => double.parse(n.toStringAsFixed(6));
