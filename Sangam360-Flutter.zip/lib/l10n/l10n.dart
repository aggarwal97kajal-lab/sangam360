import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';

import 'langs.dart';

export 'langs.dart';

/* =====================================================================================================
   THE APP'S LANGUAGE

   Every piece of text the app itself shows lives in `assets/l10n/app_<code>.arb`, bundled with the app
   (no translation service is called at run time). `app_en.arb` is the source: each entry has a stable
   key and the English text. Code asks for text by its English source:

       tr('Check in')                       -> 'चेक इन' in Hindi
       trf('{0} unread messages', [n])      -> placeholders {0}, {1} ... filled in after translating

   Text people type (notices, chat, complaints ...) is never passed through here, so it always stays
   exactly as written. A missing translation falls back to English, never to an empty string.
   ===================================================================================================== */

class L10n extends ChangeNotifier {
  L10n._();
  static final L10n I = L10n._();

  static const prefKey = 'sh-lang';

  String _code = defaultLang;
  String get code => _code;
  Lang get lang => langOf(_code);

  /// English text -> key (from app_en.arb)
  final Map<String, String> _keyOf = {};

  /// key -> text in the current language
  Map<String, String> _cur = {};

  /// key -> English
  final Map<String, String> _en = {};

  int _english = 0;

  /// while > 0 everything comes out in English (PDF receipts and invoices, which are legal documents
  /// and whose fonts carry only Latin letters)
  bool get forcedEnglish => _english > 0;

  /// the stable key of an English text: a readable slug + a short hash of the full text
  static String keyFor(String en) {
    final slug = en.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '_').replaceAll(RegExp(r'^_+|_+$'), '');
    final s = slug.length > 32 ? slug.substring(0, 32).replaceAll(RegExp(r'_+$'), '') : slug;
    final h = md5.convert(utf8.encode(en)).toString().substring(0, 6);
    final base = s.isEmpty ? 't' : (RegExp(r'^[0-9]').hasMatch(s) ? 'n$s' : s);
    return '${base}_$h';
  }

  Future<Map<String, String>> _arb(String code) async {
    try {
      final raw = await rootBundle.loadString('assets/l10n/app_$code.arb');
      final m = jsonDecode(raw) as Map<String, dynamic>;
      return {
        for (final e in m.entries)
          if (!e.key.startsWith('@') && e.value is String && (e.value as String).isNotEmpty) e.key: e.value as String
      };
    } catch (e) {
      debugPrint('l10n: could not load $code: $e');
      return {};
    }
  }

  /// called once before the app starts. [saved] is what this phone chose earlier ('' = never chose).
  Future<void> init(String saved) async {
    final en = await _arb('en');
    _en
      ..clear()
      ..addAll(en);
    _keyOf
      ..clear()
      ..addAll({for (final e in en.entries) e.value: e.key});
    try {
      await initializeDateFormatting();
    } catch (_) {}
    // dates use the language's month names but the same 0-9 digits as amounts and phone numbers
    for (final l in langs) {
      try {
        DateFormat.useNativeDigitsByDefaultFor(l.dates ?? l.material, false);
      } catch (_) {}
    }
    await _apply(langs.any((l) => l.code == saved) ? saved : defaultLang, notify: false);
  }

  Future<void> _apply(String code, {bool notify = true}) async {
    _cur = code == 'en' ? _en : {..._en, ...await _arb(code)};
    _code = code;
    final dl = lang.dates ?? lang.material;
    try {
      Intl.defaultLocale = DateFormat.localeExists(dl) ? dl : 'en_IN';
    } catch (_) {
      Intl.defaultLocale = 'en_IN';
    }
    if (notify) notifyListeners();
  }

  /// changes the language at once (no restart, no log-out)
  Future<void> set(String code) async {
    if (!langs.any((l) => l.code == code)) return;
    if (code == _code && _cur.isNotEmpty) return;
    await _apply(code);
  }

  /// tells every listener to show the language again (after the choice is saved)
  void touch() => notifyListeners();

  /// the text in the current language ([en] itself when there is no translation)
  String t(String en) {
    if (en.isEmpty || _english > 0 || _code == 'en') return en;
    final k = _keyOf[en];
    if (k == null) return en;
    return _cur[k] ?? en;
  }

  /// [t] with {0} {1} ... filled in
  String f(String en, List<Object?> args) {
    var s = t(en);
    for (var i = 0; i < args.length; i++) {
      s = s.replaceAll('{$i}', '${args[i] ?? ''}');
    }
    return s;
  }

  /// does the catalogue know this English text? (used by the tests and the completeness check)
  bool knows(String en) => _keyOf.containsKey(en);

  /// how many keys of the current language are translated (not falling back to English)
  int get translatedCount => _code == 'en' ? _en.length : _cur.entries.where((e) => _en[e.key] != e.value).length;
  int get totalCount => _en.length;

  /// runs [fn] with everything in English (see [forcedEnglish])
  Future<T> english<T>(Future<T> Function() fn) async {
    _english++;
    final old = Intl.defaultLocale;
    Intl.defaultLocale = 'en_IN';
    try {
      return await fn();
    } finally {
      _english--;
      if (_english == 0) Intl.defaultLocale = old;
    }
  }

  @visibleForTesting
  void debugLoad(String code, Map<String, String> en, Map<String, String> tr) {
    _en
      ..clear()
      ..addAll(en);
    _keyOf
      ..clear()
      ..addAll({for (final e in en.entries) e.value: e.key});
    _cur = {...en, ...tr};
    _code = code;
    notifyListeners();
  }
}

/// the app's text in the current language (see [L10n])
String tr(String en) => L10n.I.t(en);

/// [tr] with placeholders: trf('Paid {0} of {1}', [a, b])
String trf(String en, List<Object?> args) => L10n.I.f(en, args);
