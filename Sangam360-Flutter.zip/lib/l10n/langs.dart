import 'package:flutter/widgets.dart';

/// One language the app speaks.
///
/// To add a language: add a [Lang] here, add `assets/l10n/app_<code>.arb`
/// (copy `app_en.arb`, translate the values, keep the keys), and run
/// `dart run tool/l10n_check.dart` to see what is still missing.
class Lang {
  /// app code, also the ARB file name: app_<code>.arb
  final String code;

  /// name in English and in the language itself
  final String name, native;

  /// a short greeting shown on the language card, in the language's own script
  final String hello;

  /// script, for the picker ("Devanagari", "Tamil" ...)
  final String script;

  /// the locale Flutter's own widgets (date picker, copy/paste menu) use.
  /// Languages Flutter does not ship (Maithili) borrow the closest one.
  final String material;

  /// locale for dates (month and day names); null = the Material locale
  final String? dates;

  final TextDirection dir;
  const Lang(this.code, this.name, this.native, this.hello, this.script, this.material, {this.dates, this.dir = TextDirection.ltr});

  Locale get locale => Locale(code);
  Locale get materialLocale => Locale(material);
}

/// The supported languages, in the order the picker shows them.
const langs = <Lang>[
  Lang('en', 'English', 'English', 'Hello', 'Latin', 'en', dates: 'en_IN'),
  Lang('hi', 'Hindi', 'हिन्दी', 'नमस्ते', 'Devanagari', 'hi'),
  Lang('mr', 'Marathi', 'मराठी', 'नमस्कार', 'Devanagari', 'mr'),
  Lang('bn', 'Bengali', 'বাংলা', 'নমস্কার', 'Bengali', 'bn'),
  Lang('pa', 'Punjabi', 'ਪੰਜਾਬੀ', 'ਸਤ ਸ੍ਰੀ ਅਕਾਲ', 'Gurmukhi', 'pa'),
  Lang('gu', 'Gujarati', 'ગુજરાતી', 'નમસ્તે', 'Gujarati', 'gu'),
  Lang('ta', 'Tamil', 'தமிழ்', 'வணக்கம்', 'Tamil', 'ta'),
  Lang('te', 'Telugu', 'తెలుగు', 'నమస్కారం', 'Telugu', 'te'),
  Lang('kn', 'Kannada', 'ಕನ್ನಡ', 'ನಮಸ್ಕಾರ', 'Kannada', 'kn'),
  Lang('ml', 'Malayalam', 'മലയാളം', 'നമസ്കാരം', 'Malayalam', 'ml'),
  Lang('or', 'Odia', 'ଓଡ଼ିଆ', 'ନମସ୍କାର', 'Odia', 'or'),
  Lang('mai', 'Maithili', 'मैथिली', 'प्रणाम', 'Devanagari', 'hi', dates: 'hi'),
];

const defaultLang = 'en';

Lang langOf(String code) => langs.firstWhere((l) => l.code == code, orElse: () => langs.first);
