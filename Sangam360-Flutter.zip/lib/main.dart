import 'dart:async';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'core/app.dart';
import 'core/kinds.dart';
import 'core/prefs.dart';
import 'core/session.dart';
import 'core/toast.dart';
import 'l10n/l10n.dart';
import 'screens/lang.dart';
import 'screens/boot.dart';
import 'screens/comm/chat_ctl.dart';
import 'screens/fx/school_bus.dart';
import 'screens/create.dart';
import 'screens/join.dart';
import 'screens/shell.dart';
import 'ui/theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Prefs.init();
  // the app's language: bundled text, loaded before the first screen (no network)
  langDefaultForExisting();
  await L10n.I.init(Prefs.get(L10n.prefKey));
  await Firebase.initializeApp();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  FlutterError.onError = (d) {
    FlutterError.presentError(d);
  };
  runZonedGuarded(() => runApp(const SangamApp()), (e, s) => debugPrint('uncaught: $e\n$s'));
}

class SangamApp extends StatefulWidget {
  const SangamApp({super.key});
  @override
  State<SangamApp> createState() => _SangamAppState();
}

class _SangamAppState extends State<SangamApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    Chat.wire();
    Bus.wire();
    App.init();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    App.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) {
      Chat.foreground(true);
      App.foreground(true);
      App.onResume();
    } else if (s == AppLifecycleState.paused) {
      Chat.foreground(false);
      App.foreground(false);
    }
  }

  @override
  void didChangePlatformBrightness() => ThemeCtl.I.platformChanged();

  String _appKey = '';
  Widget? _app;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([ThemeCtl.I, S, L10n.I]),
      builder: (_, __) {
        final p = pal;
        final key = '${p.a.value}|${p.a2.value}|${p.rc.value}|${p.dark}|${L10n.I.code}';
        if (key == _appKey && _app != null) return _app!;
        _appKey = key;
        SystemChrome.setSystemUIOverlayStyle((p.dark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark).copyWith(statusBarColor: Colors.transparent, systemNavigationBarColor: p.bg, systemNavigationBarIconBrightness: p.dark ? Brightness.light : Brightness.dark));
        return _app = MaterialApp(
          title: '$brand — $tagline',
          debugShowCheckedModeBanner: false,
          navigatorKey: navKey,
          theme: themeFor(Pal(false, p.a, p.a2, p.rc)),
          darkTheme: themeFor(Pal(true, p.a, p.a2, p.rc)),
          themeAnimationDuration: Duration.zero,
          themeMode: ThemeCtl.I.dark ? ThemeMode.dark : ThemeMode.light,
          // Flutter's own widgets (date picker, text selection menu) in the chosen language
          locale: L10n.I.lang.materialLocale,
          supportedLocales: {for (final l in langs) l.materialLocale}.toList(),
          localizationsDelegates: const [GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],
          builder: (ctx, child) => ToastLayer(child: MediaQuery(data: MediaQuery.of(ctx).copyWith(textScaler: MediaQuery.of(ctx).textScaler.clamp(maxScaleFactor: 1.25)), child: child!)),
          home: const LangGate(child: Root()),
        );
      },
    );
  }
}

/// shows the screen of the current phase
class Root extends StatelessWidget {
  const Root({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(listenable: S, builder: (_, __) => _screen());

  Widget _screen() {
    Widget w;
    switch (S.phase) {
      case Phase.splash:
        w = SplashScreen();
        break;
      case Phase.land:
        w = LandingScreen();
        break;
      case Phase.auth:
        w = const AuthScreen();
        break;
      case Phase.choice:
        w = ChoiceScreen();
        break;
      case Phase.create:
        w = const CreateScreen();
        break;
      case Phase.join:
        w = JoinScreen(key: ValueKey('join${BootCtl.joinWant}${BootCtl.joinKid}'));
        break;
      case Phase.wait:
        w = WaitScreen();
        break;
      case Phase.main:
        w = MainShell(key: ValueKey('main${S.sid}${S.pidv}${S.startN}'));
        break;
    }
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 350),
      switchInCurve: Curves.easeOutCubic,
      transitionBuilder: (c, a) => FadeTransition(opacity: a, child: ScaleTransition(scale: Tween(begin: .985, end: 1.0).animate(a), child: c)),
      child: KeyedSubtree(key: ValueKey('${S.phase}'), child: w),
    );
  }
}
