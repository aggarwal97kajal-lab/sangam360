import 'dart:async';
import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../core/api.dart';
import '../core/app.dart';
import '../core/fs.dart';
import '../core/kinds.dart';
import '../core/session.dart';
import '../core/store.dart';
import '../core/toast.dart';
import '../core/util.dart';
import '../ui/anim.dart';
import '../ui/brand.dart';
import '../ui/fields.dart';
import '../ui/kit.dart';
import '../ui/sheets.dart';
import '../ui/theme.dart';
import 'legal.dart';
import '../l10n/l10n.dart';

/// what the create / join screens are doing
class BootCtl {
  static String? joinWant; // teacher | student | staff
  static bool joinKid = false;
  static Doc? join;
  static String joinAs = 'student';
  static String? newSid;

  static String fuSid() => newSid ??= fs.collection('societies').doc().id;

  static void gotoJoin([String? w]) {
    joinKid = false;
    joinWant = S.kind == 'school' && (w == 'teacher' || w == 'student' || w == 'staff') ? w : null;
    join = null;
    S.go(Phase.join);
  }

  static void addKid() {
    S.addMode = true;
    gotoJoin('student');
    joinKid = true;
    S.touch();
  }

  static bool kidMode() => joinKid && S.me != null && S.sid != null && join != null && join!['societyId'] == S.sid && S.kind == 'school' && str(join!['teacherUid']).isNotEmpty && S.me!['status'] == 'approved';

  static void gotoCreate() {
    newSid = null;
    S.go(Phase.create);
  }
}

/* ============================== splash ============================== */
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))..repeat(reverse: true);
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    return Scaffold(
      backgroundColor: p.bg,
      body: Aurora(
        child: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            AnimatedBuilder(animation: _c, builder: (_, c) => Transform.scale(scale: 1 + .05 * Curves.easeInOut.transform(_c.value), child: c), child: const Logo(size: 96)),
            const SizedBox(height: 18),
            const BrandText(size: 32),
            const SizedBox(height: 6),
            Text(tr(tagline), style: meta().copyWith(fontSize: 14)),
          ]),
        ),
      ),
    );
  }
}

/* ============================== landing: choose the kind ============================== */
class LandingScreen extends StatelessWidget {
  const LandingScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    return BootPage(
      glass: false,
      head: Column(children: [
        const Logo(size: 76),
        const SizedBox(height: 16),
        const BrandText(size: 34),
        const SizedBox(height: 10),
        Text(tr(tagline), style: h3().copyWith(fontSize: 16)),
        const SizedBox(height: 4),
        Text(tr('Societies, companies and schools — choose how you will use it.'), textAlign: TextAlign.center, style: meta().copyWith(fontSize: 14)),
      ]),
      children: [
        for (final (i, k) in const ['society', 'company', 'school'].indexed)
          Enter(
            index: i + 1,
            child: _KindCard(kinds[k]!, () {
              HapticFeedback.selectionClick();
              S.setKind(k);
              S.go(Phase.auth);
            }),
          ),
        const SizedBox(height: 18),
        Center(
          child: Wrap(alignment: WrapAlignment.center, children: [
            TextButton(onPressed: () => openLegal(context, 'privacy'), child: Text(tr('Privacy Policy'), style: meta(p.muted))),
            Text('·', style: meta()),
            TextButton(onPressed: () => openLegal(context, 'terms'), child: Text(tr('Terms & Conditions'), style: meta(p.muted))),
          ]),
        ),
      ],
    );
  }
}

class _KindCard extends StatefulWidget {
  final KindCfg k;
  final VoidCallback onTap;
  const _KindCard(this.k, this.onTap);
  @override
  State<_KindCard> createState() => _KindCardState();
}

class _KindCardState extends State<_KindCard> {
  double _s = 1;
  @override
  Widget build(BuildContext context) {
    final p = pal, k = widget.k;
    return GestureDetector(
      onTapDown: (_) => setState(() => _s = .97),
      onTapCancel: () => setState(() => _s = 1),
      onTapUp: (_) => setState(() => _s = 1),
      onTap: widget.onTap,
      child: AnimatedScale(
        scale: _s,
        duration: const Duration(milliseconds: 140),
        child: Container(
          margin: const EdgeInsets.only(bottom: 14),
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: p.card,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: p.line),
            boxShadow: [...p.shadow, BoxShadow(color: k.c1.withOpacity(p.dark ? 0 : .08), blurRadius: 30, offset: const Offset(0, 14))],
          ),
          child: Row(children: [
            Container(
              width: 58,
              height: 58,
              decoration: BoxDecoration(gradient: LinearGradient(colors: [k.c1, k.c2], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(18), boxShadow: [BoxShadow(color: k.c1.withOpacity(.35), blurRadius: 16, offset: const Offset(0, 8))]),
              alignment: Alignment.center,
              child: Text(k.ico, style: const TextStyle(fontSize: 28)),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(k.card, style: h2().copyWith(fontSize: 18)),
                const SizedBox(height: 3),
                Text(k.cardS, style: meta().copyWith(fontSize: 13.5)),
              ]),
            ),
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(color: k.c1.withOpacity(.1), shape: BoxShape.circle),
              child: Icon(Icons.arrow_forward_rounded, color: k.c1, size: 19),
            ),
          ]),
        ),
      ),
    );
  }
}

/* ============================== sign in / sign up ============================== */
class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  String mode = 'login';
  final an = TextEditingController(), ae = TextEditingController(), ap = TextEditingController();
  String err = '';
  bool capOk = false, capSpin = false, agree = false, gBusy = false;
  int shakeCap = 0, shakeAgr = 0;

  @override
  void initState() {
    super.initState();
    if (S.authMsg.isNotEmpty) {
      err = S.authMsg;
      S.authMsg = '';
    }
    ap.addListener(() => setState(() {}));
  }

  void _err(String t) => setState(() => err = t);

  Future<void> _submit() async {
    final em = ae.text.trim(), pw = ap.text;
    _err('');
    if (mode == 'signup' && !capOk) {
      _err(tr("Please tick “I'm not a robot” first."));
      setState(() => shakeCap++);
      return;
    }
    if (mode == 'signup' && !agree) {
      _err(tr('Please tick the box to agree to the Terms of Use and Privacy Policy.'));
      setState(() => shakeAgr++);
      return;
    }
    if (em.isEmpty || pw.isEmpty) {
      _err(tr('Enter email and password.'));
      return;
    }
    try {
      if (mode == 'login') {
        S.loginKind = S.kind;
        await FirebaseAuth.instance.signInWithEmailAndPassword(email: em, password: pw);
      } else {
        final nm = an.text.trim();
        if (nm.isEmpty) {
          _err(tr('Enter your name.'));
          return;
        }
        final c = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: em, password: pw);
        await c.user?.updateDisplayName(nm);
        S.user = FirebaseAuth.instance.currentUser;
        api('/v1/mail/welcome', {'name': nm, 'lang': L10n.I.code}).catchError((_) => <String, dynamic>{});
      }
    } catch (e) {
      _err(fr(e));
    }
  }

  Future<void> _forgot() async {
    final e = ae.text.trim();
    if (e.isEmpty) {
      _err(tr('Type your email first.'));
      return;
    }
    Future<void> fb() async {
      try {
        await FirebaseAuth.instance.sendPasswordResetEmail(email: e);
        _err(tr('Reset link sent ✔'));
      } catch (x) {
        _err(fr(x));
      }
    }

    if (payApi.isEmpty) return fb();
    _err(tr('Sending…'));
    try {
      final r = await apiOpen('/v1/mail/reset', {'email': e, 'lang': L10n.I.code});
      dynamic j;
      try {
        j = jsonDecode(r.body);
      } catch (_) {}
      if (r.statusCode >= 200 && r.statusCode < 300 && j is Map && j['ok'] == true) {
        _err(tr('If this email has an account, a reset link is on its way ✔'));
      } else if (r.statusCode == 429) {
        _err(tr('Too many tries. Please wait a few minutes and try again.'));
      } else if (r.statusCode == 422) {
        _err(tr('Please enter a valid email.'));
      } else {
        await fb();
      }
    } catch (_) {
      await fb();
    }
  }

  void _cap() {
    if (capOk || capSpin) return;
    HapticFeedback.selectionClick();
    setState(() => capSpin = true);
    Future.delayed(const Duration(milliseconds: 900), () {
      if (mounted) {
        setState(() {
          capSpin = false;
          capOk = true;
        });
      }
    });
  }

  String _ggErr(Object e) {
    final c = e is PlatformException ? e.code : e is FirebaseAuthException ? e.code : '';
    final m = e is PlatformException ? (e.message ?? '') : e.toString();
    if (RegExp('sign_in_canceled|canceled|cancelled').hasMatch(c)) return '';
    if (m.contains('ApiException: 10') || m.contains(': 10:')) return tr('Google sign-in is not set up for this copy of the app yet. Please use your email and password.');
    if (c == 'network_error' || c == 'network-request-failed' || m.contains('ApiException: 7')) return tr('No internet connection. Please check and try again.');
    if (c == 'operation-not-allowed') return tr('Google sign-in is not switched on for this app yet. Please use your email and password.');
    if (c == 'account-exists-with-different-credential') return tr('This email is already registered. Please log in with your email and password.');
    if (c == 'invalid-credential') return tr('Google could not confirm this sign-in. Please try again.');
    if (c == 'user-disabled') return tr('This account has been disabled.');
    if (c == 'sign_in_failed') return tr('Google sign-in did not work. Please try again or use your email and password.');
    return fr(e);
  }

  Future<void> _google() async {
    _err('');
    if (mode == 'signup' && !agree) {
      _err(tr('Please tick the box to agree to the Terms of Use and Privacy Policy.'));
      setState(() => shakeAgr++);
      return;
    }
    if (gBusy) return;
    setState(() => gBusy = true);
    final kind0 = S.loginKind;
    var keep = false;
    try {
      S.loginKind = S.kind;
      final gs = GoogleSignIn(serverClientId: googleWebClient, scopes: const ['email']);
      try {
        await gs.signOut();
      } catch (_) {}
      final acc = await gs.signIn();
      if (acc == null) {
        S.loginKind = kind0;
        return;
      }
      final ga = await acc.authentication;
      if (ga.idToken == null) {
        S.loginKind = kind0;
        _err(tr('Google could not confirm this sign-in. Please try again.'));
        return;
      }
      App.ggHold = true;
      App.ggHeld = null;
      final cred = await FirebaseAuth.instance.signInWithCredential(GoogleAuthProvider.credential(idToken: ga.idToken, accessToken: ga.accessToken));
      final isNew = cred.additionalUserInfo?.isNewUser ?? false;
      if (mode == 'login' && isNew) {
        S.loginKind = kind0;
        keep = true;
        final msg = tr('No account found for this Google ID. Please sign up first: tap “Sign up”, then “Continue with Google”.');
        try {
          await cred.user?.delete();
        } catch (_) {
          try {
            await FirebaseAuth.instance.signOut();
          } catch (_) {}
        }
        Future.delayed(const Duration(milliseconds: 700), () => App.ggHold = false);
        if (mounted) {
          setState(() {
            mode = 'login';
            err = msg;
          });
        }
        return;
      }
      if (mode == 'signup' && isNew) api('/v1/mail/welcome', {'lang': L10n.I.code}).catchError((_) => <String, dynamic>{});
      final held = App.ggHeld ?? FirebaseAuth.instance.currentUser;
      App.ggHold = false;
      App.ggHeld = null;
      if (held != null) {
        S.user = held;
        S.uid = held.uid;
        App.boot();
      }
    } catch (e) {
      S.loginKind = kind0;
      final held = App.ggHeld;
      App.ggHold = false;
      App.ggHeld = null;
      if (held != null) {
        S.user = held;
        S.uid = held.uid;
        App.boot();
        return;
      }
      final t = _ggErr(e);
      if (t.isNotEmpty) _err(t);
    } finally {
      if (!keep) App.ggHold = false;
      if (mounted) setState(() => gBusy = false);
    }
  }

  int _pwScore(String p) {
    if (p.isEmpty) return 0;
    var s = 0;
    if (p.length >= 6) s++;
    if (p.length >= 10) s++;
    if (RegExp('[a-z]').hasMatch(p) && RegExp('[A-Z]').hasMatch(p)) s++;
    final d = RegExp(r'\d').hasMatch(p), sy = RegExp(r'[^A-Za-z0-9]').hasMatch(p);
    if (d && sy) {
      s++;
    } else if (d || sy) {
      s += p.length >= 8 ? 1 : 0;
    }
    return s.clamp(1, 4);
  }

  @override
  Widget build(BuildContext context) {
    final p = pal, K = S.K;
    final su = mode == 'signup';
    final pw = ap.text, sc = _pwScore(pw);
    const lbl = ['', 'Weak', 'Fair', 'Good', 'Strong'];
    final scCol = [p.line, p.red, p.amber, p.blue, p.green][sc];
    final others = {'society': 'society', 'company': 'corporate', 'school': 'school'}..remove(S.kind);
    final linkSt = TextStyle(color: p.a, fontWeight: FontWeight.w700);
    return BootPage(
      head: Column(children: [
        Hero(tag: 'kind-${S.kind}', child: Container(width: 64, height: 64, decoration: BoxDecoration(gradient: p.grad, borderRadius: BorderRadius.circular(20), boxShadow: [BoxShadow(color: p.a.withOpacity(.3), blurRadius: 20, offset: const Offset(0, 10))]), alignment: Alignment.center, child: Text(K.ico, style: const TextStyle(fontSize: 30)))),
        const SizedBox(height: 14),
        const BrandText(size: 30),
        const SizedBox(height: 4),
        Text(K.tag, style: meta().copyWith(fontSize: 14)),
      ]),
      children: [
        Seg(const [('login', 'Login'), ('signup', 'Sign up')], mode, (v) => setState(() {
              mode = v;
              err = '';
            })),
        AnimatedSize(
          duration: const Duration(milliseconds: 250),
          child: su ? Field(an, 'Your full name', max: 40, kb: TextInputType.name) : const SizedBox(width: double.infinity),
        ),
        Field(ae, 'Email', kb: TextInputType.emailAddress),
        Field(ap, 'Password (min 6 characters)', password: true, action: TextInputAction.done, onSubmit: (_) => _submit()),
        if (su && pw.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 12, left: 2, right: 2),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                for (var i = 0; i < 4; i++)
                  Expanded(child: AnimatedContainer(duration: const Duration(milliseconds: 250), height: 5, margin: EdgeInsets.only(right: i < 3 ? 5 : 0), decoration: BoxDecoration(color: i < sc ? scCol : p.line, borderRadius: BorderRadius.circular(9)))),
              ]),
              const SizedBox(height: 5),
              Text(tr(lbl[sc]) + (sc < 3 ? trf(' · add {0}', [(pw.length < 10 ? tr('more characters') : tr('a capital letter, a number or a symbol'))]) : ''), style: small(scCol)),
            ]),
          ),
        if (su)
          Shake(
            trigger: shakeCap,
            child: GestureDetector(
              onTap: _cap,
              child: Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                decoration: BoxDecoration(color: p.card2, borderRadius: BorderRadius.circular(14), border: Border.all(color: p.line)),
                child: Row(children: [
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    width: 28,
                    height: 28,
                    decoration: BoxDecoration(color: capOk ? p.green : p.card, borderRadius: BorderRadius.circular(7), border: Border.all(color: capOk ? p.green : p.faint, width: 2)),
                    alignment: Alignment.center,
                    child: capSpin
                        ? SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2.4, color: p.a))
                        : capOk
                            ? const Icon(Icons.check_rounded, size: 20, color: Colors.white)
                            : null,
                  ),
                  const SizedBox(width: 12),
                  Expanded(child: Text(tr("I'm not a robot"), style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: p.text))),
                  Column(children: [const Text('🛡️', style: TextStyle(fontSize: 16)), Text(tr('Secure'), style: small())]),
                ]),
              ),
            ),
          ),
        if (su)
          Shake(
            trigger: shakeAgr,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                SizedBox(width: 30, height: 26, child: Checkbox(value: agree, onChanged: (v) => setState(() => agree = v == true))),
                const SizedBox(width: 6),
                Expanded(
                  child: Text.rich(TextSpan(style: meta().copyWith(fontSize: 13), children: [
                     TextSpan(text: tr('By selecting "Create account", you are confirming that you have read and agree to Sangam360 ')),
                    TextSpan(text: tr('Terms of Use'), style: linkSt, recognizer: TapGestureRecognizer()..onTap = () => openLegal(context, 'terms')),
                    const TextSpan(text: ' and '),
                    TextSpan(text: tr('Privacy Policy'), style: linkSt, recognizer: TapGestureRecognizer()..onTap = () => openLegal(context, 'privacy')),
                    const TextSpan(text: '.'),
                  ])),
                ),
              ]),
            ),
          ),
        Btn(su ? tr('Create account') : tr('Login'), onTap: _submit, busyDone: false),
        if (!su) Lnk(tr('Forgot password?'), onTap: _forgot),
        ErrText(err),
        const SizedBox(height: 10),
        Row(children: [Expanded(child: Divider(color: p.line)), Padding(padding: const EdgeInsets.symmetric(horizontal: 10), child: Text('or', style: meta())), Expanded(child: Divider(color: p.line))]),
        const SizedBox(height: 10),
        Material(
          color: p.card,
          borderRadius: BorderRadius.circular(15),
          child: InkWell(
            borderRadius: BorderRadius.circular(15),
            onTap: gBusy ? null : _google,
            child: Container(
              height: 50,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(15), border: Border.all(color: p.line)),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Container(
                  width: 24,
                  height: 24,
                  decoration: const BoxDecoration(shape: BoxShape.circle, gradient: SweepGradient(colors: [Color(0xFF4285F4), Color(0xFF34A853), Color(0xFFFBBC05), Color(0xFFEA4335), Color(0xFF4285F4)])),
                  alignment: Alignment.center,
                  child: Container(width: 16, height: 16, decoration: BoxDecoration(color: p.card, shape: BoxShape.circle), alignment: Alignment.center, child: const Text('G', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: Color(0xFF4285F4)))),
                ),
                const SizedBox(width: 10),
                gBusy ? SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2.2, color: p.a)) : Text(tr('Continue with Google'), style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: p.text)),
              ]),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Text.rich(
            TextSpan(style: small(), children: [
               TextSpan(text: tr('By continuing with Google you agree to the Sangam360 ')),
              TextSpan(text: tr('Terms of Use'), style: linkSt, recognizer: TapGestureRecognizer()..onTap = () => openLegal(context, 'terms')),
              const TextSpan(text: ' and '),
              TextSpan(text: tr('Privacy Policy'), style: linkSt, recognizer: TapGestureRecognizer()..onTap = () => openLegal(context, 'privacy')),
              const TextSpan(text: '.'),
            ]),
            textAlign: TextAlign.center,
          ),
        ),
        const SizedBox(height: 6),
        Lnk(trf('← Change ({0})', [others.values.join(' / ')]), onTap: () => S.go(Phase.land)),
        Center(
          child: Wrap(alignment: WrapAlignment.center, children: [
            TextButton(onPressed: () => openLegal(context, 'privacy'), child: Text(tr('Privacy Policy'), style: small(p.muted))),
            TextButton(onPressed: () => openLegal(context, 'terms'), child: Text(tr('Terms & Conditions'), style: small(p.muted))),
          ]),
        ),
      ],
    );
  }
}

/* ============================== what next: create / join ============================== */
class ChoiceScreen extends StatelessWidget {
  const ChoiceScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final p = pal, K = S.K;
    final kidOnly = BootCtl.joinKid;
    Widget opt(String t, String s, VoidCallback f, int i) => Enter(
          index: i,
          child: Container(
            margin: const EdgeInsets.only(bottom: 12),
            child: Material(
              color: p.card,
              borderRadius: BorderRadius.circular(20),
              child: InkWell(
                borderRadius: BorderRadius.circular(20),
                onTap: f,
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), border: Border.all(color: p.line)),
                  child: Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(t, style: h3().copyWith(fontSize: 16)), const SizedBox(height: 3), Text(s, style: meta())])),
                    Icon(Icons.chevron_right_rounded, color: p.a),
                  ]),
                ),
              ),
            ),
          ),
        );
    return BootPage(
      head:  BrandHead(sub: tr('What would you like to do?')),
      children: [
        if (!kidOnly) opt(K.createT, K.createS, BootCtl.gotoCreate, 1),
        if (!kidOnly && S.kind == 'school') opt(tr('🧑‍🏫 Join as a teacher'), tr('Use the school code from your Principal'), () => BootCtl.gotoJoin('teacher'), 2),
        if (!kidOnly && S.kind == 'school') opt(tr('🧹 Join as staff'), tr('Drivers, office and support staff: use the school code from your Principal'), () => BootCtl.gotoJoin('staff'), 3),
        opt(K.joinT, K.joinS, () => kidOnly ? BootCtl.addKid() : BootCtl.gotoJoin(S.kind == 'school' ? 'student' : null), 4),
        if (S.addMode && S.me != null && S.me!['status'] == 'approved')
          Lnk(trf('← Back to my {0}', [S.K.word]), onTap: () {
            S.addMode = false;
            BootCtl.joinKid = false;
            S.go(Phase.main);
          }),
        Lnk(tr('Log out'), onTap: App.logout, color: p.muted),
      ],
    );
  }
}

/* ============================== waiting / loading ============================== */
class WaitScreen extends StatelessWidget {
  const WaitScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    final loading = S.waitTitle.startsWith('Loading');
    return BootPage(
      head: const BrandHead(),
      children: [
        const SizedBox(height: 6),
        Center(child: loading ? const _Loader() : const Text('⏳', style: TextStyle(fontSize: 54))),
        const SizedBox(height: 12),
        Text(S.sk(S.waitTitle), textAlign: TextAlign.center, style: h2().copyWith(fontSize: 20)),
        if (S.waitText.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(S.sk(S.waitText), textAlign: TextAlign.center, style: meta().copyWith(fontSize: 14))),
        if (loading) const Padding(padding: EdgeInsets.only(top: 18), child: Skeleton(n: 2)),
        if (!loading || S.waitRetry) ...[
          const SizedBox(height: 18),
          Btn(tr('Check again'), onTap: () => App.boot(), busyDone: false),
        ],
        if (S.waitSwitch) Lnk(trf('🏘️ Switch {0}', [S.K.word]), onTap: () => sheet(context, (_) => const SocRows(title: true))),
        if (!loading) Lnk(tr('Log out'), onTap: App.logout, color: p.muted),
      ],
    );
  }
}

class _Loader extends StatefulWidget {
  const _Loader();
  @override
  State<_Loader> createState() => _LoaderState();
}

class _LoaderState extends State<_Loader> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))..repeat();
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) => Row(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(3, (i) {
          final t = (_c.value - i * .15) % 1.0;
          final s = t < .5 ? t * 2 : (1 - t) * 2;
          return Container(margin: const EdgeInsets.symmetric(horizontal: 5), width: 14, height: 14 + 16 * s, decoration: BoxDecoration(gradient: p.grad, borderRadius: BorderRadius.circular(9)));
        }),
      ),
    );
  }
}

/// the list of the person's workspaces with "Switch"
class SocRows extends StatefulWidget {
  final bool title;
  const SocRows({super.key, this.title = false});
  static (int, String?, List<Doc>)? cache;
  @override
  State<SocRows> createState() => _SocRowsState();
}

class _SocRowsState extends State<SocRows> {
  List<Doc>? v;
  String err = '';
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final c = SocRows.cache;
      if (c != null && now() - c.$1 < 60000 && c.$2 == S.sid) {
        setState(() => v = c.$3);
        return;
      }
      final ids = (await App.socIds()).$2;
      final r = await Future.wait(ids.map((id) async {
        try {
          final x = await Future.wait([socRef(id).get(), memRef(S.uid!, id).get()]);
          final s = x[0], mm = x[1];
          if (!mm.exists) return null;
          final d = mm.data()!;
          return <String, dynamic>{'id': id, 'nm': s.exists ? str(s.data()!['name']).isEmpty ? 'Society' : str(s.data()!['name']) : 'Society', 'role': str(d['role']).replaceFirst('_', ' ').toLowerCase(), 'st': d['status']};
        } catch (_) {
          return null;
        }
      }));
      final l = r.whereType<Doc>().toList();
      SocRows.cache = (now(), S.sid, l);
      if (mounted) setState(() => v = l);
    } catch (_) {
      if (mounted) setState(() => err = tr("Couldn't load your societies."));
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      if (widget.title) SheetTitle(trf(S.skE('Switch {0}'), [S.K.word])),
      if (err.isNotEmpty) Text(S.sk(err), style: meta()),
      if (v == null && err.isEmpty) Text(tr('Loading…'), style: meta()),
      if (v != null && v!.isEmpty) Text(S.sk('No societies yet.'), style: meta()),
      for (final r in v ?? <Doc>[])
        Ex(
          str(r['nm']),
          sub: str(r['role']) + (r['st'] != null && r['st'] != 'approved' ? ' · ${r['st'] == 'pending' ? tr('waiting for approval') : str(r['st'])}' : ''),
          right: r['id'] == S.sid
              ? Text(tr('Active'), style: TextStyle(color: p.green, fontWeight: FontWeight.w800))
              : mini(tr('Switch'), () async {
                  final nav = Navigator.of(context);
                  await App.switchTo(str(r['id']));
                  if (nav.canPop()) nav.pop();
                }),
        ),
    ]);
  }
}
