import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/files.dart';
import '../../core/fs.dart';
import '../../core/kinds.dart';
import '../../core/listen.dart' show msgLabel;
import '../../core/nav.dart';
import '../../core/prefs.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/wall.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/media.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import 'bubbles.dart';
import 'chat_ctl.dart';

/* ===== what can be done with a message, a person and a private chat ===== */

/// the text field of the chat (for "@ Mention" from a profile)
TextEditingController? chatInput;
void Function()? chatFocus;

void msgMenu(BuildContext context, Doc m, bool mine) {
  final p = pal;
  sheet(context, (ctx) {
    Widget it(IconData ic, String t, VoidCallback fn, {bool red = false}) => Ex(t, lead: Icon(ic, color: red ? p.red : p.text), onTap: () {
          Navigator.pop(ctx);
          fn();
        });
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(cut(msgLabel(m), 60), maxLines: 2, overflow: TextOverflow.ellipsis, style: meta())),
      it(Icons.reply_rounded, 'Reply', () => setReply(m)),
      if (mine && str(m['text']).isNotEmpty && now() - intv(m['ts']) <= editMs) it(Icons.edit_rounded, 'Edit', () => editMsg(context, m)),
      if (str(m['text']).isNotEmpty) it(Icons.copy_rounded, 'Copy text', () => copyText(str(m['text']))),
      if (!mine && nav.dmc == null)
        it(Icons.flag_rounded, 'Report', () {
          addDoc(col('reports'), {'msgId': m['id'], 'text': cut(str(m['text']).isEmpty ? 'Photo' : str(m['text']), 200), 'name': m['name'], 'uid': m['uid'], 'by': S.me!['name'], 'ts': now()}).then((_) => toast('🚩', 'Reported', 'The admin will review this message.')).catchError((e) {
            fail(e);
            return col('reports').doc();
          });
        }),
      it(Icons.delete_outline_rounded, 'Delete', () => delMsg(context, m, mine), red: true),
    ]);
  });
}

void copyText(String t) {
  Clipboard.setData(ClipboardData(text: t));
  toast('📋', 'Copied');
}

void setReply(Doc m) {
  Chat.replyTo = {'name': m['name'], 'text': cut(msgLabel(m), 80)};
  Chat.touch();
  chatFocus?.call();
}

void editMsg(BuildContext context, Doc m) {
  final t = TextEditingController(text: str(m['text']));
  sheet(context, (ctx) {
    final left = ((editMs - (now() - intv(m['ts']))) / 60000).ceil().clamp(1, 5);
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const SheetTitle('Edit message'),
      Field(t, 'Message', lines: 4, max: 1000, autofocus: true),
      Text('You can edit this message for $left more minute${left > 1 ? 's' : ''}.', style: meta()),
      const SizedBox(height: 12),
      Row2(
        Btn.o('Cancel', onTap: () => Navigator.pop(ctx)),
        Btn('Save', onTap: () async {
          final v = t.text.trim();
          if (v.isEmpty) {
            toast('ℹ️', "Message can't be empty");
            return;
          }
          if (now() - intv(m['ts']) > editMs) {
            Navigator.pop(ctx);
            toast('ℹ️', 'Time is over', 'Messages can only be edited within 5 minutes.');
            return;
          }
          if (v != m['text']) await updateDoc(Chat.msgRef(str(m['id'])), {'text': v, 'edited': true, 'editedAt': now()});
          if (ctx.mounted) Navigator.pop(ctx);
        }, busyDone: false),
      ),
    ]);
  });
}

void delMsg(BuildContext context, Doc m, bool mine) {
  final early = mine && now() - intv(m['ts']) <= editMs;
  final can = early || (S.isAdm && nav.dmc == null);
  var all = false;
  sheet(context, (ctx) => StatefulBuilder(builder: (ctx, set) {
        final everyone = nav.dmc != null ? 'Delete for ${Chat.peerName()}' : 'Delete for everyone';
        return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const SheetTitle('Delete message', sub: 'Are you sure you want to delete this message?'),
          if (mine && !can && m['deleted'] != true) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text('$everyone is only possible within 5 minutes of sending. This message will be deleted only for you.', style: meta())),
          if (can) CheckboxListTile(value: all, onChanged: (v) => set(() => all = v == true), title: Text(everyone, style: body()), controlAffinity: ListTileControlAffinity.leading, contentPadding: EdgeInsets.zero),
          const SizedBox(height: 8),
          Row2(
            Btn.o('Cancel', onTap: () => Navigator.pop(ctx)),
            Btn.r('Delete', onTap: () async {
              if (all && mine && !(S.isAdm && nav.dmc == null) && now() - intv(m['ts']) > editMs) {
                Navigator.pop(ctx);
                toast('ℹ️', 'Time is over', 'Messages can be deleted for everyone only within 5 minutes.');
                return;
              }
              if (all) {
                await updateDoc(Chat.msgRef(str(m['id'])), {'deleted': true, 'text': '', 'img': '', 'stk': '', 'voice': '', 'file': null, 'loc': null, 'contact': null, 'edited': false, 'delBy': S.uid});
                for (final r in [m['img'], m['voice'], mapv(m['file'])['url']]) {
                  if (r is String && isR(r)) dropFile(r);
                }
              } else {
                Chat.hide(str(m['id']));
                Chat.touch();
              }
              if (ctx.mounted) Navigator.pop(ctx);
            }, busyDone: false),
          ),
        ]);
      }));
}

/* ---------- a member's profile ---------- */
const rName = {'SOCIETY_ADMIN': 'Admin', 'COMMITTEE_MEMBER': 'Committee', 'RESIDENT': 'Resident', 'TENANT': 'Tenant', 'ACCOUNTANT': 'Accountant', 'SECURITY_GUARD': 'Security guard', 'STAFF': 'Staff'};

void profile(BuildContext context, String uid, [Doc? fb]) {
  final d = D['dir'][uid] ?? {};
  final name = str(d['name']).isNotEmpty ? str(d['name']) : (str(fb?['name']).isNotEmpty ? str(fb!['name']) : 'Member');
  final flat = str(d['flat']).isNotEmpty ? str(d['flat']) : str(fb?['flat']);
  final role = d['role'];
  final me = uid == S.uid;
  final mem = S.isAdm ? D['mem'][uid] : null;
  final inDm = nav.dmc != null && nav.dmc!.peer == uid;
  sheet(context, (ctx) {
    final p = pal;
    final on = Chat.online(uid);
    final pr = D['pres'][uid];
    Widget row(String ic, String t, String sm) => Ex(t, sub: sm, lead: Text(ic, style: const TextStyle(fontSize: 20)));
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Center(
        child: GestureDetector(
          onTap: okImg(d['photo']) ? () => Navigator.of(ctx).push(MaterialPageRoute(builder: (_) => ImageViewer(ref: str(d['photo']), name: 'photo.jpg'))) : null,
          child: Av(name, str(d['photo']), size: 96),
        ),
      ),
      const SizedBox(height: 12),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Flexible(child: Text(name + (me ? ' (You)' : ''), textAlign: TextAlign.center, style: h2().copyWith(fontSize: 20))),
        if (rName[role] != null && role != 'RESIDENT') ...[const SizedBox(width: 8), Pill(S.roleChip(role) ?? rName[role]!)],
      ]),
      const SizedBox(height: 4),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(width: 8, height: 8, decoration: BoxDecoration(color: on ? p.green : p.faint, shape: BoxShape.circle)),
        const SizedBox(width: 6),
        Text(on ? 'Online now' : (inDm && pr != null && intv(pr['seen']) > 0 ? 'Last seen ${dayLbl(pr['seen']).toLowerCase()} at ${tm(pr['seen'])}' : 'Offline'), style: meta()),
      ]),
      const SizedBox(height: 10),
      if (flat.isNotEmpty) row(S.kind == 'school' ? '🏫' : S.kind == 'company' ? '🏢' : '🏠', flat, S.sk('Flat / unit')),
      row(S.kind == 'school' ? '🎓' : S.kind == 'company' ? '🏛️' : '🏘️', str(S.soc?['name']), S.sk('Society')),
      if (role != null) row('🪪', S.roleLbl(role), 'Role'),
      if (str(mem?['mobile']).isNotEmpty) row('📞', str(mem!['mobile']), 'Mobile (visible to admins only)'),
      if (mem?['ts'] != null) row('📅', bdate(mem!['ts']), 'Joined'),
      const SizedBox(height: 12),
      if (me)
        Btn.o('✏️ Edit my profile', onTap: () {
          Navigator.pop(ctx);
          navKey.currentState?.popUntil((r) => r.isFirst);
          nav.go('more');
        })
      else ...[
        if (!inDm)
          Btn('💬 Send private message', onTap: () {
            Navigator.pop(ctx);
            Chat.openDM(uid);
          }),
        const SizedBox(height: 8),
        Row(children: [
          if (nav.dmc == null && chatInput != null)
            Expanded(
              child: Btn.o('@ Mention', small: true, onTap: () {
                Navigator.pop(ctx);
                final t = chatInput!;
                final v = t.text;
                t.text = cut('$v${v.isNotEmpty && !v.endsWith(' ') ? ' ' : ''}@${firstName(name)} ', 500);
                t.selection = TextSelection.collapsed(offset: t.text.length);
                chatFocus?.call();
              }),
            ),
          if (nav.dmc == null && chatInput != null && str(mem?['mobile']).isNotEmpty) const SizedBox(width: 8),
          if (str(mem?['mobile']).isNotEmpty) Expanded(child: Btn.g('📞 Call', small: true, onTap: () => launchUrl(Uri.parse(telOf(str(mem!['mobile'])))))),
        ]),
        if (inDm) ...[
          const SizedBox(height: 8),
          Btn.o('🖼 Media, links and docs', small: true, onTap: () {
            Navigator.pop(ctx);
            dmMedia(context);
          }),
          const SizedBox(height: 8),
          Btn.o(Chat.iBlk() ? '✅ Unblock ${firstName(name)}' : '🚫 Block ${firstName(name)}', small: true, color: Chat.iBlk() ? null : p.red, onTap: () {
            Navigator.pop(ctx);
            Chat.iBlk() ? doBlock(false) : askBlock(context);
          }),
        ],
      ],
    ]);
  });
}

/// everyone of the chat that is open
void membersSheet(BuildContext context) {
  final ppl = Chat.chatPpl()..sort((x, y) => str(x['name']).compareTo(str(y['name'])));
  sheet(context, (ctx) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        SheetTitle('Members (${ppl.length})', sub: S.sch ? '${roomTitle(Chat.curRoom())} · ${str(S.soc?['name'])}' : str(S.soc?['name'])),
        for (final m in ppl)
          Ex(
            str(m['name']),
            sub: '${str(m['flat'])} · ${Chat.online(str(m['uid'] ?? m['id'])) ? 'Online' : 'Offline'}',
            lead: Av(str(m['name']), str(m['photo']), size: 44, badge: Chat.online(str(m['uid'] ?? m['id'])) ? onlineDot() : null),
            right: S.roleChip(m['role']) != null ? Pill(S.roleChip(m['role'])!) : null,
            onTap: () {
              Navigator.pop(ctx);
              profile(context, str(m['uid'] ?? m['id']), m);
            },
          ),
      ]));
}

/* ---------- private chat: ⋮ menu, block, media, theme ---------- */
void chMenu(BuildContext context, {required VoidCallback onSearch}) {
  final p = pal;
  final n = firstName(Chat.peerName());
  sheet(context, (ctx) {
    Widget it(String ic, String t, VoidCallback fn, {bool red = false}) => Ex(t, lead: Text(ic, style: const TextStyle(fontSize: 20)), onTap: () {
          Navigator.pop(ctx);
          fn();
        }, right: red ? Icon(Icons.chevron_right_rounded, color: p.red) : null);
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      SheetTitle(Chat.peerName()),
      it('👤', 'View contact', () => profile(context, nav.dmc!.peer, {'name': Chat.peerName()})),
      it('🔍', 'Search', onSearch),
      it('🖼', 'Media, links and docs', () => dmMedia(context)),
      it('🎨', 'Chat theme', () => themePick(context)),
      if (Chat.iBlk()) it('✅', 'Unblock $n', () => doBlock(false)) else it('🚫', 'Block $n', () => askBlock(context), red: true),
    ]);
  });
}

void askBlock(BuildContext context) {
  if (nav.dmc == null) return;
  final n = Chat.peerName(), f = firstName(n);
  sheet(context, (ctx) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        SheetTitle('Block $n?', sub: "$f will no longer be able to send you messages in this private chat, and you won't get notifications from it. $f is not told that you blocked them. You can unblock any time."),
        Row2(Btn.o('Cancel', onTap: () => Navigator.pop(ctx)), Btn.r('Block', onTap: () async {
          await doBlock(true);
          if (ctx.mounted) Navigator.pop(ctx);
        }, busyDone: false)),
      ]));
}

Future<void> doBlock(bool on) async {
  final dmc = nav.dmc;
  if (dmc == null) return;
  final ref = col('dmchats').doc(dmc.cid), c = D['dmc'][dmc.cid], n = firstName(Chat.peerName());
  try {
    if (on) {
      await setDoc(ref, {
        'users': [S.uid, dmc.peer],
        'blk': {S.uid!: true}
      }, merge: true);
    } else {
      final b = {...mapv(c?['blk'])}..remove(S.uid);
      await updateDoc(ref, {'blk': b});
    }
    final cc = D['dmc'][dmc.cid] ?? (D['dmc'][dmc.cid] = {'id': dmc.cid, 'users': [S.uid, dmc.peer]});
    final b = {...mapv(cc['blk'])};
    if (on) {
      b[S.uid!] = true;
    } else {
      b.remove(S.uid);
    }
    cc['blk'] = b;
    D.bump('dmc');
    toast(on ? '🚫' : '✅', on ? '$n blocked' : '$n unblocked', on ? "They can't message you in this chat any more." : 'You can message each other again.');
  } catch (e) {
    fail(e, on ? 'Could not block' : 'Could not unblock');
  }
}

final _dmUrl = RegExp(r'''https?://[^\s<>"']+''', caseSensitive: false);

void dmMedia(BuildContext context, [String tab0 = 'Media']) {
  final dmc = nav.dmc;
  if (dmc == null) return;
  Navigator.of(context).push(MaterialPageRoute(builder: (_) => _DmMedia(cid: dmc.cid, tab0: tab0)));
}

class _DmMedia extends StatefulWidget {
  final String cid, tab0;
  const _DmMedia({required this.cid, required this.tab0});
  @override
  State<_DmMedia> createState() => _DmMediaState();
}

class _DmMediaState extends State<_DmMedia> {
  late String cur = widget.tab0;
  late Map<String, Doc> all = {...D['dmm']};
  @override
  void initState() {
    super.initState();
    col('dmchats').doc(widget.cid).collection('messages').orderBy('ts', descending: true).limit(500).get().then((sn) {
      if (!mounted) return;
      setState(() {
        for (final x in sn.docs) {
          all[x.id] = {...x.data(), 'id': x.id};
        }
      });
    }).catchError((_) {});
  }

  @override
  Widget build(BuildContext context) {
    final p = pal, hd = Chat.hid();
    final v = all.values.where((m) => m['deleted'] != true && !hd.contains(m['id'])).toList()..sort((a, b) => intv(b['ts']).compareTo(intv(a['ts'])));
    final md = v.where((m) => okImg(m['img'])).toList();
    final dc = v.where((m) => str(mapv(m['file'])['name']).isNotEmpty && (okU(mapv(m['file'])['url']) || okData(mapv(m['file'])['data']))).toList();
    final lk = <(Doc, String, Doc?)>[];
    for (final m in v) {
      final seen = <String>{};
      final lp = mapv(m['lp']);
      if (RegExp('^https?://', caseSensitive: false).hasMatch(str(lp['u']))) {
        seen.add(str(lp['u']));
        lk.add((m, str(lp['u']), lp));
      }
      for (final x in _dmUrl.allMatches(str(m['text']))) {
        final u = x.group(0)!.replaceAll(RegExp(r'[).,!?;:]+$'), '');
        if (seen.add(u)) lk.add((m, u, null));
      }
    }
    String when(dynamic t) => '${dayLbl(t)} · ${tm(t)}';
    String who(Doc m) => m['uid'] == S.uid ? 'You' : str(m['name']);
    final n = {'Media': md.length, 'Docs': dc.length, 'Links': lk.length};
    return Scaffold(
      appBar: AppBar(title: Text('Media, links and docs', style: h2())),
      body: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 0), child: Text('Shared with ${Chat.peerName()}', style: meta())),
        Padding(padding: const EdgeInsets.all(16), child: Seg([for (final t in const ['Media', 'Docs', 'Links']) (t, '$t${n[t]! > 0 ? ' (${n[t]})' : ''}')], cur, (x) => setState(() => cur = x))),
        Expanded(
          child: cur == 'Media'
              ? (md.isEmpty
                  ? const Empty('🖼 No photos shared yet')
                  : GridView.count(crossAxisCount: 3, padding: const EdgeInsets.all(12), mainAxisSpacing: 4, crossAxisSpacing: 4, children: [for (final m in md) PhotoThumb(str(m['img']), h: 120)]))
              : cur == 'Docs'
                  ? (dc.isEmpty
                      ? const Empty('📄 No documents shared yet')
                      : ListView(padding: const EdgeInsets.all(16), children: [
                          for (final m in dc) Padding(padding: const EdgeInsets.only(bottom: 12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [DocCard(mapv(m['file']), fg: p.text), Text('${who(m)} · ${when(m['ts'])}', style: small())])),
                        ]))
                  : (lk.isEmpty
                      ? const Empty('🔗 No links shared yet')
                      : ListView(padding: const EdgeInsets.all(16), children: [
                          for (final x in lk)
                            Padding(
                              padding: const EdgeInsets.only(bottom: 12),
                              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                                x.$3 != null ? LinkCard(x.$3!, fg: p.text, small: true) : InkWell(onTap: () => openLink(x.$2), child: Text(x.$2, style: TextStyle(color: p.a, decoration: TextDecoration.underline))),
                                Text('${who(x.$1)} · ${when(x.$1['ts'])}', style: small()),
                              ]),
                            ),
                        ])),
        ),
      ]),
    );
  }
}

/* ---- chat themes: chosen once, kept on this phone for every private chat ---- */
String get _ctKey => 's360-ct-${S.uid ?? ''}';
ChatTheme? ctGet() {
  final v = Prefs.get(_ctKey);
  for (final t in chatThemes) {
    if (t.key == v) return t;
  }
  return null;
}

void themePick(BuildContext context) {
  final now0 = ctGet()?.key ?? '';
  sheet(context, (ctx) {
    final p = pal;
    Widget sw(String key, String name, Color wall, Color other, Color mine, Gradient? g, [bool dk = false]) => GestureDetector(
          onTap: () {
            if (key.isEmpty) {
              Prefs.del(_ctKey);
            } else {
              Prefs.set(_ctKey, key);
            }
            Navigator.pop(ctx);
            Chat.touch();
            toast('🎨', 'Chat theme: $name');
          },
          child: Column(children: [
            Container(
              height: 70,
              decoration: BoxDecoration(color: wall, borderRadius: BorderRadius.circular(14), border: Border.all(color: key == now0 ? p.a : p.line, width: key == now0 ? 3 : 1)),
              child: WallTile(color: wall, dark: dk, radius: BorderRadius.circular(12), child: Padding(
              padding: const EdgeInsets.all(8),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Align(alignment: Alignment.centerLeft, child: Container(width: 34, height: 12, decoration: BoxDecoration(color: other, borderRadius: BorderRadius.circular(6)))),
                const SizedBox(height: 6),
                Align(alignment: Alignment.centerRight, child: Container(width: 40, height: 12, decoration: BoxDecoration(color: g == null ? mine : null, gradient: g, borderRadius: BorderRadius.circular(6)))),
              ]),
            ))),
            const SizedBox(height: 4),
            Text('${key == now0 ? '✓ ' : ''}$name', style: small(p.text).copyWith(fontWeight: FontWeight.w700)),
          ]),
        );
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const SheetTitle('🎨 Chat theme', sub: 'Used for all your private chats on this phone, until you change it.'),
      GridView.count(
        crossAxisCount: 4,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: .75,
        children: [
          sw('', 'Default', p.chat, p.bub, p.a, null, p.dark),
          for (final t in chatThemes) sw(t.key, t.name, t.wall, t.other, t.mine, t.mineGrad, t.dark),
        ],
      ),
    ]);
  });
}
