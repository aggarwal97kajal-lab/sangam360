import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import '../../core/files.dart';
import '../../core/img.dart';
import '../../core/kinds.dart';
import '../../core/nav.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/media.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import '../maps.dart';
import 'chat_ctl.dart';

/* ===== the parts of a chat message ===== */

final urlRe = RegExp(r'''\bhttps?://[^\s<>"']+|\bwww\.[a-z0-9-]+(?:\.[a-z0-9-]+)+[^\s<>"']*''', caseSensitive: false);
final _uTail = RegExp(r'[),.;:!?]+$');
String normUrl(String u) => RegExp('^https?:', caseSensitive: false).hasMatch(u) ? u : 'https://$u';
String firstUrl(String t) {
  final m = urlRe.firstMatch(t);
  return m == null ? '' : normUrl(m.group(0)!.replaceAll(_uTail, ''));
}

String hostOf(String u) {
  try {
    return Uri.parse(u).host.replaceFirst(RegExp(r'^www\.'), '');
  } catch (_) {
    return '';
  }
}

Future<void> openLink(String u) async {
  try {
    await launchUrl(Uri.parse(normUrl(u)), mode: LaunchMode.externalApplication);
  } catch (_) {
    toast('ℹ️', "Couldn't open the link", u);
  }
}

/// text with clickable links and @mention chips
class MsgText extends StatelessWidget {
  final String text;
  final List<String> mentions;
  final Color color, link;
  final String? hl;
  const MsgText(this.text, {super.key, this.mentions = const [], required this.color, required this.link, this.hl});

  @override
  Widget build(BuildContext context) {
    final p = pal;
    final base = TextStyle(fontSize: 15, height: 1.38, color: color, fontFamily: fontFam);
    final names = mentions.map((u) => (u, str(D['dir'][u]?['name']))).where((x) => x.$2.isNotEmpty).toList()..sort((a, b) => b.$2.length.compareTo(a.$2.length));
    final spans = <InlineSpan>[];
    void plain(String s) {
      if (s.isEmpty) return;
      if (hl != null && hl!.isNotEmpty) {
        final lo = s.toLowerCase();
        var i = 0;
        var j = lo.indexOf(hl!);
        while (j >= 0) {
          if (j > i) spans.add(TextSpan(text: s.substring(i, j)));
          spans.add(TextSpan(text: s.substring(j, j + hl!.length), style: TextStyle(backgroundColor: p.amber.withOpacity(.6), color: Colors.black)));
          i = j + hl!.length;
          j = lo.indexOf(hl!, i);
        }
        if (i < s.length) spans.add(TextSpan(text: s.substring(i)));
        return;
      }
      spans.add(TextSpan(text: s));
    }

    void withMentions(String s) {
      if (names.isEmpty) return plain(s);
      while (s.isNotEmpty) {
        var bi = -1;
        (String, String)? bn;
        for (final x in names) {
          final i = s.indexOf('@${x.$2}');
          if (i >= 0 && (bi < 0 || i < bi)) {
            bi = i;
            bn = x;
          }
        }
        if (bi < 0 || bn == null) {
          plain(s);
          break;
        }
        if (bi > 0) plain(s.substring(0, bi));
        final meC = bn.$1 == S.uid;
        spans.add(TextSpan(text: '@${bn.$2}', style: TextStyle(fontWeight: FontWeight.w800, color: meC ? p.amber : link, backgroundColor: (meC ? p.amber : link).withOpacity(.12))));
        s = s.substring(bi + bn.$2.length + 1);
      }
    }

    var last = 0;
    for (final m in urlRe.allMatches(text)) {
      var u = m.group(0)!;
      var tail = '';
      final tm0 = _uTail.firstMatch(u);
      if (tm0 != null) {
        tail = tm0.group(0)!;
        u = u.substring(0, u.length - tail.length);
      }
      if (u.isEmpty) continue;
      if (m.start > last) withMentions(text.substring(last, m.start));
      spans.add(TextSpan(text: u, style: TextStyle(color: link, decoration: TextDecoration.underline, decorationColor: link), recognizer: TapGestureRecognizer()..onTap = () => openLink(u)));
      if (tail.isNotEmpty) spans.add(TextSpan(text: tail));
      last = m.end;
    }
    if (last < text.length) withMentions(text.substring(last));
    return Text.rich(TextSpan(style: base, children: spans));
  }
}

/// the message this one answers
class ReplyQuote extends StatelessWidget {
  final Doc r;
  final Color fg, bar;
  const ReplyQuote(this.r, {super.key, required this.fg, required this.bar});
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 6),
        padding: const EdgeInsets.fromLTRB(10, 6, 10, 6),
        decoration: BoxDecoration(color: fg.withOpacity(.08), borderRadius: BorderRadius.circular(10), border: Border(left: BorderSide(color: bar, width: 3))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(str(r['name']), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800, color: bar)),
          Text(str(r['text']), maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 13, color: fg.withOpacity(.8))),
        ]),
      );
}

/// a photo in a message
class ImgMsg extends StatelessWidget {
  final String ref;
  final bool hd;
  const ImgMsg(this.ref, {super.key, this.hd = false});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ImageViewer(ref: ref, name: 'photo.jpg'))),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 320, maxWidth: 260, minWidth: 160, minHeight: 120),
            child: Stack(children: [
              RefImage(ref, fit: BoxFit.cover, width: 260),
              if (hd) Positioned(right: 6, top: 6, child: Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(6)), child: const Text('HD', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800)))),
            ]),
          ),
        ),
      );
}

/// a document in a message: a preview, the kind, name, pages and size; a tap opens it
class DocCard extends StatelessWidget {
  final Doc f;
  final Color fg;
  const DocCard(this.f, {super.key, required this.fg});
  @override
  Widget build(BuildContext context) {
    final name = str(f['name']);
    final ext = name.contains('.') ? cut(name.split('.').last.toLowerCase(), 5) : '';
    final k = docColors[ext] ?? const Color(0xFF64748B);
    final th = str(f['thumb']);
    return GestureDetector(
      onTap: () async {
        if (str(f['url']).isNotEmpty) {
          await openRef(context, str(f['url']), name: name, mime: str(f['type']));
        } else if (str(f['data']).isNotEmpty) {
          final b = fromDataUrl(str(f['data']));
          if (b != null) await saveBytes(name, b, str(f['type']).isEmpty ? mimeOf(name, b) : str(f['type']));
        }
      },
      child: SizedBox(
        width: 240,
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          if (th.startsWith('data:image/')) ClipRRect(borderRadius: const BorderRadius.vertical(top: Radius.circular(10)), child: SizedBox(height: 120, child: Image.memory(fromDataUrl(th)!, fit: BoxFit.cover, alignment: Alignment.topCenter))),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: fg.withOpacity(.07), borderRadius: th.startsWith('data:image/') ? const BorderRadius.vertical(bottom: Radius.circular(10)) : BorderRadius.circular(10)),
            child: Row(children: [
              Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8), decoration: BoxDecoration(color: k, borderRadius: BorderRadius.circular(6)), child: Text((ext.isEmpty ? 'file' : ext).toUpperCase(), style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800))),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(name, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5, color: fg)),
                  Text([if (intv(f['pages']) > 0) '${f['pages']} page${intv(f['pages']) == 1 ? '' : 's'}', ext.toUpperCase(), fsz(numv(f['size']))].where((x) => x.isNotEmpty).join(' · '), style: TextStyle(fontSize: 11.5, color: fg.withOpacity(.7))),
                ]),
              ),
              Icon(Icons.download_rounded, color: fg.withOpacity(.75), size: 20),
            ]),
          ),
        ]),
      ),
    );
  }
}

/// a contact card: call, copy
class ContactCard extends StatelessWidget {
  final Doc c;
  final Color fg;
  const ContactCard(this.c, {super.key, required this.fg});
  @override
  Widget build(BuildContext context) => SizedBox(
        width: 230,
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            Av(str(c['name']), null, size: 40),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(str(c['name']), style: TextStyle(fontWeight: FontWeight.w800, color: fg)), Text(str(c['phone']), style: TextStyle(fontSize: 12.5, color: fg.withOpacity(.75)))])),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: TextButton(onPressed: () => launchUrl(Uri.parse(telOf(str(c['phone'])))).catchError((_) => false), child: Text('📞 Call', style: TextStyle(color: fg, fontWeight: FontWeight.w700)))),
            Expanded(
              child: TextButton(
                  onPressed: () {
                    Clipboard.setData(ClipboardData(text: str(c['phone'])));
                    toast('📋', 'Number copied');
                  },
                  child: Text('📋 Copy', style: TextStyle(color: fg, fontWeight: FontWeight.w700))),
            ),
          ]),
        ]),
      );
}

/// a location: the drawn map, what it is, View on map / Stop sharing
class LocCard extends StatelessWidget {
  final Doc l;
  final Doc m;
  final Color fg;
  const LocCard(this.l, this.m, {super.key, required this.fg});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    final live = l['live'] == true;
    final I = live ? Chat.liveInfo(m) : null;
    final lat = I?.lat ?? numv(l['lat']).toDouble(), lng = I?.lng ?? numv(l['lng']).toDouble();
    final on = live && !I!.ended;
    return SizedBox(
      width: 240,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        GestureDetector(onTap: () => openLocShow(context, l, m), child: MapArt(h: 96, live: on)),
        const SizedBox(height: 8),
        Text(live ? (I!.ended ? 'Live location ended' : 'Live location') : 'Location', style: TextStyle(fontWeight: FontWeight.w800, color: fg)),
        Text(live ? (I!.ended ? 'Last seen here ${ago(I.ts)}' : 'Until ${tm(l['until'])} · updated ${ago(I.ts)}') : '${lat.toStringAsFixed(4)}, ${lng.toStringAsFixed(4)}${intv(l['acc']) > 0 ? ' · accurate to ${l['acc']} m' : ''}', style: TextStyle(fontSize: 12, color: fg.withOpacity(.75))),
        const SizedBox(height: 6),
        Row(children: [
          Expanded(child: TextButton(onPressed: () => openLocShow(context, l, m), style: TextButton.styleFrom(backgroundColor: fg.withOpacity(.08)), child: Text(on ? 'View live location' : 'View on map', style: TextStyle(color: fg, fontWeight: FontWeight.w700, fontSize: 13)))),
          if (on && m['uid'] == S.uid) ...[
            const SizedBox(width: 6),
            Expanded(child: TextButton(onPressed: () => locStop(l, nav.dmc?.cid), style: TextButton.styleFrom(backgroundColor: p.red.withOpacity(.12)), child: Text('Stop sharing', style: TextStyle(color: p.red, fontWeight: FontWeight.w700, fontSize: 13)))),
          ],
        ]),
      ]),
    );
  }
}

/// a poll: options with bars, my vote, View votes
class PollCard extends StatelessWidget {
  final Doc m;
  final Color fg, acc;
  const PollCard(this.m, {super.key, required this.fg, required this.acc});
  @override
  Widget build(BuildContext context) {
    final P = mapv(m['poll']);
    final opts = strList(P['opts']);
    final T = Chat.pollTally(m);
    final mine = Chat.votesOf(str(m['id']));
    return SizedBox(
      width: 250,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(str(P['q']), style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: fg)),
        Text(P['multi'] == true ? 'Select one or more' : 'Select one', style: TextStyle(fontSize: 11.5, color: fg.withOpacity(.7))),
        const SizedBox(height: 8),
        for (var i = 0; i < opts.length; i++)
          GestureDetector(
            onTap: () => Chat.pollVote(m, i),
            child: Container(
              margin: const EdgeInsets.only(bottom: 8),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Row(children: [
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(color: mine.contains(i) ? acc : Colors.transparent, shape: P['multi'] == true ? BoxShape.rectangle : BoxShape.circle, borderRadius: P['multi'] == true ? BorderRadius.circular(5) : null, border: Border.all(color: mine.contains(i) ? acc : fg.withOpacity(.4), width: 2)),
                    child: mine.contains(i) ? const Icon(Icons.check_rounded, size: 14, color: Colors.white) : null,
                  ),
                  const SizedBox(width: 8),
                  Expanded(child: Text(opts[i], style: TextStyle(color: fg, fontSize: 14))),
                  Text('${T.c[i]}', style: TextStyle(color: fg, fontWeight: FontWeight.w700)),
                ]),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(9),
                  child: TweenAnimationBuilder<double>(
                    tween: Tween(begin: 0, end: T.voters > 0 ? T.c[i] / T.voters : 0),
                    duration: const Duration(milliseconds: 500),
                    builder: (_, v, __) => LinearProgressIndicator(value: v, minHeight: 6, backgroundColor: fg.withOpacity(.12), color: acc),
                  ),
                ),
              ]),
            ),
          ),
        TextButton(
          onPressed: T.voters == 0
              ? null
              : () => sheet(context, (_) {
                    final R = Chat.pollTally(m);
                    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                      SheetTitle('Poll votes', sub: str(P['q'])),
                      for (var i = 0; i < opts.length; i++) ...[
                        Row(children: [Expanded(child: Text(opts[i], style: h3())), Text('${R.c[i]} vote${R.c[i] == 1 ? '' : 's'}', style: meta())]),
                        Padding(padding: const EdgeInsets.only(bottom: 12, top: 2), child: Text(R.who[i].isEmpty ? 'No votes' : R.who[i].join(', '), style: meta())),
                      ],
                    ]);
                  }),
          child: Text(T.voters > 0 ? 'View votes · ${T.voters}' : 'No votes yet', style: TextStyle(color: T.voters > 0 ? acc : fg.withOpacity(.5), fontWeight: FontWeight.w700)),
        ),
      ]),
    );
  }
}

/* ---------- link previews ---------- */
final Map<String, Doc> _lpCache = {};
Doc? lpBase(String u) {
  final s = hostOf(u);
  if (s.isEmpty) return null;
  final o = <String, dynamic>{'u': u, 's': s};
  final yt = RegExp(r'(?:youtube\.com/(?:watch\?(?:.*&)?v=|shorts/|live/)|youtu\.be/)([\w-]{6,})').firstMatch(u);
  if (yt != null) o['i'] = 'https://i.ytimg.com/vi/${yt.group(1)}/hqdefault.jpg';
  return o;
}

Future<Doc?> lpFetch(String u) async {
  if (_lpCache.containsKey(u)) return _lpCache[u];
  final base = lpBase(u);
  if (base == null) return null;
  var out = base;
  try {
    final r = await http.get(Uri.parse(linkPreviewApi + Uri.encodeComponent(u))).timeout(const Duration(seconds: 5));
    if (r.statusCode == 200) {
      final j = jsonDecode(r.body);
      final d = mapv(mapv(j)['data']);
      if (str(d['title']).isNotEmpty || str(d['description']).isNotEmpty) {
        final im = str(mapv(d['image'])['url']);
        out = {'u': u, 's': cut(str(d['publisher']).isNotEmpty ? str(d['publisher']) : str(base['s']), 60), 't': cut(str(d['title']), 140), 'd': cut(str(d['description']), 220)};
        if (RegExp('^https://', caseSensitive: false).hasMatch(im)) {
          out['i'] = cut(im, 500);
        } else if (base['i'] != null) {
          out['i'] = base['i'];
        }
      }
    }
  } catch (_) {}
  _lpCache[u] = out;
  return out;
}

Doc? lpCached(String u) => _lpCache[u];

class LinkCard extends StatelessWidget {
  final Doc lp;
  final Color fg;
  final bool small;
  const LinkCard(this.lp, {super.key, required this.fg, this.small = false});
  @override
  Widget build(BuildContext context) {
    final img = str(lp['i']);
    return GestureDetector(
      onTap: () => openLink(str(lp['u'])),
      child: Container(
        width: small ? null : 250,
        decoration: BoxDecoration(color: fg.withOpacity(.07), borderRadius: BorderRadius.circular(10)),
        clipBehavior: Clip.antiAlias,
        child: small
            ? Row(children: [
                if (img.startsWith('https://')) CachedNetworkImage(imageUrl: img, width: 56, height: 56, fit: BoxFit.cover, errorWidget: (_, __, ___) => const SizedBox(width: 56)),
                Expanded(child: Padding(padding: const EdgeInsets.all(8), child: _txt())),
              ])
            : Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                if (img.startsWith('https://')) CachedNetworkImage(imageUrl: img, height: 120, fit: BoxFit.cover, errorWidget: (_, __, ___) => const SizedBox.shrink()),
                Padding(padding: const EdgeInsets.all(8), child: _txt()),
              ]),
      ),
    );
  }

  Widget _txt() => Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
        if (str(lp['t']).isNotEmpty) Text(str(lp['t']), maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: fg)),
        if (str(lp['d']).isNotEmpty) Text(str(lp['d']), maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, color: fg.withOpacity(.75))),
        Text('🔗 ${str(lp['s']).isNotEmpty ? str(lp['s']) : hostOf(str(lp['u']))}', style: TextStyle(fontSize: 11, color: fg.withOpacity(.6))),
      ]);
}
