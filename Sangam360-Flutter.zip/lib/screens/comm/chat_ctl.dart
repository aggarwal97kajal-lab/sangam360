import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../core/api.dart';
import '../../core/app.dart';
import '../../core/fs.dart';
import '../../core/listen.dart';
import '../../core/nav.dart';
import '../../core/prefs.dart';
import '../../core/push.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/media.dart';

const roomStaff = '@staff';
const staffR = ['SOCIETY_ADMIN', 'COMMITTEE_MEMBER', 'ACCOUNTANT', 'SECURITY_GUARD', 'STAFF'];
const editMs = 5 * 60 * 1000;

String roomLbl(String r) => r == roomStaff ? 'Staff room' : r;
String roomTitle(String r) => r == roomStaff ? 'Staff room' : '$r chat';
String roomCk(String r, int ts) => '$r|${ts.toString().padLeft(15, '0')}';

/// The chat: the community chat (one per class + staff room in a school), private chats, what is replied to, read markers.
class Chat extends ChangeNotifier {
  static final Chat I = Chat._();
  Chat._();

  static Doc? replyTo;
  static String _room = '';
  static final Map<String, Map<String, Doc>> rm = {};
  static final List<StreamSubscription> _roomU = [];
  static StreamSubscription? _dmU;
  static bool _wired = false;
  static int openAt = 0;

  /// called once when the app starts
  static void wire() {
    if (_wired) return;
    _wired = true;
    Listen.chatOpen = () => nav.tab == 'comm' && nav.comm == 'chat' && nav.dmc == null && _fg;
    Listen.mentionHit = mnHit;
    App.onStart.add(_start);
    App.onResumeCbs.add(() {
      _fg = true;
      markRead();
    });
  }

  static bool _fg = true;
  static void foreground(bool on) => _fg = on;

  static void _start() {
    leaveDM(quiet: true);
    replyTo = null;
    _mnCaught = '';
    _room = '';
    if (S.sch) {
      roomListen();
      Listen.offs.add(_roomOff);
    }
    Listen.offs.add(() => leaveDM(quiet: true));
  }

  static void touch() => I.notifyListeners();

  /* ---------- SCHOOL: one group chat per class, and one for the staff ---------- */
  static List<String> chatRooms() {
    if (!S.sch || S.me == null) return [];
    if (S.isOwner) return [...S.schClasses().where((c) => c != roomStaff), roomStaff];
    final c = S.clsOf(S.me);
    if (S.isStu(S.me)) return [c.isEmpty ? 'School' : c];
    return [if (S.isTeacher && c.isNotEmpty && c != 'Teacher') c, roomStaff];
  }

  static String get _roomKey => 'sh-room-${S.sid}-${S.pidv}';

  static String curRoom() {
    final R = chatRooms();
    if (R.isEmpty) return '';
    if (R.contains(_room)) return _room;
    final w = Prefs.get(_roomKey);
    return _room = R.contains(w) ? w : R.first;
  }

  static bool roomUnread(String r) {
    final M = rm[r];
    if (M == null) return false;
    final t = rdGet('g:$r');
    return M.values.any((m) => m['uid'] != S.uid && m['deleted'] != true && intv(m['ts']) > t);
  }

  static void _roomOff() {
    for (final u in _roomU) {
      u.cancel();
    }
    _roomU.clear();
  }

  static void roomListen() {
    _roomOff();
    rm.clear();
    D.set('msg', {});
    _room = '';
    final cur = curRoom();
    if (cur.isEmpty) return;
    for (final r in (S.isOwner ? [cur] : chatRooms())) {
      var first = true;
      _roomU.add(col('messages').where('ck', isGreaterThanOrEqualTo: '$r|').where('ck', isLessThanOrEqualTo: '$r|').orderBy('ck', descending: true).limit(80).snapshots().listen((s) {
        final o = <String, Doc>{};
        for (final d in s.docs) {
          final v = {...d.data(), 'id': d.id};
          if (v['cls'] == r) o[d.id] = v;
        }
        rm[r] = o;
        final quiet = first || s.metadata.isFromCache;
        if (!s.metadata.isFromCache) first = false;
        if (!quiet) {
          for (final c in s.docChanges) {
            if (c.type == DocumentChangeType.added && !c.doc.metadata.hasPendingWrites) {
              final d = {...?c.doc.data(), 'id': c.doc.id};
              if (d['cls'] == r) _roomNew(d, r);
            }
          }
        }
        if (r == curRoom()) {
          D.set('msg', o);
          mnCatch();
        } else {
          D.bump('rooms');
        }
      }, onError: (e) {
        if (!(e is FirebaseException && e.code == 'permission-denied')) toast('⚠️', 'Could not load the chat', 'Check your connection.');
      }));
    }
  }

  static void _roomNew(Doc d, String r) {
    if (d['uid'] == S.uid) return;
    if (mnHit(d)) return;
    final open = nav.tab == 'comm' && nav.comm == 'chat' && nav.dmc == null && r == curRoom() && _fg;
    if (!open) toast('💬', str(d['name']) + (chatRooms().length > 1 ? ' · ${roomLbl(r)}' : ''), msgLabel(d), false, 'chat');
  }

  static void setRoom(String r) {
    if (r == curRoom() || !chatRooms().contains(r)) return;
    _room = r;
    Prefs.set(_roomKey, r);
    replyTo = null;
    if (S.isOwner) {
      D.set('msg', {});
      roomListen();
    } else {
      D.set('msg', rm[r] ?? {});
    }
    touch();
  }

  /// the people of the chat that is open: the class with its teacher and the Principal, or the staff
  static List<Doc> chatPpl() {
    final all = D['dir'].values.toList();
    if (!S.sch || nav.dmc != null) return all;
    final r = curRoom();
    return all.where((p) => r == roomStaff ? staffR.contains(p['role']) : p['role'] == 'SOCIETY_ADMIN' || S.clsOf(p) == r).toList();
  }

  /* ---------- read markers (kept on this phone) ---------- */
  static String _rdK(String k) => 'sh-rd-${S.sid}-${S.uid}-$k';
  static int rdGet(String k) => int.tryParse(Prefs.get(_rdK(k))) ?? 0;
  static void rdSet(String k, int t) {
    if (t > rdGet(k)) Prefs.set(_rdK(k), '$t');
  }

  /* ---------- messages hidden "for me" ---------- */
  static String get _hk => 'sh-hid-${S.sid}-${S.uid}';
  static Set<String> hid() {
    final j = Prefs.json(_hk);
    return {for (final x in (j is List ? j : const [])) x.toString()};
  }

  static void hide(String id) {
    final h = hid()..add(id);
    Prefs.setJson(_hk, h.toList());
  }

  /* ---------- private chats ---------- */
  /// a 2nd student of a login in another class has chats of its own ("_c<class>")
  static String dmScope() {
    try {
      final a = S.clsOf(S.me), b = S.clsOf(S.prim);
      return S.sch && S.pid != null && S.pid != S.uid && a.isNotEmpty && a != b ? a : '';
    } catch (_) {
      return '';
    }
  }

  static String dmSc(Doc? c) => str(mapv(c?['sc'])[S.uid]);
  static bool dmMine(Doc c) => !S.sch || dmSc(c) == dmScope();
  static Doc? dmKid(Doc c) {
    final sc = dmSc(c);
    for (final k in S.myProfiles()) {
      if ((k['id'] == S.uid || k['status'] == 'approved') && (sc.isNotEmpty ? S.clsOf(k) == sc : k['id'] == S.uid)) return k;
    }
    return null;
  }

  static ({String n, String? p, String f}) dmWho(Doc? c, String pu) {
    final d = D['dir'][pu] ?? {}, w = mapv(mapv(c?['who'])[pu]);
    final n = str(w['n']).isNotEmpty
        ? str(w['n'])
        : str(d['name']).isNotEmpty
            ? str(d['name'])
            : str(mapv(c?['names'])[pu]).isNotEmpty
                ? str(mapv(c?['names'])[pu])
                : 'Member';
    final p = str(w['n']).isNotEmpty ? (str(w['p']).isNotEmpty ? str(w['p']) : (w['k'] == 1 ? null : d['photo'] as String?)) : d['photo'] as String?;
    return (n: n, p: p, f: str(w['f']).isNotEmpty ? str(w['f']) : str(d['flat']));
  }

  static Doc? dmCur() => nav.dmc == null ? null : (D['dmc'][nav.dmc!.cid] ?? nav.dmc!.seed);
  static String peerName() => nav.dmc == null ? '' : dmWho(dmCur(), nav.dmc!.peer).n;
  static String? peerPhoto() => nav.dmc == null ? null : dmWho(dmCur(), nav.dmc!.peer).p;
  static String shortPh(String? p) => p != null && p.length < 600 ? p : '';

  static Map<String, dynamic> dmBlkM() => mapv(D['dmc'][nav.dmc?.cid]?['blk']);
  static bool iBlk() => nav.dmc != null && dmBlkM()[S.uid] == true;
  static bool blkAny() => dmBlkM().values.any((v) => v == true);

  static DocRef msgRef(String id) => nav.dmc != null ? col('dmchats').doc(nav.dmc!.cid).collection('messages').doc(id) : dref('messages', id);

  static Future<void> pushMsg(Map<String, dynamic> o) async {
    final dmc = nav.dmc;
    if (dmc != null && blkAny()) throw AppError(iBlk() ? 'You blocked this contact. Unblock to send messages.' : "You can't send messages to this chat.");
    if (S.pid != null && S.pid != S.uid) {
      o['pid'] = S.pid;
      final p = shortPh(myPhoto());
      if (p.isNotEmpty) o['ph'] = p;
    }
    if (dmc == null) {
      if (S.sch) {
        final r = curRoom();
        o['cls'] = r;
        o['ck'] = roomCk(r, intv(o['ts']));
      }
      await addDoc(col('messages'), o);
      return;
    }
    final ref = col('dmchats').doc(dmc.cid), c = D['dmc'][dmc.cid], seed = dmc.seed;
    final me = {'n': str(S.me!['name']), 'f': str(S.me!['flat']), 'p': shortPh(myPhoto()), 'k': o['pid'] != null ? 1 : 0};
    final old = {
      'users': [S.uid, dmc.peer],
      'names': {S.uid!: S.me!['name'], dmc.peer: peerName()},
      'last': cut(msgLabel(o), 60),
      'lastTs': o['ts'],
      'lastFrom': S.uid,
      'reads': {S.uid!: o['ts']},
    };
    final who = <String, dynamic>{S.uid!: me};
    final sw = mapv(seed['who']);
    if (sw[dmc.peer] != null && mapv(c?['who'])[dmc.peer] == null) who[dmc.peer] = sw[dmc.peer];
    final sc = {...mapv(c?['sc']), ...dmc.sc};
    final scoped = sc.isNotEmpty;
    try {
      await setDoc(ref, {...old, 'who': who, if (scoped) 'sc': sc}, merge: true);
    } on FirebaseException catch (e) {
      if (scoped || e.code != 'permission-denied') rethrow;
      await setDoc(ref, old, merge: true);
    }
    await addDoc(ref.collection('messages'), o);
  }

  /// a message with the usual fields (and the reply, if one is chosen)
  static Future<void> sendMsg(Map<String, dynamic> x) async {
    final o = <String, dynamic>{'uid': S.uid, 'name': S.me!['name'], 'flat': S.me!['flat'], 'text': '', 'ts': now(), ...x};
    if (replyTo != null) {
      o['replyTo'] = replyTo;
      replyTo = null;
      touch();
    }
    await pushMsg(o);
  }

  static void markRead() {
    final dmc = nav.dmc;
    if (dmc == null || !_fg) return;
    final last = D['dmm'].values.where((m) => m['uid'] != S.uid).fold<int>(0, (a, m) => intv(m['ts']) > a ? intv(m['ts']) : a);
    if (last == 0) return;
    final c = D['dmc'][dmc.cid];
    if (intv(mapv(c?['reads'])[S.uid]) >= last) return;
    setDoc(col('dmchats').doc(dmc.cid), {
      'reads': {S.uid!: now() > last ? now() : last}
    }, merge: true)
        .catchError((_) {});
  }

  static void leaveDM({bool quiet = false}) {
    if (nav.dmc == null) return;
    nav.dmc = null;
    _dmU?.cancel();
    _dmU = null;
    D.set('dmm', {});
    replyTo = null;
    App.pset({'typing': 0, 'typingTo': ''});
    if (!quiet) nav.touch();
  }

  static void dmBack() {
    final f = nav.dmFrom;
    leaveDM();
    nav.setComm(f == 'chat' ? 'chat' : 'inbox');
  }

  /// opens a private chat. cid0: an existing chat (from the inbox)
  static void openDM(String raw, {String? from, String? cid0, String? cid}) {
    cid0 ??= cid;
    final uid = Session.auid(raw);
    if (S.me == null || uid.isEmpty || uid == S.uid) return;
    final ids = [S.uid!, uid]..sort();
    final base = ids.join('_');
    final sc = <String, dynamic>{}, seed = <String, dynamic>{'names': {}, 'who': <String, dynamic>{}};
    var id = cid0 ?? base;
    if (cid0 == null && S.sch) {
      final mine = dmScope();
      final kid = raw != uid ? D['mem'][raw] : null;
      final theirs = kid != null && S.clsOf(kid).isNotEmpty && S.clsOf(kid) != S.clsOf(D['dir'][uid] ?? {}) ? S.clsOf(kid) : '';
      if (kid != null) (seed['who'] as Map<String, dynamic>)[uid] = {'n': str(kid['name']), 'f': str(kid['flat']), 'p': shortPh(kid['photoUrl'] as String?), 'k': 1};
      if (mine.isNotEmpty) {
        sc[S.uid!] = mine;
        id = '${base}_c${dmHash(mine)}';
      } else if (theirs.isNotEmpty) {
        sc[uid] = theirs;
        id = '${base}_c${dmHash(theirs)}';
      }
    }
    if (nav.dmc != null && nav.dmc!.cid == id) return;
    final onChat = nav.tab == 'comm' && nav.comm == 'chat' && nav.dmc == null;
    leaveDM(quiet: true);
    seed['sc'] = sc;
    final sw = mapv(seed['who'])[uid];
    nav.dmc = Dm(id, uid, sw != null ? str(mapv(sw)['n']) : (str(D['dir'][uid]?['name']).isNotEmpty ? str(D['dir'][uid]!['name']) : 'Member'), sc, seed);
    Push.clear('d:$id');
    nav.dmFrom = from ?? (onChat ? 'chat' : 'inbox');
    D.set('dmm', {});
    openAt = now();
    final cidF = id;
    _dmU = col('dmchats').doc(id).collection('messages').orderBy('ts', descending: true).limit(80).snapshots().listen((sn) {
      if (nav.dmc?.cid != cidF) return;
      D.set('dmm', {for (final x in sn.docs) x.id: {...x.data(), 'id': x.id}});
      markRead();
    }, onError: (e) {
      toast('🔒', 'Private chat unavailable', e is FirebaseException && e.code == 'permission-denied' ? 'Publish firestore.rules-dm-additions.txt in Firebase → Firestore → Rules.' : 'Check your connection.');
    });
    if (nav.tab != 'comm') nav.goTab('comm');
    nav.comm = 'chat';
    navKey.currentState?.popUntil((r) => r.isFirst);
    nav.touch();
  }

  /* ---------- @mentions ---------- */
  static String get _mnKey => 'sh-mn-${S.sid}-${S.uid}';
  static void mnAnnounce(Doc d) {
    toast('📣', '${str(d['name'])} mentioned you', cut(str(d['text']), 90));
    beep();
    Bell.I.add('📣', '${str(d['name'])} mentioned you', cut(str(d['text']), 90));
    Toasts.I.stickLast(() {
      nav.goTab('comm');
      nav.setComm('chat');
    });
    final o = int.tryParse(Prefs.get(_mnKey)) ?? 0;
    Prefs.set(_mnKey, '${intv(d['ts']) > o ? intv(d['ts']) : o}');
  }

  static bool mnHit(Doc d) {
    if (!strList(d['mentions']).contains(S.uid)) return false;
    mnAnnounce(d);
    return true;
  }

  static String _mnCaught = '';
  static void mnCatch() {
    if (S.me == null || _mnCaught == '${S.sid}${S.uid}') return;
    final L = D['msg'].values.toList();
    if (L.isEmpty) return;
    _mnCaught = '${S.sid}${S.uid}';
    final last = int.tryParse(Prefs.get(_mnKey)) ?? 0;
    if (last == 0) {
      Prefs.set(_mnKey, '${now()}');
      return;
    }
    final M = L.where((m) => m['uid'] != S.uid && m['deleted'] != true && strList(m['mentions']).contains(S.uid) && intv(m['ts']) > last).toList()..sort((a, b) => intv(a['ts']).compareTo(intv(b['ts'])));
    if (M.isNotEmpty) Future.delayed(const Duration(milliseconds: 1800), () => mnAnnounce(M.last));
  }

  /* ---------- presence ---------- */
  static bool online(String? u) {
    final p = D['pres'][u];
    return p != null && now() - intv(p['seen']) < 130000;
  }

  static String lastSeen(String u) {
    final pr = D['pres'][u];
    return pr != null && intv(pr['seen']) > 0 ? 'last seen ${dayLbl(pr['seen']).toLowerCase()} at ${tm(pr['seen'])}' : 'Offline';
  }

  static int _lastTyp = 0;
  static void typing() {
    if (now() - _lastTyp > 2000) {
      _lastTyp = now();
      App.pset({'typing': now(), 'typingTo': nav.dmc?.peer ?? '', 'typingIn': nav.dmc != null || !S.sch ? '' : curRoom()});
    }
  }

  static List<String> typers() => D['pres']
      .values
      .where((p) =>
          p['uid'] != S.uid &&
          now() - intv(p['typing']) < 4500 &&
          online(str(p['uid'])) &&
          (nav.dmc != null ? p['uid'] == nav.dmc!.peer && p['typingTo'] == S.uid : str(p['typingTo']).isEmpty && (!S.sch || str(p['typingIn']) == curRoom())))
      .map((p) => firstName(str(p['name'])))
      .toList();

  /* ---------- polls: votes are kept in presence/{uid}.pv.{msgId} ---------- */
  static List<int> votesOf(String id) => listv(mapv(D['pres'][S.uid]?['pv'])[id]).map((e) => intv(e)).toList();

  static ({List<int> c, List<List<String>> who, int voters}) pollTally(Doc m) {
    final opts = listv(mapv(m['poll'])['opts']);
    final n = opts.length;
    final c = List<int>.filled(n, 0);
    final who = List.generate(n, (_) => <String>[]);
    var voters = 0;
    for (final p in D['pres'].values) {
      final v = mapv(p['pv'])[m['id']];
      if (v is List && v.isNotEmpty) {
        var ok = false;
        for (final i0 in v) {
          final i = intv(i0);
          if (i >= 0 && i < n) {
            c[i]++;
            who[i].add(str(p['name']).isNotEmpty ? str(p['name']) : str(D['dir'][p['uid']]?['name'] ?? 'Member'));
            ok = true;
          }
        }
        if (ok) voters++;
      }
    }
    return (c: c, who: who, voters: voters);
  }

  static void pollVote(Doc m, int i) {
    var v = votesOf(str(m['id']));
    final has = v.contains(i);
    final multi = mapv(m['poll'])['multi'] == true;
    v = multi ? (has ? v.where((x) => x != i).toList() : [...v, i]) : (has ? <int>[] : [i]);
    final me = D['pres'][S.uid] ?? (D['pres'][S.uid!] = {'uid': S.uid, 'name': S.me!['name']});
    me['pv'] = {...mapv(me['pv']), str(m['id']): v};
    D.bump('pres');
    App.pset({
      'pv': {str(m['id']): v}
    });
  }

  /* ---------- live location in a chat ---------- */
  static ({double lat, double lng, int ts, int acc, bool ended}) liveInfo(Doc m) {
    final l = mapv(m['loc']);
    final cid = nav.dmc?.cid;
    final src = cid != null ? mapv(mapv(D['dmc'][cid]?['live'])[m['uid']]) : mapv(D['pres'][m['uid']]?['live']);
    final cur = src.isNotEmpty && src['lid'] == l['lid'] ? src : null;
    return (
      lat: numv(cur != null && cur['lat'] != null ? cur['lat'] : l['lat']).toDouble(),
      lng: numv(cur != null && cur['lng'] != null ? cur['lng'] : l['lng']).toDouble(),
      ts: intv(cur?['ts'] ?? m['ts']),
      acc: intv(cur != null && cur['lat'] != null ? cur['acc'] : l['acc']),
      ended: (cur != null && intv(cur['end']) > 0) || now() >= intv(l['until']) || (src.isNotEmpty && src['lid'] != l['lid'] && intv(src['ts']) > intv(m['ts'])),
    );
  }
}
