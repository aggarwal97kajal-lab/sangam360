import 'dart:async';
import 'dart:math';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:printing/printing.dart';

import '../../core/api.dart';
import '../../core/app.dart';
import '../../core/files.dart';
import '../../core/img.dart';
import '../../core/kinds.dart';
import '../../core/live.dart';
import '../../core/native.dart';
import '../../core/nav.dart';
import '../../core/perms.dart';
import '../../core/push.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../core/geo.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/media.dart';
import '../../ui/pick.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import '../maps.dart';
import 'actions.dart';
import 'bubbles.dart';
import 'chat_ctl.dart';
import 'editor.dart';
import 'voice.dart';

const _hello = {'society': '👋 No messages yet. Say hello to your neighbours!', 'company': '👋 No messages yet. Say hello to your team!', 'school': '👋 No messages yet. Say hello to your school community!'};

/// the colours of the open chat (a private chat can have a theme)
class _Look {
  final Color wall, mine, mineT, other, otherT, meta;
  final Gradient? mineG;
  final bool dark;
  const _Look(this.wall, this.mine, this.mineT, this.other, this.otherT, this.meta, this.mineG, this.dark);
}

_Look _look() {
  final p = pal;
  final t = nav.dmc != null ? ctGet() : null;
  if (t != null) return _Look(t.wall, t.mine, t.mineText, t.other, t.otherText, t.dark ? Colors.white60 : Colors.black45, t.mineGrad, t.dark);
  return _Look(p.chat, p.a, Colors.white, p.bub, p.text, p.muted, LinearGradient(colors: [p.a, Color.lerp(p.a, p.a2, .6)!]), p.dark);
}

class ChatView extends StatefulWidget {
  const ChatView({super.key});
  @override
  State<ChatView> createState() => _ChatViewState();
}

class _ChatViewState extends State<ChatView> {
  final mt = TextEditingController();
  final mf = FocusNode();
  final sc = ScrollController();
  final unrKey = GlobalKey();
  bool emo = false, rec = false, srch = false, far = false;
  int emoTab = 0, recS = 0;
  Timer? _recT, _tick, _lpT;
  final sq = TextEditingController();
  int hi = 0;
  Doc? lpCur;
  String lpOff = '';
  List<Doc> mnL = [];
  final Map<String, String> mnMap = {};
  String? chatKey;
  int unrAt = 0, unrN = 0, chatSeen = 0;
  bool _jumped = false;

  @override
  void initState() {
    super.initState();
    chatInput = mt;
    chatFocus = () => mf.requestFocus();
    _tick = Timer.periodic(const Duration(seconds: 3), (_) {
      if (mounted) setState(() {});
    });
    sc.addListener(_onScroll);
    mt.addListener(_onType);
  }

  @override
  void dispose() {
    _tick?.cancel();
    _recT?.cancel();
    _lpT?.cancel();
    if (rec) VoiceRec.stop(cancel: true);
    VoiceBus.I.stop();
    if (chatInput == mt) {
      chatInput = null;
      chatFocus = null;
    }
    super.dispose();
  }

  String get ck => nav.dmc != null ? nav.dmc!.cid : (S.sch ? 'g:${Chat.curRoom()}' : 'g');

  List<Doc> _msgs() {
    final hd = Chat.hid();
    return (nav.dmc != null ? D['dmm'] : D['msg']).values.where((x) => !hd.contains(x['id'])).toList()..sort((a, b) => intv(a['ts']).compareTo(intv(b['ts'])));
  }

  void _onScroll() {
    final f = sc.hasClients && sc.offset > 140;
    if (f != far) setState(() => far = f);
    if (!f) _seen();
  }

  void _seen() {
    final v = _msgs();
    if (v.isEmpty) return;
    final n = intv(v.last['ts']);
    chatSeen = n;
    Chat.rdSet(ck, n);
  }

  /* ---------- typing: mention picker, link preview, "typing…" ---------- */
  void _onType() {
    setState(() {});
    if (mt.text.isNotEmpty) Chat.typing();
    _mnUpd();
    _lpT?.cancel();
    _lpT = Timer(const Duration(milliseconds: 450), () async {
      final u = firstUrl(mt.text);
      if (u.isEmpty || u == lpOff) {
        if (lpCur != null && mounted) setState(() => lpCur = null);
        return;
      }
      if (lpCur != null && lpCur!['u'] == u) return;
      final b = lpBase(u);
      if (b == null) return;
      if (mounted) setState(() => lpCur = b);
      final x = await lpFetch(u);
      if (x != null && mounted && firstUrl(mt.text) == u) setState(() => lpCur = x);
    });
  }

  void _mnUpd() {
    if (nav.dmc != null) {
      if (mnL.isNotEmpty) setState(() => mnL = []);
      return;
    }
    final c = mt.selection.baseOffset < 0 ? mt.text.length : mt.selection.baseOffset;
    final m = RegExp(r'(^|\s)@([^\s@]{0,24})$').firstMatch(mt.text.substring(0, min(c, mt.text.length)));
    if (m == null) {
      if (mnL.isNotEmpty) setState(() => mnL = []);
      return;
    }
    final q = m.group(2)!.toLowerCase();
    final L = D['dir'].values.where((p) => str(p['uid'] ?? p['id']) != S.uid && str(p['name']).isNotEmpty && (q.isEmpty || str(p['name']).toLowerCase().split(RegExp(r'\s+')).any((w) => w.startsWith(q)) || str(p['name']).toLowerCase().startsWith(q))).toList()
      ..sort((a, b) => str(a['name']).compareTo(str(b['name'])));
    setState(() => mnL = L.take(8).toList());
  }

  void _mnPick(Doc p) {
    final c = mt.selection.baseOffset < 0 ? mt.text.length : mt.selection.baseOffset;
    final v = mt.text;
    final m = RegExp(r'(^|\s)@([^\s@]{0,24})$').firstMatch(v.substring(0, c));
    if (m == null) return;
    final st = c - m.group(2)!.length - 1;
    final nm = str(p['name']);
    mt.text = '${v.substring(0, st)}@$nm ${v.substring(c)}';
    mnMap[nm] = str(p['uid'] ?? p['id']);
    mt.selection = TextSelection.collapsed(offset: st + nm.length + 2);
    setState(() => mnL = []);
  }

  List<String> _mnOf(String t) => mnMap.keys.where((n) => t.contains('@$n')).map((n) => mnMap[n]!).toSet().take(20).toList();

  Future<void> _send() async {
    final t = mt.text.trim();
    if (t.isEmpty) return;
    mt.clear();
    App.pset({'typing': 0});
    final o = <String, dynamic>{'uid': S.uid, 'name': S.me!['name'], 'flat': S.me!['flat'], 'text': t, 'ts': now()};
    if (nav.dmc == null) {
      final mn = _mnOf(t);
      if (mn.isNotEmpty) o['mentions'] = mn;
    }
    final u = firstUrl(t);
    if (u.isNotEmpty && u != lpOff) {
      final lp = lpCur != null && lpCur!['u'] == u ? lpCur : (lpCached(u) ?? lpBase(u));
      if (lp != null) o['lp'] = lp;
    }
    lpOff = '';
    setState(() => lpCur = null);
    final rt = Chat.replyTo;
    if (rt != null) o['replyTo'] = rt;
    Chat.replyTo = null;
    try {
      await Chat.pushMsg(o);
      if (sc.hasClients) sc.animateTo(0, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
    } catch (e) {
      mt.text = t;
      Chat.replyTo = rt;
      Chat.touch();
      fail(e, 'Message not sent');
    }
  }

  /* ---------- attachments ---------- */
  void _attach() {
    setState(() => emo = false);
    mf.unfocus();
    final p = pal;
    sheet(context, (ctx) {
      Widget tile(String l, IconData ic, Color c, VoidCallback f) => GestureDetector(
            onTap: () {
              Navigator.pop(ctx);
              f();
            },
            child: Column(children: [
              Container(width: 60, height: 60, decoration: BoxDecoration(color: c.withOpacity(.13), borderRadius: BorderRadius.circular(20)), child: Icon(ic, color: c, size: 28)),
              const SizedBox(height: 6),
              Text(l, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: p.text)),
            ]),
          );
      return GridView.count(crossAxisCount: 3, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), mainAxisSpacing: 18, children: [
        tile('Gallery', Icons.photo_library_rounded, const Color(0xFF7C3AED), _gallery),
        tile('Camera', Icons.photo_camera_rounded, const Color(0xFFE11D48), _camera),
        tile('Document', Icons.description_rounded, const Color(0xFF2563EB), _doc),
        tile('Location', Icons.location_on_rounded, const Color(0xFF059669), _loc),
        tile('Contact', Icons.person_rounded, const Color(0xFFD97706), _contact),
        tile('Poll', Icons.bar_chart_rounded, const Color(0xFF0891B2), _poll),
      ]);
    });
  }

  Future<void> _gallery() async {
    final l = await pickGalleryMany(max: 10);
    if (l.isNotEmpty && mounted) await openEditor(context, l);
  }

  Future<void> _camera() async {
    final f = await pickCamera();
    if (f != null && mounted) await openEditor(context, [f]);
  }

  Future<void> _doc() async {
    final f = await pickDoc();
    if (f == null) return;
    if (f.size > 3 * 1048576) {
      toast('ℹ️', 'File too large', 'Please choose a file under 3 MB.');
      return;
    }
    try {
      final pv = await _docThumb(f);
      await Chat.sendMsg({
        'file': {'name': cut(f.name, 80), 'size': f.size, 'type': cut(f.mime, 80), 'url': await up(f.bytes, 'docs', f.name), ...pv}
      });
    } catch (e) {
      fail(e, 'File not sent');
    }
  }

  Future<Map<String, dynamic>> _docThumb(PFile f) async {
    Future<Map<String, dynamic>> work() async {
      if (f.isImg) return {'thumb': toDataUrl(await shrink(f.bytes, 480, .6), 'image/jpeg')};
      if (f.isPdf || f.name.toLowerCase().endsWith('.pdf')) {
        final pages = RegExp(r'/Type\s*/Page[^s]').allMatches(String.fromCharCodes(f.bytes)).length;
        await for (final r in Printing.raster(f.bytes, pages: [0], dpi: 54)) {
          final png = await r.toPng();
          final im = await decodeImg(png);
          final h = min(im.height, (im.width * .62).round());
          final pr = ui.PictureRecorder();
          final cv = Canvas(pr);
          cv.drawRect(Rect.fromLTWH(0, 0, im.width.toDouble(), h.toDouble()), Paint()..color = Colors.white);
          cv.drawImage(im, Offset.zero, Paint());
          final out = await pr.endRecording().toImage(im.width, h);
          final jpg = await imageToJpeg(out, q: 62);
          return {'thumb': toDataUrl(jpg, 'image/jpeg'), if (pages > 0) 'pages': pages};
        }
      }
      return {};
    }

    try {
      return await work().timeout(const Duration(seconds: 7), onTimeout: () => {});
    } catch (_) {
      return {};
    }
  }

  Future<void> _contact() async {
    try {
      final r = await Native.pickContact();
      if (r != null && r['cancelled'] != true) {
        final tl = cleanPh(str(r['phone']));
        if (tl.isEmpty) {
          toast('ℹ️', 'No number found', 'This contact has no phone number.');
          return;
        }
        await Chat.sendMsg({
          'contact': {'name': cleanName(str(r['name'])).isEmpty ? tl : cleanName(str(r['name'])), 'phone': tl}
        });
        return;
      }
      if (r != null && r['cancelled'] == true) return;
    } catch (_) {}
    if (!mounted) return;
    final n = TextEditingController(), t = TextEditingController();
    sheet(context, (ctx) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const SheetTitle('👤 Share contact', sub: 'Send a name and phone number to the chat.'),
          Field(n, 'Name', max: 40),
          Field(t, 'Mobile number', max: 18, kb: TextInputType.phone),
          Btn('Send contact', onTap: () async {
            final nm = cleanName(n.text), ph = cleanPh(t.text);
            if (nm.isEmpty || ph.replaceAll(RegExp(r'\D'), '').length < 7) {
              toast('ℹ️', 'Enter a name and valid number');
              return;
            }
            await Chat.sendMsg({
              'contact': {'name': nm, 'phone': ph}
            });
            if (ctx.mounted) Navigator.pop(ctx);
          }, busyDone: false),
        ]));
  }

  void _poll() {
    final q = TextEditingController();
    final rows = [TextEditingController(), TextEditingController()];
    var multi = false;
    sheet(context, (ctx) => StatefulBuilder(builder: (ctx, set) {
          return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const SheetTitle('Create poll'),
            Field(q, 'Ask a question', lines: 2, max: 200, autofocus: true),
            Text('Options', style: meta()),
            const SizedBox(height: 6),
            for (final (i, r) in rows.indexed)
              Field(r, 'Option ${i + 1}', max: 80, onChanged: (v) {
                if (r == rows.last && v.trim().isNotEmpty && rows.length < 12) set(() => rows.add(TextEditingController()));
              }),
            ToggleRow('Allow multiple answers', multi, (v) => set(() => multi = v)),
            const SizedBox(height: 8),
            Btn('Send poll', onTap: () async {
              final qq = q.text.trim();
              final o = rows.map((r) => r.text.trim()).where((x) => x.isNotEmpty).toSet().toList();
              if (qq.isEmpty) {
                toast('ℹ️', 'Add a question');
                return;
              }
              if (o.length < 2) {
                toast('ℹ️', 'Add at least 2 options');
                return;
              }
              await Chat.sendMsg({
                'poll': {'q': qq, 'opts': o, 'multi': multi}
              });
              if (ctx.mounted) Navigator.pop(ctx);
            }, busyDone: false),
          ]);
        }));
  }

  Future<void> _loc() async {
    if (!await askPerm('loc')) return;
    if (!mounted) return;
    sheet(context, (_) => const _ShareLoc());
  }

  /* ---------- voice notes ---------- */
  Future<void> _recStart() async {
    if (!await VoiceRec.start()) return;
    setState(() {
      rec = true;
      emo = false;
      recS = 0;
    });
    _recT = Timer.periodic(const Duration(milliseconds: 250), (_) {
      final s = ((now() - VoiceRec.t0) / 1000).round();
      if (s != recS && mounted) setState(() => recS = s);
      if (s >= 120) _recStop(false);
    });
  }

  Future<void> _recStop(bool cancel) async {
    _recT?.cancel();
    setState(() => rec = false);
    final r = await VoiceRec.stop(cancel: cancel);
    if (r == null) return;
    if (r.$1.length > 2 * 1048576) {
      toast('ℹ️', 'Voice note too long', 'Keep it under 2 minutes.');
      return;
    }
    try {
      await Chat.sendMsg({'voice': await up(Uint8List.fromList(r.$1), 'voice', 'v.m4a', mime: 'audio/mp4'), 'dur': r.$2});
    } catch (e) {
      fail(e, 'Voice note not sent');
    }
  }

  void _sticker(String e) {
    setState(() => emo = false);
    Chat.pushMsg({'uid': S.uid, 'name': S.me!['name'], 'flat': S.me!['flat'], 'text': '', 'stk': e, 'ts': now()}).catchError((x) => fail(x, 'Sticker not sent'));
  }

  void _emoji(String e) {
    final s = mt.selection.isValid ? mt.selection.start : mt.text.length;
    final en = mt.selection.isValid ? mt.selection.end : s;
    mt.text = mt.text.substring(0, s) + e + mt.text.substring(en);
    mt.selection = TextSelection.collapsed(offset: s + e.length);
  }

  /* ---------- build ---------- */
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([D.on(['msg', 'dmm', 'dmc', 'dir', 'pres', 'rooms']), Chat.I, nav]),
      builder: (_, __) => _build(context),
    );
  }

  Widget _build(BuildContext context) {
    final p = pal, L = _look(), dmc = nav.dmc;
    final v = _msgs();
    final shown = true;
    final fresh = shown && chatKey != ck;
    if (fresh) {
      chatKey = ck;
      final r0 = Chat.rdGet(ck);
      unrN = r0 > 0 ? v.where((m) => intv(m['ts']) > r0 && m['uid'] != S.uid).length : 0;
      unrAt = unrN > 0 ? r0 : 0;
      chatSeen = unrN > 0 ? r0 : (v.isNotEmpty ? intv(v.last['ts']) : 0);
      _jumped = false;
      if (dmc == null) Push.clear('g:${S.sid}:${S.sch ? Chat.curRoom() : ''}');
    }
    if (!far && v.isNotEmpty) WidgetsBinding.instance.addPostFrameCallback((_) => _seen());
    if (unrN > 0 && !_jumped) {
      _jumped = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        final c = unrKey.currentContext;
        if (c != null) Scrollable.ensureVisible(c, alignment: .1);
      });
    }
    final ppl = Chat.chatPpl();
    final ty = Chat.typers();
    final onl = ppl.where((x) => Chat.online(str(x['uid'] ?? x['id']))).length;
    final title = dmc != null ? Chat.peerName() : (S.sch ? roomTitle(Chat.curRoom()) : '${str(S.soc?['name'])} Community');
    final subT = ty.isNotEmpty
        ? '${ty.take(2).join(', ')} typing…'
        : dmc != null
            ? (Chat.online(dmc.peer) ? 'Online' : Chat.lastSeen(dmc.peer))
            : '$onl online · ${ppl.length} members';
    final rooms = S.sch && dmc == null ? Chat.chatRooms() : <String>[];
    final q = srch ? sq.text.trim().toLowerCase() : '';

    // rows (oldest first)
    final rows = <Widget>[];
    if (v.length < 80) {
      rows.add(Padding(
        padding: const EdgeInsets.fromLTRB(30, 12, 30, 8),
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: (L.dark ? Colors.white : Colors.black).withOpacity(.05), borderRadius: BorderRadius.circular(12)),
          child: Text(
              dmc != null
                  ? '🔒 Private chat with ${Chat.peerName()}. Only the two of you can read these messages.'
                  : S.sch
                      ? (Chat.curRoom() == roomStaff
                          ? '💬 Staff room · the chat of the Principal, the teachers and the staff of ${str(S.soc?['name'])}.'
                          : '💬 ${roomTitle(Chat.curRoom())} · for the students and parents of this class, the class teacher and the Principal.')
                      : '🔒 ${str(S.soc?['name'])} community chat. Only approved members can read these messages.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, color: L.meta)),
        ),
      ));
    }
    if (v.isEmpty) {
      rows.add(Padding(
        padding: const EdgeInsets.all(30),
        child: Text(
            dmc != null
                ? '👋 Say hi to ${firstName(Chat.peerName())}!'
                : S.sch
                    ? (Chat.curRoom() == roomStaff ? '👋 No messages yet. Say hello to the staff!' : '👋 No messages yet. Say hello to your class!')
                    : (_hello[S.kind] ?? _hello['society']!),
            textAlign: TextAlign.center,
            style: TextStyle(color: L.meta, fontSize: 14)),
      ));
    }
    var last = 0;
    var lu = '', ld = '';
    var unrDone = false;
    var hits = 0;
    for (final m in v) {
      final ts = intv(m['ts']);
      final day = dayLbl(ts);
      if (day != ld) {
        rows.add(Center(child: Container(margin: const EdgeInsets.symmetric(vertical: 10), padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5), decoration: BoxDecoration(color: L.other.withOpacity(.9), borderRadius: BorderRadius.circular(99), boxShadow: p.shadow), child: Text(day, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: L.otherT)))));
        ld = day;
        lu = '';
      }
      if (unrAt > 0 && !unrDone && ts > unrAt && m['uid'] != S.uid) {
        unrDone = true;
        rows.add(Container(key: unrKey, margin: const EdgeInsets.symmetric(vertical: 8), padding: const EdgeInsets.symmetric(vertical: 6), color: p.a.withOpacity(.12), child: Text('$unrN unread message${unrN == 1 ? '' : 's'}', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5, color: p.a))));
        lu = '';
      }
      final mine = m['uid'] == S.uid;
      final skk = '${m['uid']}|${str(m['pid'])}';
      final grp = skk == lu && ts - last < 300000;
      lu = skk;
      last = ts;
      if (q.isNotEmpty && str(m['text']).toLowerCase().contains(q)) hits++;
      rows.add(_MsgRow(m: m, mine: mine, grp: grp, look: L, hl: q.isEmpty ? null : q, dm: dmc != null));
    }
    final newN = far ? v.where((m) => intv(m['ts']) > chatSeen && m['uid'] != S.uid).length : 0;

    return Container(
      color: L.wall,
      child: SafeArea(
        child: Column(children: [
          // header
          Container(
            padding: const EdgeInsets.fromLTRB(4, 6, 6, 6),
            decoration: BoxDecoration(color: p.card, border: Border(bottom: BorderSide(color: p.line))),
            child: Row(children: [
              IconButton(
                  onPressed: () {
                    if (rec) _recStop(true);
                    VoiceBus.I.stop();
                    if (dmc != null) {
                      Chat.dmBack();
                    } else {
                      nav.setComm('ann');
                    }
                  },
                  icon: const Icon(Icons.arrow_back_rounded)),
              Expanded(
                child: InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: () => dmc != null ? profile(context, dmc.peer, {'name': Chat.peerName()}) : membersSheet(context),
                  child: Row(children: [
                    dmc != null
                        ? Av(Chat.peerName(), Chat.peerPhoto(), size: 42, badge: Chat.online(dmc.peer) ? onlineDot() : null)
                        : Container(width: 42, height: 42, decoration: BoxDecoration(gradient: p.grad, borderRadius: BorderRadius.circular(14)), alignment: Alignment.center, child: Text(S.K.ico, style: const TextStyle(fontSize: 20))),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: h3().copyWith(fontSize: 16)),
                        Text(subT, maxLines: 1, overflow: TextOverflow.ellipsis, style: small(ty.isNotEmpty ? p.green : p.muted)),
                      ]),
                    ),
                    if (dmc == null)
                      SizedBox(
                        width: 30.0 + 18 * (min(ppl.length, 4) - 1).clamp(0, 3),
                        height: 30,
                        child: Stack(children: [for (final (i, x) in ppl.take(4).indexed) Positioned(left: i * 18.0, child: Container(decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: p.card, width: 2)), child: Av(str(x['name']), str(x['photo']), size: 26)))]),
                      ),
                  ]),
                ),
              ),
              if (dmc != null) IconButton(onPressed: () => chMenu(context, onSearch: () => setState(() => srch = true)), icon: const Icon(Icons.more_vert_rounded)),
            ]),
          ),
          if (srch)
            Container(
              color: p.card,
              padding: const EdgeInsets.fromLTRB(12, 4, 4, 4),
              child: Row(children: [
                Expanded(child: TextField(controller: sq, autofocus: true, onChanged: (_) => setState(() {}), decoration: const InputDecoration(hintText: 'Search in this chat', isDense: true))),
                const SizedBox(width: 8),
                Text(q.isEmpty ? '' : (hits == 0 ? 'No results' : '$hits found'), style: small()),
                IconButton(
                    onPressed: () => setState(() {
                          srch = false;
                          sq.clear();
                        }),
                    icon: const Icon(Icons.close_rounded)),
              ]),
            ),
          if (rooms.length >= 2)
            Container(
              color: p.card,
              child: Chips([for (final r in rooms) (r, '${roomLbl(r)}${r != Chat.curRoom() && Chat.roomUnread(r) ? ' •' : ''}')], Chat.curRoom(), (r) {
                Chat.setRoom(r);
                chatKey = null;
              }, pad: const EdgeInsets.fromLTRB(12, 6, 12, 8)),
            ),
          Expanded(
            child: Stack(children: [
              ListView.builder(
                controller: sc,
                reverse: true,
                padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
                itemCount: rows.length,
                itemBuilder: (_, i) => rows[rows.length - 1 - i],
              ),
              if (far)
                Positioned(
                  right: 12,
                  bottom: 12,
                  child: GestureDetector(
                    onTap: () => sc.animateTo(0, duration: const Duration(milliseconds: 300), curve: Curves.easeOut),
                    child: Stack(clipBehavior: Clip.none, children: [
                      Container(width: 44, height: 44, decoration: BoxDecoration(color: p.card, shape: BoxShape.circle, boxShadow: p.shadow, border: Border.all(color: p.line)), child: Icon(Icons.keyboard_arrow_down_rounded, color: p.text)),
                      if (newN > 0) Positioned(right: -4, top: -4, child: Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: p.a, borderRadius: BorderRadius.circular(99)), child: Text(newN > 99 ? '99+' : '$newN', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800)))),
                    ]),
                  ),
                ),
            ]),
          ),
          _dock(p, dmc, ty),
        ]),
      ),
    );
  }

  Widget _dock(Pal p, Dm? dmc, List<String> ty) {
    final blk = dmc != null && Chat.blkAny();
    final empty = mt.text.trim().isEmpty;
    return Container(
      color: p.card,
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        if (blk)
          Padding(
            padding: const EdgeInsets.all(14),
            child: Row(children: [
              Expanded(child: Text(Chat.iBlk() ? "You blocked ${firstName(Chat.peerName())}. You can't message each other in this chat." : "You can't send messages to this chat.", style: meta(p.text))),
              if (Chat.iBlk()) mini('Unblock', () => doBlock(false)),
            ]),
          )
        else ...[
          if (ty.isNotEmpty) Padding(padding: const EdgeInsets.fromLTRB(16, 6, 16, 0), child: Text('✍️ ${ty.join(', ')}${ty.length > 1 ? ' are' : ' is'} typing…', style: small(p.green))),
          if (Chat.replyTo != null)
            Container(
              margin: const EdgeInsets.fromLTRB(10, 8, 10, 0),
              padding: const EdgeInsets.fromLTRB(12, 8, 4, 8),
              decoration: BoxDecoration(color: p.tint, borderRadius: BorderRadius.circular(12), border: Border(left: BorderSide(color: p.a, width: 3))),
              child: Row(children: [
                Expanded(child: Text('↩ ${str(Chat.replyTo!['name'])}: ${str(Chat.replyTo!['text'])}', maxLines: 2, overflow: TextOverflow.ellipsis, style: meta(p.text))),
                IconButton(
                    onPressed: () {
                      Chat.replyTo = null;
                      Chat.touch();
                    },
                    icon: const Icon(Icons.close_rounded, size: 18)),
              ]),
            ),
          if (mnL.isNotEmpty)
            Container(
              constraints: const BoxConstraints(maxHeight: 220),
              margin: const EdgeInsets.fromLTRB(10, 8, 10, 0),
              decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(14), boxShadow: p.shadow, border: Border.all(color: p.line)),
              child: ListView(shrinkWrap: true, padding: const EdgeInsets.symmetric(horizontal: 8), children: [
                for (final x in mnL) Ex(str(x['name']), sub: str(x['flat']), lead: Av(str(x['name']), str(x['photo']), size: 30), onTap: () => _mnPick(x)),
              ]),
            ),
          if (lpCur != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 0),
              child: Row(children: [
                Expanded(child: LinkCard(lpCur!, fg: p.text, small: true)),
                IconButton(
                    onPressed: () => setState(() {
                          lpOff = str(lpCur!['u']);
                          lpCur = null;
                        }),
                    icon: const Icon(Icons.close_rounded, size: 18)),
              ]),
            ),
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
            child: rec
                ? Row(children: [
                    IconButton(onPressed: () => _recStop(true), icon: Icon(Icons.delete_outline_rounded, color: p.red)),
                    const _RecDot(),
                    const SizedBox(width: 8),
                    Text(fd(recS), style: h3()),
                    const SizedBox(width: 10),
                    const Expanded(child: _RecWave()),
                    GestureDetector(onTap: () => _recStop(false), child: Container(width: 46, height: 46, decoration: BoxDecoration(gradient: p.grad, shape: BoxShape.circle), child: const Icon(Icons.send_rounded, color: Colors.white))),
                  ])
                : Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(color: p.card2, borderRadius: BorderRadius.circular(26)),
                        child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                          IconButton(
                              onPressed: () {
                                setState(() => emo = !emo);
                                if (emo) mf.unfocus();
                              },
                              icon: Icon(emo ? Icons.keyboard_rounded : Icons.emoji_emotions_outlined, color: p.muted)),
                          Expanded(
                            child: TextField(
                              controller: mt,
                              focusNode: mf,
                              minLines: 1,
                              maxLines: 5,
                              maxLength: 500,
                              textCapitalization: TextCapitalization.sentences,
                              onTap: () => setState(() => emo = false),
                              style: TextStyle(fontSize: 15.5, color: p.text),
                              decoration: const InputDecoration(hintText: 'Message', counterText: '', border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none, filled: false, contentPadding: EdgeInsets.symmetric(vertical: 12)),
                            ),
                          ),
                          IconButton(onPressed: _attach, icon: Transform.rotate(angle: -.6, child: Icon(Icons.attach_file_rounded, color: p.muted))),
                          if (empty) IconButton(onPressed: _camera, icon: Icon(Icons.photo_camera_outlined, color: p.muted)),
                        ]),
                      ),
                    ),
                    const SizedBox(width: 6),
                    GestureDetector(
                      onTap: empty ? _recStart : _send,
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(gradient: p.grad, shape: BoxShape.circle, boxShadow: [BoxShadow(color: p.a.withOpacity(.3), blurRadius: 10, offset: const Offset(0, 4))]),
                        child: AnimatedSwitcher(duration: const Duration(milliseconds: 180), transitionBuilder: (c, a) => ScaleTransition(scale: a, child: c), child: Icon(empty ? Icons.mic_rounded : Icons.send_rounded, key: ValueKey(empty), color: Colors.white)),
                      ),
                    ),
                  ]),
          ),
          if (emo) _emoPanel(p),
        ],
      ]),
    );
  }

  Widget _emoPanel(Pal p) {
    final stk = emoTab == emoji.length;
    final items = stk ? stickers : emoji[emoTab][1].split(' ');
    return SizedBox(
      height: 270,
      child: Column(children: [
        SizedBox(
          height: 44,
          child: ListView(scrollDirection: Axis.horizontal, children: [
            for (var i = 0; i <= emoji.length; i++)
              GestureDetector(
                onTap: () => setState(() => emoTab = i),
                child: Container(width: 46, alignment: Alignment.center, decoration: BoxDecoration(border: Border(bottom: BorderSide(color: emoTab == i ? p.a : Colors.transparent, width: 3))), child: Text(i == emoji.length ? '🎭' : emoji[i][0], style: const TextStyle(fontSize: 22))),
              ),
          ]),
        ),
        Expanded(
          child: GridView.count(
            crossAxisCount: stk ? 5 : 8,
            padding: const EdgeInsets.all(6),
            children: [
              for (final e in items)
                InkWell(
                  borderRadius: BorderRadius.circular(10),
                  onTap: () => stk ? _sticker(e) : _emoji(e),
                  child: Center(child: Text(e, style: TextStyle(fontSize: stk ? 40 : 26))),
                ),
            ],
          ),
        ),
      ]),
    );
  }
}

/* ---------- one message ---------- */
class _MsgRow extends StatefulWidget {
  final Doc m;
  final bool mine, grp, dm;
  final _Look look;
  final String? hl;
  const _MsgRow({required this.m, required this.mine, required this.grp, required this.look, required this.dm, this.hl});
  @override
  State<_MsgRow> createState() => _MsgRowState();
}

class _MsgRowState extends State<_MsgRow> {
  double dx = 0;
  bool fired = false;

  @override
  Widget build(BuildContext context) {
    final p = pal, m = widget.m, mine = widget.mine, L = widget.look;
    final dr = D['dir'][m['uid']] ?? {};
    final bg = mine ? L.mine : L.other, fg = mine ? L.mineT : L.otherT;
    final kids = <Widget>[];
    final deleted = m['deleted'] == true;
    final sg = mine ? 1.0 : -1.0;
    if (deleted) {
      kids.add(Text('🚫 ${mine ? 'You deleted this message' : (str(m['delBy']).isNotEmpty && m['delBy'] != m['uid'] ? 'Removed by admin' : 'This message was deleted')}', style: TextStyle(fontStyle: FontStyle.italic, color: fg.withOpacity(.7), fontSize: 14)));
    } else {
      if ((!mine || (str(m['pid']).isNotEmpty ? m['pid'] : m['uid']) != S.pidv) && !widget.grp && !widget.dm) {
        kids.add(Padding(
          padding: const EdgeInsets.only(bottom: 3),
          child: Wrap(crossAxisAlignment: WrapCrossAlignment.center, spacing: 6, children: [
            GestureDetector(onTap: () => profile(context, str(m['uid']), m), child: Text(str(m['name']), style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: mine ? fg : ucol(str(m['uid']).isNotEmpty ? str(m['uid']) : str(m['name']))))),
            Text(str(m['flat']), style: TextStyle(fontSize: 11, color: fg.withOpacity(.6))),
            if (S.roleChip(dr['role']) != null) Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1), decoration: BoxDecoration(color: p.a.withOpacity(.12), borderRadius: BorderRadius.circular(6)), child: Text(S.roleChip(dr['role'])!, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: p.a))),
          ]),
        ));
      }
      if (m['replyTo'] != null) kids.add(ReplyQuote(mapv(m['replyTo']), fg: fg, bar: mine ? fg : p.a));
      if (okImg(m['img'])) kids.add(ImgMsg(str(m['img']), hd: intv(m['hd']) == 1));
      if (okAud(m['voice'])) kids.add(VoiceNote(mid: str(m['id']), ref: str(m['voice']), durS: intv(m['dur']), fg: fg, track: fg.withOpacity(.28)));
      final f = mapv(m['file']);
      if (str(f['name']).isNotEmpty && (okU(f['url']) || okData(f['data']))) kids.add(DocCard(f, fg: fg));
      final l = mapv(m['loc']);
      if (l['lat'] != null && l['lng'] != null && numv(l['lat']).abs() <= 90 && numv(l['lng']).abs() <= 180) kids.add(LocCard(l, m, fg: fg));
      final pl = mapv(m['poll']);
      if (str(pl['q']).isNotEmpty && pl['opts'] is List) kids.add(PollCard(m, fg: fg, acc: mine ? fg : p.a));
      final c = mapv(m['contact']);
      if (str(c['name']).isNotEmpty && str(c['phone']).isNotEmpty) kids.add(ContactCard(c, fg: fg));
      if (str(m['stk']).isNotEmpty) kids.add(Text(str(m['stk']), style: const TextStyle(fontSize: 64)));
      final lp = mapv(m['lp']);
      if (RegExp('^https?://', caseSensitive: false).hasMatch(str(lp['u']))) kids.add(Padding(padding: const EdgeInsets.only(bottom: 4), child: LinkCard(lp, fg: fg)));
      if (str(m['text']).isNotEmpty) kids.add(MsgText(str(m['text']), mentions: strList(m['mentions']), color: fg, link: mine ? fg : p.a, hl: widget.hl));
    }
    final c0 = D['dmc'][nav.dmc?.cid];
    final seen = widget.dm && mine && nav.dmc != null && intv(mapv(c0?['reads'])[nav.dmc!.peer]) >= intv(m['ts']);
    kids.add(Padding(
      padding: const EdgeInsets.only(top: 3),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        if (m['edited'] == true) Text('edited ', style: TextStyle(fontSize: 10.5, fontStyle: FontStyle.italic, color: fg.withOpacity(.6))),
        Text(tm(m['ts']), style: TextStyle(fontSize: 10.5, color: fg.withOpacity(.65))),
        if (widget.dm && mine) Padding(padding: const EdgeInsets.only(left: 4), child: Text(seen ? '✓✓' : '✓', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: seen ? const Color(0xFF9AE6FF) : fg.withOpacity(.65)))),
      ]),
    ));
    final stk = str(m['stk']).isNotEmpty && !deleted;
    final r = BorderRadius.only(topLeft: Radius.circular(!mine && !widget.grp ? 4 : 18), topRight: Radius.circular(mine && !widget.grp ? 4 : 18), bottomLeft: const Radius.circular(18), bottomRight: const Radius.circular(18));
    final bubble = GestureDetector(
      onTap: deleted ? null : () => msgMenu(context, m, mine),
      onLongPress: () => msgMenu(context, m, mine),
      child: Container(
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .78),
        padding: stk ? const EdgeInsets.all(2) : const EdgeInsets.fromLTRB(11, 7, 11, 6),
        decoration: stk ? null : BoxDecoration(color: mine && L.mineG == null ? bg : (mine ? null : bg), gradient: mine && !deleted ? L.mineG : null, borderRadius: r, boxShadow: [BoxShadow(color: Colors.black.withOpacity(L.dark ? .2 : .05), blurRadius: 4, offset: const Offset(0, 1))]),
        child: Column(crossAxisAlignment: mine ? CrossAxisAlignment.end : CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: kids),
      ),
    );
    return GestureDetector(
      onHorizontalDragUpdate: deleted
          ? null
          : (d) {
              setState(() => dx = (dx + d.delta.dx * sg).clamp(0.0, 80.0));
              if (dx > 64 && !fired) {
                fired = true;
                HapticFeedback.selectionClick();
              }
            },
      onHorizontalDragEnd: (_) {
        if (fired) setReply(m);
        setState(() {
          dx = 0;
          fired = false;
        });
      },
      child: AnimatedContainer(
        duration: Duration(milliseconds: dx == 0 ? 200 : 0),
        transform: Matrix4.translationValues(dx * sg, 0, 0),
        padding: EdgeInsets.only(top: widget.grp ? 2 : 8),
        child: Row(mainAxisAlignment: mine ? MainAxisAlignment.end : MainAxisAlignment.start, crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (!mine)
            widget.grp
                ? const SizedBox(width: 44)
                : Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: GestureDetector(onTap: () => profile(context, str(m['uid']), m), child: Av(str(m['name']), str(m['pid']).isNotEmpty ? str(m['ph']) : str(dr['photo']), size: 36, badge: Chat.online(str(m['uid'])) ? onlineDot(10) : null)),
                  ),
          Flexible(child: bubble),
        ]),
      ),
    );
  }
}

class _RecDot extends StatefulWidget {
  const _RecDot();
  @override
  State<_RecDot> createState() => _RecDotState();
}

class _RecDotState extends State<_RecDot> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))..repeat(reverse: true);
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => FadeTransition(opacity: _c, child: Container(width: 12, height: 12, decoration: BoxDecoration(color: pal.red, shape: BoxShape.circle)));
}

class _RecWave extends StatefulWidget {
  const _RecWave();
  @override
  State<_RecWave> createState() => _RecWaveState();
}

class _RecWaveState extends State<_RecWave> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat();
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _c,
        builder: (_, __) => Row(children: [
          for (var i = 0; i < 26; i++)
            Expanded(
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 1),
                height: 6 + 22 * (0.5 + 0.5 * sin((_c.value * 2 * pi) + i * .7)).abs(),
                decoration: BoxDecoration(color: pal.a.withOpacity(.7), borderRadius: BorderRadius.circular(3)),
              ),
            ),
        ]),
      );
}

/* ---------- send a location: current, or live for 15 min / 1 h / 8 h ---------- */
class _ShareLoc extends StatefulWidget {
  const _ShareLoc();
  @override
  State<_ShareLoc> createState() => _ShareLocState();
}

class _ShareLocState extends State<_ShareLoc> {
  Position? c;
  String st = 'Getting your location…';
  bool liveOpen = false;
  int dur = 15;
  final cm = TextEditingController();

  @override
  void initState() {
    super.initState();
    here().then((x) {
      if (mounted) {
        setState(() {
          c = x;
          st = 'Accurate to about ${x.accuracy.round()} m';
        });
      }
    }).catchError((e) {
      if (mounted) setState(() => st = e is Exception ? fr(e) : "Couldn't get your location. Please try again.");
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    Widget row(IconData ic, String t, String s, VoidCallback? f, {bool on = false}) => Opacity(
          opacity: c == null ? .5 : 1,
          child: Container(
            margin: const EdgeInsets.only(bottom: 10),
            decoration: BoxDecoration(color: on ? p.tint : p.card2, borderRadius: BorderRadius.circular(16)),
            child: ListTile(onTap: c == null ? null : f, leading: CircleAvatar(backgroundColor: p.a.withOpacity(.15), child: Icon(ic, color: p.a)), title: Text(t, style: h3()), subtitle: Text(s, style: meta())),
          ),
        );
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const SheetTitle('Send location'),
      const MapArt(h: 110),
      Padding(padding: const EdgeInsets.symmetric(vertical: 10), child: Text(st, style: meta())),
      row(Icons.wifi_tethering_rounded, 'Share live location', 'Others can follow where you are for the time you choose', () => setState(() => liveOpen = !liveOpen), on: liveOpen),
      if (liveOpen) ...[
        Text('Share for', style: meta()),
        const SizedBox(height: 6),
        Chips(const [('15', '15 minutes'), ('60', '1 hour'), ('480', '8 hours')], '$dur', (v) => setState(() => dur = int.parse(v))),
        Field(cm, 'Add a comment (optional)', max: 200),
        Btn('Share live location', onTap: () async {
          final x = c!;
          final lid = rid(), until = now() + dur * 60000, cid = nav.dmc?.cid;
          await Chat.sendMsg({
            'text': cm.text.trim(),
            'loc': {'lat': fix6(x.latitude), 'lng': fix6(x.longitude), 'acc': x.accuracy.round(), 'live': true, 'until': until, 'lid': lid}
          });
          Live.start(LiveS(lid: lid, until: until, cid: cid), x);
          if (context.mounted) Navigator.pop(context);
        }, busyDone: false),
        Padding(padding: const EdgeInsets.only(top: 8, bottom: 10), child: Text('Sharing continues in the background and when the phone is locked. Android shows a notification while it is on, and you can stop at any time.', style: small())),
      ],
      row(Icons.location_on_rounded, 'Send your current location', 'One-time location', () async {
        final x = c!;
        await Chat.sendMsg({
          'loc': {'lat': fix6(x.latitude), 'lng': fix6(x.longitude), 'acc': x.accuracy.round()}
        });
        if (context.mounted) Navigator.pop(context);
      }),
    ]);
  }
}

