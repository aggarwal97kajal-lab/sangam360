import 'package:flutter/material.dart';

import '../../core/app.dart';
import '../../core/fs.dart';
import '../../core/kinds.dart';
import '../../core/listen.dart';
import '../../core/nav.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/anim.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/media.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import 'chat_ctl.dart';
import 'chat_view.dart';
import '../../l10n/l10n.dart';

/// Community (Team for companies): notices, the chat, private chats
class CommTab extends StatelessWidget {
  const CommTab({super.key});
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([nav, D.on(['dmc'])]),
      builder: (_, __) {
        if (S.noChat && nav.comm == 'chat' && nav.dmc == null) nav.comm = 'ann';
        if (nav.dmc != null || nav.comm == 'chat') return const ChatView();
        final A = D['dmc'].values.where((c) => strList(c['users']).contains(S.uid) && intv(c['lastTs']) > 0).toList();
        final un = A.where((c) => Chat.dmMine(c) && isUn(c)).length + A.where((c) => !Chat.dmMine(c) && isUn(c)).length;
        return Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
            child: Seg([('ann', '📢 Notices'), if (!S.noChat) ('chat', '💬 Chat'), ('inbox', '✉️ Inbox${un > 0 ? ' ($un)' : ''}')], nav.comm, (v) {
              Chat.leaveDM(quiet: true);
              nav.setComm(v);
            }),
          ),
          Expanded(
            child: GestureDetector(
              onHorizontalDragEnd: (d) {
                if (nav.comm == 'ann' && !S.noChat && (d.primaryVelocity ?? 0) < -400) nav.setComm('chat');
              },
              child: AnimatedSwitcher(duration: const Duration(milliseconds: 220), child: nav.comm == 'inbox' ? const InboxView(key: ValueKey('ib')) : const AnnView(key: ValueKey('an'))),
            ),
          ),
        ]);
      },
    );
  }
}

/* ============================== notices ============================== */
class AnnView extends StatefulWidget {
  const AnnView({super.key});
  @override
  State<AnnView> createState() => _AnnViewState();
}

class _AnnViewState extends State<AnnView> {
  static String annF = '';
  String at = annTypes.first, aud = 'students';
  final atl = TextEditingController(), atx = TextEditingController();

  Future<void> _pub() async {
    final t = atl.text.trim(), x = atx.text.trim();
    if (t.isEmpty || x.isEmpty) {
      toast('ℹ️', tr('Add title and message'));
      return;
    }
    await addDoc(col('announcements'), {
      'uid': S.uid,
      'type': at,
      'title': t,
      'text': x,
      'ts': now(),
      'by': S.me!['name'],
      if (S.sch) ...{
        'role': S.me!['role'],
        if (S.isOwner) 'aud': aud.isEmpty ? 'all' : aud else if (S.isTeacher) ...{'aud': 'class', 'cls': S.myCls},
      },
    });
    atl.clear();
    atx.clear();
    fxDone(tr('Notice published'), '', true, 1600);
  }

  String audL(Doc a) {
    if (!S.sch) return '';
    switch (a['aud']) {
      case 'teachers':
        return tr('👩‍🏫 For all teachers');
      case 'students':
        return tr('🎓 For all students');
      case 'class':
        return '📚 ${str(a['cls'])}';
      case 'all':
        return tr('🏫 For everyone');
    }
    return '';
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    return ListenableBuilder(
      listenable: D.on(['ann']),
      builder: (_, __) {
        var v = D['ann'].values.toList()..sort((a, b) => intv(b['ts']).compareTo(intv(a['ts'])));
        List<(String, String)>? O;
        if (S.sch && S.isOwner && v.isNotEmpty) {
          final cl = v.where((a) => a['aud'] == 'class' && str(a['cls']).isNotEmpty).map((a) => str(a['cls'])).toSet().toList()..sort(natCmp);
          O = [('', tr('All notices')), ('teachers', tr('For teachers')), ('students', tr('For students')), for (final c in cl) ('c:$c', c + (S.tOf(c).isNotEmpty ? ' · ${S.tOf(c)}' : ''))];
          if (!O.any((o) => o.$1 == annF)) annF = '';
          if (annF.isNotEmpty) v = v.where((a) => annF.startsWith('c:') ? a['aud'] == 'class' && a['cls'] == annF.substring(2) : a['aud'] == annF).toList();
        }
        return ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 110), physics: const BouncingScrollPhysics(), children: [
          if (S.isAdm)
            AppCard(title: 'Publish a notice', children: [
              if (S.sch && S.isOwner) SelectField('Audience', aud, const [('students', 'For all students'), ('teachers', 'For all teachers'), ('all', 'For everyone (teachers + students)')], (x) => setState(() => aud = x)),
              if (S.isTeacher) Note(trf('📚 This notice goes to your class: {0}. The Principal can see it too.', [S.myCls]), margin: const EdgeInsets.only(bottom: 10)),
              SelectField('Type', at, SelectField.same(annTypes), (x) => setState(() => at = x)),
              Field(atl, 'Title', max: 80),
              Field(atx, 'Message…', lines: 4, max: 800),
              Btn(tr('Publish'), onTap: _pub, busyDone: false),
            ]),
          if (O != null) SelectField('Show', annF, O, (x) => setState(() => annF = x)),
          if (v.isEmpty) const Empty('No notices yet', icon: '📢'),
          for (final (i, a) in v.indexed)
            Enter(
              index: i,
              child: Item(bar: a['type'] == 'Emergency' ? p.red : p.a, children: [
                ItemHead('${a['type'] == 'Emergency' ? '🚨 ' : '📢 '}${str(a['title'])}', badge: Pill(str(a['type']), tone: a['type'] == 'Emergency' ? Tone.r : Tone.a)),
                if (audL(a).isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(audL(a), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: p.a))),
                Desc(str(a['text'])),
                Meta('${str(a['by'])}${S.sch && a['role'] != null ? ' (${S.roleLbl(a['role'])})' : ''} · ${dt(a['ts'])}'),
                if (S.sch ? (S.isOwner || a['uid'] == S.uid) : S.isAdm)
                  ActRow([
                    mini(tr('Delete'), () async {
                      if (!await confirmDlg(context, tr('Delete this notice?'), ok: tr('Delete'), danger: true)) return;
                      await dref('announcements', str(a['id'])).delete();
                    }, BtnKind.red)
                  ]),
              ]),
            ),
        ]);
      },
    );
  }
}

/* ============================== private chats ============================== */
class InboxView extends StatelessWidget {
  const InboxView({super.key});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    return ListenableBuilder(
      listenable: D.on(['dmc', 'dir', 'pres']),
      builder: (_, __) {
        final A = D['dmc'].values.where((c) => strList(c['users']).contains(S.uid) && intv(c['lastTs']) > 0).toList();
        final L = A.where(Chat.dmMine).toList()..sort((x, y) => intv(y['lastTs']).compareTo(intv(x['lastTs'])));
        final oth = A.where((c) => !Chat.dmMine(c) && isUn(c)).toList();
        final by = <String, (Doc, int)>{};
        for (final c in oth) {
          final k = Chat.dmKid(c);
          if (k != null) by[str(k['id'])] = (k, (by[str(k['id'])]?.$2 ?? 0) + 1);
        }
        return ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 110), physics: const BouncingScrollPhysics(), children: [
          Btn(tr('✏️ New private chat'), onTap: () => newChatSheet(context)),
          const SizedBox(height: 12),
          for (final e in by.values)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Material(
                color: p.tint,
                borderRadius: BorderRadius.circular(14),
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => Kids.switchKid(str(e.$1['id'])),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Row(children: [
                      Expanded(child: Text(trf('✉️ {0} unread chat{1} for {2} · {3}', [e.$2, (e.$2 == 1 ? '' : 's'), firstName(str(e.$1['name'])), S.clsOf(e.$1)]), style: TextStyle(fontWeight: FontWeight.w600, color: p.text))),
                      Text(tr('Switch ›'), style: TextStyle(fontWeight: FontWeight.w800, color: p.a)),
                    ]),
                  ),
                ),
              ),
            ),
          if (L.isEmpty) const Empty('💬 No private chats yet.\nTap “New private chat” or open a member’s profile to start one.'),
          for (final (i, c) in L.indexed)
            Enter(
              index: i,
              child: Builder(builder: (_) {
                final pu = strList(c['users']).firstWhere((u) => u != S.uid, orElse: () => '');
                final d = D['dir'][pu] ?? {};
                final W = Chat.dmWho(c, pu);
                final cls = S.clsOf({'flat': W.f});
                final nm = W.n + (S.sch && W.f.isNotEmpty && S.isStu(d['role'] != null ? d : {'role': 'RESIDENT'}) && cls.isNotEmpty ? ' · $cls' : '');
                final u = isUn(c);
                final today = dayLbl(c['lastTs']) == 'Today';
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  decoration: BoxDecoration(color: u ? p.tint : p.card, borderRadius: BorderRadius.circular(18), border: Border.all(color: p.line)),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(18),
                    onTap: () => Chat.openDM(pu, from: 'inbox', cid0: str(c['id'])),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Row(children: [
                        Av(W.n, W.p, size: 48, badge: Chat.online(pu) ? onlineDot() : null),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(nm, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: u ? FontWeight.w800 : FontWeight.w700, fontSize: 15, color: p.text)),
                            const SizedBox(height: 2),
                            Text('${c['lastFrom'] == S.uid ? tr('You: ') : ''}${str(c['last'])}', maxLines: 1, overflow: TextOverflow.ellipsis, style: meta(u ? p.text : p.muted)),
                          ]),
                        ),
                        const SizedBox(width: 8),
                        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                          Text(today ? tm(c['lastTs']) : dayLbl(c['lastTs']), style: small(u ? p.a : p.muted)),
                          if (u) Container(margin: const EdgeInsets.only(top: 6), width: 10, height: 10, decoration: BoxDecoration(color: p.a, shape: BoxShape.circle)),
                        ]),
                      ]),
                    ),
                  ),
                );
              }),
            ),
        ]);
      },
    );
  }
}

void newChatSheet(BuildContext context) => sheet(context, (_) => const _NewChat());

class _NewChat extends StatefulWidget {
  const _NewChat();
  @override
  State<_NewChat> createState() => _NewChatState();
}

class _NewChatState extends State<_NewChat> {
  final q = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final t = q.text.trim().toLowerCase();
    final ppl = D['dir'].values.where((p) => str(p['uid'] ?? p['id']) != S.uid && '${str(p['name'])} ${str(p['flat'])}'.toLowerCase().contains(t)).toList()..sort((a, b) => str(a['name']).compareTo(str(b['name'])));
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      SheetTitle('✉️ New private chat',
          sub: S.kind == 'company'
              ? 'Choose a colleague to message.'
              : S.kind == 'school'
                  ? 'Choose someone from your school to message.'
                  : 'Choose a neighbour to message.'),
      Field(q, '🔍 Search by name or flat', onChanged: (_) => setState(() {})),
      if (ppl.isEmpty) const Empty('No members found'),
      for (final p in ppl.take(200))
        Ex(
          str(p['name']),
          sub: '${str(p['flat'])} · ${Chat.online(str(p['uid'] ?? p['id'])) ? tr('Online') : tr('Offline')}',
          lead: Av(str(p['name']), str(p['photo']), size: 44, badge: Chat.online(str(p['uid'] ?? p['id'])) ? onlineDot() : null),
          onTap: () {
            Navigator.pop(context);
            Chat.openDM(str(p['uid'] ?? p['id']), from: 'inbox');
          },
        ),
    ]);
  }
}
