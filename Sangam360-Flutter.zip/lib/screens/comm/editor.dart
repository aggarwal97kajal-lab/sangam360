import 'dart:math';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/files.dart';
import '../../core/img.dart';
import '../../core/toast.dart';
import '../../ui/kit.dart';
import '../../ui/pick.dart';
import '../../ui/theme.dart';
import 'chat_ctl.dart';

/* ===== gallery / camera: an editor before sending (crop, rotate, draw, text, HD, caption) ===== */

const _ieCols = [Color(0xFFFFFFFF), Color(0xFF111827), Color(0xFFEF4444), Color(0xFFF59E0B), Color(0xFF22C55E), Color(0xFF3B82F6), Color(0xFFA855F7)];
const _iMax = 2560;

Future<ui.Image> _load(Uint8List b) async {
  final im = await decodeImg(b);
  final s = min(1.0, _iMax / max(im.width, im.height));
  if (s >= 1) return im;
  final w = max(1, (im.width * s).round()), h = max(1, (im.height * s).round());
  final out = await _draw(w, h, (c) => c.drawImageRect(im, Rect.fromLTWH(0, 0, im.width.toDouble(), im.height.toDouble()), Rect.fromLTWH(0, 0, w.toDouble(), h.toDouble()), Paint()..filterQuality = FilterQuality.high));
  im.dispose();
  return out;
}

Future<ui.Image> _draw(int w, int h, void Function(Canvas c) fn) async {
  final rec = ui.PictureRecorder();
  final c = Canvas(rec);
  fn(c);
  return rec.endRecording().toImage(w, h);
}

class _It {
  ui.Image img;
  final List<ui.Image> hist = [];
  String cap = '';
  _It(this.img);
}

class _Stroke {
  final List<Offset> p;
  final Color c;
  final double w;
  _Stroke(this.p, this.c, this.w);
}

/// opens the editor for 1–10 photos; it sends them itself
Future<void> openEditor(BuildContext context, List<PFile> files) async {
  final items = <_It>[];
  for (final f in files.take(10)) {
    try {
      items.add(_It(await _load(f.bytes)));
    } catch (_) {
      toast('⚠️', "Couldn't open a photo", f.name);
    }
  }
  if (items.isEmpty || !context.mounted) return;
  await Navigator.of(context).push(MaterialPageRoute(fullscreenDialog: true, builder: (_) => _Editor(items)));
}

class _Editor extends StatefulWidget {
  final List<_It> items;
  const _Editor(this.items);
  @override
  State<_Editor> createState() => _EditorState();
}

class _EditorState extends State<_Editor> {
  int i = 0;
  bool hd = false, busy = false, qOpen = false;
  String? tool; // crop | draw | text
  final cap = TextEditingController();
  // crop
  Rect box = const Rect.fromLTWH(.08, .08, .84, .84);
  double asp = 0;
  // draw
  final List<_Stroke> strokes = [];
  Color pen = _ieCols[2];
  double penW = 2;
  // text
  String tx = '';
  Color txC = _ieCols[0];
  Offset txAt = const Offset(.5, .5);
  final txCtl = TextEditingController();

  _It get it => widget.items[i];

  @override
  void initState() {
    super.initState();
    cap.text = it.cap;
  }

  void _push() {
    it.hist.add(it.img);
    if (it.hist.length > 8) it.hist.removeAt(0);
  }

  void _setTool(String? t) {
    setState(() {
      strokes.clear();
      tool = t;
      qOpen = false;
      if (t == 'crop') {
        box = const Rect.fromLTWH(.08, .08, .84, .84);
        asp = 0;
      }
      if (t == 'text') {
        tx = '';
        txCtl.clear();
        txAt = const Offset(.5, .5);
      }
    });
  }

  void _aspSet(double r) {
    setState(() {
      asp = r;
      if (r == 0) return;
      final ia = it.img.width / it.img.height;
      var w = .86, h = w * ia / r;
      if (h > .86) {
        h = .86;
        w = h * r / ia;
      }
      box = Rect.fromLTWH((1 - w) / 2, (1 - h) / 2, w, h);
    });
  }

  Future<void> _cropDone() async {
    final im = it.img;
    final sx = (box.left * im.width).round(), sy = (box.top * im.height).round(), sw = max(8, (box.width * im.width).round()), sh = max(8, (box.height * im.height).round());
    _push();
    it.img = await _draw(sw, sh, (c) => c.drawImageRect(im, Rect.fromLTWH(sx.toDouble(), sy.toDouble(), sw.toDouble(), sh.toDouble()), Rect.fromLTWH(0, 0, sw.toDouble(), sh.toDouble()), Paint()));
    _setTool(null);
  }

  Future<void> _rotate() async {
    _setTool(null);
    final im = it.img;
    _push();
    it.img = await _draw(im.height, im.width, (c) {
      c.translate(im.height.toDouble(), 0);
      c.rotate(pi / 2);
      c.drawImage(im, Offset.zero, Paint());
    });
    setState(() {});
  }

  Future<void> _drawDone() async {
    if (strokes.isNotEmpty) {
      final im = it.img;
      _push();
      final st = List.of(strokes);
      it.img = await _draw(im.width, im.height, (c) {
        c.drawImage(im, Offset.zero, Paint());
        for (final s in st) {
          _paintStroke(c, s);
        }
      });
    }
    _setTool(null);
  }

  Future<void> _textDone() async {
    if (tx.trim().isNotEmpty) {
      final im = it.img;
      _push();
      final fs = max(14.0, im.width * .07);
      final at = Offset(txAt.dx * im.width, txAt.dy * im.height);
      final t = tx, col = txC;
      it.img = await _draw(im.width, im.height, (c) {
        c.drawImage(im, Offset.zero, Paint());
        TextPainter mk(Paint? fg, Color? colr) => TextPainter(
              text: TextSpan(text: t, style: TextStyle(fontSize: fs, fontWeight: FontWeight.w700, fontFamily: fontFam, foreground: fg, color: fg == null ? colr : null)),
              textDirection: TextDirection.ltr,
              textAlign: TextAlign.center,
            )..layout(maxWidth: im.width * .95);
        final stroke = Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = fs * .14
          ..strokeJoin = StrokeJoin.round
          ..color = col == const Color(0xFF111827) ? Colors.white.withOpacity(.85) : Colors.black.withOpacity(.55);
        final a = mk(stroke, null), b = mk(null, col);
        final o = at - Offset(a.width / 2, a.height / 2);
        a.paint(c, o);
        b.paint(c, o);
      });
    }
    _setTool(null);
  }

  void _undo() {
    _setTool(null);
    if (it.hist.isNotEmpty) setState(() => it.img = it.hist.removeLast());
  }

  void _del() {
    _setTool(null);
    if (widget.items.length < 2) return;
    setState(() {
      widget.items.removeAt(i);
      i = min(i, widget.items.length - 1);
      cap.text = it.cap;
    });
  }

  /// a JPEG small enough to send: standard 1280 px / 440 KB, HD 2560 px / 2.6 MB
  Future<Uint8List> _blob(ui.Image im, bool hd) async {
    final capB = hd ? (2.6 * 1048576).round() : 440 * 1024;
    var s = min(1.0, (hd ? 2560 : 1280) / max(im.width, im.height));
    var q = hd ? 90 : 78;
    Uint8List? b;
    for (var k = 0; k < 8; k++) {
      final w = max(1, (im.width * s).round()), h = max(1, (im.height * s).round());
      final t = await _draw(w, h, (c) {
        c.drawRect(Rect.fromLTWH(0, 0, w.toDouble(), h.toDouble()), Paint()..color = Colors.white);
        c.drawImageRect(im, Rect.fromLTWH(0, 0, im.width.toDouble(), im.height.toDouble()), Rect.fromLTWH(0, 0, w.toDouble(), h.toDouble()), Paint()..filterQuality = FilterQuality.high);
      });
      b = await imageToJpeg(t, q: q);
      t.dispose();
      if (b.length <= capB) return b;
      if (q > 62) {
        q -= 8;
      } else {
        s *= .85;
      }
    }
    return b!;
  }

  Future<void> _send() async {
    if (busy) return;
    _setTool(null);
    it.cap = cap.text;
    setState(() => busy = true);
    final list = List.of(widget.items);
    var sent = 0;
    try {
      for (final x in list) {
        final b = await _blob(x.img, hd);
        final url = await up(b, hd ? 'docs' : 'chat', 'p.jpg', raw: true, mime: 'image/jpeg');
        await Chat.sendMsg({'img': url, 'text': x.cap.trim().length > 300 ? x.cap.trim().substring(0, 300) : x.cap.trim(), if (hd) 'hd': 1});
        sent++;
      }
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        busy = false;
        widget.items.removeRange(0, sent);
        i = 0;
      });
      if (widget.items.isEmpty) Navigator.pop(context);
      fail(e, sent > 0 ? 'Some photos were not sent' : 'Photo not sent');
    }
  }

  Widget _tb(IconData ic, String tip, VoidCallback? fn, {bool on = false}) => IconButton(
        tooltip: tip,
        onPressed: busy ? null : fn,
        icon: Icon(ic, color: on ? const Color(0xFF8B5CF6) : Colors.white),
        style: IconButton.styleFrom(backgroundColor: on ? Colors.white : Colors.white.withOpacity(.08)),
      );

  @override
  Widget build(BuildContext context) {
    final p = pal;
    return PopScope(
      canPop: tool == null && !busy,
      onPopInvokedWithResult: (did, _) {
        if (!did && tool != null) _setTool(null);
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(6, 6, 6, 4),
              child: Row(children: [
                _tb(Icons.close_rounded, 'Close', () => Navigator.pop(context)),
                const Spacer(),
                if (widget.items.length > 1) _tb(Icons.delete_outline_rounded, 'Remove this photo', _del),
                _tb(Icons.undo_rounded, 'Undo', it.hist.isEmpty ? null : _undo),
                _tb(Icons.crop_rounded, 'Crop', () => _setTool(tool == 'crop' ? null : 'crop'), on: tool == 'crop'),
                _tb(Icons.rotate_90_degrees_cw_rounded, 'Rotate', _rotate),
                _tb(Icons.edit_rounded, 'Draw', () => _setTool(tool == 'draw' ? null : 'draw'), on: tool == 'draw'),
                _tb(Icons.text_fields_rounded, 'Add text', () => _setTool(tool == 'text' ? null : 'text'), on: tool == 'text'),
                TextButton(
                  onPressed: busy
                      ? null
                      : () => setState(() {
                            tool = null;
                            qOpen = !qOpen;
                          }),
                  child: Text('HD', style: TextStyle(color: hd ? const Color(0xFF22C55E) : Colors.white, fontWeight: FontWeight.w900)),
                ),
              ]),
            ),
            Expanded(child: LayoutBuilder(builder: (_, c) => _stage(c))),
            if (qOpen)
              Padding(
                padding: const EdgeInsets.all(10),
                child: Row(children: [
                  for (final h in [false, true])
                    Expanded(
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            hd = h;
                            qOpen = false;
                          });
                          toast('🖼️', hd ? 'HD quality' : 'Standard quality', hd ? 'Photos are sent sharper (larger file).' : 'Photos are sent smaller and faster.');
                        },
                        child: Container(
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(color: hd == h ? Colors.white : Colors.white12, borderRadius: BorderRadius.circular(14)),
                          child: Column(children: [
                            Text(h ? 'HD quality' : 'Standard quality', style: TextStyle(fontWeight: FontWeight.w800, color: hd == h ? Colors.black : Colors.white)),
                            Text(h ? 'Sharper photo, larger file' : 'Smaller file, sends faster', style: TextStyle(fontSize: 11.5, color: hd == h ? Colors.black54 : Colors.white70)),
                          ]),
                        ),
                      ),
                    ),
                ]),
              ),
            if (tool != null) _toolBar(),
            if (tool == null && widget.items.length > 1)
              SizedBox(
                height: 64,
                child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 10), children: [
                  for (var k = 0; k < widget.items.length; k++)
                    GestureDetector(
                      onTap: () => setState(() {
                        it.cap = cap.text;
                        i = k;
                        cap.text = it.cap;
                      }),
                      child: Container(
                        width: 54,
                        height: 54,
                        margin: const EdgeInsets.only(right: 8, top: 5),
                        decoration: BoxDecoration(border: Border.all(color: k == i ? p.a : Colors.transparent, width: 2.5), borderRadius: BorderRadius.circular(10)),
                        clipBehavior: Clip.antiAlias,
                        child: RawImage(image: widget.items[k].img, fit: BoxFit.cover),
                      ),
                    ),
                ]),
              ),
            if (tool == null)
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
                child: Row(children: [
                  Expanded(
                    child: TextField(
                      controller: cap,
                      maxLength: 300,
                      style: const TextStyle(color: Colors.white),
                      onChanged: (v) => it.cap = v,
                      decoration: InputDecoration(counterText: '', hintText: 'Add a caption…', hintStyle: const TextStyle(color: Colors.white54), filled: true, fillColor: Colors.white12, border: OutlineInputBorder(borderRadius: BorderRadius.circular(99), borderSide: BorderSide.none), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(99), borderSide: BorderSide.none), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(99), borderSide: BorderSide.none)),
                    ),
                  ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: _send,
                    child: Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(gradient: p.grad, shape: BoxShape.circle),
                      alignment: Alignment.center,
                      child: busy
                          ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                          : Stack(clipBehavior: Clip.none, children: [
                              const Icon(Icons.send_rounded, color: Colors.white),
                              if (widget.items.length > 1) Positioned(right: -14, top: -14, child: CircleAvatar(radius: 10, backgroundColor: Colors.white, child: Text('${widget.items.length}', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: p.a)))),
                            ]),
                    ),
                  ),
                ]),
              ),
          ]),
        ),
      ),
    );
  }

  /// the photo, scaled into the space, with the crop box / drawing / text on top
  Widget _stage(BoxConstraints c) {
    final im = it.img;
    final W = c.maxWidth - 16, H = c.maxHeight - 16;
    final s = min(W / im.width, H / im.height);
    final dw = im.width * s, dh = im.height * s;
    Offset norm(Offset l) => Offset((l.dx / dw).clamp(0.0, 1.0), (l.dy / dh).clamp(0.0, 1.0));
    return Center(
      child: SizedBox(
        width: dw,
        height: dh,
        child: Stack(clipBehavior: Clip.none, children: [
          Positioned.fill(child: RawImage(image: im, fit: BoxFit.fill)),
          if (tool == 'draw')
            Positioned.fill(
              child: GestureDetector(
                onPanStart: (d) {
                  final n = norm(d.localPosition);
                  setState(() => strokes.add(_Stroke([Offset(n.dx * im.width, n.dy * im.height)], pen, max(2, penW * 3 * (im.width / dw)))));
                },
                onPanUpdate: (d) {
                  final n = norm(d.localPosition);
                  setState(() => strokes.last.p.add(Offset(n.dx * im.width, n.dy * im.height)));
                },
                child: CustomPaint(painter: _StrokesP(strokes, dw / im.width)),
              ),
            ),
          if (tool == 'crop') ..._cropBox(dw, dh),
          if (tool == 'text')
            Positioned(
              left: txAt.dx * dw - 150,
              top: txAt.dy * dh - 30,
              width: 300,
              height: 60,
              child: GestureDetector(
                onPanUpdate: (d) => setState(() => txAt = Offset((txAt.dx + d.delta.dx / dw).clamp(.05, .95), (txAt.dy + d.delta.dy / dh).clamp(.05, .95))),
                child: Center(
                  child: Text(tx.isEmpty ? 'Type your text' : tx,
                      textAlign: TextAlign.center, style: TextStyle(fontSize: max(14, dw * .07), fontWeight: FontWeight.w700, color: txC.withOpacity(tx.isEmpty ? .6 : 1), shadows: const [Shadow(blurRadius: 4, color: Colors.black54)])),
                ),
              ),
            ),
        ]),
      ),
    );
  }

  List<Widget> _cropBox(double dw, double dh) {
    const M = .08;
    Widget handle(String h) => GestureDetector(
          onPanUpdate: (d) {
            final dx = d.delta.dx / dw, dy = d.delta.dy / dh;
            var x = box.left, y = box.top, w = box.width, hh = box.height;
            if (h.contains('w')) {
              final nx = (x + dx).clamp(0.0, x + w - M);
              w += x - nx;
              x = nx;
            }
            if (h.contains('e')) w = (w + dx).clamp(M, 1 - x);
            if (h.contains('n')) {
              final ny = (y + dy).clamp(0.0, y + hh - M);
              hh += y - ny;
              y = ny;
            }
            if (h.contains('s')) hh = (hh + dy).clamp(M, 1 - y);
            if (asp > 0) {
              final k = asp * it.img.height / it.img.width;
              var nh = w / k;
              if (nh > 1 || (h.contains('n') ? box.bottom - nh < 0 : y + nh > 1)) {
                nh = h.contains('n') ? box.bottom : 1 - y;
                w = nh * k;
              }
              if (h.contains('w')) x = box.right - w;
              if (h.contains('n')) y = box.bottom - nh;
              hh = nh;
            }
            setState(() => box = Rect.fromLTWH(x, y, w, hh));
          },
          child: Container(width: 26, height: 26, decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, border: Border.all(color: pal.a, width: 3))),
        );
    final r = Rect.fromLTWH(box.left * dw, box.top * dh, box.width * dw, box.height * dh);
    return [
      Positioned.fill(child: IgnorePointer(child: CustomPaint(painter: _ShadeP(r)))),
      Positioned.fromRect(
        rect: r,
        child: GestureDetector(
          onPanUpdate: (d) => setState(() => box = Rect.fromLTWH((box.left + d.delta.dx / dw).clamp(0.0, 1 - box.width), (box.top + d.delta.dy / dh).clamp(0.0, 1 - box.height), box.width, box.height)),
          child: Container(decoration: BoxDecoration(border: Border.all(color: Colors.white, width: 2))),
        ),
      ),
      Positioned(left: r.left - 13, top: r.top - 13, child: handle('nw')),
      Positioned(left: r.right - 13, top: r.top - 13, child: handle('ne')),
      Positioned(left: r.left - 13, top: r.bottom - 13, child: handle('sw')),
      Positioned(left: r.right - 13, top: r.bottom - 13, child: handle('se')),
    ];
  }

  Widget _toolBar() {
    Widget chip(String l, bool on, VoidCallback f) => Padding(
          padding: const EdgeInsets.only(right: 6),
          child: GestureDetector(onTap: f, child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7), decoration: BoxDecoration(color: on ? Colors.white : Colors.white12, borderRadius: BorderRadius.circular(99)), child: Text(l, style: TextStyle(color: on ? Colors.black : Colors.white, fontWeight: FontWeight.w700, fontSize: 12.5)))),
        );
    Widget sw(Color cur, ValueChanged<Color> f) => Row(mainAxisSize: MainAxisSize.min, children: [
          for (final c in _ieCols)
            GestureDetector(onTap: () => f(c), child: Container(width: 26, height: 26, margin: const EdgeInsets.only(right: 6), decoration: BoxDecoration(color: c, shape: BoxShape.circle, border: Border.all(color: c == cur ? Colors.white : Colors.white24, width: c == cur ? 3 : 1)))),
        ]);
    final opts = <Widget>[];
    VoidCallback done = () => _setTool(null);
    if (tool == 'crop') {
      for (final a in const [('Free', 0.0), ('1:1', 1.0), ('4:3', 4 / 3), ('3:4', 3 / 4), ('16:9', 16 / 9)]) {
        opts.add(chip(a.$1, asp == a.$2, () => _aspSet(a.$2)));
      }
      done = _cropDone;
    } else if (tool == 'draw') {
      opts.add(IconButton(onPressed: () => setState(() => strokes.isNotEmpty ? strokes.removeLast() : null), icon: const Icon(Icons.undo_rounded, color: Colors.white)));
      opts.add(sw(pen, (c) => setState(() => pen = c)));
      for (final s in const [('S', 1.0), ('M', 2.0), ('L', 4.0)]) {
        opts.add(chip(s.$1, penW == s.$2, () => setState(() => penW = s.$2)));
      }
      done = _drawDone;
    } else if (tool == 'text') {
      done = _textDone;
    }
    return Container(
      color: Colors.black,
      padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
      child: Column(children: [
        if (tool == 'text')
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: TextField(
              controller: txCtl,
              autofocus: true,
              maxLength: 60,
              style: const TextStyle(color: Colors.white),
              onChanged: (v) => setState(() => tx = v),
              decoration: InputDecoration(counterText: '', hintText: 'Type your text', hintStyle: const TextStyle(color: Colors.white54), filled: true, fillColor: Colors.white12, border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)),
            ),
          ),
        if (tool == 'text') Padding(padding: const EdgeInsets.only(bottom: 8), child: sw(txC, (c) => setState(() => txC = c))),
        Row(children: [
          Expanded(child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: opts))),
          TextButton(onPressed: () => _setTool(null), child: const Text('Cancel', style: TextStyle(color: Colors.white70))),
          FilledButton(onPressed: done, child: const Text('Done')),
        ]),
      ]),
    );
  }
}

void _paintStroke(Canvas c, _Stroke s, [double k = 1]) {
  final pt = Paint()
    ..color = s.c
    ..strokeWidth = s.w * k
    ..strokeCap = StrokeCap.round
    ..strokeJoin = StrokeJoin.round
    ..style = PaintingStyle.stroke;
  if (s.p.length == 1) {
    c.drawPoints(ui.PointMode.points, [s.p.first * k], pt);
    return;
  }
  final path = Path()..moveTo(s.p.first.dx * k, s.p.first.dy * k);
  for (final q in s.p.skip(1)) {
    path.lineTo(q.dx * k, q.dy * k);
  }
  c.drawPath(path, pt);
}

class _StrokesP extends CustomPainter {
  final List<_Stroke> s;
  final double k;
  _StrokesP(this.s, this.k);
  @override
  void paint(Canvas c, Size sz) {
    for (final x in s) {
      _paintStroke(c, x, k);
    }
  }

  @override
  bool shouldRepaint(_StrokesP o) => true;
}

class _ShadeP extends CustomPainter {
  final Rect r;
  _ShadeP(this.r);
  @override
  void paint(Canvas c, Size s) {
    final path = Path()
      ..addRect(Offset.zero & s)
      ..addRect(r)
      ..fillType = PathFillType.evenOdd;
    c.drawPath(path, Paint()..color = Colors.black.withOpacity(.5));
  }

  @override
  bool shouldRepaint(_ShadeP o) => o.r != r;
}

/* ===== crop a photo (profile pictures): drag to move, slider to zoom, ratio chips ===== */
Future<Uint8List?> cropImage(BuildContext context, Uint8List bytes, {List<double> ratios = const [1], bool circle = false, int out = 640, double q = .8}) async {
  final ui.Image im;
  try {
    im = await decodeImg(bytes);
  } catch (e) {
    fail(e, 'Could not read photo');
    return null;
  }
  if (!context.mounted) return null;
  return Navigator.of(context).push<Uint8List>(MaterialPageRoute(fullscreenDialog: true, builder: (_) => _Crop(im: im, ratios: ratios, circle: circle, out: out, q: q)));
}

class _Crop extends StatefulWidget {
  final ui.Image im;
  final List<double> ratios;
  final bool circle;
  final int out;
  final double q;
  const _Crop({required this.im, required this.ratios, required this.circle, required this.out, required this.q});
  @override
  State<_Crop> createState() => _CropState();
}

class _CropState extends State<_Crop> {
  late double ra = widget.ratios.first;
  double z = 1, x = 0, y = 0, W = 300;
  bool init = false, busy = false;
  double get H => W / ra;
  double get mn => max(W / widget.im.width, H / widget.im.height);
  double get sc => mn * z;

  void _clamp() {
    x = min(0, max(W - widget.im.width * sc, x));
    y = min(0, max(H - widget.im.height * sc, y));
  }

  void _centre() {
    x = (W - widget.im.width * sc) / 2;
    y = (H - widget.im.height * sc) / 2;
    _clamp();
  }

  Future<void> _use() async {
    setState(() => busy = true);
    final ow = widget.out, oh = (widget.out / ra).round();
    final src = Rect.fromLTWH(-x / sc, -y / sc, W / sc, H / sc);
    final img = await _draw(ow, oh, (c) => c.drawImageRect(widget.im, src, Rect.fromLTWH(0, 0, ow.toDouble(), oh.toDouble()), Paint()..filterQuality = FilterQuality.high));
    final b = await imageToJpeg(img, q: (widget.q * 100).round());
    img.dispose();
    if (mounted) Navigator.pop(context, b);
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    W = min(320, MediaQuery.of(context).size.width - 70);
    if (!init) {
      init = true;
      _centre();
    }
    _clamp();
    return Scaffold(
      appBar: AppBar(title: const Text('Crop photo')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          Text('Drag to move · slider to zoom', style: meta()),
          const SizedBox(height: 16),
          GestureDetector(
            onPanUpdate: (d) => setState(() {
              x += d.delta.dx;
              y += d.delta.dy;
              _clamp();
            }),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(widget.circle ? 999 : 14),
              child: SizedBox(
                width: W,
                height: H,
                child: Stack(children: [
                  Positioned(left: x, top: y, width: widget.im.width * sc, height: widget.im.height * sc, child: RawImage(image: widget.im, fit: BoxFit.fill)),
                ]),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Slider(
            value: z,
            min: 1,
            max: 4,
            onChanged: (v) => setState(() {
              final cx = (W / 2 - x) / sc, cy = (H / 2 - y) / sc;
              z = v;
              x = W / 2 - cx * sc;
              y = H / 2 - cy * sc;
              _clamp();
            }),
          ),
          if (widget.ratios.length > 1)
            Seg([for (final (k, r) in widget.ratios.indexed) ('$r', const ['Square', 'Wide', 'Tall'][k.clamp(0, 2)])], '$ra', (v) => setState(() {
                  ra = double.parse(v);
                  _centre();
                })),
          const Spacer(),
          Row2(Btn.o('Cancel', onTap: () => Navigator.pop(context)), Btn('Use photo', onTap: busy ? null : _use, busyDone: false)),
          if (p.dark) const SizedBox(height: 4),
        ]),
      ),
    );
  }
}

/// haptic tick for the editor buttons
void tick() => HapticFeedback.selectionClick();
