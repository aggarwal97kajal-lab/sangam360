import 'dart:async';
import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';

import '../../core/files.dart';
import '../../core/perms.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/theme.dart';

/// one voice note plays at a time
class VoiceBus extends ChangeNotifier {
  static final VoiceBus I = VoiceBus._();
  VoiceBus._() {
    _p.onPlayerStateChanged.listen((s) {
      playing = s == PlayerState.playing;
      if (s == PlayerState.completed) {
        id = null;
        pos = Duration.zero;
      }
      notifyListeners();
    });
    _p.onPositionChanged.listen((d) {
      pos = d;
      notifyListeners();
    });
    _p.onDurationChanged.listen((d) {
      dur = d;
      notifyListeners();
    });
  }
  final AudioPlayer _p = AudioPlayer();
  String? id;
  bool playing = false, loading = false;
  Duration pos = Duration.zero, dur = Duration.zero;

  Future<void> toggle(String mid, String ref) async {
    if (id == mid) {
      if (playing) {
        await _p.pause();
      } else {
        await _p.resume();
      }
      return;
    }
    await stop();
    id = mid;
    loading = true;
    notifyListeners();
    try {
      final l = await resolveRef(ref);
      if (l.bytes != null) {
        await _p.play(BytesSource(l.bytes!));
      } else {
        await _p.play(UrlSource(l.url!));
      }
    } catch (e) {
      id = null;
      fail(e, "Couldn't play voice note");
    }
    loading = false;
    notifyListeners();
  }

  Future<void> seek(double r) async {
    if (dur.inMilliseconds > 0) await _p.seek(Duration(milliseconds: (dur.inMilliseconds * r).round()));
  }

  Future<void> stop() async {
    try {
      await _p.stop();
    } catch (_) {}
    id = null;
    pos = Duration.zero;
    notifyListeners();
  }
}

/// the player inside a message: play / pause, a waveform made from the message id, the time
class VoiceNote extends StatelessWidget {
  final String mid, ref;
  final int durS;
  final Color fg, track;
  const VoiceNote({super.key, required this.mid, required this.ref, required this.durS, required this.fg, required this.track});

  List<double> _bars() {
    var h = 0;
    for (final c in mid.codeUnits) {
      h = (h * 33 + c).toSigned(32);
    }
    final r = <double>[];
    for (var i = 0; i < 28; i++) {
      h = (h * 1103515245 + 12345) & 0x7fffffff;
      r.add((22 + h % 78) / 100);
    }
    return r;
  }

  @override
  Widget build(BuildContext context) {
    final bars = _bars();
    return ListenableBuilder(
      listenable: VoiceBus.I,
      builder: (_, __) {
        final b = VoiceBus.I, me = b.id == mid;
        final total = me && b.dur.inMilliseconds > 0 ? b.dur.inMilliseconds / 1000 : durS.toDouble();
        final r = me && total > 0 ? (b.pos.inMilliseconds / 1000 / total).clamp(0.0, 1.0) : 0.0;
        return SizedBox(
          width: 230,
          child: Row(children: [
            GestureDetector(
              onTap: () => b.toggle(mid, ref),
              child: Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(color: fg.withOpacity(.14), shape: BoxShape.circle),
                alignment: Alignment.center,
                child: me && b.loading ? SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: fg)) : Icon(me && b.playing ? Icons.pause_rounded : Icons.play_arrow_rounded, color: fg),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: LayoutBuilder(builder: (_, c) {
                return GestureDetector(
                  onTapDown: (d) {
                    if (me) b.seek((d.localPosition.dx / c.maxWidth).clamp(0.0, 1.0));
                  },
                  child: SizedBox(
                    height: 30,
                    child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
                      for (var i = 0; i < bars.length; i++)
                        Expanded(child: Container(margin: const EdgeInsets.symmetric(horizontal: .8), height: 30 * bars[i], decoration: BoxDecoration(color: i < (r * bars.length).round() ? fg : track, borderRadius: BorderRadius.circular(3)))),
                    ]),
                  ),
                );
              }),
            ),
            const SizedBox(width: 8),
            Text(fd(me && b.pos.inMilliseconds > 0 ? b.pos.inMilliseconds / 1000 : durS), style: TextStyle(fontSize: 11.5, color: fg.withOpacity(.8), fontWeight: FontWeight.w600)),
          ]),
        );
      },
    );
  }
}

/* ---------- the recorder: max 2 minutes, AAC (.m4a) ---------- */
class VoiceRec {
  static final AudioRecorder _r = AudioRecorder();
  static String? _path;
  static int t0 = 0;
  static bool get on => _path != null;

  static Future<bool> start() async {
    if (on) return true;
    if (!await askPerm('mic')) return false;
    try {
      if (!await _r.hasPermission()) {
        toast('🎤', 'Microphone blocked', 'Allow microphone access to send voice notes.');
        return false;
      }
      await VoiceBus.I.stop();
      final d = await getTemporaryDirectory();
      _path = '${d.path}/v${now()}.m4a';
      await _r.start(const RecordConfig(encoder: AudioEncoder.aacLc, bitRate: 32000, sampleRate: 22050, numChannels: 1), path: _path!);
      t0 = now();
      return true;
    } catch (e) {
      _path = null;
      fail(e, 'Voice notes not supported');
      return false;
    }
  }

  /// -> (bytes, seconds) or null when cancelled
  static Future<(List<int>, int)?> stop({bool cancel = false}) async {
    if (!on) return null;
    final p = _path!;
    _path = null;
    String? out;
    try {
      out = await _r.stop();
    } catch (_) {}
    final f = File(out ?? p);
    if (cancel) {
      try {
        if (await f.exists()) await f.delete();
      } catch (_) {}
      return null;
    }
    final dur = ((now() - t0) / 1000).round().clamp(1, 100000);
    try {
      final b = await f.readAsBytes();
      await f.delete();
      return (b, dur);
    } catch (e) {
      fail(e, 'Voice note not sent');
      return null;
    }
  }
}

Color waveTrack(Color fg) => fg.withOpacity(.28);
Color voiceFg(bool mine, Color bubbleText) => mine ? bubbleText : pal.a;
