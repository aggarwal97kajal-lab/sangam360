import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/app.dart';
import '../core/files.dart';
import '../core/fs.dart';
import '../core/kinds.dart';
import '../core/places.dart';
import '../core/plan.dart' show gF;
import '../core/session.dart';
import '../core/toast.dart';
import '../core/util.dart';
import '../ui/brand.dart';
import '../ui/fields.dart';
import '../ui/kit.dart';
import '../ui/pick.dart';
import '../ui/theme.dart';
import 'boot.dart';
import 'join.dart';

class _Tw {
  final TextEditingController name;
  int floors, per;
  _Tw(String n, this.floors, this.per) : name = TextEditingController(text: n);
}

class CreateScreen extends StatefulWidget {
  const CreateScreen({super.key});
  @override
  State<CreateScreen> createState() => _CreateScreenState();
}

class _CreateScreenState extends State<CreateScreen> {
  int step = 1;
  String err = '';
  String crole = 'SOCIETY_ADMIN';
  final cpc = TextEditingController(), sn = TextEditingController(), sa = TextEditingController(), sco = TextEditingController(), spin = TextEditingController();
  final cn = TextEditingController(), cm = TextEditingController();
  String? st, city;
  final Map<String, String> xsel = {};
  final Map<String, TextEditingController> xtxt = {};
  bool multi = false;
  List<_Tw> towers = [_Tw('Main', 4, 4)];
  List<TextEditingController> grps = [];
  String? idRef, phRef;
  String newCode = '';

  @override
  void initState() {
    super.initState();
    cn.text = S.user?.displayName ?? '';
    final K = S.K;
    for (final f in K.x) {
      if (f.kind == 'txt') xtxt[f.label] = TextEditingController();
    }
    if (K.grp != null) grps = K.grp!.pre.map((x) => TextEditingController(text: x)).toList();
  }

  bool get org => S.kind != 'society';
  bool get teacherMode => S.kind == 'school' && crole == 'COMMITTEE_MEMBER';
  String get cityVal => city == '__other' ? sco.text.trim() : (city ?? '');
  int get flatTotal => towers.fold(0, (a, t) => a + t.floors * t.per);

  void _e(String t) => setState(() => err = t);
  void _go(int n) => setState(() {
        step = n;
        err = '';
      });

  Future<void> _n1() async {
    if (teacherMode) {
      final c = cpc.text.trim().toUpperCase();
      if (c.length < 4) return _e("Enter the Principal's school code. You cannot continue without it.");
      BootCtl.joinWant = 'teacher';
      final er = await findJoin(c, needP: true);
      if (er != null) return _e(er);
      S.go(Phase.join);
      return;
    }
    if (sn.text.trim().isEmpty || cityVal.isEmpty || (st ?? '').isEmpty || !RegExp(r'^\d{6}$').hasMatch(spin.text.trim())) {
      return _e((st ?? '').isEmpty
          ? 'Choose your state.'
          : cityVal.isEmpty
              ? 'Choose your city.'
              : 'Fill all fields. PIN must be 6 digits.');
    }
    if (org && S.K.x.any((f) => f.kind == 'sel' && (xsel[f.label] ?? '').isEmpty)) return _e('Please choose all the options.');
    if (S.kind == 'company') {
      final g = xtxt['GST number'];
      final gv = (g?.text ?? '').trim().toUpperCase();
      if (!gstRe.hasMatch(gv)) return _e('GST number is mandatory for companies. Enter a valid 15-character GSTIN (e.g. 22AAAAA0000A1Z5).');
      g!.text = gv;
    }
    _go(2);
  }

  void _n2() {
    if (org) {
      final g = grps.map((x) => x.text.trim()).where((x) => x.isNotEmpty).toList();
      if (g.isEmpty || g.map((x) => x.toLowerCase()).toSet().length != g.length) return _e('Add at least one ${S.K.grp!.one} (no duplicates).');
      grps = g.map((x) => TextEditingController(text: x)).toList();
      _go(3);
      return;
    }
    if (towers.any((t) => t.name.text.trim().isEmpty)) return _e('Give every tower a name.');
    _go(3);
  }

  Future<void> _n3() async {
    final nm = cn.text.trim(), mo = cm.text.trim();
    if (nm.isEmpty || mo.length < 8) return _e('Enter your name and mobile number.');
    if (idRef == null || phRef == null) return _e('ID proof and your photo are both required to sign up.');
    final sid = BootCtl.fuSid(), t0 = now();
    final tw = org ? grps.map((g) => {'name': g.text.trim(), 'floors': 1, 'perFloor': 1}).toList() : towers.map((t) => {'name': t.name.text.trim(), 'floors': t.floors, 'perFloor': t.per}).toList();
    final ex = <String, dynamic>{};
    if (org) {
      for (final f in S.K.x) {
        ex[f.label.replaceAll(' (optional)', '')] = f.kind == 'sel' ? (xsel[f.label] ?? '') : xtxt[f.label]!.text.trim();
      }
    }
    await rtdb.ref('soc/$sid/owner').set(S.uid);
    await rtdb.ref('soc/$sid').update({'members/${S.uid}': true, 'admins/${S.uid}': true});
    final role = teacherMode ? 'COMMITTEE_MEMBER' : 'SOCIETY_ADMIN';
    for (var k = 0; k < 4; k++) {
      final code = genCode();
      final b = Batch();
      b.set(socRef(sid), {
        'name': sn.text.trim(),
        'address': sa.text.trim(),
        'city': cityVal,
        'state': st,
        'pin': spin.text.trim(),
        'code': code,
        'adminUid': S.uid,
        'plan': 'FREE',
        'type': S.kind,
        'active': true,
        'createdAt': t0,
        'towers': tw,
        'flatCount': org ? 0 : flatTotal,
        'extra': ex,
        'gstin': str(ex['GST number']).toUpperCase(),
        'settings': {'monthlyAmount': 0, 'upiId': '', 'payMode': 'upi'},
      });
      b.set(memRef(S.uid!, sid), {
        'uid': S.uid,
        'name': nm,
        'mobile': mo,
        'role': role,
        'status': 'approved',
        'flat': S.kind == 'school' ? (role == 'COMMITTEE_MEMBER' ? 'Teacher' : 'Principal') : 'Admin',
        'ts': t0,
        'idUrl': idRef,
        'photoUrl': phRef,
      });
      b.set(fs.collection('joinCodes').doc(code), {'societyId': sid, 'name': sn.text.trim(), 'towers': tw, 'type': S.kind});
      b.set(fs.collection('userSociety').doc(S.uid), {'societyId': sid, 'list': FieldValue.arrayUnion(S.sid != null && S.sid != sid ? [S.sid, sid] : [sid])}, merge: true);
      try {
        await b.commit();
        newCode = code;
        break;
      } catch (e) {
        if (k == 3) rethrow;
      }
    }
    SocRows.cache = null;
    _go(4);
  }

  void _copy(String t) {
    Clipboard.setData(ClipboardData(text: t));
    toast('✅', 'Copied ✓', t);
  }

  Widget _stepsBar() {
    final p = pal;
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: Row(children: [
        for (var i = 1; i <= 4; i++) Expanded(child: AnimatedContainer(duration: const Duration(milliseconds: 350), height: 5, margin: EdgeInsets.only(right: i < 4 ? 6 : 0), decoration: BoxDecoration(color: i <= step ? p.a : p.line, borderRadius: BorderRadius.circular(9)))),
      ]),
    );
  }

  Widget _numBox(String label, int v, int lo, int hi, ValueChanged<int> on) {
    final p = pal;
    return Container(
      height: 54,
      decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: p.line)),
      child: Row(children: [
        InkWell(onTap: v > lo ? () => on(v - 1) : null, child: SizedBox(width: 30, height: 54, child: Icon(Icons.remove_rounded, size: 18, color: v > lo ? p.a : p.faint))),
        Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text('$v', style: h3()), Text(label, style: small())])),
        InkWell(onTap: v < hi ? () => on(v + 1) : null, child: SizedBox(width: 30, height: 54, child: Icon(Icons.add_rounded, size: 18, color: v < hi ? p.a : p.faint))),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = pal, K = S.K;
    final kids = <Widget>[];
    if (step == 1) {
      kids.addAll([
        Text(S.sk('Step 1 · Society details'), style: h2()),
        const SizedBox(height: 4),
        Text(S.sk('Tell us about your society.'), style: meta()),
        const SizedBox(height: 14),
        if (S.kind == 'school') ...[
          Text('You are creating this school as', style: meta()),
          const SizedBox(height: 6),
          SelectField('Select your role', crole, const [('SOCIETY_ADMIN', 'Create as Principal'), ('COMMITTEE_MEMBER', 'Create as Teacher')], (v) => setState(() {
                crole = v;
                err = '';
              })),
        ],
        if (teacherMode) ...[
          Text("Principal's school code (required)", style: meta()),
          const SizedBox(height: 6),
          Field(cpc, 'e.g. K7M2QX', max: 8, upper: true, center: true, spacing: 3),
          Padding(padding: const EdgeInsets.only(bottom: 12), child: Text('Your Principal gets this code after creating the school. You cannot continue without it.', style: meta())),
        ] else ...[
          Field(sn, S.sk('Society name'), max: 60),
          Field(sa, 'Address', max: 120),
          Row(children: [
            Expanded(
              child: SelectField('State', st, SelectField.same(inPlaces.keys.toList()), (v) => setState(() {
                    st = v;
                    city = null;
                    sco.clear();
                  })),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: SelectField(
                st == null ? 'City (choose state first)' : 'City',
                city,
                st == null ? const [] : [...SelectField.same((inPlaces[st] ?? '').split(',').where((x) => x.isNotEmpty).toList()), ('__other', 'Other (type your city)')],
                st == null ? null : (v) => setState(() => city = v),
              ),
            ),
          ]),
          if (city == '__other') Field(sco, 'Type your city / town', max: 40, autofocus: true),
          Field(spin, 'PIN code', max: 6, kb: TextInputType.number, digitsOnly: true),
          if (org)
            for (final f in K.x)
              f.kind == 'sel'
                  ? SelectField(f.label, xsel[f.label], SelectField.same(f.opts), (v) => setState(() => xsel[f.label] = v))
                  : Field(xtxt[f.label]!, f.label == 'GST number' ? 'GST number (15 characters) *' : f.label, max: f.label == 'GST number' ? 15 : 40, upper: f.label == 'GST number'),
        ],
        Btn(teacherMode ? 'Verify code & continue' : 'Next', onTap: _n1, busyDone: false),
      ]);
    } else if (step == 2) {
      kids.addAll([
        Text(org ? 'Step 2 · ${K.grp!.t}' : 'Step 2 · Property structure', style: h2()),
        const SizedBox(height: 4),
        Text(org ? K.grp!.s : 'Flats are created automatically (e.g. floor 2, flat 3 → 203).', style: meta()),
        const SizedBox(height: 14),
        if (!org) ...[
          Seg(const [('s', 'Single building'), ('m', 'Multiple towers')], multi ? 'm' : 's', (v) => setState(() {
                multi = v == 'm';
                if (!multi) towers = [towers.first];
              })),
          for (final t in towers)
            Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: p.card2, borderRadius: BorderRadius.circular(16)),
              child: Column(children: [
                Field(t.name, 'Tower name', max: 30, onChanged: (_) => setState(() {})),
                Row(children: [
                  Expanded(child: _numBox('Floors', t.floors, 1, 60, (v) => setState(() => t.floors = v))),
                  const SizedBox(width: 10),
                  Expanded(child: _numBox('Flats / floor', t.per, 1, 20, (v) => setState(() => t.per = v))),
                ]),
              ]),
            ),
          if (multi) Btn.o('+ Add tower', small: true, onTap: () => setState(() => towers.add(_Tw('Tower ${String.fromCharCode(65 + towers.length)}', 4, 4)))),
          Padding(padding: const EdgeInsets.symmetric(vertical: 10), child: Text(S.sk('Total flats: $flatTotal · Tower name · Floors · Flats per floor'), style: meta())),
        ] else ...[
          for (final (i, g) in grps.indexed)
            Row(children: [
              Expanded(child: Field(g, K.grp!.ph, max: 40)),
              const SizedBox(width: 8),
              Padding(padding: const EdgeInsets.only(bottom: 12), child: IconBtn(Icons.close_rounded, size: 46, onTap: () => setState(() => grps.removeAt(i)))),
            ]),
          Btn.o('+ Add ${K.grp!.one}', small: true, onTap: () => setState(() => grps.add(TextEditingController()))),
          const SizedBox(height: 12),
        ],
        Row2(Btn.o('Back', onTap: () => _go(1)), Btn('Next', onTap: _n2, busyDone: false)),
      ]);
    } else if (step == 3) {
      final t = teacherMode;
      kids.addAll([
        Text(S.kind != 'school' ? 'Step 3 · Admin account' : 'Step 3 · ${t ? 'Teacher' : 'Principal'} account', style: h2()),
        const SizedBox(height: 4),
        Text(
            S.kind != 'school'
                ? S.sk('You become the society administrator.')
                : t
                    ? 'You set up this school as a teacher. You can appoint the Principal later from the People tab.'
                    : 'You become the Principal, with full rights over students, teachers and records.',
            style: meta()),
        const SizedBox(height: 14),
        Field(cn, 'Your name', max: 40, kb: TextInputType.name),
        Field(cm, 'Your mobile number', max: 15, kb: TextInputType.phone),
        Padding(padding: const EdgeInsets.only(bottom: 8), child: Text('Upload your ID proof (photo or PDF) and a photo of yourself — both are required.', style: meta())),
        FileSlot(label: '🪪 ID proof', icon: '🪪', pdf: true, upload: (f) => upID(BootCtl.fuSid(), f.bytes, f.name, 'idproofs'), onRef: (r) => idRef = r),
        FileSlot(label: '🤳 Your photo', icon: '🤳', front: true, upload: (f) => upID(BootCtl.fuSid(), f.bytes, f.name, 'idphotos', sq: true), onRef: (r) => phRef = r),
        const SizedBox(height: 6),
        Row2(Btn.o('Back', onTap: () => _go(2)), Btn(S.sk('Create society'), onTap: _n3, busyDone: false)),
      ]);
    } else {
      final sc = S.kind == 'school';
      final share = sc ? inviteText(newCode, org: sn.text.trim(), teacher: true) : inviteText(newCode, org: 'our ${K.word}');
      kids.addAll([
        Text(S.sk('🎉 Society created!'), style: h2().copyWith(fontSize: 21)),
        const SizedBox(height: 4),
        Text(sc ? "This is your Principal's code. Share it only with your teachers: they choose Join as a teacher and enter it. Each teacher then gets a class code for students." : S.sk('Invite residents with this code or link.'), style: meta()),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.symmetric(vertical: 18),
          decoration: BoxDecoration(gradient: LinearGradient(colors: [p.a.withOpacity(.12), p.a2.withOpacity(.08)]), borderRadius: BorderRadius.circular(18), border: Border.all(color: p.a.withOpacity(.25))),
          child: Text(newCode, textAlign: TextAlign.center, style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: 8, color: p.a)),
        ),
        const SizedBox(height: 14),
        Btn.o('Copy code', small: true, onTap: () => _copy(newCode)),
        const SizedBox(height: 8),
        Btn.o('Copy invitation', small: true, onTap: () => _copy(share)),
        const SizedBox(height: 8),
        Btn.g('Share on WhatsApp', small: true, onTap: () => launchUrl(Uri.parse('https://wa.me/?text=${Uri.encodeComponent(share)}'), mode: LaunchMode.externalApplication)),
        const SizedBox(height: 14),
        Btn('Open my dashboard', onTap: () async {
          S.addMode = false;
          await App.boot();
        }, busyDone: false),
      ]);
    }
    return BootPage(
      head: BrandHead(title: S.sk('Create your society')),
      children: [
        _stepsBar(),
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          transitionBuilder: (c, a) => FadeTransition(opacity: a, child: SlideTransition(position: Tween(begin: const Offset(.06, 0), end: Offset.zero).animate(a), child: c)),
          child: Column(key: ValueKey(step), crossAxisAlignment: CrossAxisAlignment.stretch, children: kids),
        ),
        ErrText(err),
        if (step != 4) Lnk('← Back', onTap: () => S.go(Phase.choice)),
      ],
    );
  }
}

/// flats of one tower as the earlier app counted them (kept for the summary line)
int towerFlats(Map<String, dynamic> t) => gF(t, true).length;
