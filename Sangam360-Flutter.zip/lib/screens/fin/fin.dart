import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/api.dart';
import '../../core/csv.dart';
import '../../core/files.dart';
import '../../core/fs.dart';
import '../../core/kinds.dart';
import '../../core/listen.dart';
import '../../core/pdfs.dart';
import '../../core/prefs.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/anim.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/media.dart';
import '../../ui/pick.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import 'history.dart';
import 'pay.dart';

/* ===== the Finance tab (Billing / Fees): fund, receive payments, GST, bills, dues, confirmations, history ===== */

String bref(String m, String f) => '${m}_${f.replaceAll(RegExp('[^A-Za-z0-9]'), '_')}';

/// who can be billed: unit -> names of the people in it
Map<String, List<String>> billUnits() {
  final m = <String, List<String>>{};
  for (final x in D['mem'].values) {
    if (x['status'] != 'approved' || str(x['flat']).isEmpty) continue;
    if (S.kind == 'school' ? !S.isStu(x) : !S.isOrg && !str(x['flat']).contains('Flat ')) continue;
    final a = m[str(x['flat'])] ??= [];
    if (str(x['name']).isNotEmpty && !a.contains(str(x['name']))) a.add(str(x['name']));
  }
  return m;
}

String uGrp(String f) => f.split(' · ').first;
String uId(String f) => f.split(' · ').skip(1).join(' · ');
String uLabel(String f, List<String>? names) {
  final nm = (names ?? []).join(', ');
  if (!S.isOrg) return nm.isNotEmpty ? '$f — $nm' : f;
  final id = uId(f);
  return (nm.isNotEmpty ? nm : f) + (id.isNotEmpty ? ' · ${S.kind == 'school' ? 'Roll ' : ''}$id' : '');
}

class FinTab extends StatelessWidget {
  const FinTab({super.key});
  static final Set<String> _bfix = {};

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: D.on(['inc', 'exp', 'bills', 'pay', 'soc', 'mem']),
      builder: (_, __) {
        final mine = !S.canFin;
        final i0 = D['inc'].values.toList();
        final I = mine ? i0.where((t) => t['flat'] == S.me?['flat']).toList() : i0;
        final E = mine ? <Doc>[] : D['exp'].values.toList();
        final ti = I.fold<num>(0, (a, c) => a + numv(c['amount'])), te = E.fold<num>(0, (a, c) => a + numv(c['amount']));
        if (!mine && S.role != 'ACCOUNTANT') {
          for (final t in i0) {
            if (str(t['flat']).isEmpty && t['category'] == 'Maintenance' && str(t['reason']).contains(' maintenance ') && !_bfix.contains(t['id'])) {
              _bfix.add(str(t['id']));
              updateDoc(dref('contributions', str(t['id'])), {'flat': str(t['reason']).split(' maintenance ').first}).catchError((_) {});
            }
          }
        }
        payWarm();
        return ListView(physics: const BouncingScrollPhysics(), padding: const EdgeInsets.fromLTRB(16, 4, 16, 110), children: [
          if (!mine) Enter(child: _BalCard(ti - te, ti, te)),
          if (S.isOwner) const PayoutCard(),
          if (S.isAdm && S.kind == 'company') const _GstCard(),
          if (!S.isGuard) ...billCards(context),
          if (S.canFin) const _IncExp(),
        ]);
      },
    );
  }
}

class _BalCard extends StatelessWidget {
  final num bal, ti, te;
  const _BalCard(this.bal, this.ti, this.te);
  @override
  Widget build(BuildContext context) {
    final p = pal;
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(gradient: LinearGradient(colors: [p.a, p.rc], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(24), boxShadow: [BoxShadow(color: p.a.withOpacity(.3), blurRadius: 24, offset: const Offset(0, 10))]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(S.sk('Society fund balance'), style: TextStyle(color: Colors.white.withOpacity(.85), fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        CountUp(bal, money: true, style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w800, letterSpacing: -.5)),
        const SizedBox(height: 4),
        Text('Collected ${rs(ti)} · Spent ${rs(te)}', style: TextStyle(color: Colors.white.withOpacity(.85), fontSize: 13)),
      ]),
    );
  }
}

/* ---------- how the organisation is paid (main admin) ---------- */
class PayoutCard extends StatefulWidget {
  const PayoutCard({super.key});
  @override
  State<PayoutCard> createState() => _PayoutCardState();
}

class _PayoutCardState extends State<PayoutCard> {
  bool edit = false;
  String m = '';
  final upiId = TextEditingController(), payee = TextEditingController(), holder = TextEditingController(), acc1 = TextEditingController(), acc2 = TextEditingController(), ifsc = TextEditingController(), bank = TextEditingController();
  String type = '';

  String get fee => S.kind == 'society'
      ? 'maintenance bills'
      : S.kind == 'school'
          ? 'fees'
          : 'bills';

  void _fill(Doc? p) {
    final u = mapv(p?['upi']), k = mapv(p?['bank']);
    upiId.text = p?['method'] == 'upi' ? str(u['id']) : '';
    payee.text = p?['method'] == 'upi' ? str(u['name']) : '';
    holder.text = p?['method'] == 'bank' ? str(k['holder']) : '';
    ifsc.text = p?['method'] == 'bank' ? str(k['ifsc']) : '';
    bank.text = p?['method'] == 'bank' ? str(k['bankName']) : '';
    type = p?['method'] == 'bank' ? str(k['type']) : '';
    acc1.clear();
    acc2.clear();
  }

  Future<void> _save() async {
    final body = <String, dynamic>{'sid': S.sid, 'method': m};
    if (m == 'upi') {
      final id = upiId.text.trim(), nm = payee.text.trim();
      if (!vpaRe.hasMatch(id)) throw AppError('That UPI ID does not look right. It looks like name@bank, for example 9876543210@upi.');
      if (nm.length < 3) throw AppError('Enter the name the UPI ID is registered to, as members will see it while paying.');
      body['upiId'] = id;
      body['payeeName'] = nm;
    } else {
      final ho = holder.text.trim(), a1 = acc1.text.replaceAll(RegExp(r'[\s-]'), ''), a2 = acc2.text.replaceAll(RegExp(r'[\s-]'), ''), ic = ifsc.text.replaceAll(RegExp(r'\s'), '').toUpperCase();
      if (ho.length < 3) throw AppError('Enter the account holder name exactly as it is in the bank.');
      if (!RegExp(r'^[0-9]{6,20}$').hasMatch(a1)) throw AppError('Enter the bank account number: digits only.');
      if (a1 != a2) throw AppError('The two account numbers are not the same. Please type them again.');
      if (!ifscRe.hasMatch(ic)) throw AppError('Enter the 11-character IFSC of the branch, for example HDFC0001234.');
      body.addAll({'holder': ho, 'accountNumber': a1, 'accountNumber2': a2, 'ifsc': ic, 'bankName': bank.text.trim(), 'type': type});
    }
    final r = await api('/v1/orgs/payout/save', body);
    S.soc!['payout'] = r['payout'];
    D.bump('soc');
    setState(() {
      edit = false;
      m = '';
    });
    toast('✅', 'Payment details saved', 'Members can now pay their $fee from the app.');
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    final po = poOn() ? mapv(S.soc!['payout']) : null;
    if (!payOn()) return const AppCard(title: '💳 Receive payments', children: [Note('Payments are not switched on in this version of the app yet. The payment server address (PAY_API) has to be added first.', tone: Tone.y)]);
    if (po != null && !edit) {
      final up = po['method'] == 'upi', u = mapv(po['upi']), k = mapv(po['bank']);
      final rows = up
          ? [('UPI ID', str(u['id'])), ('Name', str(u['name']))]
          : [('Account holder', str(k['holder'])), ('Account number', str(k['last4']).isNotEmpty ? '•••• ${k['last4']}' : ''), ('IFSC', str(k['ifsc'])), ('Bank', str(k['bankName'])), ('Account type', actName[k['type']] ?? '')];
      return AppCard(title: '💳 Receive payments', children: [
        Row(children: [const Pill('Active', tone: Tone.g), const SizedBox(width: 6), Pill(up ? 'UPI ID' : 'Bank account', tone: Tone.b)]),
        const SizedBox(height: 8),
        for (final r in rows.where((r) => r.$2.isNotEmpty)) KvRow(r.$1, r.$2),
        Padding(padding: const EdgeInsets.symmetric(vertical: 12), child: Text('Members pay their $fee straight to this ${up ? 'UPI ID' : 'account'} from the app and enter the payment reference number (UTR). Each payment waits in Payments to confirm until you have seen it in your bank statement.', style: meta())),
        Row2(
          Btn.o('Change', small: true, onTap: () => setState(() {
                edit = true;
                m = str(po['method']);
                _fill(po);
              })),
          Btn.o('Remove', small: true, color: p.red, onTap: () async {
            if (!await confirmDlg(context, 'Remove these payment details? Members will not be able to pay in the app until you add a UPI ID or bank account again.', ok: 'Remove', danger: true)) return;
            final r = await api('/v1/orgs/payout/remove', {'sid': S.sid});
            S.soc!['payout'] = r['payout'];
            D.bump('soc');
            toast('ℹ️', 'Payment details removed');
          }),
        ),
      ]);
    }
    final mm = m.isNotEmpty ? m : (po != null ? str(po['method']) : 'upi');
    if (m.isEmpty) m = mm;
    return AppCard(title: '💳 Receive payments', children: [
      Text('Choose how members pay you. The money goes from their bank straight to yours: no payment gateway is needed and $brand never holds it.', style: meta()),
      const SizedBox(height: 12),
      Seg(const [('upi', 'UPI ID'), ('bank', 'Bank account')], mm, (v) => setState(() => m = v)),
      if (mm == 'upi') ...[
        Field(upiId, 'UPI ID (e.g. 9876543210@upi)', max: 300),
        Field(payee, 'Name on the UPI ID (as members see it while paying)', max: 60),
      ] else ...[
        Field(holder, 'Account holder name (as in the bank)', max: 120),
        Field(acc1, 'Account number', max: 24, kb: TextInputType.number),
        Field(acc2, 'Re-enter account number', max: 24, kb: TextInputType.number),
        Field(ifsc, 'IFSC (e.g. HDFC0001234)', max: 11, upper: true),
        Field(bank, 'Bank name (optional)', max: 60),
        SelectField('Account type (optional)', type, const [('', 'Account type (optional)'), ('savings', 'Savings account'), ('current', 'Current account')], (v) => setState(() => type = v)),
        if (po != null && po['method'] == 'bank') Padding(padding: const EdgeInsets.only(bottom: 10), child: Text('For safety the saved account number (•••• ${str(mapv(po['bank'])['last4'])}) is not shown. Type it again to save a change.', style: small())),
      ],
      Btn(po != null ? 'Save changes' : 'Save', small: true, onTap: _save, busyDone: false),
      if (po != null)
        TextButton(
            onPressed: () => setState(() {
                  edit = false;
                  m = '';
                }),
            child: const Text('Cancel'))
      else
        Padding(padding: const EdgeInsets.only(top: 8), child: Text('Until you save this, members cannot pay their $fee in the app.', style: small())),
    ]);
  }
}

class _GstCard extends StatefulWidget {
  const _GstCard();
  @override
  State<_GstCard> createState() => _GstCardState();
}

class _GstCardState extends State<_GstCard> {
  late final g = TextEditingController(text: S.socGst());
  @override
  Widget build(BuildContext context) => AppCard(title: '🧾 GST number', children: [
        Text('Printed on every invoice and receipt.', style: meta()),
        const SizedBox(height: 10),
        Field(g, 'Company GST number (15 characters) *', max: 15, upper: true),
        Btn('Save', small: true, onTap: () async {
          final v = g.text.trim().toUpperCase();
          if (!gstRe.hasMatch(v)) throw AppError('Enter a valid 15-character GST number');
          await updateDoc(socRef(), {'gstin': v});
          S.soc!['gstin'] = v;
          toast('✅', 'GST number saved');
        }),
      ]);
}

/* ---------- record income / expense ---------- */
class _IncExp extends StatefulWidget {
  const _IncExp();
  @override
  State<_IncExp> createState() => _IncExpState();
}

class _IncExpState extends State<_IncExp> {
  String mode = 'inc', cat = incCats.first;
  final r = TextEditingController(), a = TextEditingController();
  @override
  Widget build(BuildContext context) => AppCard(title: 'Record income / expense', children: [
        Seg(const [('inc', 'Income'), ('exp', 'Expense')], mode, (v) => setState(() {
              mode = v;
              cat = (v == 'inc' ? incCats : expCats).first;
            })),
        SelectField('Category', cat, SelectField.same(mode == 'inc' ? incCats : expCats), (v) => setState(() => cat = v)),
        Field(r, S.sk('Details (e.g. Flat 203 maintenance)'), max: 80),
        Field(a, 'Amount ₹', kb: TextInputType.number),
        Btn('Save entry', onTap: () async {
          final n = num.tryParse(a.text) ?? 0;
          if (r.text.trim().isEmpty || n <= 0) {
            toast('ℹ️', 'Enter details and amount');
            return;
          }
          await addDoc(col(mode == 'inc' ? 'contributions' : 'expenses'), {'reason': r.text.trim(), 'amount': n, 'category': cat, 'ts': now(), 'by': S.uid});
          r.clear();
          a.clear();
          toast('✅', 'Saved');
        }),
      ]);
}

/* ============================== bills ============================== */
List<Widget> billCards(BuildContext context) {
  final p = pal;
  final B = D['bills'].values.toList(), n0 = now();
  final w = <Widget>[];
  if (S.isAdm) w.add(const _GenBill());
  if (S.isAdm && S.kind == 'company') w.add(const _CustInvoice());
  final mineB = (S.isAdm ? B.where((b) => str(b['flat']).isNotEmpty && b['flat'] == S.me?['flat']).toList() : B.toList())
    ..sort((a, b) {
      final c = str(b['month']).compareTo(str(a['month']));
      return c != 0 ? c : intv(b['ts']).compareTo(intv(a['ts']));
    });
  final due = mineB.where((b) => !closedBill(b)).toList();
  if (!S.isAdm || due.isNotEmpty) {
    final tot = due.where((b) => b['status'] == 'Unpaid').fold<num>(0, (a, b) => a + numv(b['amount']));
    _remind(due);
    w.add(AppCard(title: '🧾 Maintenance dues', children: [
      Text(due.isNotEmpty ? (tot > 0 ? 'Outstanding: ${rs(tot)}' : 'Waiting for admin to confirm your payment') : "No dues — you're all paid up ✅", style: meta()),
      const SizedBox(height: 8),
      for (final b in due)
        Builder(builder: (_) {
          final pend = b['status'] == 'Pending';
          final rej = !pend && intv(b['rejectedAt']) > 0 && intv(b['rejectedAt']) >= intv(b['reportedAt']);
          final ov = !pend && intv(b['due']) < n0;
          return Item(bar: pend ? p.a : ov ? p.red : p.amber, children: [
            ItemHead('${billTitle(b)} · ${rs(b['amount'])}', badge: Pill(pend ? 'Awaiting confirmation' : ov ? 'Overdue' : 'Due ${dt(b['due'])}', tone: pend ? Tone.a : ov ? Tone.r : Tone.y)),
            if (str(b['title']).isNotEmpty && str(b['month']).isNotEmpty) Meta(mname(str(b['month']))),
            if (pend) Meta('${[str(b['utr']).isNotEmpty ? 'Ref ${b['utr']}' : '', intv(b['reportedAt']) > 0 ? 'reported ${dtm(b['reportedAt'])}' : ''].where((x) => x.isNotEmpty).join(' · ')}${str(b['utr']).isNotEmpty || intv(b['reportedAt']) > 0 ? '. ' : ''}Your admin confirms it after checking the bank statement.'),
            if (rej) Note('⚠️ Your last payment could not be confirmed${str(b['rejectNote']).isNotEmpty ? ': ${b['rejectNote']}' : ''}. Check the reference number and report it again, or contact your admin.', tone: Tone.y),
            if (intv(b['remindedAt']) > 0 && !pend) Note('⏰ Reminder from admin · ${dt(b['remindedAt'])}', tone: Tone.y),
            ActRow([
              if (isR(b['docUrl']) || str(b['docUrl']).startsWith('https://firebasestorage.googleapis.com/')) mini('📎 View bill', () => openRef(context, str(b['docUrl']), name: str(b['docName']).isEmpty ? 'bill.pdf' : str(b['docName']))),
              mini('📄 Invoice', () => shareInvoice(b)),
              if (!pend) mini(rej ? 'Pay / report again' : 'Pay now', () => payBill(context, b), BtnKind.primary),
            ]),
          ]);
        }),
    ]));
  }
  if (S.isAdm) {
    final pd = B.where((b) => b['status'] == 'Pending').toList()..sort((a, b) => intv(a['reportedAt']).compareTo(intv(b['reportedAt'])));
    final pu = billUnits();
    if (pd.isNotEmpty) {
      w.add(AppCard(title: '⏳ Payments to confirm (${pd.length})', children: [
        Text('Members say they have paid these. Find the reference number in your bank statement or UPI app, then confirm. Reject it if the money has not arrived.', style: meta()),
        const SizedBox(height: 10),
        for (final b in pd)
          Builder(builder: (_) {
            final who = S.isOrg ? uLabel(str(b['flat']), pu[b['flat']]) : str(b['flat']);
            return Item(bar: p.a, children: [
              Text('$who · ${billTitle(b)} · ${rs(b['amount'])}', style: h3()),
              Meta(['by ${str(b['paidBy']).isEmpty ? 'resident' : str(b['paidBy'])}', [payMeth(b['payMethod']), str(b['paidTo']).isNotEmpty ? 'to ${b['paidTo']}' : ''].where((x) => x.isNotEmpty).join(' '), intv(b['reportedAt']) > 0 ? dtm(b['reportedAt']) : ''].where((x) => x.isNotEmpty).join(' · ')),
              if (str(b['utr']).isNotEmpty) Align(alignment: Alignment.centerLeft, child: TextButton(onPressed: () => copy(str(b['utr'])), child: Text('Ref ${b['utr']}  ⧉', style: TextStyle(color: p.a, fontWeight: FontWeight.w700)))),
              Row2(
                Btn.g('Confirm', small: true, onTap: () async {
                  final r = await api('/v1/payments/direct/confirm', {'sid': S.sid, 'chargeId': b['id']});
                  toast('✅', 'Payment confirmed', '$who · ${rs(b['amount'])}${str(r['receiptNo']).isNotEmpty ? ' · receipt ${r['receiptNo']}' : ''}');
                }),
                Btn.r('Reject', small: true, onTap: () async {
                  final why = await promptDlg(context, 'Reject this payment? The bill becomes unpaid again and the member is told.\n\nReason (the member sees it):', initial: 'Payment not found in the bank statement', ok: 'Reject', max: 160);
                  if (why == null) return;
                  await api('/v1/payments/direct/reject', {'sid': S.sid, 'chargeId': b['id'], 'reason': cut(why.trim(), 160)});
                  toast('ℹ️', 'Payment rejected', '$who · the bill is unpaid again');
                }),
              ),
            ]);
          }),
      ]));
    }
  }
  if (!S.canFin) w.add(PayHistCard(mineB));
  if (S.canFin) w.add(const AdminPayCards());
  if (S.isAdm) {
    final rf = B.where((b) => b['status'] == 'Refunded').toList();
    if (rf.isNotEmpty) {
      w.add(AppCard(title: '↩️ Refunded bills (${rf.length})', children: [
        Text('The payment for these bills was refunded. Reopen a bill if it still has to be paid.', style: meta()),
        for (final b in rf)
          Ex(str(b['flat']), sub: '${billTitle(b)} · ${rs(b['amount'])}', right: mini('Reopen', () async {
            if (!await confirmDlg(context, 'Reopen this bill so it can be paid again?', ok: 'Reopen')) return;
            await updateDoc(dref('bills', str(b['id'])), {'status': 'Unpaid', 'paymentId': '', 'utr': '', 'receiptNo': '', 'payMethod': '', 'paidAt': 0, 'reopenedAt': now()});
          })),
      ]));
    }
    final od = B.where((b) => b['status'] == 'Unpaid' && intv(b['due']) < n0).toList();
    final by = <String, List<Doc>>{};
    for (final b in od) {
      (by[str(b['flat'])] ??= []).add(b);
    }
    final fs0 = by.keys.toList()..sort(natCmp);
    final out = B.where((b) => !closedBill(b)).fold<num>(0, (a, b) => a + numv(b['amount']));
    final got = B.where((b) => b['status'] == 'Paid').fold<num>(0, (a, b) => a + numv(b['amount']));
    final bu = billUnits();
    w.add(AppCard(title: '🚨 Defaulters (${fs0.length})', children: [
      Text('Total outstanding ${rs(out)} · collected ${rs(got)}', style: meta()),
      if (fs0.isEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text('No overdue dues 🎉', style: meta())),
      for (final f in fs0)
        Builder(builder: (_) {
          final L = by[f]!;
          final tot = L.fold<num>(0, (a, b) => a + numv(b['amount']));
          final rm = L.map((x) => intv(x['remindedAt'])).fold<int>(0, (a, b) => a > b ? a : b);
          return Ex(S.isOrg ? uLabel(f, bu[f]) : f, sub: '${rs(tot)} · ${L.length} overdue: ${L.map(billTitle).join(', ')}${rm > 0 ? ' · reminded ${dt(rm)}' : ''}', right: mini('Remind', () async {
            final mm = D['mem'].values.where((x) => x['flat'] == f && str(x['mobile']).isNotEmpty).firstOrNull;
            final msg = 'Hello, dues of ${rs(tot)} for $f (${str(S.soc?['name'])}) are overdue: ${L.map(billTitle).join(', ')}. Please pay in the $brand app at the earliest.';
            if (mm != null) launchUrl(Uri.parse('https://wa.me/${wa91(str(mm['mobile']))}?text=${Uri.encodeComponent(msg)}'), mode: LaunchMode.externalApplication).catchError((_) => false);
            final bt = Batch();
            for (final x in L) {
              bt.update(dref('bills', str(x['id'])), {'remindedAt': now()});
            }
            await bt.commit();
            toast('⏰', 'Reminder sent', 'In-app alert${mm != null ? ' + WhatsApp' : ''}');
          }));
        }),
      if (B.isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(top: 10),
          child: Btn.o('⬇️ Export all bills (CSV)', small: true, onTap: () {
            final s = [...B]..sort((a, b) => str(b['month']).compareTo(str(a['month'])));
            return exportCSV('bills', const ['Month', 'Bill', 'Flat', 'Amount', 'Due', 'Status', 'Paid on', 'Receipt', 'Paid via', 'Reference'], [
              for (final b in s) [b['month'], billTitle(b), b['flat'], b['amount'], bdate(b['due']), b['status'] == 'Unpaid' && intv(b['due']) < n0 ? 'Overdue' : b['status'], intv(b['paidAt']) > 0 ? bdate(b['paidAt']) : '', str(b['receiptNo']), b['gateway'] == 'razorpay' ? 'Online ${payMeth(b['payMethod'])}' : payMeth(b['payMethod']), str(b['utr'])]
            ]);
          }),
        ),
    ]));
  }
  return w;
}

/// a reminder on this phone when a bill is due within 7 days (once a day)
void _remind(List<Doc> due) {
  final n0 = now();
  for (final b in due) {
    if (b['status'] != 'Unpaid') continue;
    final dl = ((intv(b['due']) - n0) / dayMs).ceil();
    if (dl > 7) continue;
    final k = 'sh-rem-${b['id']}-${td()}';
    if (Prefs.has(k)) continue;
    Prefs.set(k, '1');
    Future.microtask(() => toast(
        '⏰',
        dl < 0
            ? 'Maintenance bill overdue'
            : dl == 0
                ? 'Maintenance due today'
                : 'Maintenance due in $dl day${dl == 1 ? '' : 's'}',
        '${billTitle(b)} · ${rs(b['amount'])}',
        false,
        'bill'));
  }
}

/* ---------- generate a bill (admins) ---------- */
class _GenBill extends StatefulWidget {
  const _GenBill();
  @override
  State<_GenBill> createState() => _GenBillState();
}

class _GenBillState extends State<_GenBill> {
  String fl = '', grp = '', type = 'maintenance';
  String mon = mKey(DateTime.now());
  late String due = ymd(DateTime.now().add(const Duration(days: 10)));
  final ti = TextEditingController();
  late final ai = TextEditingController(text: numv(mapv(S.soc?['settings'])['monthlyAmount']) > 0 ? '${mapv(S.soc?['settings'])['monthlyAmount']}' : '');
  PFile? doc;

  @override
  Widget build(BuildContext context) {
    final U = billUnits(), F = U.keys.toList(), K = S.K, org = S.isOrg;
    final G = F.map(uGrp).toSet().toList()..sort(natCmp);
    final L = F.where((f) => !org || (grp.isNotEmpty && uGrp(f) == grp)).toList()..sort((a, b) => org ? natCmp(uLabel(a, U[a]), uLabel(b, U[b])) : natCmp(a, b));
    if (fl.isNotEmpty && !L.contains(fl)) fl = '';
    final gname = (K.grp?.t ?? 'groups').toLowerCase(), who = '${K.person.toLowerCase()}s';
    return AppCard(title: '🧾 Generate a bill', children: [
      Text(S.sk('The bill is sent to the resident(s) of the flat you choose. They pay it from the app, straight to your UPI ID or bank account.'), style: meta()),
      const SizedBox(height: 10),
      if (org) SelectField('Choose ${K.grp?.one ?? 'group'}', grp, [('', 'All $gname'), ...SelectField.same(G)], (v) => setState(() => grp = v)),
      SelectField(org ? 'Choose ${K.person.toLowerCase()}' : 'Choose flat', fl, [('', !org ? 'All occupied flats' : grp.isNotEmpty ? 'All $who of $grp' : 'All $who'), for (final f in L) (f, uLabel(f, U[f]))], (v) => setState(() => fl = v)),
      SelectField('Type of bill', type, [for (final b in btypes) (b[0], b[1])], (v) => setState(() => type = v)),
      if (type != 'maintenance') Field(ti, 'Name of this charge (e.g. Diwali event fee)', max: 60),
      Row2(MonthField('Month', mon, (v) => setState(() => mon = v)), Field(ai, 'Amount ₹', kb: TextInputType.number)),
      DateField('Due date', due, (v) => setState(() => due = v)),
      Row(children: [
        mini(doc == null ? '📎 Upload maintenance bill (photo or PDF)' : '✓ ${cut(doc!.name, 26)}', () async {
          final f = await pickPhotoSheet(context, pdf: true, title: 'Bill document');
          if (f != null) setState(() => doc = f);
        }),
      ]),
      const SizedBox(height: 12),
      Btn('Generate bill & send', onTap: () async {
        final a = ((num.tryParse(ai.text) ?? 0) * 100).round() / 100;
        final title = type == 'maintenance' ? '' : ti.text.trim();
        if (mon.isEmpty || a < 1 || due.isEmpty) {
          toast('ℹ️', 'Enter amount, month and due date', 'The amount must be at least ₹1.');
          return;
        }
        if (type != 'maintenance' && title.isEmpty) {
          toast('ℹ️', 'Enter a name for this charge');
          return;
        }
        final T = fl.isNotEmpty ? [fl] : F.where((f) => grp.isEmpty || uGrp(f) == grp).toList();
        if (T.isEmpty) {
          toast('ℹ️', S.sk('No flat selected'));
          return;
        }
        final tag = type == 'maintenance' ? '' : '_${now().toRadixString(36)}';
        String bid(String f) => bref(mon, f) + tag;
        final todo = T.where((f) => D['bills'][bid(f)] == null).toList();
        if (todo.isEmpty) {
          toast('ℹ️', 'Bill already exists', S.sk('That flat already has a bill for ${mname(mon)}'));
          return;
        }
        var docUrl = '', docName = '';
        if (doc != null) {
          docUrl = await up(doc!.bytes, 'billdocs', doc!.name);
          docName = doc!.name;
        }
        final dueMs = DateTime.parse('${due}T23:59:59').millisecondsSinceEpoch;
        for (var i = 0; i < todo.length; i += 400) {
          final bt = Batch();
          for (final f in todo.sublist(i, i + 400 > todo.length ? todo.length : i + 400)) {
            bt.set(dref('bills', bid(f)), {'flat': f, 'month': mon, 'type': type, 'amount': a, 'due': dueMs, 'status': 'Unpaid', 'ts': now(), 'docUrl': docUrl, 'docName': docName, if (title.isNotEmpty) 'title': title});
          }
          await bt.commit();
        }
        setState(() {
          doc = null;
          ti.clear();
        });
        fxDone('Bill sent to ${todo.length == 1 ? todo.first : '${todo.length} ${S.sk('flats')}'}', title.isNotEmpty ? title : mname(mon));
      }, busyDone: false),
    ]);
  }
}

/* ---------- raise an invoice (companies) ---------- */
class _CustInvoice extends StatefulWidget {
  const _CustInvoice();
  @override
  State<_CustInvoice> createState() => _CustInvoiceState();
}

class _CustInvoiceState extends State<_CustInvoice> {
  final cn = TextEditingController(), cg = TextEditingController(), cd = TextEditingController(), ca = TextEditingController();
  String rate = '18';
  @override
  Widget build(BuildContext context) => AppCard(title: '🧾 Raise an invoice', children: [
        Text('For a customer or employee. Your company GST number is printed on the invoice.', style: meta()),
        const SizedBox(height: 10),
        Field(cn, 'Customer / employee name', max: 60),
        Field(cg, 'Customer GST number (optional)', max: 15, upper: true),
        Field(cd, 'Description (e.g. Consulting – October)', max: 80),
        Field(ca, 'Amount ₹ (before GST)', kb: TextInputType.number),
        SelectField('GST', rate, [for (final v in const [0, 5, 12, 18, 28]) ('$v', 'GST $v%')], (v) => setState(() => rate = v)),
        Btn('⬇️ Create & download invoice', onTap: () async {
          final gs = S.socGst(), nm = cn.text.trim(), cgv = cg.text.trim().toUpperCase(), amt = num.tryParse(ca.text) ?? 0, rt = int.parse(rate);
          if (gs.isEmpty) throw AppError('Add your company GST number first (Payment details).');
          if (nm.isEmpty || cd.text.trim().isEmpty || amt <= 0) throw AppError('Enter name, description and amount.');
          if (cgv.isNotEmpty && !gstRe.hasMatch(cgv)) throw AppError('Customer GST number is not valid.');
          final tax = (amt * rt).round() / 100;
          final no = 'INV-${td().replaceAll('-', '')}-${rid().substring(rid().length - 4).toUpperCase()}';
          final d = await receiptPdf({'amount': amt + tax}, InvOpt(no: no, paid: false, rows: [
            ['Invoice no.', no],
            ['Invoice date', bdate(now())],
            ['Billed to', nm],
            ['Customer GSTIN', cgv.isEmpty ? '—' : cgv],
            ['Description', cd.text.trim()],
            ['Taxable amount', rs(amt)],
            ['GST @ $rt%', rs(tax)],
            ['Total payable', rs(amt + tax)],
          ]));
          await saveBytes(d.name, d.bytes, 'application/pdf');
        }),
      ]);
}

/// "Receipt" sheet from anywhere (used by the plan invoices card too)
void openReceipt(BuildContext context, Doc b) => receipt(context, b);
void openSheetOf(BuildContext c, Widget w) => sheet(c, (_) => w);
