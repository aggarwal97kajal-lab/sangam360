import 'package:flutter/material.dart';

import '../../core/csv.dart';
import '../../core/fs.dart';
import '../../core/kinds.dart';
import '../../core/listen.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/util.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/theme.dart';
import 'pay.dart';
import '../../l10n/l10n.dart';

/* ===== Payment History (members) and Transaction History (finance roles), with a date range ===== */

class HDates {
  static String from = '', to = '';
  static bool get on => from.isNotEmpty || to.isNotEmpty;
  static int? dayMs(String s, [bool end = false]) {
    final d = parseYmd(s);
    if (d == null) return null;
    return (end ? DateTime(d.year, d.month, d.day, 23, 59, 59, 999) : d).millisecondsSinceEpoch;
  }

  static bool inR(int t) {
    final a = dayMs(from), b = dayMs(to, true);
    return (a == null || t >= a) && (b == null || t <= b);
  }

  static String label() {
    String f(String x) => bdate(dayMs(x));
    return from.isNotEmpty && to.isNotEmpty ? (from == to ? f(from) : '${f(from)} – ${f(to)}') : from.isNotEmpty ? trf('From {0}', [f(from)]) : trf('Up to {0}', [f(to)]);
  }
}

class _HDatesBox extends StatelessWidget {
  final VoidCallback changed;
  const _HDatesBox(this.changed);
  @override
  Widget build(BuildContext context) {
    final t0 = td(), d = DateTime.now();
    final m0 = ymd(DateTime(d.year, d.month, 1)), p0 = ymd(DateTime(d.year, d.month - 1, 1)), p1 = ymd(DateTime(d.year, d.month, 0));
    void set(String a, String b) {
      HDates.from = a;
      HDates.to = b;
      changed();
    }

    final q = [('|', tr('All dates'), '', ''), ('$t0|$t0', 'Today', t0, t0), ('$m0|$t0', tr('This month'), m0, t0), ('$p0|$p1', tr('Last month'), p0, p1)];
    return Column(children: [
      Row2(
        DateField(tr('From'), HDates.from, (v) => set(v, HDates.to.isNotEmpty && HDates.to.compareTo(v) < 0 ? v : HDates.to), max: HDates.to.isNotEmpty ? HDates.to : t0),
        DateField(tr('To'), HDates.to, (v) => set(HDates.from.isNotEmpty && v.compareTo(HDates.from) < 0 ? v : HDates.from, v), max: t0, min: HDates.from.isEmpty ? null : HDates.from),
      ),
      Chips([for (final x in q) (x.$1, x.$2)], '${HDates.from}|${HDates.to}', (k) {
        final x = q.firstWhere((e) => e.$1 == k);
        set(x.$3, x.$4);
      }),
    ]);
  }
}

/* ---------- members: their own bill payments ---------- */
class PayHistCard extends StatefulWidget {
  final List<Doc> mineB;
  const PayHistCard(this.mineB, {super.key});
  @override
  State<PayHistCard> createState() => _PayHistCardState();
}

class _PayHistCardState extends State<PayHistCard> {
  static String phF = 'all';
  @override
  Widget build(BuildContext context) {
    final p = pal;
    final mineP = D['pay'].values.where((x) => x['userId'] == S.uid && (str(x['flat']).isEmpty || str(S.me?['flat']).isEmpty || x['flat'] == S.me?['flat'])).toList();
    final own = widget.mineB
        .where((b) => (b['status'] == 'Paid' && str(b['paymentId']).isEmpty) || b['status'] == 'Pending')
        .map((b) => <String, dynamic>{
              'bill': b,
              'status': b['status'] == 'Paid' ? 'SUCCESS' : 'PENDING',
              'description': billTitle(b),
              'amount': b['amount'],
              'paidAt': b['paidAt'],
              'createdAt': intv(b['reportedAt']) > 0 ? b['reportedAt'] : b['ts'],
              'receiptNumber': b['receiptNo'],
              'paymentMethod': b['payMethod'],
              'utr': b['utr'],
            })
        .toList();
    final all = [...mineP, ...own]..sort((a, b) => pWhen(b).compareTo(pWhen(a)));
    final F = [('all', 'All'), ('ok', 'Paid'), ('pend', tr('Awaiting confirmation')), if (mineP.isNotEmpty) ...[('fail', 'Failed'), ('ref', 'Refunded')]];
    if (!F.any((x) => x.$1 == phF)) phF = 'all';
    final R = all.where((x) => HDates.inR(pWhen(x))).toList();
    final L = R.where((x) => pIn(x, phF)).toList();
    final cnt = {for (final f in F) f.$1: R.where((x) => pIn(x, f.$1)).length};
    return AppCard(title: '📜 Payment History', children: [
      if (all.isEmpty)
        const Empty('No payments yet')
      else ...[
        _HDatesBox(() => setState(() {})),
        Chips([for (final f in F) (f.$1, f.$2 + (f.$1 != 'all' && (cnt[f.$1] ?? 0) > 0 ? ' · ${cnt[f.$1]}' : ''))], phF, (k) => setState(() => phF = k)),
        if (HDates.on) Text(trf('{0} · {1} payment{2}{3}', [HDates.label(), L.length, (L.length == 1 ? '' : 's'), (L.where((x) => pState(x) == 'SUCCESS').isNotEmpty ? trf(' · paid {0}', [rs(L.where((x) => pState(x) == 'SUCCESS').fold<num>(0, (a, x) => a + numv(x['amount'])))]) : '')]), style: meta()),
        if (L.isEmpty) Padding(padding: const EdgeInsets.all(8), child: Text(HDates.on ? tr('No payments on these dates.') : tr('Nothing here yet.'), style: meta())),
        for (final x in L.take(60))
          Builder(builder: (_) {
            final s = pState(x), wait = x['bill'] != null && s == 'PENDING';
            return Container(
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(border: Border(bottom: BorderSide(color: p.line))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(str(x['description']).isEmpty ? tr('Payment') : str(x['description']), style: h3()),
                      Text([s == 'SUCCESS' || s == 'REFUNDED' ? trf('Paid {0}', [dtm(pWhen(x))]) : wait ? trf('Reported {0}', [dtm(pWhen(x))]) : dtm(pWhen(x)), payMeth(x['paymentMethod'])].where((e) => e.isNotEmpty).join(' · '), style: meta()),
                      if (x['bill'] != null && str(x['utr']).isNotEmpty) Text(trf('Ref {0}', [x['utr']]), style: meta()),
                    ]),
                  ),
                  Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(rs(x['amount']), style: h3()), const SizedBox(height: 4), wait ?  Pill(tr('Awaiting confirmation'), tone: Tone.y) : pPill(x)]),
                ]),
                if (intv(x['refundedAmountPaise']) > 0 && s != 'REFUNDED') Meta(trf('{0} of this was refunded', [rs(intv(x['refundedAmountPaise']) / 100)])),
                if (x['duplicate'] == true && s == 'SUCCESS')  Meta(tr('Received twice for the same bill. Please ask your admin for a refund.')),
                if (s == 'FAILED' && str(mapv(x['failure'])['reason']).isNotEmpty) Meta(str(mapv(x['failure'])['reason'])),
                if (wait)  Meta(tr('Your admin confirms it after checking the bank statement.')),
                if (s == 'SUCCESS') ActRow([mini(tr('View Receipt'), () => receipt(context, x['bill'] != null ? mapv(x['bill']) : payAsBill(x)))]),
              ]),
            );
          }),
      ],
    ]);
  }
}

/* ---------- finance roles: collections and every transaction ---------- */
class _HX {
  String k = '';
  bool busy = false, ok = false, err = false, cap = false;
  List<Doc> pay = [], inc = [], exp = [];
}

class AdminPayCards extends StatefulWidget {
  const AdminPayCards({super.key});
  @override
  State<AdminPayCards> createState() => _AdminPayCardsState();
}

class _AdminPayCardsState extends State<AdminPayCards> {
  static String txF = 'all';
  int txMax = 40;
  static final _HX hx = _HX();
  static const hLim = 1000;

  String get hKey => '${S.sid}|${HDates.from}|${HDates.to}';

  void _fetch() {
    final k = hKey;
    if (hx.k == k) return;
    hx
      ..k = k
      ..busy = true
      ..ok = false
      ..err = false
      ..cap = false
      ..pay = []
      ..inc = []
      ..exp = [];
    final a = HDates.dayMs(HDates.from) ?? 0, b = HDates.dayMs(HDates.to, true) ?? now() + dayMs;
    Future<List<Doc>> g(String n, String f, int lo) async {
      final q = await col(n).where(f, isGreaterThanOrEqualTo: lo).where(f, isLessThanOrEqualTo: b).orderBy(f, descending: true).limit(hLim).get();
      if (q.docs.length >= hLim) hx.cap = true;
      return docsOf(q);
    }

    Future.wait([g('payments', 'createdAt', (a - 2 * dayMs).clamp(0, 1 << 50)), g('contributions', 'ts', a), g('expenses', 'ts', a)]).then((r) {
      hx.pay = r[0];
      hx.inc = r[1];
      hx.exp = r[2];
      hx.ok = true;
    }).catchError((_) {
      hx.err = true;
    }).whenComplete(() {
      hx.busy = false;
      if (mounted && hx.k == k) setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = pal, n0 = now();
    final kids = <Widget>[];
    if (S.isAdm) {
      final B = D['bills'].values.toList();
      int n(bool Function(Doc) f) => B.where(f).length;
      final paid = B.where((b) => b['status'] == 'Paid').toList();
      final k = [
        ('Total Collected', rs(paid.fold<num>(0, (a, b) => a + numv(b['amount']))), p.a),
        ('Paid', '${paid.length}', p.green),
        ('To confirm', '${n((b) => b['status'] == 'Pending')}', p.amber),
        ('Unpaid', '${n((b) => b['status'] == 'Unpaid' && intv(b['due']) >= n0)}', p.blue),
        ('Overdue', '${n((b) => b['status'] == 'Unpaid' && intv(b['due']) < n0)}', p.red),
      ];
      kids.add(AppCard(title: '💳 Collections', children: [
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final x in k)
            Container(
              width: (MediaQuery.of(context).size.width - 32 - 32 - 16) / 3,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: x.$3.withOpacity(.09), borderRadius: BorderRadius.circular(14)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(x.$1, style: small()), const SizedBox(height: 2), FittedBox(child: Text(x.$2, style: h3(x.$3).copyWith(fontSize: 17)))]),
            ),
        ]),
        if (!poOn())
          Note(S.isOwner ? tr('Add your UPI ID or bank account in Receive payments (above) so members can pay their bills from the app.') : tr('The main admin has not added a UPI ID or bank account yet, so members cannot pay from the app.'), tone: Tone.y)
        else if (B.isEmpty)
           Meta(tr('No bills yet. Generate a bill and members pay it from the app.')),
      ]));
    }
    final rg = HDates.on;
    if (rg) _fetch();
    final X = rg && hx.k == hKey ? hx : null;
    List<Doc> both(List<Doc>? a, List<Doc> b) {
      final o = <String, Doc>{};
      for (final v in [...?a, ...b]) {
        o[str(v['id'] ?? v['paymentId'])] = v;
      }
      return o.values.toList();
    }

    bool hand(Doc v) => v['online'] != true && str(v['paymentId']).isEmpty;
    final p0 = D['pay'].values.toList()..sort((a, b) => pWhen(b).compareTo(pWhen(a)));
    final i0 = D['inc'].values.where(hand).toList(), e0 = D['exp'].values.toList();
    final pa = both(X?.pay, p0);
    final all = <(Doc?, Doc?, bool, int)>[
      for (final x in pa) (x, null, false, pWhen(x)),
      for (final l in both(X?.inc, i0).where(hand)) (null, l, true, intv(l['ts'])),
      for (final l in both(X?.exp, e0)) (null, l, false, intv(l['ts'])),
    ].where((r) => HDates.inR(r.$4)).toList()
      ..sort((a, b) => b.$4.compareTo(a.$4));
    final tf = [('all', 'All'), ('bill', tr('Bill payments')), ('man', tr('Entered by hand')), if (pa.isNotEmpty) ...[('pend', 'Pending'), ('fail', 'Failed'), ('ref', 'Refunded')]];
    if (!tf.any((x) => x.$1 == txF)) txF = 'all';
    bool rIn((Doc?, Doc?, bool, int) r, String f) => f == 'all' || (r.$1 != null ? (f == 'bill' ? pState(r.$1!) == 'SUCCESS' : pIn(r.$1!, f)) : f == (r.$2!['direct'] == true ? 'bill' : 'man'));
    final cnt = {for (final x in tf) x.$1: all.where((r) => rIn(r, x.$1)).length};
    final L = all.where((r) => rIn(r, txF)).toList();
    final got = L.fold<num>(0, (a, r) => a + (r.$1 != null ? (pState(r.$1!) == 'SUCCESS' ? numv(r.$1!['amount']) - intv(r.$1!['refundedAmountPaise']) / 100 : 0) : (r.$3 ? numv(r.$2!['amount']) : 0)));
    final out = L.fold<num>(0, (a, r) => a + (r.$2 != null && !r.$3 ? numv(r.$2!['amount']) : 0));
    String how(Doc v) => v['direct'] == true ? [payMeth(v['method']).isNotEmpty ? payMeth(v['method']) : 'Paid directly', str(v['utr']).isNotEmpty ? 'Ref ${v['utr']}' : ''].where((x) => x.isNotEmpty).join(' · ') : tr('Entered by hand');
    final t = <Widget>[];
    if (!rg && p0.isEmpty && i0.isEmpty && e0.isEmpty) {
      t.add(const Empty('No transactions yet'));
    } else {
      t.add(_HDatesBox(() => setState(() => txMax = 40)));
      t.add(Chips([for (final x in tf) (x.$1, x.$2 + (x.$1 != 'all' && (cnt[x.$1] ?? 0) > 0 ? ' · ${cnt[x.$1]}' : ''))], txF, (k) => setState(() {
            txF = k;
            txMax = 40;
          })));
      t.add(Text(trf('{0}{1}{2} · received {3}{4}', [(rg ? '${HDates.label()} · ' : ''), L.length, (L.length == 1 ? ' entry' : ' entries'), rs(got), (out > 0 ? trf(' · spent {0}', [rs(out)]) : '')]), style: meta()));
      if (X != null && X.busy) {
        t.add( Meta(tr('Loading these dates…')));
      } else if (X != null && X.err) {
        t.add( Note(tr('Older entries could not be loaded just now. Showing what is already on this phone.'), tone: Tone.y));
      } else if (X != null && X.cap) {
        t.add( Note(trf('These dates hold more than {0} entries, so the oldest are left out. Choose fewer days to see them all.', [hLim]), tone: Tone.y));
      }
      if (L.isEmpty && !(X != null && X.busy)) t.add(Meta(rg ? tr('No transactions on these dates.') : tr('No transactions in this view.')));
      for (final q in L.take(txMax)) {
        if (q.$2 != null) {
          final v = q.$2!, k = q.$3;
          final bl = v['direct'] == true && str(v['billId']).isNotEmpty ? D['bills'][v['billId']] : null;
          t.add(Container(
            padding: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(border: Border(bottom: BorderSide(color: p.line))),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(str(v['reason']).isNotEmpty ? str(v['reason']) : (k ? tr('Income') : tr('Expense')), style: h3()),
                    if ([str(v['category']), str(v['flat'])].any((x) => x.isNotEmpty)) Text([str(v['category']), str(v['flat'])].where((x) => x.isNotEmpty).join(' · '), style: meta()),
                    Text('${how(v)} · ${dtm(q.$4)}', style: meta()),
                  ]),
                ),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text('${k ? '+ ' : '− '}${rs(v['amount'])}', style: h3(k ? p.green : p.red)),
                  const SizedBox(height: 4),
                  Pill(v['direct'] == true ? tr('Bill paid') : k ? tr('Income') : tr('Expense'), tone: k ? Tone.g : Tone.m),
                ]),
              ]),
              if (bl != null && bl['status'] == 'Paid') ActRow([mini(tr('View Receipt'), () => receipt(context, bl))]),
            ]),
          ));
          continue;
        }
        final x = q.$1!, s = pState(x);
        t.add(Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(border: Border(bottom: BorderSide(color: p.line))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text([str(x['payerName']).isEmpty ? tr('Member') : str(x['payerName']), str(x['flat'])].where((e) => e.isNotEmpty).join(' · '), style: h3()),
                  Text([str(x['description']), str(x['invoiceId'])].where((e) => e.isNotEmpty).join(' · '), style: meta()),
                  Text([payMeth(x['paymentMethod']), dtm(pWhen(x))].where((e) => e.isNotEmpty).join(' · '), style: meta()),
                ]),
              ),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(rs(x['amount']), style: h3()), const SizedBox(height: 4), pPill(x)]),
            ]),
            if (str(x['razorpayPaymentId']).isNotEmpty) Align(alignment: Alignment.centerLeft, child: TextButton(onPressed: () => copy(str(x['razorpayPaymentId'])), child: Text(trf('Txn {0}  ⧉', [x['razorpayPaymentId']]), style: small(p.a)))),
            if (x['duplicate'] == true && s == 'SUCCESS')  Note(tr('⚠️ Paid twice for the same bill. Please send this amount back to the member.'), tone: Tone.y),
            if (intv(x['refundedAmountPaise']) > 0 && s != 'REFUNDED') Meta(trf('{0} refunded', [rs(intv(x['refundedAmountPaise']) / 100)])),
            if (s == 'FAILED' && str(mapv(x['failure'])['reason']).isNotEmpty) Meta(str(mapv(x['failure'])['reason'])),
            if (s == 'SUCCESS') ActRow([mini(tr('View Receipt'), () => receipt(context, payAsBill(x)))]),
          ]),
        ));
      }
      if (L.length > txMax) t.add(Padding(padding: const EdgeInsets.only(top: 10), child: Btn.o(trf('Show more ({0})', [L.length - txMax]), small: true, onTap: () => setState(() => txMax += 40))));
      if (L.isNotEmpty) {
        t.add(Padding(
          padding: const EdgeInsets.only(top: 10),
          child: Btn.o(tr('⬇️ Export transactions (CSV)'), small: true, onTap: () => exportCSV('transactions${rg ? '-${HDates.from.isEmpty ? 'start' : HDates.from}-to-${HDates.to.isEmpty ? td() : HDates.to}' : ''}', const ['User', 'Unit', 'Invoice', 'Description', 'Amount', 'Method', 'Status', 'Date', 'Reference / transaction ID', 'Receipt', 'Refunded'], [
                for (final q in L)
                  q.$2 != null
                      ? ['', str(q.$2!['flat']), '', str(q.$2!['reason']), q.$3 ? q.$2!['amount'] : -numv(q.$2!['amount']), q.$2!['direct'] == true ? (payMeth(q.$2!['method']).isNotEmpty ? payMeth(q.$2!['method']) : 'Paid directly') : 'Entered by hand', q.$2!['direct'] == true ? 'Bill paid' : q.$3 ? 'Income' : 'Expense', dtm(q.$4), str(q.$2!['utr']), '', '']
                      : [str(q.$1!['payerName']), str(q.$1!['flat']), str(q.$1!['invoiceId']), str(q.$1!['description']), q.$1!['amount'], payMeth(q.$1!['paymentMethod']), (pst[pState(q.$1!)] ?? [str(q.$1!['status'])])[0], dtm(pWhen(q.$1!)), str(q.$1!['razorpayPaymentId']), str(q.$1!['receiptNumber']), intv(q.$1!['refundedAmountPaise']) > 0 ? intv(q.$1!['refundedAmountPaise']) / 100 : '']
              ], raw: rg)),
        ));
      }
    }
    kids.add(AppCard(title: '🧾 Transaction History', children: t));
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: kids);
  }
}
