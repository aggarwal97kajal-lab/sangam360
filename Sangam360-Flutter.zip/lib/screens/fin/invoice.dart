import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:archive/archive.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../../core/api.dart';
import '../../core/files.dart';
import '../../core/fs.dart';
import '../../core/kinds.dart';
import '../../core/pdfs.dart';
import '../../core/prefs.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/media.dart';
import '../../ui/pick.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import '../../l10n/l10n.dart';

/* =====================================================================================================
   TAX INVOICE (companies): a full page to make a GST invoice, on the company's own letterhead.
   - the seller's details, bank details, terms and the letterhead are kept in societies/{sid}.invoiceProfile
   - "Get taxpayer details" fills the customer from the GSTIN (server: /v1/gst/lookup; without it, state and PAN)
   - same state -> CGST + SGST, other state -> IGST
   ===================================================================================================== */

const gstStates = {
  '01': 'Jammu and Kashmir', '02': 'Himachal Pradesh', '03': 'Punjab', '04': 'Chandigarh', '05': 'Uttarakhand', '06': 'Haryana', '07': 'Delhi', '08': 'Rajasthan',
  '09': 'Uttar Pradesh', '10': 'Bihar', '11': 'Sikkim', '12': 'Arunachal Pradesh', '13': 'Nagaland', '14': 'Manipur', '15': 'Mizoram', '16': 'Tripura', '17': 'Meghalaya',
  '18': 'Assam', '19': 'West Bengal', '20': 'Jharkhand', '21': 'Odisha', '22': 'Chhattisgarh', '23': 'Madhya Pradesh', '24': 'Gujarat', '26': 'Dadra and Nagar Haveli and Daman and Diu',
  '27': 'Maharashtra', '29': 'Karnataka', '30': 'Goa', '31': 'Lakshadweep', '32': 'Kerala', '33': 'Tamil Nadu', '34': 'Puducherry', '35': 'Andaman and Nicobar Islands',
  '36': 'Telangana', '37': 'Andhra Pradesh', '38': 'Ladakh', '97': 'Other Territory',
};

final _inr = NumberFormat('#,##,##0.00', 'en_IN');
String inr(num v) => _inr.format(v);

/// 4490 -> "FOUR THOUSAND FOUR HUNDRED AND NINETY RUPEES ONLY" (Indian numbering: thousand, lakh, crore)
String amountWords(num v) {
  const ones = ['', 'ONE', 'TWO', 'THREE', 'FOUR', 'FIVE', 'SIX', 'SEVEN', 'EIGHT', 'NINE', 'TEN', 'ELEVEN', 'TWELVE', 'THIRTEEN', 'FOURTEEN', 'FIFTEEN', 'SIXTEEN', 'SEVENTEEN', 'EIGHTEEN', 'NINETEEN'];
  const tens = ['', '', 'TWENTY', 'THIRTY', 'FORTY', 'FIFTY', 'SIXTY', 'SEVENTY', 'EIGHTY', 'NINETY'];
  String two(int n) => n < 20 ? ones[n] : '${tens[n ~/ 10]}${n % 10 > 0 ? '-${ones[n % 10]}' : ''}';
  String three(int n) {
    final h = n ~/ 100, r = n % 100;
    return [if (h > 0) '${ones[h]} HUNDRED', if (r > 0) (h > 0 ? 'AND ${two(r)}' : two(r))].join(' ');
  }

  String words(int n) {
    if (n == 0) return 'ZERO';
    final parts = <String>[];
    final cr = n ~/ 10000000, la = (n ~/ 100000) % 100, th = (n ~/ 1000) % 100, rest = n % 1000;
    if (cr > 0) parts.add('${words(cr)} CRORE');
    if (la > 0) parts.add('${two(la)} LAKH');
    if (th > 0) parts.add('${two(th)} THOUSAND');
    if (rest > 0) parts.add(three(rest));
    return parts.join(' ');
  }

  final paise = (v * 100).round();
  final r = paise ~/ 100, p = paise % 100;
  return '${words(r)} RUPEES${p > 0 ? ' AND ${two(p)} PAISA' : ''} ONLY';
}

class _Item {
  final n = TextEditingController(), desc = TextEditingController(), hsn = TextEditingController(), qty = TextEditingController(text: '1'), unit = TextEditingController(text: 'NOS'), rate = TextEditingController();
  String gst = '18';
  num get q => num.tryParse(qty.text.trim()) ?? 0;
  num get r => num.tryParse(rate.text.replaceAll(',', '').trim()) ?? 0;
  num get taxable => (q * r * 100).round() / 100;
  num get pct => num.tryParse(gst) ?? 0;
}

void openInvoicePage(BuildContext context) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const InvoicePage()));

class InvoicePage extends StatefulWidget {
  const InvoicePage({super.key});
  @override
  State<InvoicePage> createState() => _InvoicePageState();
}

class _InvoicePageState extends State<InvoicePage> {
  late final Doc pf = {...mapv(Prefs.json('sh-invp-${S.sid}')), ...mapv(S.soc?['invoiceProfile'])};
  // seller
  late final sName = TextEditingController(text: str(pf['name']).isNotEmpty ? str(pf['name']) : str(S.soc?['name']));
  late final sTag = TextEditingController(text: str(pf['tagline']));
  late final sAddr = TextEditingController(text: str(pf['address']).isNotEmpty ? str(pf['address']) : [str(S.soc?['address']), str(S.soc?['city'])].where((e) => e.isNotEmpty).join(', '));
  late final sPhone = TextEditingController(text: str(pf['phone']));
  late final sMail = TextEditingController(text: str(pf['email']));
  late final sWeb = TextEditingController(text: str(pf['web']));
  late final sGst = TextEditingController(text: S.socGst());
  // customer
  final cGst = TextEditingController(), cPan = TextEditingController(), cName = TextEditingController(), cAddr = TextEditingController(), cPhone = TextEditingController();
  String cState = '';
  bool looking = false;
  String lookNote = '';
  // invoice
  late final no = TextEditingController(text: _nextNo());
  String date = td();
  final challan = TextEditingController(), eway = TextEditingController(), trans = TextEditingController(), transId = TextEditingController();
  String challanDate = '';
  final items = <_Item>[_Item()];
  // bank + terms
  late final bName = TextEditingController(text: str(pf['bankName']));
  late final bBranch = TextEditingController(text: str(pf['branch']));
  late final bAcc = TextEditingController(text: str(pf['account']));
  late final bIfsc = TextEditingController(text: str(pf['ifsc']));
  late final bUpi = TextEditingController(text: str(pf['upi']).isNotEmpty ? str(pf['upi']) : str(mapv(mapv(S.soc?['payout'])['upi'])['id']));
  late final terms = TextEditingController(text: str(pf['terms']).isNotEmpty ? str(pf['terms']) : 'Goods once sold will not be taken back.\nPayment is due within 15 days of the invoice date.\nSubject to local jurisdiction.');
  // letterhead
  late String lhRef = str(pf['letterhead']);
  Uint8List? lhBytes;

  @override
  void initState() {
    super.initState();
    if (lhRef.isNotEmpty) {
      refBytes(lhRef).then((r) {
        if (mounted) setState(() => lhBytes = r.$1);
      }).catchError((_) {});
    }
  }

  String _nextNo() {
    final n = intv(pf['next']) > 0 ? intv(pf['next']) : 1;
    final d = DateTime.now();
    final fy = d.month >= 4 ? '${d.year % 100}-${(d.year + 1) % 100}' : '${(d.year - 1) % 100}-${d.year % 100}';
    return '${str(pf['prefix']).isNotEmpty ? str(pf['prefix']) : 'INV'}/$fy/${n.toString().padLeft(3, '0')}';
  }

  String get sellerState => sGst.text.trim().length >= 2 ? sGst.text.trim().substring(0, 2) : '';
  bool get inter => cState.isNotEmpty && sellerState.isNotEmpty && cState != sellerState;
  num get taxable => items.fold<num>(0, (a, i) => a + i.taxable);
  num get tax => items.fold<num>(0, (a, i) => a + (i.taxable * i.pct / 100 * 100).round() / 100);
  num get total => ((taxable + tax) * 100).round() / 100;

  Future<void> _lookup() async {
    final g = cGst.text.trim().toUpperCase();
    cGst.text = g;
    if (!gstRe.hasMatch(g)) {
      toast('ℹ️', tr('Enter a valid 15-character GST number'));
      return;
    }
    setState(() {
      looking = true;
      lookNote = '';
      if (gstStates.containsKey(g.substring(0, 2))) cState = g.substring(0, 2);
      cPan.text = g.substring(2, 12);
    });
    try {
      final r = await api('/v1/gst/lookup', {'sid': S.sid, 'gstin': g});
      final tn = str(r['tradeName']), ln = str(r['legalName']);
      cName.text = ln.isNotEmpty ? ln : tn;
      cAddr.text = [str(r['address']), str(r['pincode'])].where((e) => e.isNotEmpty).join(' - ');
      lookNote = trf('✓ {0}{1} · PAN {2}{3}', [(ln.isNotEmpty ? ln : tn), (tn.isNotEmpty && tn != ln ? trf(' (trade name: {0})', [tn]) : ''), cPan.text, (str(r['status']).isNotEmpty ? ' · ${r['status']}' : '')]);
      toast('✅', tr('Taxpayer details filled'), cName.text);
    } on AppError catch (e) {
      if (e.code == 'gst-not-found') {
        lookNote = tr('No taxpayer found for this GST number. State and PAN are filled; check the number or type the details.');
      } else if (e.code == 'bad-gstin') {
        lookNote = e.message;
      } else if (e.code == 'not-configured' || e.http == 404 || e.net) {
        lookNote = tr('State and PAN filled from the GST number. Full details (name, address) need the GST lookup to be switched on in the payments server.');
      } else {
        lookNote = e.message;
      }
    } catch (e) {
      lookNote = fr(e);
    }
    if (mounted) setState(() => looking = false);
  }

  /// where the letterhead's own printing ends at the top and starts at the bottom (fractions of the page height),
  /// so the invoice is written in the empty middle of every page
  Future<(double, double)> _bands(Uint8List b) async {
    try {
      final codec = await ui.instantiateImageCodec(b, targetWidth: 160);
      final img = (await codec.getNextFrame()).image;
      final w = img.width, h = img.height;
      final bd = await img.toByteData(format: ui.ImageByteFormat.rawRgba);
      if (bd == null || h < 20) return (.17, .09);
      bool inked(int y) {
        var n = 0;
        for (var x = 0; x < w; x++) {
          final o = (y * w + x) * 4;
          final a = bd.getUint8(o + 3);
          final l = (bd.getUint8(o) + bd.getUint8(o + 1) + bd.getUint8(o + 2)) / 3;
          if (a > 40 && l < 225) n++;
        }
        return n > w * .01;
      }

      var top = 0;
      for (var y = 0; y < (h * .4).round(); y++) {
        if (inked(y)) top = y;
      }
      var bot = h;
      for (var y = h - 1; y > (h * .65).round(); y--) {
        if (inked(y)) bot = y;
      }
      final t = ((top / h) + .02).clamp(.06, .38), bo = ((h - bot) / h + .02).clamp(.04, .3);
      return (t.toDouble(), bo.toDouble());
    } catch (_) {
      return (.17, .09);
    }
  }

  /// JPG / PNG as it is; PDF -> its first page as a picture; Word (.docx) -> the biggest picture in it (the letterhead)
  Future<Uint8List?> _toImage(PFile f) async {
    final n = f.name.toLowerCase();
    if (f.isImg) return f.bytes;
    if (f.isPdf || n.endsWith('.pdf')) {
      await for (final r in Printing.raster(f.bytes, pages: [0], dpi: 150)) {
        return await r.toPng();
      }
      return null;
    }
    if (n.endsWith('.docx')) {
      final z = ZipDecoder().decodeBytes(f.bytes);
      ArchiveFile? best;
      for (final e in z.files) {
        final en = e.name.toLowerCase();
        if (e.isFile && en.startsWith('word/media/') && RegExp(r'\.(png|jpe?g)$').hasMatch(en) && (best == null || e.size > best.size)) best = e;
      }
      if (best == null) throw AppError(tr('This Word file has no letterhead picture in it. Save the letterhead as PDF or JPG and upload that.'));
      return Uint8List.fromList(best.content as List<int>);
    }
    if (n.endsWith('.doc')) throw AppError(tr('Old Word files (.doc) cannot be read on the phone. Save it as .docx, PDF or JPG and upload that.'));
    throw AppError(tr('Choose the letterhead as JPG, PNG, PDF or Word (.docx).'));
  }

  Future<void> _pickLetterhead() async {
    final f = await pickDoc(ext: const ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx']);
    if (f == null) return;
    if (f.size > 15 * 1048576) throw AppError(tr('The file is too large (max 15 MB).'));
    final img = await _toImage(f);
    if (img == null) throw AppError(tr("Couldn't read this file. Try a JPG or PDF."));
    final ref = await up(img, 'docs', 'letterhead.${f.isImg && !f.name.toLowerCase().endsWith('.png') ? 'jpg' : 'png'}');
    setState(() {
      lhRef = ref;
      lhBytes = img;
    });
    await _saveProfile(silent: true);
    toast('✅', tr('Letterhead saved'), tr('Every invoice is made on it.'));
  }

  Map<String, dynamic> _profile({bool bump = false}) => {
        'name': sName.text.trim(),
        'tagline': sTag.text.trim(),
        'address': sAddr.text.trim(),
        'phone': sPhone.text.trim(),
        'email': sMail.text.trim(),
        'web': sWeb.text.trim(),
        'bankName': bName.text.trim(),
        'branch': bBranch.text.trim(),
        'account': bAcc.text.trim(),
        'ifsc': bIfsc.text.trim().toUpperCase(),
        'upi': bUpi.text.trim(),
        'terms': terms.text.trim(),
        'letterhead': lhRef,
        'prefix': str(pf['prefix']).isNotEmpty ? str(pf['prefix']) : 'INV',
        'next': (intv(pf['next']) > 0 ? intv(pf['next']) : 1) + (bump ? 1 : 0),
      };

  Future<void> _saveProfile({bool silent = false, bool bump = false}) async {
    final p = _profile(bump: bump);
    pf.addAll(p);
    Prefs.setJson('sh-invp-${S.sid}', p);
    final g = sGst.text.trim().toUpperCase();
    try {
      await updateDoc(socRef(), {'invoiceProfile': p, if (gstRe.hasMatch(g)) 'gstin': g});
      S.soc!['invoiceProfile'] = p;
      if (gstRe.hasMatch(g)) S.soc!['gstin'] = g;
      D.bump('soc');
    } catch (e) {
      if (!silent) fail(e, tr('Saved on this phone only'));
    }
  }

  Future<void> _create() async {
    final g = sGst.text.trim().toUpperCase();
    if (!gstRe.hasMatch(g)) throw AppError(tr('Enter your company GST number (15 characters).'));
    if (cName.text.trim().isEmpty) throw AppError(tr('Enter the customer name.'));
    if (cState.isEmpty) throw AppError(tr('Choose the place of supply (customer state).'));
    final its = items.where((i) => i.n.text.trim().isNotEmpty).toList();
    if (its.isEmpty || its.any((i) => i.q <= 0 || i.r <= 0)) throw AppError(tr('Add at least one item with quantity and rate.'));
    final c = cGst.text.trim().toUpperCase();
    if (c.isNotEmpty && !gstRe.hasMatch(c)) throw AppError(tr('The customer GST number is not valid.'));
    final pdf = await L10n.I.english(() => _pdf(its));
    await _saveProfile(silent: true, bump: true);
    if (!mounted) return;
    setState(() => no.text = _nextNo());
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => PdfViewer(bytes: pdf.bytes, name: pdf.name)));
  }

  /* ---------------------------------------------- the PDF ---------------------------------------------- */
  Future<PdfDoc> _pdf(List<_Item> its) async {
    final f = await pdfFonts();
    final K = S.K;
    final acc = PdfColor.fromInt(K.c1.value), ink = PdfColor.fromInt(0xFF111827), mut = PdfColor.fromInt(0xFF4B5563), line = PdfColor.fromInt(0xFF111827);
    pw.TextStyle st(double s, [int w = 0, PdfColor? c]) => pw.TextStyle(font: [f.$1, f.$2, f.$3, f.$4][w], fontSize: s, color: c ?? ink);
    final bd = pw.BorderSide(color: line, width: .8);
    pw.Widget cell(String t, {double s = 8.5, int w = 0, pw.TextAlign a = pw.TextAlign.left, PdfColor? c}) => pw.Padding(padding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 3), child: pw.Text(t, textAlign: a, style: st(s, w, c)));
    pw.Widget kv(String k, String v, {double kw = 70, bool bold = false}) => pw.Padding(
        padding: const pw.EdgeInsets.symmetric(vertical: 1.6),
        child: pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
          pw.SizedBox(width: kw, child: pw.Text(k, style: st(8.5, 1))),
          pw.Expanded(child: pw.Text(v.isEmpty ? '—' : v, style: st(8.5, bold ? 2 : 0))),
        ]));

    // letterhead: a tall image is the whole page (content inside), a wide one is a banner on top
    pw.MemoryImage? lh;
    var full = false;
    if (lhBytes != null) {
      try {
        lh = pw.MemoryImage(lhBytes!);
        final w0 = lh.width ?? 1, h0 = lh.height ?? 1;
        full = h0 / w0 >= 1.15;
      } catch (_) {
        lh = null;
      }
    }
    const pw0 = 595.28, ph0 = 841.89;
    final bands = full ? await _bands(lhBytes!) : (.17, .09);
    final margin = full ? pw.EdgeInsets.fromLTRB(28, ph0 * bands.$1, 28, ph0 * bands.$2) : const pw.EdgeInsets.fromLTRB(28, 24, 28, 24);

    final seller = sName.text.trim().isEmpty ? str(S.soc?['name']) : sName.text.trim();
    final g = sGst.text.trim().toUpperCase(), pan = g.length >= 12 ? g.substring(2, 12) : '';
    final cg = cGst.text.trim().toUpperCase();
    final half = !inter;
    // HSN summary
    final hs = <String, List<num>>{}; // hsn|pct -> [taxable, tax]
    for (final i in its) {
      final k = '${i.hsn.text.trim()}|${i.gst}';
      final t = (i.taxable * i.pct / 100 * 100).round() / 100;
      final a = hs[k] ??= [0, 0];
      a[0] += i.taxable;
      a[1] += t;
    }
    final txT = its.fold<num>(0, (a, i) => a + i.taxable), taxT = hs.values.fold<num>(0, (a, v) => a + v[1]);
    final grand = ((txT + taxT) * 100).round() / 100, qtyT = its.fold<num>(0, (a, i) => a + i.q);
    final round = (grand.round() - grand);
    final payable = grand.round();
    final upi = bUpi.text.trim();
    String fmtD(String ymd0) {
      final d = DateTime.tryParse(ymd0);
      return d == null ? '' : DateFormat('dd-MMM-yyyy').format(d);
    }

    final head = <pw.Widget>[];
    // a wide (banner) letterhead is repeated at the top of every page through the page header (see below)
    final banner = lh != null && !full ? lh : null;
    if (lh == null) {
      head.add(pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
        pw.Expanded(
            child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
          pw.Text(seller.toUpperCase(), style: st(24, 3, acc)),
          if (sTag.text.trim().isNotEmpty)
            pw.Container(margin: const pw.EdgeInsets.only(top: 4), padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 4), color: acc, child: pw.Text(sTag.text.trim(), style: st(10, 2, PdfColors.white))),
          pw.SizedBox(height: 6),
          pw.Text(sAddr.text.trim(), style: st(9, 0, mut)),
        ])),
        pw.SizedBox(width: 16),
        pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.end, children: [
          if (sPhone.text.trim().isNotEmpty) pw.Text('Tel : ${sPhone.text.trim()}', style: st(9, 0, mut)),
          if (sWeb.text.trim().isNotEmpty) pw.Text('Web : ${sWeb.text.trim()}', style: st(9, 0, mut)),
          if (sMail.text.trim().isNotEmpty) pw.Text('Email : ${sMail.text.trim()}', style: st(9, 0, mut)),
        ]),
      ]));
      head.add(pw.SizedBox(height: 10));
    }

    final body = <pw.Widget>[
      ...head,
      // title row
      pw.Container(
        decoration: pw.BoxDecoration(border: pw.Border.all(color: line, width: .8)),
        padding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 5),
        child: pw.Row(children: [
          pw.Expanded(child: pw.Text('GSTIN : $g${pan.isNotEmpty ? '   PAN : $pan' : ''}', style: st(9, 2))),
          pw.Text('TAX INVOICE', style: st(14, 3)),
          pw.Expanded(child: pw.Text('ORIGINAL FOR RECIPIENT', textAlign: pw.TextAlign.right, style: st(8, 2))),
        ]),
      ),
      // customer | invoice details
      pw.Container(
        decoration: pw.BoxDecoration(border: pw.Border(left: bd, right: bd, bottom: bd)),
        child: pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
          pw.Expanded(
              child: pw.Container(
            decoration: pw.BoxDecoration(border: pw.Border(right: bd)),
            padding: const pw.EdgeInsets.all(5),
            child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.Center(child: pw.Text('Customer Detail', style: st(8.5, 2))),
              pw.SizedBox(height: 3),
              kv('M/S', cName.text.trim(), kw: 52, bold: true),
              kv('Address', cAddr.text.trim(), kw: 52),
              kv('Phone', cPhone.text.trim(), kw: 52),
              kv('GSTIN', cg, kw: 52),
              if (cPan.text.trim().isNotEmpty) kv('PAN', cPan.text.trim().toUpperCase(), kw: 52),
              kv('Place of Supply', '${gstStates[cState] ?? ''} ( $cState )', kw: 52),
            ]),
          )),
          pw.Expanded(
              child: pw.Padding(
            padding: const pw.EdgeInsets.all(5),
            child: pw.Column(children: [
              pw.Row(children: [pw.Expanded(child: kv('Invoice No.', no.text.trim(), kw: 58, bold: true)), pw.Expanded(child: kv('Invoice Date', fmtD(date), kw: 58))]),
              if (challan.text.trim().isNotEmpty || challanDate.isNotEmpty) pw.Row(children: [pw.Expanded(child: kv('Challan No', challan.text.trim(), kw: 58)), pw.Expanded(child: kv('Challan Date', fmtD(challanDate), kw: 58))]),
              if (eway.text.trim().isNotEmpty) kv('E-Way Bill No.', eway.text.trim(), kw: 58),
              if (trans.text.trim().isNotEmpty) kv('Transport', trans.text.trim(), kw: 58),
              if (transId.text.trim().isNotEmpty) kv('Transport ID', transId.text.trim(), kw: 58),
              kv('Supply type', inter ? 'Inter-state (IGST)' : 'Intra-state (CGST + SGST)', kw: 58),
            ]),
          )),
        ]),
      ),
      pw.SizedBox(height: 6),
      // items
      pw.Table(
        border: pw.TableBorder(left: bd, right: bd, top: bd, bottom: bd, verticalInside: bd),
        columnWidths: const {0: pw.FixedColumnWidth(26), 1: pw.FlexColumnWidth(5), 2: pw.FlexColumnWidth(1.4), 3: pw.FlexColumnWidth(1.3), 4: pw.FlexColumnWidth(1.1), 5: pw.FlexColumnWidth(1.6), 6: pw.FlexColumnWidth(1.8)},
        children: [
          pw.TableRow(decoration: pw.BoxDecoration(border: pw.Border(bottom: bd)), children: [
            for (final h in const ['Sr.', 'Name of Product / Service', 'HSN / SAC', 'Qty', 'GST %', 'Rate', 'Taxable Value']) cell(h, w: 2, a: pw.TextAlign.center, s: 8),
          ]),
          for (var i = 0; i < its.length; i++)
            pw.TableRow(children: [
              cell('${i + 1}', a: pw.TextAlign.center),
              its[i].desc.text.trim().isEmpty
                  ? cell(its[i].n.text.trim(), w: 2)
                  : pw.Padding(
                      padding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 3),
                      child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                        pw.Text(its[i].n.text.trim(), style: st(8.5, 2)),
                        pw.SizedBox(height: 1.5),
                        pw.Text(its[i].desc.text.trim(), style: st(7.5, 0, mut)),
                      ])),
              cell(its[i].hsn.text.trim(), a: pw.TextAlign.center),
              cell('${_q(its[i].q)} ${its[i].unit.text.trim()}', a: pw.TextAlign.center),
              cell('${its[i].gst}%', a: pw.TextAlign.center),
              cell(inr(its[i].r), a: pw.TextAlign.right),
              cell(inr(its[i].taxable), a: pw.TextAlign.right),
            ]),
          // tax lines
          pw.TableRow(children: [
            cell(''),
            pw.Padding(
                padding: const pw.EdgeInsets.fromLTRB(4, 12, 4, 4),
                child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.end, children: [
                  pw.Text('Taxable amount', style: st(8.5, 1)),
                  if (half) ...[pw.Text('CGST', style: st(8.5, 1)), pw.Text('SGST', style: st(8.5, 1))] else pw.Text('IGST', style: st(8.5, 1)),
                  if (round.abs() >= .005) pw.Text('Round off', style: st(8.5, 1)),
                ])),
            cell(''),
            cell(''),
            cell(''),
            cell(''),
            pw.Padding(
                padding: const pw.EdgeInsets.fromLTRB(4, 12, 4, 4),
                child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.end, children: [
                  pw.Text(inr(txT), style: st(8.5, 2)),
                  if (half) ...[pw.Text(inr(taxT / 2), style: st(8.5)), pw.Text(inr(taxT - (taxT / 2 * 100).round() / 100), style: st(8.5))] else pw.Text(inr(taxT), style: st(8.5)),
                  if (round.abs() >= .005) pw.Text('${round > 0 ? '+' : '-'}${inr(round.abs())}', style: st(8.5)),
                ])),
          ]),
          pw.TableRow(decoration: pw.BoxDecoration(border: pw.Border(top: bd)), children: [
            cell(''),
            cell('Total', w: 3, a: pw.TextAlign.right, s: 9.5),
            cell(''),
            cell('${_q(qtyT)} ${its.map((i) => i.unit.text.trim()).toSet().length == 1 ? its.first.unit.text.trim() : ''}', w: 3, a: pw.TextAlign.center, s: 9),
            cell(''),
            cell(''),
            cell('₹ ${inr(payable)}', w: 3, a: pw.TextAlign.right, s: 10),
          ]),
        ],
      ),
      // in words
      pw.Container(
        decoration: pw.BoxDecoration(border: pw.Border(left: bd, right: bd, bottom: bd)),
        padding: const pw.EdgeInsets.all(5),
        child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
          pw.Row(children: [pw.Expanded(child: pw.Text('Total in words', style: st(8.5, 1))), pw.Text('(E & O.E.)', style: st(8, 2))]),
          pw.Text(amountWords(payable), style: st(9, 3)),
        ]),
      ),
      pw.SizedBox(height: 6),
      // HSN summary
      pw.Table(
        border: pw.TableBorder.all(color: line, width: .8),
        children: [
          pw.TableRow(children: [
            cell('HSN / SAC', w: 2, a: pw.TextAlign.center),
            cell('Taxable Value', w: 2, a: pw.TextAlign.center),
            if (half) ...[cell('CGST %', w: 2, a: pw.TextAlign.center), cell('CGST Amt', w: 2, a: pw.TextAlign.center), cell('SGST %', w: 2, a: pw.TextAlign.center), cell('SGST Amt', w: 2, a: pw.TextAlign.center)] else ...[cell('IGST %', w: 2, a: pw.TextAlign.center), cell('IGST Amt', w: 2, a: pw.TextAlign.center)],
            cell('Total Tax', w: 2, a: pw.TextAlign.center),
          ]),
          for (final e in hs.entries)
            pw.TableRow(children: [
              cell(e.key.split('|').first),
              cell(inr(e.value[0]), a: pw.TextAlign.right),
              if (half) ...[
                cell('${_q(num.parse(e.key.split('|').last) / 2)}', a: pw.TextAlign.center),
                cell(inr(e.value[1] / 2), a: pw.TextAlign.right),
                cell('${_q(num.parse(e.key.split('|').last) / 2)}', a: pw.TextAlign.center),
                cell(inr(e.value[1] / 2), a: pw.TextAlign.right),
              ] else ...[
                cell(e.key.split('|').last, a: pw.TextAlign.center),
                cell(inr(e.value[1]), a: pw.TextAlign.right),
              ],
              cell(inr(e.value[1]), a: pw.TextAlign.right),
            ]),
          pw.TableRow(children: [
            cell('Total', w: 3, a: pw.TextAlign.right),
            cell(inr(txT), w: 3, a: pw.TextAlign.right),
            if (half) ...[cell(''), cell(inr(taxT / 2), w: 3, a: pw.TextAlign.right), cell(''), cell(inr(taxT / 2), w: 3, a: pw.TextAlign.right)] else ...[cell(''), cell(inr(taxT), w: 3, a: pw.TextAlign.right)],
            cell(inr(taxT), w: 3, a: pw.TextAlign.right),
          ]),
        ],
      ),
      pw.Container(
        decoration: pw.BoxDecoration(border: pw.Border(left: bd, right: bd, bottom: bd)),
        padding: const pw.EdgeInsets.all(5),
        child: pw.RichText(text: pw.TextSpan(children: [pw.TextSpan(text: 'Total Tax in words: ', style: st(8.5, 1)), pw.TextSpan(text: amountWords(taxT), style: st(8.5, 3))])),
      ),
      pw.SizedBox(height: 6),
      // bank + QR | signatory
      pw.Container(
        decoration: pw.BoxDecoration(border: pw.Border.all(color: line, width: .8)),
        child: pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
          pw.Expanded(
              flex: 3,
              child: pw.Container(
                decoration: pw.BoxDecoration(border: pw.Border(right: bd)),
                padding: const pw.EdgeInsets.all(5),
                child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                  pw.Center(child: pw.Text('Bank Details', style: st(8.5, 2))),
                  pw.SizedBox(height: 3),
                  pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                    pw.Expanded(
                        child: pw.Column(children: [
                      kv('Name', bName.text.trim(), kw: 60, bold: true),
                      kv('Branch', bBranch.text.trim(), kw: 60, bold: true),
                      kv('Acc. Number', bAcc.text.trim(), kw: 60),
                      kv('IFSC', bIfsc.text.trim().toUpperCase(), kw: 60),
                      kv('UPI ID', upi, kw: 60, bold: true),
                    ])),
                    if (upi.isNotEmpty)
                      pw.Column(children: [
                        pw.BarcodeWidget(barcode: pw.Barcode.qrCode(), data: 'upi://pay?pa=${Uri.encodeComponent(upi)}&pn=${Uri.encodeComponent(seller)}&am=$payable&cu=INR&tn=${Uri.encodeComponent(no.text.trim())}', width: 78, height: 78),
                        pw.SizedBox(height: 3),
                        pw.Text('Pay using UPI', style: st(8, 2)),
                      ]),
                  ]),
                ]),
              )),
          pw.Expanded(
              flex: 2,
              child: pw.SizedBox(
                height: 120,
                child: pw.Column(children: [
                  pw.Padding(padding: const pw.EdgeInsets.all(4), child: pw.Text('Certified that the particulars given above are true and correct.', textAlign: pw.TextAlign.center, style: st(7.5, 1))),
                  pw.Text('For $seller', style: st(9, 2)),
                  pw.Spacer(),
                  pw.Transform.rotate(angle: .2, child: pw.Text('This is a computer generated\ninvoice, no signature required.', textAlign: pw.TextAlign.center, style: st(8, 0, mut))),
                  pw.Spacer(),
                  pw.Container(width: double.infinity, decoration: pw.BoxDecoration(border: pw.Border(top: bd)), padding: const pw.EdgeInsets.all(3), child: pw.Text('Authorised Signatory', textAlign: pw.TextAlign.center, style: st(7.5, 2))),
                ]),
              )),
        ]),
      ),
      // terms + customer signature
      pw.Container(
        decoration: pw.BoxDecoration(border: pw.Border(left: bd, right: bd, bottom: bd)),
        child: pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
          pw.Expanded(
              flex: 3,
              child: pw.Container(
                decoration: pw.BoxDecoration(border: pw.Border(right: bd)),
                padding: const pw.EdgeInsets.all(5),
                child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                  pw.Center(child: pw.Text('Terms and Conditions', style: st(8.5, 2))),
                  pw.SizedBox(height: 3),
                  pw.Text(terms.text.trim(), style: st(8)),
                ]),
              )),
          pw.Expanded(flex: 2, child: pw.Container(height: 54, padding: const pw.EdgeInsets.all(5), alignment: pw.Alignment.bottomLeft, child: pw.Text('Customer Signature', style: st(8.5, 2)))),
        ]),
      ),
      pw.SizedBox(height: 6),
      pw.Text('Thank you for your business!', style: st(9)),
    ];

    final doc = pw.Document(title: 'Tax Invoice ${no.text.trim()}', author: seller);
    doc.addPage(pw.MultiPage(
      pageTheme: pw.PageTheme(
        pageFormat: PdfPageFormat.a4,
        margin: margin,
        buildBackground: full && lh != null ? (_) => pw.FullPage(ignoreMargins: true, child: pw.Image(lh!, fit: pw.BoxFit.fill)) : null,
      ),
      header: banner == null ? null : (_) => pw.Padding(padding: const pw.EdgeInsets.only(bottom: 6), child: pw.Image(banner, width: pw0 - 56, fit: pw.BoxFit.fitWidth)),
      build: (_) => body,
    ));
    final name = 'Invoice ${no.text.trim()} - ${cName.text.trim()}'.replaceAll(RegExp(r'[\\/:*?"<>|]+'), '-');
    return PdfDoc(await doc.save(), '$name.pdf');
  }

  String _q(num v) => v == v.roundToDouble() ? v.toInt().toString() : v.toString();

  /* ---------------------------------------------- the page ---------------------------------------------- */
  @override
  Widget build(BuildContext context) {
    final p = pal;
    final states = gstStates.entries.map((e) => (e.key, '${e.value} (${e.key})')).toList();
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(title:  Text(tr('🧾 Create tax invoice'))),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 40), children: [
        AppCard(title: '🖼️ Company letterhead', children: [
          Text(tr('Upload your letterhead as JPG, PNG, PDF or Word (.docx). A full A4 page letterhead becomes the page of the invoice; a wide header image goes on top.'), style: meta()),
          const SizedBox(height: 10),
          if (lhBytes != null) ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.memory(lhBytes!, height: 140, width: double.infinity, fit: BoxFit.contain)),
          if (lhBytes == null && lhRef.isNotEmpty) const Skeleton(n: 1),
          const SizedBox(height: 10),
          Row2(
            Btn(lhRef.isEmpty ? tr('⬆ Upload letterhead') : tr('Change'), small: true, onTap: _pickLetterhead),
            Btn.o(tr('Remove'), small: true, onTap: lhRef.isEmpty
                ? null
                : () async {
                    setState(() {
                      lhRef = '';
                      lhBytes = null;
                    });
                    await _saveProfile(silent: true);
                  }),
          ),
        ]),
        AppCard(title: '🏢 Your company', children: [
          Field(sName, 'Company name', max: 80),
          Field(sTag, 'Tagline (optional, e.g. what you make or supply)', max: 90),
          Field(sAddr, 'Address', lines: 2, max: 200),
          Row2(Field(sPhone, 'Phone', kb: TextInputType.phone, max: 20), Field(sMail, 'Email', kb: TextInputType.emailAddress, max: 60)),
          Field(sWeb, 'Website (optional)', max: 60),
          Field(sGst, 'Company GST number *', max: 15, upper: true, onChanged: (_) => setState(() {})),
          if (sellerState.isNotEmpty) Meta('${gstStates[sellerState] ?? tr('Unknown state')}${sGst.text.trim().length >= 12 ? trf(' · PAN {0}', [sGst.text.trim().toUpperCase().substring(2, 12)]) : ''}'),
        ]),
        AppCard(title: '👤 Bill to', children: [
          Field(cGst, 'Customer GST number (optional)', max: 15, upper: true, onChanged: (v) {
            final g = v.trim().toUpperCase();
            if (gstRe.hasMatch(g) && !looking) _lookup(); // like Zoho: details come as soon as the number is complete
          }),
          Align(
            alignment: Alignment.centerLeft,
            child: Btn.o(looking ? tr('Looking up…') : tr('🔍 Get taxpayer details'), small: true, full: false, onTap: looking ? null : _lookup),
          ),
          if (lookNote.isNotEmpty) Note(lookNote, tone: lookNote.startsWith('✓') ? Tone.g : Tone.y, margin: const EdgeInsets.only(top: 8, bottom: 4)),
          const SizedBox(height: 10),
          Field(cName, 'Customer name (M/S) *', max: 100),
          Field(cPan, 'Customer PAN', max: 10, upper: true),
          Field(cAddr, 'Address', lines: 2, max: 220),
          Field(cPhone, 'Phone', kb: TextInputType.phone, max: 20),
          SelectField('Place of supply (state) *', cState, [('', 'Choose the state'), ...states], (v) => setState(() => cState = v)),
          if (cState.isNotEmpty && sellerState.isNotEmpty) Meta(inter ? tr('Other state: IGST is charged.') : tr('Same state: CGST + SGST are charged.')),
        ]),
        AppCard(title: '📄 Invoice details', children: [
          Row2(Field(no, 'Invoice no.', max: 30), DateField(tr('Invoice date'), date, (v) => setState(() => date = v))),
          Row2(Field(challan, 'Challan no. (optional)', max: 30), DateField(tr('Challan date'), challanDate, (v) => setState(() => challanDate = v))),
          Field(eway, 'E-way bill no. (optional)', max: 30),
          Row2(Field(trans, 'Transport (optional)', max: 40), Field(transId, 'Transport ID (optional)', max: 30)),
        ]),
        AppCard(title: '📦 Items', children: [
          for (var i = 0; i < items.length; i++)
            Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: p.card2, borderRadius: BorderRadius.circular(14)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Row(children: [
                  Text(trf('Item {0}', [i + 1]), style: h3()),
                  const Spacer(),
                  if (items.length > 1) IconButton(tooltip: tr('Remove item'), onPressed: () => setState(() => items.removeAt(i)), icon: Icon(Icons.close_rounded, color: p.muted)),
                ]),
                Field(items[i].n, 'Name of product / service', max: 120, onChanged: (_) => setState(() {})),
                Field(items[i].desc, 'Description (optional)', lines: 2, max: 300),
                Row2(Field(items[i].hsn, 'HSN / SAC', max: 10, kb: TextInputType.number), SelectField('GST %', items[i].gst, [for (final v in const ['0', '5', '12', '18', '28']) (v, '$v%')], (v) => setState(() => items[i].gst = v))),
                Row(children: [
                  Expanded(child: Field(items[i].qty, 'Qty', kb: const TextInputType.numberWithOptions(decimal: true), onChanged: (_) => setState(() {}))),
                  const SizedBox(width: 8),
                  Expanded(child: Field(items[i].unit, 'Unit', max: 8)),
                  const SizedBox(width: 8),
                  Expanded(flex: 2, child: Field(items[i].rate, 'Rate ₹', kb: const TextInputType.numberWithOptions(decimal: true), onChanged: (_) => setState(() {}))),
                ]),
                Text(trf('Taxable ₹{0} · GST ₹{1}', [inr(items[i].taxable), inr(items[i].taxable * items[i].pct / 100)]), style: small()),
              ]),
            ),
          Btn.o(tr('＋ Add item'), small: true, onTap: () => setState(() => items.add(_Item()))),
          const SizedBox(height: 12),
          KvRow(tr('Taxable amount'), '₹${inr(taxable)}'),
          if (inter) KvRow('IGST', '₹${inr(tax)}') else ...[KvRow('CGST', '₹${inr(tax / 2)}'), KvRow('SGST', '₹${inr(tax / 2)}')],
          KvRow(tr('Total (rounded)'), '₹${inr(total.round())}', vColor: p.a),
        ]),
        AppCard(title: '🏦 Bank details & UPI', children: [
          Text(tr('Printed on the invoice with a UPI QR code for the exact amount.'), style: meta()),
          const SizedBox(height: 8),
          Row2(Field(bName, 'Bank name', max: 40), Field(bBranch, 'Branch', max: 40)),
          Row2(Field(bAcc, 'Account number', max: 24, kb: TextInputType.number), Field(bIfsc, 'IFSC', max: 11, upper: true)),
          Field(bUpi, 'UPI ID', max: 60),
        ]),
        AppCard(title: '📝 Terms and conditions', children: [Field(terms, 'One per line', lines: 4, max: 600)]),
        Btn(tr('⬇️ Create invoice PDF'), onTap: _create, busyDone: false),
        const SizedBox(height: 8),
        Center(child: Text(tr('Your company details, bank details, terms and letterhead are kept for the next invoice.'), style: small(), textAlign: TextAlign.center)),
      ]),
    );
  }
}

/// the small card in Billing that opens the invoice page
class InvoiceEntry extends StatelessWidget {
  const InvoiceEntry({super.key});
  @override
  Widget build(BuildContext context) => AppCard(title: '🧾 Raise an invoice', children: [
        Text(tr('Make a GST tax invoice for a customer on your own letterhead, with HSN summary, bank details and a UPI QR code.'), style: meta()),
        const SizedBox(height: 10),
        Btn(tr('Create a tax invoice'), onTap: () => openInvoicePage(context)),
      ]);
}

void openInvoiceSheet(BuildContext c) => sheet(c, (_) => const InvoiceEntry());
