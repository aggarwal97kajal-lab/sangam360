import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/api.dart';
import '../../core/files.dart';
import '../../core/kinds.dart';
import '../../core/listen.dart';
import '../../core/nav.dart';
import '../../core/pdfs.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import '../fx/fx.dart';
import '../../l10n/l10n.dart';

/* ===== paying a bill straight to the organisation, receipts, and Razorpay for a Sangam360 plan ===== */

bool payOn() => payApi.isNotEmpty;
bool poOn() {
  final p = mapv(S.soc?['payout']);
  return p['method'] == 'upi' || p['method'] == 'bank';
}

bool closedBill(Doc b) => b['status'] == 'Paid' || b['status'] == 'Refunded';
const actName = {'savings': 'Savings account', 'current': 'Current account'};

void copy(String t) {
  Clipboard.setData(ClipboardData(text: t));
  toast('✅', tr('Copied ✓'), t);
}

/// a payment made online before bills were paid directly, shown through the receipt / invoice code of the bills
Doc payAsBill(Doc p) => {
      'id': p['chargeId'],
      'flat': str(p['flat']),
      'month': str(p['period']),
      'title': p['description'],
      'amount': p['amount'],
      'due': p['dueAt'] ?? p['createdAt'],
      'ts': p['createdAt'],
      'status': 'Paid',
      'paidAt': p['paidAt'],
      'receiptNo': p['receiptNumber'],
      'paidBy': str(p['payerName']),
      'utr': p['razorpayPaymentId'],
      'payMethod': p['paymentMethod'],
      'gateway': 'razorpay',
      'confirmedBy': 'Verified online',
    };

/* ---------- receipts and invoices ---------- */
Future<void> downloadReceipt(Doc b) async {
  final d = await L10n.I.english(() => receiptPdf(b));
  await saveBytes(d.name, d.bytes, 'application/pdf');
}

Future<void> shareReceipt(Doc b) async {
  final d = await L10n.I.english(() => receiptPdf(b));
  final f = await tempFile(d.name, d.bytes);
  await Share.shareXFiles([XFile(f.path, mimeType: 'application/pdf')], subject: 'Payment receipt ${str(b['receiptNo'])}', text: '${str(S.soc?['name'])} · ${str(b['flat'])} · ${billTitle(b)} ${rs(b['amount'])}');
}

Future<void> shareInvoice(Doc b) async {
  final d = await L10n.I.english(() => receiptPdf(b, billInv(b)));
  await saveBytes(d.name, d.bytes, 'application/pdf');
}

Future<void> planInvoice(Doc v) async {
  final d = await L10n.I.english(() => receiptPdf({'amount': v['amount']}, planInv(v)));
  await saveBytes(d.name, d.bytes, 'application/pdf');
}

void receipt(BuildContext context, Doc b) {
  final on = b['gateway'] == 'razorpay', dr = b['gateway'] == 'direct';
  final rows = <List<String>>[
    ['Receipt no.', str(b['receiptNo'])],
    [S.sk('Society'), str(S.soc?['name'])],
    [S.sk('Flat'), str(b['flat'])],
    ['Paid by', str(b['paidBy'])],
    ['For', billTitle(b)],
    ['Amount', rs(b['amount'])],
    ['Paid on', on ? dtm(b['paidAt']) : bdate(b['paidAt'])],
    ['Payment method', on || dr ? payMeth(b['payMethod']) : ''],
    ['Paid to', dr ? str(b['paidTo']) : ''],
    [on ? 'Online payment ID' : 'Reference no. (UTR)', str(b['utr'])],
    ['Confirmed by', on ? '' : str(b['confirmedBy'])],
    ['Status', 'PAID'],
    if (S.socGst().isNotEmpty) ['GSTIN', S.socGst()],
  ].where((r) => r[1].isNotEmpty).toList();
  sheet(context, (ctx) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const SheetTitle('🧾 Payment receipt'),
        for (final r in rows) KvRow(r[0], r[1], onTap: RegExp(r'ID$|UTR\)$').hasMatch(r[0]) ? () => copy(r[1]) : null, vColor: r[0] == 'Status' ? pal.green : null),
        const SizedBox(height: 14),
        Btn.g(tr('⬇️ Download receipt (PDF)'), small: true, onTap: () => downloadReceipt(b)),
        const SizedBox(height: 8),
        Btn.o(tr('📤 Share receipt'), small: true, onTap: () => shareReceipt(b)),
        const SizedBox(height: 8),
        Btn.o(tr('📄 Download invoice'), small: true, onTap: () => shareInvoice(b)),
      ]));
}

/* ---------- pay a bill: straight to the organisation's UPI ID or bank account ---------- */
void payBill(BuildContext context, Doc b) {
  final n = now(), ov = intv(b['due']) < n;
  final ready = payOn() && poOn();
  final pm = ready ? str(mapv(S.soc!['payout'])['method']) : '';
  sheet(context, (ctx) {
    final p = pal;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const SheetTitle('Payment Details'),
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(gradient: LinearGradient(colors: [p.a.withOpacity(.12), p.a2.withOpacity(.06)]), borderRadius: BorderRadius.circular(18)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(billTitle(b), style: h3()),
          Text(str(b['title']).isNotEmpty && str(b['month']).isNotEmpty ? mname(str(b['month'])) : str(S.soc?['name']), style: meta()),
          const SizedBox(height: 10),
          Text(tr('Amount'), style: small()),
          Text(rs(b['amount']), style: h1(p.a)),
        ]),
      ),
      const SizedBox(height: 8),
      KvRow(tr('Due Date'), '${bdate(b['due'])}${ov ? tr(' · Overdue') : ''}', vColor: ov ? p.red : null),
      KvRow(S.K.unit, str(b['flat'])),
      KvRow(tr('Invoice no.'), invNo(b)),
      if (!ready) Note(trf('Payments are not set up for this {0} yet. Please ask your admin to add a UPI ID or bank account.', [S.K.word]), tone: Tone.y, margin: const EdgeInsets.only(top: 14)),
      const SizedBox(height: 16),
      Btn(tr('Proceed to Pay'), onTap: !ready
          ? null
          : () async {
              Doc d;
              try {
                d = await api('/v1/payments/direct/details', {'sid': S.sid, 'chargeId': b['id'], 'profileId': S.pidv});
              } on AppError catch (e) {
                final paid = e.code == 'already-paid';
                if (paid || e.code == 'already-reported') {
                  if (ctx.mounted) Navigator.pop(ctx);
                  toast(paid ? '✅' : '⏳', paid ? tr('Already paid') : tr('Waiting for confirmation'), e.message);
                  return;
                }
                rethrow;
              }
              if (ctx.mounted) Navigator.pop(ctx);
              if (context.mounted) payDirect(context, b, d);
            }, busyDone: false),
      if (ready) Padding(padding: const EdgeInsets.only(top: 10), child: Text(trf('🔒 You pay {0} directly by {1}. {2} never holds your money.', [(str(S.soc?['name'])), (pm == 'upi' ? 'UPI' : tr('bank transfer')), brand]), textAlign: TextAlign.center, style: small())),
    ]);
  });
}

/// d = the answer of the payment server: {method, amount, note} and the UPI ID or the bank account
void payDirect(BuildContext context, Doc b, Doc d) {
  final upi = d['method'] == 'upi', amt = numv(d['amount']).toDouble(), app = upi ? 'UPI' : 'bank';
  final ref = TextEditingController();
  sheet(context, (ctx) {
    final p = pal;
    Widget row(String l, dynamic v, {String? copyV}) {
      if (v == null || str(v).isEmpty) return const SizedBox.shrink();
      return Container(
        margin: const EdgeInsets.only(bottom: 8),
        decoration: BoxDecoration(color: p.card2, borderRadius: BorderRadius.circular(12)),
        child: ListTile(
          dense: true,
          onTap: copyV == null ? null : () => copy(copyV),
          title: Text(l, style: small()),
          subtitle: Text(str(v), style: TextStyle(fontFamily: 'monospace', fontSize: 15, fontWeight: FontWeight.w700, color: p.text)),
          trailing: copyV == null ? null : Icon(Icons.copy_rounded, size: 18, color: p.a),
        ),
      );
    }

    final link = upi ? 'upi://pay?pa=${Uri.encodeComponent(str(d['upiId']))}&pn=${Uri.encodeComponent(str(d['payeeName']))}&am=${amt.toStringAsFixed(2)}&cu=INR&tn=${Uri.encodeComponent(str(d['note']))}' : '';
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      SheetTitle(trf(S.skE('Pay {0}'), [rs(amt)]), sub: '${billTitle(b)} · ${str(S.soc?['name'])}'),
      Sec(upi ? 'Step 1 · Pay to this UPI ID' : 'Step 1 · Send to this bank account'),
      if (upi) ...[row(tr('UPI ID'), d['upiId'], copyV: str(d['upiId'])), row(tr('Name'), d['payeeName'])] else ...[
        row(tr('Account holder'), d['holder'], copyV: str(d['holder'])),
        row(tr('Account number'), d['accountNumber'], copyV: str(d['accountNumber'])),
        row('IFSC', d['ifsc'], copyV: str(d['ifsc'])),
        row(tr('Bank'), [str(d['bankName']), actName[d['type']] ?? ''].where((x) => x.isNotEmpty).join(' · ')),
      ],
      row(tr('Amount'), rs(amt), copyV: amt.toStringAsFixed(amt == amt.roundToDouble() ? 0 : 2)),
      row(upi ? tr('Note') : tr('Remark'), d['note'], copyV: str(d['note'])),
      if (upi) ...[
        Btn(tr('📲 Open UPI app'), onTap: () async {
          if (!await launchUrl(Uri.parse(link), mode: LaunchMode.externalApplication)) toast('ℹ️', tr('No UPI app found'), tr('Copy the UPI ID and pay to it from your UPI app.'));
        }),
        const SizedBox(height: 12),
        Center(child: FxQR(link, size: 180)),
        Padding(padding: const EdgeInsets.only(top: 8), child: Text(tr('Or scan this QR code with any UPI app. If your UPI app does not open, copy the UPI ID and pay to it from the app.'), textAlign: TextAlign.center, style: small())),
      ] else
        Text(tr('Use NEFT, IMPS or UPI (to bank account) from your bank app.'), style: meta()),
      const Sec('Step 2 · Enter the reference number'),
      Field(ref, upi ? 'UPI reference no. (UTR), e.g. 412345678901' : 'UTR / reference no. of the transfer', max: 44, upper: true),
      Text(trf('Pay first, then enter the number. Your {0} app shows it as UTR, {1} or Transaction ID.', [app, (upi ? tr('UPI Ref. No.') : tr('Reference No.'))]), style: small()),
      const SizedBox(height: 12),
      Btn(tr('I have paid'), onTap: () async {
        final u = ref.text.replaceAll(RegExp(r'[\s-]'), '').toUpperCase();
        if (!RegExp(r'^[A-Z0-9]{8,35}$').hasMatch(u)) throw AppError(trf('Enter the reference number of your payment (UTR / Ref no.). You find it in your {0} app after paying.', [app]));
        await api('/v1/payments/direct/report', {'sid': S.sid, 'chargeId': b['id'], 'profileId': S.pidv, 'reference': u});
        if (ctx.mounted) Navigator.pop(ctx);
        toast('✅', tr('Sent to your admin'), trf('Reference {0}. The bill is marked paid as soon as your admin confirms it.', [u]));
      }, busyDone: false),
      Padding(padding: const EdgeInsets.only(top: 10), child: Text(trf('🔒 The money goes straight from your bank to {0}. Your admin confirms it after checking the bank statement.', [(str(S.soc?['name']))]), textAlign: TextAlign.center, style: small())),
    ]);
  });
}

/* ============================== Razorpay for a Sangam360 plan ============================== */
class PayOpts {
  final bool plan;
  final List<String> pm;
  final VoidCallback? retry;
  final void Function(Doc v)? after;
  const PayOpts({this.plan = true, this.pm = const [], this.retry, this.after});
}

/// the full-screen payment states: processing, success, failed, being verified
class PayFlow extends ChangeNotifier {
  static final PayFlow I = PayFlow._();
  PayFlow._();
  String kind = ''; // wait | ok | bad | unsure
  String title = '', sub = '', reason = '', status = '';
  bool soft = false, lock = false, slow = false;
  Doc? v;
  PayOpts o = const PayOpts();
  String payKind = '', paymentId = '';
  Timer? _poll, _slow;
  bool get open => kind.isNotEmpty;

  void _show() {
    if (!_routeOpen) {
      _routeOpen = true;
      navKey.currentState?.push(PageRouteBuilder(opaque: true, pageBuilder: (_, __, ___) => const PayPage(), transitionsBuilder: (_, a, __, c) => FadeTransition(opacity: a, child: c))).then((_) => _routeOpen = false);
    }
    notifyListeners();
  }

  bool _routeOpen = false;

  void _clear() {
    _poll?.cancel();
    _poll = null;
    _slow?.cancel();
  }

  void wait(String t, String s) {
    _clear();
    kind = 'wait';
    title = t;
    sub = s;
    lock = true;
    slow = false;
    _slow = Timer(const Duration(seconds: 7), () {
      slow = true;
      notifyListeners();
    });
    _show();
  }

  void done(Doc x, PayOpts op) {
    _clear();
    kind = 'ok';
    lock = false;
    v = x;
    o = op;
    _show();
    HapticFeedback.heavyImpact();
    try {
      op.after?.call(x);
    } catch (_) {}
  }

  void failed(PayOpts op, {bool soft0 = false, String msg = '', String why = ''}) {
    _clear();
    kind = 'bad';
    lock = false;
    soft = soft0;
    sub = msg;
    reason = why;
    o = op;
    _show();
  }

  void unsure(String k, String pid, PayOpts op) {
    _clear();
    kind = 'unsure';
    lock = false;
    payKind = k;
    paymentId = pid;
    o = op;
    status = '';
    _show();
    var n = 0;
    _poll = Timer.periodic(const Duration(seconds: 6), (_) {
      if (++n > 12) {
        _poll?.cancel();
        return;
      }
      check(false);
    });
  }

  bool _busy = false;
  Future<void> check(bool manual) async {
    if (_busy || kind != 'unsure') return;
    _busy = true;
    if (manual) {
      status = tr('Checking…');
      notifyListeners();
    }
    try {
      var x = await api('/v1/$payKind/status', {'sid': S.sid, 'paymentId': paymentId});
      if (x['status'] == 'CREATED' && x['gatewayChecked'] == true) x = await api('/v1/$payKind/fail', {'sid': S.sid, 'paymentId': paymentId, 'outcome': 'cancelled'});
      _busy = false;
      if (x['status'] == 'SUCCESS') return done(x, o);
      if (x['status'] == 'FAILED' || x['status'] == 'REFUNDED') return failed(o, why: str(mapv(x['failure'])['reason']));
      if (x['status'] == 'CANCELLED') return failed(o, soft0: true, msg: tr('No payment was received for this attempt. This is still unpaid.'));
      if (manual) status = tr('Still being verified. This can take a few minutes.');
    } catch (e) {
      if (manual) status = e is AppError && e.net ? tr('No internet connection. Please try again.') : tr('Could not check right now. Please try again.');
    }
    _busy = false;
    notifyListeners();
  }

  void close() {
    _clear();
    kind = '';
    lock = false;
    if (_routeOpen) navKey.currentState?.pop();
    notifyListeners();
  }
}

class PayPage extends StatelessWidget {
  const PayPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: PayFlow.I,
      builder: (_, __) {
        final f = PayFlow.I, p = pal;
        Widget icon;
        String title;
        final kids = <Widget>[];
        final btns = <Widget>[];
        switch (f.kind) {
          case 'ok':
            final v = f.v ?? {};
            icon = Icon(Icons.check_circle_rounded, color: p.green, size: 86);
            title = tr('Payment Successful');
            kids.addAll([
              Text(rs(v['amount']), textAlign: TextAlign.center, style: h1(p.green).copyWith(fontSize: 34)),
              if (str(v['description']).isNotEmpty) Text(str(v['description']), textAlign: TextAlign.center, style: meta()),
              const SizedBox(height: 14),
              for (final r in [
                ['Transaction ID', str(v['razorpayPaymentId'])],
                ['Date & Time', dtm(intv(v['paidAt']) > 0 ? v['paidAt'] : now())],
                ['Paid via', payMeth(v['paymentMethod'])],
                ['Receipt no.', str(v['receiptNumber'])],
                ['Invoice no.', f.o.plan ? str(v['invoiceId']) : ''],
                ['Valid till', f.o.plan && intv(v['periodEnd']) > 0 ? bdate(v['periodEnd']) : ''],
              ].where((r) => r[1].isNotEmpty))
                KvRow(r[0], r[1], onTap: r[0] == 'Transaction ID' ? () => copy(r[1]) : null),
              if (v['duplicate'] == true)  Note(tr('This was already paid earlier, so this amount was received twice. Please ask your admin for a refund.'), tone: Tone.y),
              if (f.o.plan)
                Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Text(trf('{0}Your invoice is ready. You can also download it later from the Plan tab.', [(intv(v['carriedDays']) > 0 ? trf('{0} day{1} from your earlier plan {2} carried forward. ', [v['carriedDays'], (intv(v['carriedDays']) == 1 ? '' : 's'), (intv(v['carriedDays']) == 1 ? 'was' : 'were')]) : '')]),
                        textAlign: TextAlign.center, style: small())),
            ]);
            if (f.o.plan) {
              btns.addAll([
                Btn(tr('⬇️ Download invoice'), onTap: () => planInvoice(v)),
                const SizedBox(height: 8),
                Btn.o(tr('Done'), onTap: () {
                  f.close();
                  nav.go('sub');
                }),
              ]);
            } else {
              btns.add(Btn.o(tr('Back to Home'), onTap: () {
                f.close();
                nav.go('home');
              }));
            }
            break;
          case 'bad':
            icon = Icon(Icons.cancel_rounded, color: p.red, size: 86);
            title = f.soft ? tr('Payment could not start') : tr('Payment Failed');
            if (f.soft) {
              kids.add(Text(f.sub.isEmpty ? tr('Please try again.') : f.sub, textAlign: TextAlign.center, style: body()));
            } else {
              kids.addAll([
                Text(tr("We couldn't confirm this payment."), textAlign: TextAlign.center, style: body()),
                Text(tr('Your account has NOT been marked as paid.'), textAlign: TextAlign.center, style: h3(p.red)),
                if (f.reason.isNotEmpty) Text(trf('Reason: {0}', [f.reason]), textAlign: TextAlign.center, style: meta()),
              ]);
            }
            if (f.o.retry != null) {
              btns.addAll([
                Btn(tr('Try Again'), onTap: () {
                  f.close();
                  f.o.retry!();
                }),
                const SizedBox(height: 8)
              ]);
            }
            btns.add(Btn.o(f.o.plan ? tr('Close') : tr('View Payment History'), onTap: () {
              f.close();
              if (!f.o.plan) nav.go('fin');
            }));
            break;
          case 'unsure':
            icon = Icon(Icons.schedule_rounded, color: p.amber, size: 86);
            title = tr('Verifying payment');
            kids.addAll([
              Text(tr('Payment status is being verified. Please check Payment History before trying again.'), textAlign: TextAlign.center, style: body()),
              if (f.status.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(f.status, textAlign: TextAlign.center, style: meta())),
            ]);
            btns.addAll([
              Btn(tr('Check status'), onTap: () => f.check(true), busyDone: false),
              const SizedBox(height: 8),
              Btn.o(f.o.plan ? tr('Close') : tr('View Payment History'), onTap: () {
                f.close();
                if (!f.o.plan) nav.go('fin');
              }),
            ]);
            break;
          default:
            icon = SizedBox(width: 70, height: 70, child: CircularProgressIndicator(strokeWidth: 5, color: p.a));
            title = f.title;
            kids.addAll([
              Text(f.slow ? tr('This is taking a little longer than usual. Please keep the app open.') : f.sub, textAlign: TextAlign.center, style: body()),
              const SizedBox(height: 8),
              Text(tr('Please do not close the app or press back.'), textAlign: TextAlign.center, style: small()),
            ]);
        }
        return PopScope(
          canPop: false,
          onPopInvokedWithResult: (did, _) {
            if (!did && !f.lock) f.close();
          },
          child: Scaffold(
            backgroundColor: p.bg,
            body: SafeArea(
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(24),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 440),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                      Center(child: TweenAnimationBuilder<double>(key: ValueKey(f.kind), tween: Tween(begin: .5, end: 1), duration: const Duration(milliseconds: 500), curve: Curves.easeOutBack, builder: (_, s, c) => Transform.scale(scale: s, child: c), child: icon)),
                      const SizedBox(height: 16),
                      Text(title, textAlign: TextAlign.center, style: h1()),
                      const SizedBox(height: 10),
                      ...kids,
                      const SizedBox(height: 22),
                      ...btns,
                    ]),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

Razorpay? _rzp;

String _hex(Color c) => '#${(c.value & 0xFFFFFF).toRadixString(16).padLeft(6, '0')}';

/// Razorpay Checkout for a Sangam360 plan (kind = "subscriptions")
Future<void> payStart(String kind, Map<String, dynamic> body, PayOpts o) async {
  final f = PayFlow.I;
  if (f.lock || f.open) return;
  f.wait(tr('Starting secure payment…'), tr('Please wait a moment.'));
  Doc ord;
  try {
    ord = await api('/v1/$kind/order', body);
  } on AppError catch (e) {
    if (e.code == 'already-paid') {
      f.close();
      toast('✅', tr('Already paid'), tr('This has already been paid.'));
      return;
    }
    if (e.code == 'payment-pending' && str(e.info['paymentId']).isNotEmpty) {
      f.unsure(kind, str(e.info['paymentId']), o);
      return;
    }
    f.failed(o, soft0: true, msg: e.message);
    return;
  } catch (e) {
    f.failed(o, soft0: true, msg: fr(e));
    return;
  }
  final ref = {'sid': S.sid, 'paymentId': ord['paymentId']};
  var answered = false;
  void settle(Doc v) {
    final st = v['status'];
    if (st == 'SUCCESS') {
      f.done(v, o);
    } else if (st == 'PENDING' || st == 'CREATED') {
      f.unsure(kind, str(v['paymentId']).isEmpty ? str(ord['paymentId']) : str(v['paymentId']), o);
    } else if (st == 'CANCELLED') {
      f.close();
      toast('ℹ️', tr('Payment cancelled'), tr('This is still unpaid. You can pay any time.'));
    } else {
      f.failed(o, why: str(mapv(v['failure'])['reason']));
    }
  }

  _rzp?.clear();
  final rp = _rzp = Razorpay();
  rp.on(Razorpay.EVENT_PAYMENT_SUCCESS, (PaymentSuccessResponse x) async {
    if (answered) return;
    answered = true;
    f.wait(tr('Payment Processing…'), tr('Please wait while we confirm your payment.'));
    final b = {...ref, 'razorpay_order_id': x.orderId, 'razorpay_payment_id': x.paymentId, 'razorpay_signature': x.signature};
    for (var i = 0; i < 4; i++) {
      try {
        settle(await api('/v1/$kind/verify', b));
        return;
      } on AppError catch (e) {
        if (['signature-invalid', 'verification-failed', 'order-mismatch'].contains(e.code)) {
          f.failed(o);
          return;
        }
        if (!(e.net || e.http >= 500 || e.http == 429) || i == 3) break;
        await Future.delayed(Duration(milliseconds: 1500 * (i + 1)));
      }
    }
    f.unsure(kind, str(ord['paymentId']), o);
  });
  rp.on(Razorpay.EVENT_PAYMENT_ERROR, (PaymentFailureResponse x) async {
    if (answered) return;
    answered = true;
    final cancelled = x.code == Razorpay.PAYMENT_CANCELLED;
    f.wait(tr('Checking payment…'), tr('Please wait while we check with Razorpay.'));
    try {
      settle(await api('/v1/$kind/fail', {...ref, 'outcome': cancelled ? 'cancelled' : 'failed', 'code': '${x.code ?? ''}', 'reason': x.message ?? ''}));
    } catch (_) {
      f.unsure(kind, str(ord['paymentId']), o);
    }
  });
  rp.on(Razorpay.EVENT_EXTERNAL_WALLET, (ExternalWalletResponse x) {});
  final opts = <String, dynamic>{
    'key': ord['keyId'],
    'order_id': ord['orderId'],
    'amount': ord['amount'],
    'currency': ord['currency'],
    'name': brand,
    'description': ord['description'],
    'prefill': {'name': str(S.me?['name']), 'email': FirebaseAuth.instance.currentUser?.email ?? '', 'contact': () {
      final d = str(S.me?['mobile']).replaceAll(RegExp(r'\D'), '');
      return d.length > 10 ? d.substring(d.length - 10) : d;
    }()},
    'theme': {'color': _hex(S.K.c1)},
    'retry': {'enabled': true, 'max_count': 3},
    'modal': {'confirm_close': true, 'escape': false},
    if (o.pm.isNotEmpty)
      'config': {
        'display': {
          'blocks': {
            'pref': {'name': 'Pay with your choice', 'instruments': [for (final m in o.pm) {'method': m}]}
          },
          'sequence': ['block.pref'],
          'preferences': {'show_default_blocks': true},
        }
      },
  };
  try {
    f._slow?.cancel();
    rp.open(opts);
  } catch (e) {
    api('/v1/$kind/fail', {...ref, 'outcome': 'cancelled'}).catchError((_) => <String, dynamic>{});
    f.failed(o, soft0: true, msg: tr('Razorpay could not be opened. Please try again.'));
  }
}

/// payment status words
const pst = {'SUCCESS': ['Successful', 'g'], 'PENDING': ['Pending', 'y'], 'CREATED': ['Pending', 'y'], 'FAILED': ['Failed', 'r'], 'CANCELLED': ['Cancelled', 'm'], 'REFUNDED': ['Refunded', 'b']};
String pState(Doc p) => p['status'] == 'CREATED' && intv(p['expiresAt']) > 0 && now() > intv(p['expiresAt']) ? 'CANCELLED' : str(p['status']);
bool pIn(Doc p, String f) {
  final s = pState(p);
  return f == 'all' || (f == 'ok' && s == 'SUCCESS') || (f == 'pend' && (s == 'PENDING' || s == 'CREATED')) || (f == 'fail' && (s == 'FAILED' || s == 'CANCELLED')) || (f == 'ref' && (s == 'REFUNDED' || intv(p['refundedAmountPaise']) > 0));
}

int pWhen(Doc p) => intv(p['paidAt']) > 0 ? intv(p['paidAt']) : intv(p['createdAt']);
Widget pPill(Doc p) {
  final s = pState(p);
  final q = pst[s] ?? [s, 'm'];
  return Pill(q[0], tone: toneOf(q[1]));
}

/// D is used by the history cards
Map<String, Doc> billsOf() => D['bills'];
