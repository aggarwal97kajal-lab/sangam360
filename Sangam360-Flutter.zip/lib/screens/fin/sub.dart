import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/api.dart';
import '../../core/fs.dart';
import '../../core/kinds.dart';
import '../../core/nav.dart';
import '../../core/pdfs.dart';
import '../../core/plan.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/kit.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import 'pay.dart';
import '../../l10n/l10n.dart';

/* ===================== the Plan tab (main admin) ===================== */

/// every plan payment of this organisation, asked from the payment server, which alone keeps these records
class SubHist extends ChangeNotifier {
  static final SubHist I = SubHist._();
  SubHist._();
  String sid = '';
  int at = 0;
  List<Doc>? _list;
  bool busy = false, err = false;

  List<Doc> list() => sid == S.sid && _list != null ? _list! : const [];
  bool get got => payApi.isEmpty || (sid == S.sid && _list != null);
  bool get bad => sid == S.sid && err;

  Future<void> load([bool force = false]) async {
    if (payApi.isEmpty || S.me == null || !S.isMgr || S.sid == null) return;
    final s = S.sid!;
    if (sid != s) {
      sid = s;
      at = 0;
      _list = null;
      busy = false;
      err = false;
    }
    if (busy || (!force && now() - at < 120000)) return;
    busy = true;
    err = false;
    at = now();
    try {
      final r = await api('/v1/subscriptions/history', {'sid': s});
      if (sid != s) return;
      _list = [for (final x in listv(r['payments'])) Map<String, dynamic>.from(x as Map)];
    } catch (_) {
      if (sid != s) return;
      err = true;
      at = 0;
    }
    busy = false;
    notifyListeners();
  }
}

/// "Plan invoices": one small card; tapping it opens the invoices month by month
class PlanInvCard extends StatelessWidget {
  const PlanInvCard({super.key});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    return ListenableBuilder(
      listenable: SubHist.I,
      builder: (_, __) {
        final h = SubHist.I, L = h.list();
        final last = L.isNotEmpty ? L.first : null;
        final sub = L.isNotEmpty
            ? trf('{0} invoice{1} · latest {2}', [L.length, (L.length == 1 ? '' : 's'), bdate(pWhen(last!))])
            : h.got
                ? tr('No invoices yet · they appear here when you buy a plan')
                : h.bad
                    ? tr('Could not load · tap to try again')
                    : tr('Loading…');
        return AppCard(
          onTap: () {
            if (!h.got) h.load(true);
            invSheet(context);
          },
          child: Row(children: [
            Container(width: 44, height: 44, alignment: Alignment.center, decoration: BoxDecoration(color: p.tint, borderRadius: BorderRadius.circular(14)), child: const Text('🧾', style: TextStyle(fontSize: 22))),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(tr('Plan invoices'), style: h3()), const SizedBox(height: 2), Text(sub, style: meta())])),
            Icon(Icons.chevron_right_rounded, color: p.muted),
          ]),
        );
      },
    );
  }
}

String _invOpen = '';
void invSheet(BuildContext context) {
  sheet(context, (_) => ListenableBuilder(
        listenable: SubHist.I,
        builder: (c, __) => StatefulBuilder(builder: (c, set) {
          final h = SubHist.I, L = h.list(), p = pal;
          final by = <String, List<Doc>>{};
          for (final v in L) {
            final d = dtOf(pWhen(v));
            (by['${d.year}-${p2(d.month)}'] ??= []).add(v);
          }
          final K = by.keys.toList()..sort((a, b) => b.compareTo(a));
          if (by[_invOpen] == null && _invOpen != '-') _invOpen = K.isNotEmpty ? K.first : '';
          return Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
            const SheetTitle('🧾 Plan invoices', sub: 'Month by month. Tap a month to see the invoice of the plan you bought or renewed in it.'),
            if (K.isEmpty) ...[
              Empty(h.got ? 'No invoices yet' : h.bad ? 'Could not load your invoices' : 'Loading your invoices…', icon: '🧾'),
              Text(
                  h.got
                      ? trf('You have not bought a plan for this {0} yet. When you buy or renew one in the Plan tab, its invoice appears here under that month.', [S.K.word])
                      : h.bad
                          ? tr('Check your internet connection and try again.')
                          : tr('This can take a moment.'),
                  style: meta(),
                  textAlign: TextAlign.center),
              if (h.bad) Padding(padding: const EdgeInsets.only(top: 12), child: Btn(tr('Try again'), small: true, onTap: () => h.load(true))),
            ],
            for (final k in K) ...[
              InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => set(() => _invOpen = _invOpen == k ? '-' : k),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(color: k == _invOpen ? p.tint : p.card2, borderRadius: BorderRadius.circular(14)),
                  child: Row(children: [
                    Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(mname(k), style: h3()),
                      Text(trf('{0} invoice{1} · {2}', [by[k]!.length, (by[k]!.length == 1 ? '' : 's'), rs(by[k]!.fold<num>(0, (a, v) => a + numv(v['amount'])))]), style: small()),
                    ])),
                    AnimatedRotation(turns: k == _invOpen ? .25 : 0, duration: const Duration(milliseconds: 200), child: Icon(Icons.chevron_right_rounded, color: p.muted)),
                  ]),
                ),
              ),
              if (k == _invOpen)
                for (final v in by[k]!)
                  Builder(builder: (_) {
                    final I = planInv(v);
                    return Item(children: [
                      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(I.desc, style: h3()),
                          Meta(trf('Paid {0}{1}', [dtm(pWhen(v)), (payMeth(v['paymentMethod']).isNotEmpty ? ' · ${payMeth(v['paymentMethod'])}' : '')])),
                          Meta(trf('Invoice {0}', [I.no])),
                        ])),
                        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(rs(v['amount']), style: h3()), const SizedBox(height: 4), pPill(v)]),
                      ]),
                      const SizedBox(height: 10),
                      Btn.o(tr('⬇️ Download invoice'), small: true, onTap: () => planInvoice(v).catchError((x) => fail(x, tr("Couldn't create invoice")))),
                    ]);
                  }),
            ],
          ]);
        }),
      ));
}

class SubTab extends StatefulWidget {
  const SubTab({super.key});
  @override
  State<SubTab> createState() => _SubTabState();
}

class _SubTabState extends State<SubTab> {
  String? cyc;
  final _plansKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    SubHist.I.load();
  }

  void _toPlans() {
    final c = _plansKey.currentContext;
    if (c != null) Scrollable.ensureVisible(c, duration: const Duration(milliseconds: 400), curve: Curves.easeOutCubic);
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([S, SubHist.I]),
      builder: (_, __) {
        if (!S.isMgr) {
          return ListView(padding: const EdgeInsets.all(16), children: [_head(tr('⭐ Your plan'), PlanSt.name(), '', null, false)]);
        }
        final (sub, p, cy) = PlanSt.info();
        final until = intv(sub['until']);
        final ex = until > 0 && until <= now();
        final left = until > 0 ? (ex ? 0 : dayGap(until).clamp(0, 99999)) : null;
        final pst = PlanSt.state();
        final status = until > 0
            ? (ex ? trf('⚠️ Expired on {0}', [dt(until)]) : trf('Active · {0} (until {1})', [(left! > 0 ? trf('{0} day{1} left', [left, (left == 1 ? '' : 's')]) : tr('last day today')), dt(until)]))
            : pst.kind == 'trial'
                ? trf('Free trial · {0} day{1} left (until {2})', [pst.left, (pst.left == 1 ? '' : 's'), dt(pst.until)])
                : pst.kind == 'locked'
                    ? trf('⚠️ Free trial ended on {0} — upgrade to continue.', [dt(pst.until)])
                    : trf('{0}-day free trial — pick a plan below any time.', [trialDays]);
        double? prog;
        if (until > 0 && !ex && cy != null) prog = ((left! / (cy == 'y' ? 365 : 30)).clamp(.04, 1.0)).toDouble();
        Widget? renew;
        if (S.isAdm && ex) {
          if (p != null && p.m > 0 && cy != null) {
            renew = Btn(trf('Renew {0} · {1} · {2}', [p.name, (cy == 'y' ? tr('1 year') : tr('30 days')), (rs(cy == 'y' ? p.y : p.m))]), small: true, onTap: () => paySheet(context, p, cy));
          } else if (p != null && p.m > 0) {
            renew = Btn(trf('Renew {0} plan', [p.name]), small: true, onTap: _toPlans);
          } else {
            renew = Btn(tr('Choose a plan to renew'), small: true, onTap: _toPlans);
          }
        }
        return ListView(physics: const BouncingScrollPhysics(), padding: const EdgeInsets.fromLTRB(16, 4, 16, 110), children: [
          if (!S.isAdm) Align(alignment: Alignment.centerLeft, child: TextButton(onPressed: () => nav.go('more'), child:  Text(tr('‹ Back')))),
          Enter(child: _head(tr('💳 Your subscription'), p != null && p.m > 0 ? '${p.name}${cy != null ? ' · ${cy == 'y' ? tr('Yearly') : tr('Monthly')}' : ''}' : tr('Free trial'), status, prog, ex || pst.kind == 'locked', renew)),
          const Enter(index: 1, child: PlanInvCard()),
          Enter(index: 2, child: KeyedSubtree(key: _plansKey, child: _plans(context))),
        ]);
      },
    );
  }

  Widget _head(String cap, String name, String status, double? prog, bool xp, [Widget? btn]) {
    final p = pal;
    final c1 = xp ? p.red : p.a, c2 = xp ? const Color(0xFFF97316) : p.rc;
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(gradient: LinearGradient(colors: [c1, c2], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(24), boxShadow: [BoxShadow(color: c1.withOpacity(.28), blurRadius: 24, offset: const Offset(0, 10))]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(cap, style: TextStyle(color: Colors.white.withOpacity(.85), fontWeight: FontWeight.w600, fontSize: 13)),
        const SizedBox(height: 6),
        Text(name, style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800, letterSpacing: -.4)),
        if (status.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(status, style: TextStyle(color: Colors.white.withOpacity(.92), fontSize: 13.5))),
        if (prog != null)
          Padding(
            padding: const EdgeInsets.only(top: 14),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: prog),
                duration: const Duration(milliseconds: 900),
                curve: Curves.easeOutCubic,
                builder: (_, v, __) => LinearProgressIndicator(value: v, minHeight: 8, backgroundColor: Colors.white.withOpacity(.25), valueColor: const AlwaysStoppedAnimation(Colors.white)),
              ),
            ),
          ),
        if (btn != null) Padding(padding: const EdgeInsets.only(top: 14), child: Theme(data: Theme.of(context), child: btn)),
      ]),
    );
  }

  Widget _plans(BuildContext context) {
    final p0 = pal;
    final n = PlanSt.unitsN(), adm = S.isAdm, PL = PlanSt.paid();
    final rec = PL.firstWhere((p) => n <= p.max, orElse: () => PL.last);
    cyc ??= PlanSt.info().$3 ?? 'm';
    final st = PlanSt.state();
    final cur = st.kind == 'paid' ? st.p : null, cc = cur != null ? PlanSt.info().$3 : null;
    return AppCard(title: '⭐ Subscription plans', children: [
      Text(trf('{0} · suggested plan: {1}', [(S.isOrg ? trf('Your {0} has {1}{2}', [S.K.word, n, (S.kind == 'school' ? ' users' : ' employees')]) : trf('Your society has {0} flats', [n])), rec.name]), style: meta()),
      if (st.kind != 'paid')
        Note(
            st.kind == 'locked'
                ? trf('🔒 {0} Choose a plan to continue.', [(st.why == 'expired' ? tr('Your plan has expired.') : tr('Your free trial has ended.'))])
                : st.kind == 'trial'
                    ? trf('🎁 Free trial: {0} day{1} left. Choose a plan any time to continue after the trial.', [st.left, (st.left == 1 ? '' : 's')])
                    : trf('🎁 Every new workspace starts with a {0}-day free trial.', [trialDays]),
            tone: st.kind == 'locked' ? Tone.r : Tone.y),
      const SizedBox(height: 12),
      Seg(const [('m', 'Monthly'), ('y', 'Yearly · save 17%')], cyc!, (v) => setState(() => cyc = v)),
      AnimatedSwitcher(
        duration: const Duration(milliseconds: 250),
        child: Column(key: ValueKey(cyc), children: [
          for (final p in PL)
            Builder(builder: (_) {
              final same = cur != null && cur.id == p.id, isCur = same && (cc == null || cc == cyc), hi = cur != null ? isCur : p == rec;
              final t = PlanSt.tier(p);
              Widget act;
              if (isCur) {
                act =  Btn.o(tr('✓ Active plan'), small: true);
              } else if (p.m > 0 && adm) {
                act = Btn(same ? trf('Switch to {0} billing', [(cyc == 'y' ? 'yearly' : 'monthly')]) : '${cur != null && cur.m > p.m ? tr('Switch to ') : tr('Upgrade to ')}${p.name}', small: true, kind: hi ? BtnKind.primary : BtnKind.outline, onTap: () => paySheet(context, p, cyc!));
              } else if (p.cu) {
                act = Btn.o(tr('Contact sales'), small: true, onTap: () => launchUrl(Uri.parse('mailto:$supportEmail?subject=${Uri.encodeComponent('$brand ${p.name} plan · ${str(S.soc?['name'])}')}')));
              } else {
                act =  Btn.o(tr('Free forever'), small: true);
              }
              return AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.only(top: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: isCur ? p0.tint : p0.card,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: isCur ? p0.a : (cur == null && p == rec ? t.$2 : p0.line), width: isCur || (cur == null && p == rec) ? 1.6 : 1),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Text(t.$1, style: const TextStyle(fontSize: 18)),
                    const SizedBox(width: 8),
                    Expanded(child: Text(p.name, style: h3())),
                    if (isCur)  Pill(tr('Current'), tone: Tone.g) else if (cur == null && p == rec)  Pill(tr('Suggested'), tone: Tone.a),
                  ]),
                  const SizedBox(height: 6),
                  Text(p.m > 0 ? '${rs(cyc == 'm' ? p.m : p.y)}${cyc == 'm' ? tr(' / month') : tr(' / year')}' : (p.cu ? tr('Custom pricing') : tr('Free')), style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: t.$2)),
                  const SizedBox(height: 8),
                  for (final f in p.f) Padding(padding: const EdgeInsets.only(bottom: 3), child: Text('✓ $f', style: body().copyWith(fontSize: 13.5))),
                  const SizedBox(height: 10),
                  act,
                ]),
              );
            }),
        ]),
      ),
      if (!adm) Padding(padding: const EdgeInsets.only(top: 10), child: Text(trf('Only the main admin of this {0} can change the plan.', [S.K.word]), style: meta())),
    ]);
  }
}

/// choose how to pay for a plan; explains what the payment buys (remaining days carried forward)
void paySheet(BuildContext context, Plan p, String cyc) {
  final st = PlanSt.state(), run = st.kind == 'paid' && st.until > now();
  final left = run ? dayGap(st.until).clamp(0, 99999) : 0, days = cyc == 'y' ? 365 : 30;
  final e = dtOf(run ? st.until : now()).add(Duration(days: days)), nx = e.add(const Duration(days: 1));
  final note = trf('{0}{1}{2} and is valid till {3}. Next renewal: {4}.', [(left > 0 ? trf('Your {0} remaining day{1} carried forward: {2} + {3} = {4} days. ', [left, (left == 1 ? ' is' : 's are'), left, days, left + days]) : ''), p.name, (run && st.p?.id == p.id ? ' continues' : tr(' starts today')), bdate(e.millisecondsSinceEpoch), bdate(nx.millisecondsSinceEpoch)]);
  final pp = pal;
  sheet(context, (c) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
        SheetTitle(trf(S.skE('Pay for {0}'), [p.name]), sub: trf(S.skE('{0}{1} · choose how to pay'), [(rs(cyc == 'm' ? p.m : p.y)), (cyc == 'm' ? ' per month' : ' per year')])),
        Note(note, margin: const EdgeInsets.only(bottom: 12)),
        for (final x in payMethods)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Material(
              color: pp.card2,
              borderRadius: BorderRadius.circular(16),
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () {
                  Navigator.of(c).pop();
                  _payPlan(p, cyc, x[4].isEmpty ? const <String>[] : [x[4]]);
                },
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(children: [
                    Text(x[1], style: const TextStyle(fontSize: 24)),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(tr(x[2]), style: h3()), Text(tr(x[3]), style: small())])),
                    Icon(Icons.chevron_right_rounded, color: pp.muted),
                  ]),
                ),
              ),
            ),
          ),
        Padding(padding: const EdgeInsets.only(top: 4), child: Text(tr('Secured by Razorpay.'), style: meta(), textAlign: TextAlign.center)),
      ]));
}

void _payPlan(Plan p, String cyc, List<String> pm) {
  payStart(
      'subscriptions',
      {'sid': S.sid, 'plan': p.id, 'cycle': cyc},
      PayOpts(
          plan: true,
          pm: pm,
          retry: () => _payPlan(p, cyc, pm),
          after: (_) async {
            try {
              final d = await socRef().get();
              final s = d.data()?['subscription'];
              if (s != null) S.soc!['subscription'] = s;
            } catch (_) {}
            S.touch();
            SubHist.I.load(true);
          })).catchError((e) => fail(e, tr('Payment failed')));
}
