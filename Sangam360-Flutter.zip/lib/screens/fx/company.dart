import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../core/files.dart';
import '../../core/fs.dart';
import '../../core/kinds.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/media.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import 'fx.dart';
import '../../l10n/l10n.dart';

/* =============================== COMPANY add-ons =============================== */
List<(String, String)> fxPOpts(List<Doc> P) => [for (final p in P) (str(p['uid']), '${p['name']}${str(p['flat']).isNotEmpty ? ' · ${p['flat']}' : ''}')];

/* ---------- Task assignment ---------- */
class TaskPage extends StatefulWidget {
  const TaskPage({super.key});
  @override
  State<TaskPage> createState() => _TaskPageState();
}

class _TaskPageState extends State<TaskPage> {
  String f = 'Open';

  void _edit([Doc? x]) {
    final P = fxPpl();
    if (P.isEmpty) {
      toast('ℹ️', tr('No employees yet'));
      return;
    }
    fxForm(context, x != null ? tr('Edit task') : tr('Assign a task'), tr('The person sees it under Tasks and marks it done.'), [
      FF('to', tr('Assign to'), type: 'select', opts: fxPOpts(P), val: x != null ? str(x['to']) : str(P.first['uid']), req: true),
      FF('title', tr('Task'), ph: tr('e.g. Send the March sales report'), req: true, val: x?['title'], max: 100),
      FF('desc', tr('Details'), type: 'area', val: x?['desc'], max: 600),
      FF('due', tr('Due date'), type: 'date', req: true, val: x != null ? str(x['due']) : td()),
      FF('pri', tr('Priority'), type: 'select', opts: SelectField.same(const ['Normal', 'High']), val: x != null ? str(x['pri']) : 'Normal', req: true),
    ], x != null ? tr('Save') : tr('Assign'), (v) async {
      final p = P.where((q) => q['uid'] == v['to']).firstOrNull;
      if (p == null) throw fxBadE(tr('Choose a person.'));
      final o = {'to': p['uid'], 'toName': p['name'], 'title': v['title'], 'desc': v['desc'], 'due': v['due'], 'pri': v['pri']};
      if (x != null) {
        await updateDoc(dref('tasks', str(x['id'])), o);
      } else {
        await fxAdd('tasks', {...o, 'status': 'Open', 'uid': S.uid, 'byName': S.me!['name']});
      }
      toast('✅', x != null ? tr('Saved') : tr('Task assigned'), str(p['name']));
    });
  }

  void _done(Doc x) {
    final n = TextEditingController();
    sheet(context, (c) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
          SheetTitle('Mark as done', sub: str(x['title'])),
          Field(n, 'Add a note for your manager (optional)', lines: 3, max: 300),
          Btn.g(tr('✓ Done'), onTap: () async {
            await updateDoc(dref('tasks', str(x['id'])), {'status': 'Done', 'doneTs': now(), 'doneNote': n.text.trim()});
            if (c.mounted) Navigator.of(c).pop();
            toast('✅', tr('Task done'));
          }),
        ]));
  }

  @override
  Widget build(BuildContext context) {
    final adm = S.isAdm, p = pal;
    return QList(
      query: adm ? col('tasks').orderBy('ts', descending: true).limit(400) : col('tasks').where('to', isEqualTo: S.uid).limit(200),
      allowEmpty: true,
      builder: (_, L) {
        final fs = [('Open', 'Open'), ('Done', 'Done'), ('All', 'All'), if (adm) ('Mine', 'Assigned to me')];
        final R = L.where((x) => f == 'All' || (f == 'Mine' ? x['to'] == S.uid : x['status'] == f)).toList()
          ..sort((a, b) => a['status'] == b['status']
              ? str(a['due']).compareTo(str(b['due']))
              : a['status'] == 'Open'
                  ? -1
                  : 1);
        return fxBody([
          FxHead(adm ? tr('Team tasks') : tr('My tasks'), sub: adm ? tr('Give a task with a due date. The person marks it done, and you see it here.') : tr('Tasks your manager has given you.'), btn: adm ? tr('＋ Assign a task') : null, onTap: () => _edit()),
          if (L.isEmpty)
            Empty(adm ? 'No tasks yet.' : 'You have no tasks. 🎉', icon: '✅')
          else ...[
            Chips([for (final k in fs) (k.$1, '${k.$2}${k.$1 == 'Open' || k.$1 == 'Done' ? ' · ${L.where((x) => x['status'] == k.$1).length}' : ''}')], f, (v) => setState(() => f = v)),
            if (R.isEmpty) const Empty('Nothing here.', icon: '✅'),
            for (final x in R)
              Builder(builder: (_) {
                final open = x['status'] == 'Open', ovd = open && str(x['due']).compareTo(td()) < 0, id = str(x['id']);
                return FxCard(bar: open ? (ovd ? p.red : p.a) : p.green, [
                  Wrap(spacing: 6, runSpacing: 4, crossAxisAlignment: WrapCrossAlignment.center, children: [
                    Pill(open ? (ovd ? tr('Overdue') : tr('Open')) : tr('Done ✓'), tone: open ? (ovd ? Tone.r : Tone.a) : Tone.g),
                    if (x['pri'] == 'High')  Pill(tr('High priority'), tone: Tone.r),
                    Text(trf('Due {0}', [fxDate(str(x['due']))]), style: small()),
                  ]),
                  const SizedBox(height: 6),
                  Text(str(x['title']), style: h3()),
                  if (str(x['desc']).isNotEmpty) Desc(str(x['desc'])),
                  Meta(trf('{0}From {1} · {2}', [(adm ? trf('To {0} · ', [x['toName']]) : ''), (str(x['byName']).isEmpty ? 'manager' : x['byName']), dt(x['ts'])])),
                  if (!open) Note(trf('Done on {0}{1}', [(dt(intv(x['doneTs']) > 0 ? x['doneTs'] : x['ts'])), (str(x['doneNote']).isNotEmpty ? ' — ${x['doneNote']}' : '')]), tone: Tone.g),
                  fxActs([
                    if (open && x['to'] == S.uid) mini(tr('✓ Mark as done'), () => _done(x), BtnKind.green),
                    if (adm && open && x['to'] != S.uid) mini(tr('✓ Done'), () => updateDoc(dref('tasks', id), {'status': 'Done', 'doneTs': now(), 'doneNote': 'Closed by ${S.me!['name']}'}), BtnKind.green),
                    if (adm && !open) mini(tr('Reopen'), () => updateDoc(dref('tasks', id), {'status': 'Open'})),
                    if (adm) mini(tr('Edit'), () => _edit(x)),
                    if (adm)
                      mini(tr('Delete'), () async {
                        if (await fxSure(context, tr('Delete this task?'))) await delDoc(dref('tasks', id));
                      }, BtnKind.red),
                  ]),
                ]);
              }),
          ],
        ]);
      },
    );
  }
}

/* ---------- Shift roster + swap requests ---------- */
DateTime fxMonday(DateTime d) {
  final x = DateTime(d.year, d.month, d.day);
  return x.subtract(Duration(days: (x.weekday + 6) % 7));
}

class ShiftPage extends StatefulWidget {
  const ShiftPage({super.key});
  @override
  State<ShiftPage> createState() => _ShiftPageState();
}

class _ShiftPageState extends State<ShiftPage> {
  late String wk = ymd(fxMonday(DateTime.now()));
  List<Doc> L = const [];

  List<DateTime> days() {
    final d0 = DateTime.parse('${wk}T00:00:00');
    return [for (var i = 0; i < 7; i++) DateTime(d0.year, d0.month, d0.day + i)];
  }

  String dl(DateTime d) => '${const ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][d.weekday - 1]} ${d.day} ${const ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.month - 1]}';
  String cell(String uid, int i) => str(mapv(L.where((x) => x['uid'] == uid).firstOrNull?['d'])['$i']);
  DocRef ref(String uid) => dref('shifts', '${wk}_$uid');
  Future<void> put(Doc p, int i, String v) => setDoc(ref(str(p['uid'])), {'uid': p['uid'], 'name': p['name'], 'week': wk, 'd': {'$i': v}, 'ts': now()}, merge: true);

  void _pick(Doc p, int i, DateTime d) => sheet(context, (c) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
        SheetTitle(str(p['name']), sub: dl(d)),
        for (final e in [...shiftNames.entries.map((e) => (e.key, e.value)), ('', 'Clear')])
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Btn(e.$2, small: true, kind: cell(str(p['uid']), i) == e.$1 ? BtnKind.primary : BtnKind.outline, onTap: () async {
              await put(p, i, e.$1);
              if (c.mounted) Navigator.of(c).pop();
            }),
          ),
      ]));

  Future<void> _copy() async {
    final pd = DateTime.parse('${wk}T00:00:00').subtract(const Duration(days: 7));
    final s = await col('shifts').where('week', isEqualTo: ymd(pd)).limit(500).get();
    if (s.docs.isEmpty) {
      toast('ℹ️', tr("Last week's roster is empty"));
      return;
    }
    final bt = Batch();
    for (final x in s.docs) {
      final o = x.data();
      bt.set(ref(str(o['uid'])), {'uid': o['uid'], 'name': o['name'], 'week': wk, 'd': o['d'] ?? {}, 'ts': now()});
    }
    await bt.commit();
    toast('✅', tr('Copied from last week'));
  }

  void _swap() {
    final P = fxPpl().where((p) => p['uid'] != S.uid).toList(), D7 = days();
    if (P.isEmpty) {
      toast('ℹ️', tr('No colleagues to swap with'));
      return;
    }
    fxForm(context, tr('Request a shift swap'), tr('Your manager approves it. The roster changes only after approval.'), [
      FF('day', tr('Which day?'), type: 'select', opts: [for (var i = 0; i < 7; i++) ('$i', '${dl(D7[i])} · ${shiftNames[cell(S.uid!, i)] ?? 'not set'}')], val: '0', req: true),
      FF('withUid', tr('Swap with'), type: 'select', opts: fxPOpts(P), val: str(P.first['uid']), req: true),
       FF('note', tr('Reason'), ph: tr('e.g. Family function'), max: 160),
    ], tr('Send request'), (v) async {
      final p = P.firstWhere((q) => q['uid'] == v['withUid']);
      await fxAdd('swaps', {'uid': S.uid, 'name': S.me!['name'], 'week': wk, 'day': int.parse(str(v['day'])), 'withUid': p['uid'], 'withName': p['name'], 'note': v['note'], 'status': 'Pending'});
      toast('✅', tr('Request sent'));
    });
  }

  Future<void> _approve(Doc q) async {
    final day = intv(q['day']);
    final a = cell(str(q['uid']), day), c = cell(str(q['withUid']), day);
    final bt = Batch();
    bt.set(ref(str(q['uid'])), {'uid': q['uid'], 'name': q['name'], 'week': wk, 'd': {'$day': c}, 'ts': now()}, merge: true);
    bt.set(ref(str(q['withUid'])), {'uid': q['withUid'], 'name': q['withName'], 'week': wk, 'd': {'$day': a}, 'ts': now()}, merge: true);
    bt.update(dref('swaps', str(q['id'])), {'status': 'Approved', 'by': S.uid, 'byName': S.me!['name']});
    await bt.commit();
    toast('✅', tr('Shifts swapped'));
  }

  static const _sc = {'M': Color(0xFFF59E0B), 'E': Color(0xFF6D5DFC), 'N': Color(0xFF0F172A), 'G': Color(0xFF10B981), 'O': Color(0xFF94A3B8)};

  @override
  Widget build(BuildContext context) {
    final adm = S.isAdm, p = pal, D7 = days();
    void mv(int n) => setState(() => wk = ymd(DateTime.parse('${wk}T00:00:00').add(Duration(days: n))));
    final nav = Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(16), boxShadow: p.shadow),
      child: Row(children: [
        IconButton(tooltip: tr('Previous week'), onPressed: () => mv(-7), icon: const Icon(Icons.chevron_left_rounded)),
        Expanded(child: Text('${dl(D7[0])} – ${dl(D7[6])}', textAlign: TextAlign.center, style: h3())),
        IconButton(tooltip: tr('Next week'), onPressed: () => mv(7), icon: const Icon(Icons.chevron_right_rounded)),
      ]),
    );
    return QMulti(
      key: ValueKey(wk),
      queries: [col('shifts').where('week', isEqualTo: wk).limit(500), col('swaps').where('week', isEqualTo: wk).limit(200)],
      allowEmpty: true,
      builder: (_, ls) {
        L = ls[0];
        final SW = ls[1];
        final P = [...fxPpl()]..sort((a, b) => (b['uid'] == S.uid ? 1 : 0) - (a['uid'] == S.uid ? 1 : 0));
        final Q = SW.where((q) => adm || q['uid'] == S.uid || q['withUid'] == S.uid).toList()..sort((a, b) => intv(b['ts']).compareTo(intv(a['ts'])));
        return fxBody([
          nav,
          if (P.isEmpty)
            const Empty('No employees yet.', icon: '🕒')
          else ...[
            AppCard(
              padding: const EdgeInsets.all(8),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Table(
                  defaultColumnWidth: const FixedColumnWidth(44),
                  columnWidths: const {0: FixedColumnWidth(110)},
                  defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                  children: [
                    TableRow(children: [
                      Padding(padding: const EdgeInsets.all(6), child: Text(tr('Name'), style: small().copyWith(fontWeight: FontWeight.w700))),
                      for (final d in D7) Column(children: [Text( [tr('Mon'), tr('Tue'), tr('Wed'), tr('Thu'), tr('Fri'), tr('Sat'), tr('Sun')][d.weekday - 1], style: small().copyWith(fontWeight: FontWeight.w700)), Text('${d.day}/${d.month}', style: small().copyWith(fontSize: 10))]),
                    ]),
                    for (final pp in P)
                      TableRow(decoration: pp['uid'] == S.uid ? BoxDecoration(color: p.tint, borderRadius: BorderRadius.circular(8)) : null, children: [
                        Padding(padding: const EdgeInsets.all(6), child: Text(str(pp['name']), maxLines: 1, overflow: TextOverflow.ellipsis, style: body().copyWith(fontSize: 13, fontWeight: FontWeight.w600))),
                        for (var i = 0; i < 7; i++)
                          Builder(builder: (_) {
                            final v = cell(str(pp['uid']), i);
                            return Padding(
                              padding: const EdgeInsets.all(3),
                              child: Tooltip(
                                message: shiftNames[v] ?? tr('Not set'),
                                child: InkWell(
                                  borderRadius: BorderRadius.circular(8),
                                  onTap: adm ? () => _pick(pp, i, D7[i]) : null,
                                  child: AnimatedContainer(
                                    duration: const Duration(milliseconds: 200),
                                    height: 34,
                                    alignment: Alignment.center,
                                    decoration: BoxDecoration(color: v.isEmpty ? p.card2 : (_sc[v] ?? p.a), borderRadius: BorderRadius.circular(8)),
                                    child: Text(v.isEmpty ? '·' : v, style: TextStyle(color: v.isEmpty ? p.faint : Colors.white, fontWeight: FontWeight.w800)),
                                  ),
                                ),
                              ),
                            );
                          }),
                      ]),
                  ],
                ),
              ),
            ),
            Meta(trf('M Morning · E Evening · N Night · G General · O Off{0}', [(adm ? tr(' — tap a box to set the shift.') : '')])),
            fxActs([
              if (adm)
                mini(tr("Copy last week's roster"), () async {
                  if (L.isEmpty || await fxSure(context, tr("Replace this week's roster with last week's?"), danger: false)) await _copy();
                }),
              mini(tr('⇄ Request a swap'), _swap, BtnKind.primary),
            ]),
            if (Q.isNotEmpty) ...[
              fxSec(tr('Swap requests')),
              for (final q in Q)
                Builder(builder: (_) {
                  final s = str(q['status']), day = intv(q['day']), id = str(q['id']);
                  return FxCard([
                    Row(children: [Pill(s, tone: s == 'Pending' ? Tone.a : s == 'Approved' ? Tone.g : Tone.r), const Spacer(), Text(dl(day >= 0 && day < 7 ? D7[day] : D7[0]), style: small())]),
                    const SizedBox(height: 6),
                    Text('${q['name']} ⇄ ${q['withName']}', style: h3()),
                    Meta('${shiftNames[cell(str(q['uid']), day)] ?? tr('not set')} ⇄ ${shiftNames[cell(str(q['withUid']), day)] ?? tr('not set')}${str(q['note']).isNotEmpty ? ' · ${q['note']}' : ''}'),
                    fxActs([
                      if (adm && s == 'Pending') mini(tr('Approve'), () => _approve(q), BtnKind.green),
                      if (adm && s == 'Pending') mini(tr('Reject'), () => updateDoc(dref('swaps', id), {'status': 'Rejected', 'by': S.uid, 'byName': S.me!['name']}), BtnKind.red),
                      if (q['uid'] == S.uid && s == 'Pending') mini(tr('Cancel'), () => delDoc(dref('swaps', id)), BtnKind.red),
                      if (adm && s != 'Pending') mini(tr('Remove'), () => delDoc(dref('swaps', id)), BtnKind.red),
                    ]),
                  ]);
                }),
            ],
          ],
        ]);
      },
    );
  }
}

/* ---------- Payslips & letters (private to each employee) ---------- */
class PayPage extends StatefulWidget {
  const PayPage({super.key});
  @override
  State<PayPage> createState() => _PayPageState();
}

class _PayPageState extends State<PayPage> {
  String who = 'All';
  String mlbl(dynamic m) => RegExp(r'^\d{4}-\d{2}$').hasMatch(str(m)) ? mname(str(m)) : '';

  void _up() {
    final P = fxPpl().where((p) => S.kind != 'school' || !S.isStu(p)).toList();
    if (P.isEmpty) {
      toast('ℹ️', tr('No employees yet'));
      return;
    }
    fxForm(context, tr('Upload a document'), tr('Only this employee and you (the admin) can open it.'), [
      FF('to', tr('Employee'), type: 'select', opts: fxPOpts(P), val: who != 'All' && P.any((p) => p['uid'] == who) ? who : str(P.first['uid']), req: true),
      FF('kind', tr('Type'), type: 'select', opts: SelectField.same(payKinds), val: 'Payslip', req: true),
      FF('month', tr('Month'), type: 'month', val: td().substring(0, 7)),
       FF('title', tr('Title'), ph: tr('e.g. Salary slip'), max: 60),
       FF('file', tr('File (PDF or photo, up to 3 MB)'), type: 'file', accept: 'application/pdf,image/*', req: true),
    ], tr('Upload'), (v) async {
      final p = P.firstWhere((q) => q['uid'] == v['to']);
      final f = v['file'];
      if (f.size > 5 * 1048576 && !f.isImg) throw fxBadE(tr('File is too large (max 5 MB).'));
      final url = await up(f.bytes, 'docs', f.name);
      await fxAdd('payslips', {'to': p['uid'], 'toName': p['name'], 'kind': v['kind'], 'month': v['month'], 'title': v['title'], 'file': {'url': url, 'name': f.name, 'type': f.mime, 'size': f.size}, 'uid': S.uid, 'byName': S.me!['name']});
      toast('✅', tr('Uploaded'), str(p['name']));
    });
  }

  @override
  Widget build(BuildContext context) {
    final hr = S.isOwner;
    return QList(
      query: hr ? col('payslips').orderBy('ts', descending: true).limit(500) : col('payslips').where('to', isEqualTo: S.uid).limit(200),
      allowEmpty: true,
      builder: (_, L) {
        var R = L;
        final ids = L.map((x) => str(x['to'])).toSet().toList();
        if (hr && who != 'All') R = L.where((x) => x['to'] == who).toList();
        R = [...R]..sort((a, b) => intv(b['ts']).compareTo(intv(a['ts'])));
        return fxBody([
          FxHead(hr ? tr('Payslips & letters') : tr('My documents'), sub: hr ? tr('Upload a payslip or letter for one employee. Nobody else can open it.') : trf('Payslips and letters from your {0}. Only you can open them.', [S.K.word]), btn: hr ? tr('⬆ Upload a document') : null, onTap: _up),
          if (L.isEmpty) Empty(hr ? 'Nothing uploaded yet.' : 'No documents for you yet.', icon: '📄'),
          if (hr && ids.length > 1) SelectField('Employee', who, [('All', 'All employees'), for (final i in ids) (i, str(L.firstWhere((x) => x['to'] == i)['toName']).isEmpty ? i : str(L.firstWhere((x) => x['to'] == i)['toName']))], (v) => setState(() => who = v)),
          for (final x in R)
            Builder(builder: (_) {
              final fl = mapv(x['file']);
              return FxCard([
                Row(children: [Pill(str(x['kind']), tone: Tone.b), const Spacer(), if (mlbl(x['month']).isNotEmpty) Text(mlbl(x['month']), style: small())]),
                const SizedBox(height: 6),
                Text(str(x['title']).isNotEmpty ? str(x['title']) : '${x['kind']}${mlbl(x['month']).isNotEmpty ? ' · ${mlbl(x['month'])}' : ''}', style: h3()),
                Meta(trf('{0}Uploaded {1}', [(hr ? trf('For {0} · ', [x['toName']]) : ''), dt(x['ts'])])),
                fxActs([
                  mini(tr('📄 Open'), () => openRef(context, str(fl['url']), name: str(fl['name']), mime: str(fl['type'])), BtnKind.primary),
                  if (hr)
                    mini(tr('Delete'), () async {
                      if (!await fxSure(context, tr('Delete this document?'))) return;
                      await delDoc(dref('payslips', str(x['id'])));
                      rmFile(fl['url']);
                    }, BtnKind.red),
                ]),
              ]);
            }),
        ]);
      },
    );
  }
}

/* ---------- Asset tracking ---------- */
class AssetPage extends StatefulWidget {
  const AssetPage({super.key});
  @override
  State<AssetPage> createState() => _AssetPageState();
}

class _AssetPageState extends State<AssetPage> {
  String f = 'All';

  void _edit([Doc? x]) => fxForm(context, x != null ? tr('Edit asset') : tr('Add an asset'), '', [
        FF('name', tr('Item'), ph: tr('e.g. Dell Latitude 5440'), req: true, val: x?['name'], max: 60),
        FF('type', tr('Type'), type: 'select', opts: SelectField.same(assetKinds), val: x != null ? str(x['type']) : 'Laptop', req: true),
        FF('tag', tr('Serial / asset no.'), ph: tr('e.g. LAP-0042'), val: x?['tag'], max: 40),
        FF('note', tr('Note'), val: x?['note'], max: 160),
      ], tr('Save'), (v) async {
        if (x != null) {
          await updateDoc(dref('assets', str(x['id'])), v);
        } else {
          await fxAdd('assets', {...v, 'to': '', 'toName': '', 'log': [], 'uid': S.uid});
        }
        toast('✅', tr('Saved'));
      });

  void _give(Doc x) {
    final P = fxPpl();
    if (P.isEmpty) return;
    fxForm(context, tr('Give to an employee'), '${x['name']}${str(x['tag']).isNotEmpty ? ' · ${x['tag']}' : ''}', [
      FF('to', tr('Employee'), type: 'select', opts: fxPOpts(P), val: str(P.first['uid']), req: true),
      FF('date', tr('Given on'), type: 'date', val: td(), req: true),
    ], tr('Save'), (v) async {
      final p = P.firstWhere((q) => q['uid'] == v['to']);
      final ts = DateTime.parse('${v['date']}T12:00:00').millisecondsSinceEpoch;
      await updateDoc(dref('assets', str(x['id'])), {
        'to': p['uid'],
        'toName': p['name'],
        'givenTs': ts,
        'log': FieldValue.arrayUnion([
          {'a': 'Given to', 'name': p['name'], 'ts': ts}
        ])
      });
      toast('✅', trf('Given to {0}', [p['name']]));
    });
  }

  void _hist(Doc x) {
    final H = listv(x['log']).map(mapv).toList()..sort((a, b) => intv(b['ts']).compareTo(intv(a['ts'])));
    sheet(context, (c) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
          SheetTitle(str(x['name']), sub: 'History'),
          if (H.isEmpty) Text(tr('Not given to anyone yet.'), style: meta()),
          for (final h in H) Ex('${h['a']} ${h['name']}', sub: '${dt(h['ts'])} ${dtOf(h['ts']).year}'),
        ]));
  }

  @override
  Widget build(BuildContext context) {
    final adm = S.isAdm, p = pal;
    return QList(
      query: adm ? col('assets').limit(600) : col('assets').where('to', isEqualTo: S.uid).limit(100),
      allowEmpty: true,
      builder: (_, L) {
        var R = L;
        if (adm) R = L.where((x) => f == 'All' || (f == 'Out' ? str(x['to']).isNotEmpty : str(x['to']).isEmpty)).toList();
        R = [...R]..sort((a, b) => str(a['name']).compareTo(str(b['name'])));
        return fxBody([
          FxHead(adm ? tr('Company assets') : tr('My assets'), sub: adm ? tr('Record what was given to whom, and when it came back.') : tr('Things the company has given you.'), btn: adm ? tr('＋ Add an asset') : null, onTap: () => _edit()),
          if (L.isEmpty)
            Empty(adm ? 'No assets yet.' : 'Nothing is recorded in your name.', icon: '💻')
          else ...[
            if (adm) Chips([('All', 'All · ${L.length}'), ('Out', 'Given · ${L.where((x) => str(x['to']).isNotEmpty).length}'), ('In', 'In stock · ${L.where((x) => str(x['to']).isEmpty).length}')], f, (v) => setState(() => f = v)),
            if (R.isEmpty) const Empty('Nothing here.', icon: '💻'),
            for (final x in R)
              Builder(builder: (_) {
                final out = str(x['to']).isNotEmpty, id = str(x['id']);
                return FxCard(bar: out ? p.amber : p.green, [
                  Wrap(spacing: 6, children: [Pill(str(x['type']), tone: Tone.b), Pill(out ? tr('Given') : tr('In stock'), tone: out ? Tone.a : Tone.g)]),
                  const SizedBox(height: 6),
                  Text(str(x['name']), style: h3()),
                  Meta('${str(x['tag']).isNotEmpty ? trf('No. {0} · ', [x['tag']]) : ''}${out ? '${adm ? trf('With {0} since ', [x['toName']]) : tr('With you since ')}${dt(intv(x['givenTs']) > 0 ? x['givenTs'] : x['ts'])}' : tr('Not given to anyone')}'),
                  if (str(x['note']).isNotEmpty) Meta(str(x['note'])),
                  if (adm)
                    fxActs([
                      if (out)
                        mini(tr('↩ Mark returned'), () => updateDoc(dref('assets', id), {
                              'to': '',
                              'toName': '',
                              'returnedTs': now(),
                              'log': FieldValue.arrayUnion([
                                {'a': 'Returned by', 'name': x['toName'], 'ts': now()}
                              ])
                            }), BtnKind.green)
                      else
                        mini(tr('Give to employee'), () => _give(x), BtnKind.primary),
                      mini(tr('History'), () => _hist(x)),
                      mini(tr('Edit'), () => _edit(x)),
                      mini(tr('Delete'), () async {
                        if (await fxSure(context, trf('Delete {0}?', [x['name']]))) await delDoc(dref('assets', id));
                      }, BtnKind.red),
                    ]),
                ]);
              }),
          ],
        ]);
      },
    );
  }
}

/* ---------- Expense claims ---------- */
const _clmc = {'Pending': Tone.a, 'Approved': Tone.b, 'Paid': Tone.g, 'Rejected': Tone.r};

class ClaimPage extends StatefulWidget {
  const ClaimPage({super.key});
  @override
  State<ClaimPage> createState() => _ClaimPageState();
}

class _ClaimPageState extends State<ClaimPage> {
  String f = 'Pending';

  void _add() => fxForm(context, tr('New expense claim'), tr('Attach a photo of the bill so that it can be approved quickly.'), [
         FF('title', tr('What was it for?'), ph: tr('e.g. Cab to client office'), req: true, max: 80),
         FF('amount', tr('Amount (₹)'), type: 'number', req: true),
        FF('date', tr('Date of expense'), type: 'date', req: true, val: td()),
        FF('cat', tr('Category'), type: 'select', opts: SelectField.same(claimKinds), val: 'Travel', req: true),
         FF('img', tr('Photo of the bill'), type: 'file'),
         FF('note', tr('Note'), max: 200),
      ], tr('Submit claim'), (v) async {
        if (str(v['date']).compareTo(td()) > 0) throw fxBadE(tr('The date cannot be in the future.'));
        final img = v['img'] != null ? await up(v['img'].bytes, 'chat', 'bill.jpg') : '';
        await fxAdd('claims', {...fxMe(), 'title': v['title'], 'amount': ((v['amount'] as num) * 100).round() / 100, 'date': v['date'], 'cat': v['cat'], 'note': v['note'], 'img': img, 'status': 'Pending'});
        toast('✅', tr('Claim submitted'));
      });

  Future<void> _set(Doc x, String status, [String? why]) => updateDoc(dref('claims', str(x['id'])), {'status': status, 'by': S.uid, 'byName': S.me!['name'], 'decTs': now(), if (why != null) 'why': why});

  Future<void> _reject(Doc x) async {
    final why = await promptDlg(context, trf('Reject claim\n{0} · {1}\n\nReason (the employee sees this):', [x['name'], rs(x['amount'])]), ok: tr('Reject'), max: 200);
    if (why == null) return;
    await _set(x, 'Rejected', why.trim());
  }

  @override
  Widget build(BuildContext context) {
    final adm = S.isAdm, p = pal;
    return QList(
      query: adm ? col('claims').orderBy('ts', descending: true).limit(500) : col('claims').where('uid', isEqualTo: S.uid).limit(200),
      allowEmpty: true,
      builder: (_, L) {
        final fs = adm ? const [('Pending', 'Pending'), ('Approved', 'To pay'), ('Paid', 'Paid'), ('Rejected', 'Rejected'), ('Mine', 'My claims'), ('All', 'All')] : const [('Pending', 'Pending'), ('Approved', 'Approved'), ('Paid', 'Paid'), ('Rejected', 'Rejected'), ('All', 'All')];
        List<Doc> pick(String k) => L.where((x) => k == 'All' || (k == 'Mine' ? x['uid'] == S.uid : x['status'] == k)).toList();
        final R = pick(f)..sort((a, b) => intv(b['ts']).compareTo(intv(a['ts'])));
        final sum = R.fold<num>(0, (s, x) => s + numv(x['amount']));
        return fxBody([
          FxHead(adm ? tr('Expense claims') : tr('My expense claims'), sub: adm ? tr('Approve or reject claims, then mark them paid.') : tr('Paid for something for work? Claim it here with the bill.'), btn: tr('＋ New claim'), onTap: _add),
          if (L.isEmpty)
            const Empty('No claims yet.', icon: '🧾')
          else ...[
            Chips([for (final k in fs) (k.$1, '${k.$2}${k.$1 == 'All' || k.$1 == 'Mine' ? '' : ' · ${pick(k.$1).length}'}')], f, (v) => setState(() => f = v)),
            if (R.isEmpty) const Empty('Nothing here.', icon: '🧾') else Meta(trf('{0} claim{1} · total {2}', [R.length, (R.length == 1 ? '' : 's'), rs(sum)]), pad: const EdgeInsets.only(bottom: 8)),
            for (final x in R)
              Builder(builder: (_) {
                final s = str(x['status']);
                return FxCard(bar: toneColor(_clmc[s] ?? Tone.m), [
                  Row(children: [Pill(s, tone: _clmc[s] ?? Tone.m), const SizedBox(width: 6), Pill(str(x['cat']), tone: Tone.m), const Spacer(), Text(rs(x['amount']), style: h3().copyWith(color: p.a))]),
                  const SizedBox(height: 6),
                  Text(str(x['title']), style: h3()),
                  Meta(trf('{0}Spent on {1}', [(adm ? '${x['name']}${str(x['flat']).isNotEmpty ? ' · ${x['flat']}' : ''} · ' : ''), fxDate(str(x['date']))])),
                  if (str(x['note']).isNotEmpty) Meta(str(x['note'])),
                  if (s == 'Rejected' && str(x['why']).isNotEmpty) Note(trf('Reason: {0}', [x['why']]), tone: Tone.r) else if (str(x['byName']).isNotEmpty && s != 'Pending') Meta(trf('{0} by {1}', [s, x['byName']])),
                  fxActs([
                    if (okImg(x['img'])) mini(tr('🧾 View bill'), () => openRef(context, str(x['img']), name: 'bill.jpg')),
                    if (adm && s == 'Pending') mini(tr('Approve'), () => _set(x, 'Approved'), BtnKind.green),
                    if (adm && s == 'Pending') mini(tr('Reject'), () => _reject(x), BtnKind.red),
                    if (adm && s == 'Approved') mini(tr('₹ Mark as paid'), () => _set(x, 'Paid'), BtnKind.green),
                    if (x['uid'] == S.uid && s == 'Pending')
                      mini(tr('Delete'), () async {
                        if (!await fxSure(context, tr('Delete this claim?'))) return;
                        await delDoc(dref('claims', str(x['id'])));
                        rmFile(x['img']);
                      }, BtnKind.red),
                  ]),
                ]);
              }),
          ],
        ]);
      },
    );
  }
}
