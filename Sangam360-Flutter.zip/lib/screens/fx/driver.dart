import 'dart:async';
import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';

import '../../core/files.dart';
import '../../core/fs.dart';
import '../../core/geo.dart';
import '../../core/kinds.dart';
import '../../core/listen.dart';
import '../../core/nav.dart';
import '../../core/perms.dart';
import '../../core/prefs.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/anim.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/media.dart';
import '../../ui/pick.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import '../maps.dart';
import 'fx.dart';
import 'school_bus.dart';

/* =====================================================================================================
   DRIVERS: their own dashboard (no classroom tools), vehicle papers, vehicle issues, incident reports,
   duty check-in with PIN + photo, alerts. Everything a driver reports is read by the Principal only.
   Collections: busveh/{bus id}, busissues, businc, drvmsg.
   ===================================================================================================== */

int? drvDays(dynamic d) {
  final s = str(d);
  if (s.isEmpty) return null;
  final t = DateTime.tryParse('${s}T00:00:00');
  if (t == null) return null;
  return (t.difference(DateTime.parse('${td()}T00:00:00')).inHours / 24).round();
}

/// papers of a vehicle that are over or due within 15 days -> (expired?, text)
(bool, String)? drvDocWarn(Doc? v) {
  final L = <(bool, String)>[];
  for (final k in const [['ins', 'Insurance'], ['puc', 'PUC'], ['svc', 'Service']]) {
    final n = drvDays(v?[k[0]]);
    if (n == null) continue;
    if (n < 0) {
      L.add((true, '${k[1]}${k[0] == 'svc' ? ' was due ' : ' expired '}${-n} day${n == -1 ? '' : 's'} ago'));
    } else if (n <= 15) {
      L.add((false, '${k[1]}${k[0] == 'svc' ? ' is due' : ' expires'}${n == 0 ? ' today' : ' in $n day${n == 1 ? '' : 's'}'}'));
    }
  }
  return L.isEmpty ? null : (L.any((a) => a.$1), '⚠️ ${L.map((a) => a.$2).join(' · ')}');
}

/* ---------- duty check-in: PIN, then a photo of the driver, then the trip can start ---------- */
String drvHash(String pin) => sha256.convert(utf8.encode('${S.sid}:${S.uid}:$pin')).toString();

class DrvDuty {
  static String _day = '', _uid = '';
  static Doc? _d;
  static bool _has = false;
  static void reset() {
    _has = false;
    _d = null;
  }

  static DocRef ref() => dref('attendance', '${S.uid}_${td()}');
  static Doc? get cached => _has && _day == td() && _uid == S.uid ? (_d ?? {}) : null;
  static bool get known => _has && _day == td() && _uid == S.uid;
  static Future<Doc?> load([bool force = false]) async {
    final day = td();
    if (!force && known) return _d;
    Doc? d;
    try {
      final s = await ref().get();
      d = s.exists ? s.data() : null;
    } catch (_) {}
    _day = day;
    _uid = S.uid ?? '';
    _d = d;
    _has = true;
    return d;
  }
}

/// -> {via:"pin",selfie} when the driver has proved it is them, null when they backed out
Future<Map<String, dynamic>?> drvVerify(BuildContext context) async {
  final r = await sheet<Map<String, dynamic>>(context, (c) => const _DrvVerify());
  return r;
}

class _DrvVerify extends StatefulWidget {
  const _DrvVerify();
  @override
  State<_DrvVerify> createState() => _DrvVerifyState();
}

class _DrvVerifyState extends State<_DrvVerify> {
  int step = 1, tries = 0;
  final p1 = TextEditingController(), p2 = TextEditingController();
  String err = '';
  PFile? shot;
  bool get has => str(S.me?['pinH']).isNotEmpty;

  Future<void> _next() async {
    setState(() => err = '');
    if (!RegExp(r'^\d{4}$').hasMatch(p1.text)) {
      setState(() => err = 'Enter 4 digits.');
      return;
    }
    if (!has) {
      if (p1.text != p2.text) {
        setState(() => err = 'The two PINs are not the same.');
        return;
      }
      final h = drvHash(p1.text);
      await updateDoc(memRef(S.uid!), {'pinH': h});
      S.me!['pinH'] = h;
      setState(() => step = 2);
      return;
    }
    if (drvHash(p1.text) != S.me!['pinH']) {
      tries++;
      p1.clear();
      setState(() => err = tries >= 5 ? 'Too many wrong tries. Ask the Principal to reset your PIN.' : 'Wrong PIN. Try again.');
      return;
    }
    setState(() => step = 2);
  }

  Future<void> _fin(PFile? f) async {
    var selfie = '';
    if (f != null) {
      try {
        selfie = await up(f.bytes, 'drv', 'duty.jpg', raw: true);
      } catch (_) {}
    }
    if (mounted) Navigator.of(context).pop({'via': 'pin', 'selfie': selfie});
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    if (step == 1) {
      return Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
        SheetTitle(has ? 'Duty check-in' : 'Choose your duty PIN', sub: has ? 'Enter your 4-digit PIN. The school sees that you are on duty.' : 'Pick a 4-digit PIN that only you know. You enter it every day before the first trip.'),
        Shake(trigger: tries, child: Field(p1, 'PIN', password: true, max: 4, kb: TextInputType.number, digitsOnly: true, center: true, autofocus: true, onChanged: (_) => setState(() => err = ''))),
        if (!has) Field(p2, 'Enter it once more', password: true, max: 4, kb: TextInputType.number, digitsOnly: true, center: true),
        if (err.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(err, style: TextStyle(color: p.red, fontWeight: FontWeight.w600))),
        Btn(has ? 'Next' : 'Save PIN', onTap: tries >= 5 ? null : _next, busyDone: false),
        if (has) Padding(padding: const EdgeInsets.only(top: 8), child: Text('Forgot the PIN? Ask the Principal to reset it (School buses → your bus → Reset driver PIN).', style: small(), textAlign: TextAlign.center)),
      ]);
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
      const SheetTitle('Photo for today', sub: 'Take a photo of your face. Only the Principal can see it, as proof that you are the one on duty.'),
      if (shot != null) Center(child: ClipRRect(borderRadius: BorderRadius.circular(18), child: Image.memory(shot!.bytes, height: 200, fit: BoxFit.cover))),
      const SizedBox(height: 10),
      Btn.o(shot == null ? '🤳 Take photo' : '🤳 Take again', small: true, onTap: () async {
        final f = await pickCamera(front: true);
        if (f != null) setState(() => shot = f);
      }),
      const SizedBox(height: 10),
      Btn('Check in', onTap: shot == null ? null : () => _fin(shot), busyDone: false),
      TextButton(onPressed: () => _fin(null), child: const Text('Camera not working? Check in without a photo')),
    ]);
  }
}

/// makes sure a driver has checked in today before a trip starts (teachers / the Principal driving are not asked)
Future<bool> drvDuty(BuildContext context) async {
  if (!S.isDrv) return true;
  final cur = await DrvDuty.load(true);
  if (cur != null && intv(cur['in']) > 0 && intv(cur['out']) == 0) return true;
  if (!context.mounted) return false;
  final dv = await drvVerify(context);
  if (dv == null) return false;
  final n0 = now();
  try {
    if (cur != null && intv(cur['in']) > 0) {
      await updateDoc(DrvDuty.ref(), {'out': 0});
    } else {
      await setDoc(DrvDuty.ref(), {'uid': S.uid, 'name': S.me!['name'], 'flat': str(S.me!['flat']), 'role': str(S.me!['role']), 'date': td(), 'in': n0, ...dv});
    }
  } on FirebaseException catch (e) {
    if (e.code == 'permission-denied') throw fxBadE('Check-in is not allowed right now. Please contact the Principal.');
    rethrow;
  }
  DrvDuty.reset();
  toast('✅', 'You are on duty', 'Checked in at ${tm(n0)}');
  Bus.I.ping();
  return true;
}

/* ---------- reports: vehicle issue (busissues) and incident (businc) ---------- */
void drvView(BuildContext context, String url, bool video) => openRef(context, url, name: video ? 'video.mp4' : 'photo.jpg', mime: video ? 'video/mp4' : '');

void drvRepForm(BuildContext context, String colName) => sheet(context, (c) => _DrvRepForm(colName));

class _DrvRepForm extends StatefulWidget {
  final String colName;
  const _DrvRepForm(this.colName);
  @override
  State<_DrvRepForm> createState() => _DrvRepFormState();
}

class _DrvRepFormState extends State<_DrvRepForm> {
  String type = '', err = '';
  late String bus = Bus.my.isNotEmpty ? Bus.my.keys.first : '';
  final note = TextEditingController();
  PFile? media;
  bool get inc => widget.colName == 'businc';

  @override
  Widget build(BuildContext context) {
    final p = pal;
    final T = inc ? drvInc : drvIss, B = Bus.my.values.toList();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
      SheetTitle(inc ? 'Report an incident' : 'Report a vehicle issue', sub: inc ? 'Goes straight to the Principal with the time, your bus and where you are.' : 'Tell the Principal what is wrong with the bus. Only the Principal sees it.'),
      GridView.count(
        crossAxisCount: 3,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
        childAspectRatio: 1.1,
        children: [
          for (final t in T)
            AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              decoration: BoxDecoration(color: type == t[0] ? p.a.withOpacity(.14) : p.card2, borderRadius: BorderRadius.circular(16), border: Border.all(color: type == t[0] ? p.a : p.line, width: type == t[0] ? 1.6 : 1)),
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => setState(() {
                  type = t[0];
                  err = '';
                }),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(t[1], style: const TextStyle(fontSize: 24)), const SizedBox(height: 4), Text(t[2], textAlign: TextAlign.center, style: small().copyWith(fontWeight: FontWeight.w600))]),
              ),
            ),
        ],
      ),
      const SizedBox(height: 12),
      if (B.length > 1) SelectField('Bus', bus, [for (final x in B) (str(x['id']), str(x['name']))], (v) => setState(() => bus = v)),
      Field(note, inc ? "What happened? (student's name, place…)" : 'Describe the problem', lines: 3, max: 600),
      Row(children: [
        Expanded(child: Text(media == null ? (inc ? '📎 Add a photo or video (optional)' : '📷 Add a photo (optional)') : '✓ ${cut(media!.name, 28)} · ${fuSize(media!.size)}', style: meta())),
        if (media != null) IconButton(onPressed: () => setState(() => media = null), icon: Icon(Icons.close_rounded, color: p.muted)),
        mini(media == null ? 'Choose' : 'Change', () async {
          final f = await pickPhotoSheet(context, title: inc ? 'Photo or video' : 'Photo', video: inc);
          if (f == null) return;
          final bad = checkFile(f, ext: inc ? const ['jpg', 'jpeg', 'png', 'mp4'] : const ['jpg', 'jpeg', 'png'], max: 5 * 1048576);
          if (bad != null) {
            toast('⚠️', bad);
            return;
          }
          setState(() => media = f);
        }),
      ]),
      if (err.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(err, style: TextStyle(color: p.red, fontWeight: FontWeight.w600))),
      const SizedBox(height: 10),
      Btn('Send to the Principal', busyDone: false, onTap: () async {
        if (type.isEmpty) {
          setState(() => err = 'Choose what it is about.');
          return;
        }
        if (!inc && note.text.trim().isEmpty && type == 'other') {
          setState(() => err = 'Describe the problem.');
          return;
        }
        final x = Bus.my[bus] ?? (B.isNotEmpty ? B.first : <String, dynamic>{});
        final t = T.firstWhere((q) => q[0] == type);
        var url = '';
        if (media != null) url = await up(media!.bytes, 'drv', media!.name, raw: true, mime: media!.mime);
        Doc? loc;
        if (inc && pHint('loc')) {
          try {
            final cp = await here().timeout(const Duration(seconds: 5));
            loc = {'lat': fix6(cp.latitude), 'lng': fix6(cp.longitude)};
          } catch (_) {}
        }
        await fxAdd(widget.colName, {
          'type': type,
          'label': t[2],
          'ic': t[1],
          'note': note.text.trim(),
          'busId': str(x['id']),
          'busName': str(x['name']),
          'tripId': busOn(x) ? str(x['tripId']) : '',
          'uid': S.uid,
          'name': S.me!['name'],
          'media': url,
          'video': media != null && media!.mime.startsWith('video/'),
          if (loc != null) 'loc': loc,
          'status': 'Open',
          'reply': '',
        });
        if (context.mounted) Navigator.of(context).pop();
        toast('✅', 'Sent to the Principal', t[2]);
      }),
    ]);
  }
}

/// L = the reports; adm = the Principal's view (can answer and close)
List<Widget> drvRepList(BuildContext context, String colName, List<Doc>? L, bool adm) {
  final inc = colName == 'businc';
  if (L == null) return const [Skeleton(n: 3)];
  if (L.isEmpty) return [Empty(adm ? (inc ? 'No incident has been reported.' : 'No vehicle issue has been reported.') : 'Nothing reported yet.', icon: inc ? '📝' : '🔧')];
  final p = pal;
  final s = [...L]..sort((a, b) => intv(b['ts']).compareTo(intv(a['ts'])));
  return [
    for (final r in s)
      Builder(builder: (_) {
        final st = str(r['status']).isEmpty ? 'Open' : str(r['status']), id = str(r['id']);
        final loc = mapv(r['loc']);
        return FxCard(bar: st == 'Resolved' ? p.green : st == 'In progress' ? p.blue : p.red, [
          Row(children: [Pill(st, tone: st == 'Resolved' ? Tone.g : st == 'In progress' ? Tone.b : Tone.r), const Spacer(), Text('${fxDate(ymd(dtOf(r['ts'])))} · ${tm(r['ts'])}', style: small())]),
          const SizedBox(height: 6),
          Text('${str(r['ic'])} ${str(r['label']).isNotEmpty ? r['label'] : r['type']}', style: h3()),
          Meta([if (str(r['busName']).isNotEmpty) '🚌 ${r['busName']}', if (adm) str(r['name'])].where((e) => e.isNotEmpty).join(' · ')),
          if (str(r['note']).isNotEmpty) Desc(str(r['note'])),
          if (str(r['reply']).isNotEmpty) Note('Principal: ${r['reply']}'),
          fxActs([
            if (str(r['media']).isNotEmpty) mini(r['video'] == true ? '▶ Video' : '🖼 Photo', () => drvView(context, str(r['media']), r['video'] == true)),
            if (loc['lat'] != null) mini('📍 Where', () => placeShow(context, numv(loc['lat']).toDouble(), numv(loc['lng']).toDouble(), title: str(r['label']).isEmpty ? 'Incident' : str(r['label']))),
            if (adm)
              for (final s2 in const ['In progress', 'Resolved'])
                if (s2 != st) mini(s2 == 'Resolved' ? '✓ Resolved' : s2, () => updateDoc(dref(colName, id), {'status': s2, 'doneTs': now()}), s2 == 'Resolved' ? BtnKind.green : BtnKind.outline),
            if (adm)
              mini('Reply', () async {
                final t = await promptDlg(context, 'Message to ${str(r['name']).isEmpty ? 'the driver' : r['name']}:', initial: str(r['reply']), ok: 'Send', max: 300);
                if (t != null) await updateDoc(dref(colName, id), {'reply': cut(t, 300)});
              }),
            if (adm)
              mini('Delete', () async {
                if (await fxSure(context, 'Delete this report?')) await delDoc(dref(colName, id));
              }, BtnKind.red),
          ]),
        ]);
      }),
  ];
}

/// a driver's own reports (vehicle issues / incidents)
class DrvRepPage extends StatelessWidget {
  final String kind; // iss | inc
  const DrvRepPage({super.key, required this.kind});
  @override
  Widget build(BuildContext context) {
    final iss = kind == 'iss', colName = iss ? 'busissues' : 'businc';
    return QList(
      query: col(colName).where('uid', isEqualTo: S.uid).limit(120),
      allowEmpty: true,
      builder: (_, L) => fxBody([
        FxHead(iss ? 'Report a vehicle issue' : 'Incident reports',
            sub: iss ? 'Brake, tyre, AC, battery or engine trouble: tell the Principal here. Only the Principal sees it.' : 'Anything that happens on a trip: a student, an accident, traffic, a breakdown. You can add a photo or a video.',
            btn: iss ? '＋ Report an issue' : '＋ New report',
            onTap: () => drvRepForm(context, colName)),
        ...drvRepList(context, colName, L, false),
      ]),
    );
  }
}

/* ---------- vehicle papers ---------- */
const vehDoc = [['rc', 'RC'], ['insf', 'Insurance'], ['pucf', 'PUC']];
Widget? vehDocLinks(BuildContext context, Doc? v) {
  final D2 = mapv(v?['docs']);
  final have = vehDoc.where((k) => str(mapv(D2[k[0]])['url']).isNotEmpty).toList();
  if (have.isEmpty) return null;
  return Wrap(spacing: 4, children: [
    for (final k in have)
      TextButton(
          onPressed: () {
            final d = mapv(D2[k[0]]);
            openRef(context, str(d['url']), name: str(d['name']), mime: str(d['type']));
          },
          child: Text('📄 ${k[1]}')),
  ]);
}

String _dtv(dynamic d) {
  if (str(d).isEmpty) return 'Not entered yet';
  final n = drvDays(d);
  return '${fxDate(str(d))}${n == null ? '' : n < 0 ? ' · expired' : n <= 15 ? ' · $n day${n == 1 ? '' : 's'} left' : ''}';
}

void busPapers(BuildContext context, Doc x, Doc? v0) {
  final v = v0 ?? {};
  final D2 = mapv(v['docs']);
  String has(String k) => str(mapv(D2[k])['url']).isNotEmpty ? ' · already added, choose a file to replace it' : '';
  const acc = 'application/pdf,image/jpeg,image/png';
  fxForm(context, 'Vehicle papers · ${x['name']}', 'The driver of this bus can see these papers. Nobody else in the school is shown them.', [
    FF('reg', 'Vehicle registration no.', ph: 'e.g. DL1PC 1234', val: v['reg'], max: 20),
    FF('ins', 'Insurance valid until', type: 'date', val: v['ins']),
    FF('puc', 'PUC valid until', type: 'date', val: v['puc']),
    FF('svc', 'Next service due', type: 'date', val: v['svc']),
    FF('rc', 'RC (registration certificate)${has('rc')}', type: 'file', accept: acc),
    FF('insf', 'Insurance policy${has('insf')}', type: 'file', accept: acc),
    FF('pucf', 'PUC certificate${has('pucf')}', type: 'file', accept: acc),
  ], 'Save', (q) async {
    final docs = Map<String, dynamic>.from(D2), gone = <String>[];
    for (final k in vehDoc) {
      final f = q[k[0]];
      if (f == null) continue;
      final url = await up(f.bytes, 'docs', f.name);
      final old = str(mapv(docs[k[0]])['url']);
      if (old.isNotEmpty && old != url) gone.add(old);
      docs[k[0]] = {'url': url, 'name': f.name, 'type': f.mime, 'size': f.size, 'ts': now()};
    }
    await setDoc(dref('busveh', str(x['id'])), {'busId': x['id'], 'busName': x['name'], 'reg': str(q['reg']).toUpperCase(), 'ins': str(q['ins']), 'puc': str(q['puc']), 'svc': str(q['svc']), 'docs': docs, 'ts': now()}, merge: true);
    for (final u in gone) {
      rmFile(u);
    }
    toast('✅', 'Papers saved', str(x['name']));
  });
}

Widget _vehCard(BuildContext context, Doc x, Doc v, {bool drv = false, bool ok = true}) {
  final w = drvDocWarn(v), dl = vehDocLinks(context, v);
  return FxCard([
    Text('🚌 ${x['name']}', style: h3()),
    if (drv && str(x['route']).isNotEmpty) Meta('🛣️ ${x['route']}'),
    if (!drv) Meta('Driver: ${str(x['driverName']).isEmpty ? '—' : x['driverName']}'),
    const SizedBox(height: 6),
    if (drv) KvRow('Bus number', str(x['name'])),
    KvRow('Vehicle registration', str(v['reg']).isEmpty ? 'Not entered yet' : str(v['reg'])),
    KvRow('Insurance expiry', _dtv(v['ins'])),
    KvRow('PUC expiry', _dtv(v['puc'])),
    KvRow('Next service', _dtv(v['svc'])),
    if (dl != null) dl else if (!drv) const Meta('No paper has been uploaded yet.'),
    if (w != null) busZone(w.$1 ? 'r' : 'y', w.$2),
    if (drv && ok && str(v['reg']).isEmpty && str(v['ins']).isEmpty && str(v['puc']).isEmpty) const Meta('The Principal has not entered the papers yet.'),
    fxActs([
      if (drv) mini('🔧 Report a vehicle issue', () => drvRepForm(context, 'busissues'), BtnKind.primary) else mini('📄 Add / edit papers', () => busPapers(context, x, v), BtnKind.primary),
    ]),
  ]);
}

/// my vehicle: number, registration, insurance and PUC dates (the Principal fills them in)
class MyVehPage extends StatefulWidget {
  const MyVehPage({super.key});
  @override
  State<MyVehPage> createState() => _MyVehPageState();
}

class _MyVehPageState extends State<MyVehPage> {
  final Map<String, Doc> V = {};
  bool ok = false;
  @override
  void initState() {
    super.initState();
    Future.wait(Bus.my.keys.map((id) => dref('busveh', id).get().then((d) {
          if (d.exists) V[id] = d.data()!;
        }).catchError((_) {}))).then((_) {
      if (mounted) setState(() => ok = true);
    });
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: Bus.I,
        builder: (_, __) {
          final B = Bus.my.values.toList();
          return fxBody([
            const FxHead('My vehicle', sub: 'The papers of your bus. The Principal keeps them up to date.'),
            if (!Bus.myOk)
              const Skeleton(n: 2)
            else if (B.isEmpty)
              const Empty('No bus is on your name yet. Open My bus to send your bus number.', icon: '🚐')
            else
              for (final x in B) _vehCard(context, x, V[x['id']] ?? {}, drv: true, ok: ok),
          ]);
        },
      );
}

/// vehicle papers (the Principal): numbers, dates and the files themselves (RC, insurance, PUC)
class VdocPage extends StatelessWidget {
  const VdocPage({super.key});
  @override
  Widget build(BuildContext context) => QMulti(
        queries: [col('buses').limit(100), col('busveh').limit(200)],
        allowEmpty: true,
        builder: (_, ls) {
          final L = [...ls[0]]..sort((a, b) => natCmp(str(a['name']), str(b['name'])));
          final V = {for (final v in ls[1]) str(v['id']): v};
          return fxBody([
            const FxHead('Vehicle papers', sub: 'Registration, insurance and PUC of every school bus: the dates and the papers themselves. You are reminded before a paper runs out.'),
            if (L.isEmpty) const Empty('No bus yet. Add the bus under School bus first.', icon: '🚐'),
            for (final x in L) _vehCard(context, x, V[x['id']] ?? {}),
          ]);
        },
      );
}

/* ---------- alerts for the driver ---------- */
String _logK() => 'sh-drvlog-${S.sid}-${S.uid}';
String _snapK() => 'sh-drvsnap-${S.sid}-${S.uid}';
List<Doc> drvLog() {
  final a = Prefs.json(_logK());
  return a is List ? a.map(mapv).toList() : <Doc>[];
}

class DrvLog extends ChangeNotifier {
  static final DrvLog I = DrvLog._();
  DrvLog._();
  void ping() => notifyListeners();
}

const drvK = {'msg': ['💬', 'Message from the Principal'], 'emg': ['🚨', 'Emergency alert'], 'hol': ['🎉', 'School holiday'], 'svc': ['🛠️', 'Vehicle service reminder']};
void drvPush(String ic, String t, String x, [String id = '', bool quiet = false]) {
  final L = drvLog();
  if (id.isNotEmpty && L.any((e) => e['id'] == id)) return;
  L.insert(0, {'ic': ic, 't': t, 'x': x, 'ts': now(), 'id': id});
  Prefs.setJson(_logK(), L.take(60).toList());
  if (!quiet) Bus.note(ic, t, x, 'dnote');
  DrvLog.I.ping();
}

/// compares what this phone saw last time with now: bus assigned / reassigned, route, students, pickup points, today off
void drvDiff() {
  if (!S.isDrv || !Bus.myOk) return;
  final cur = <String, dynamic>{};
  for (final x in Bus.my.values) {
    final r = Bus.ro[x['id']];
    if (r == null || r['am'] == null || r['pm'] == null) return;
    final st = <String, dynamic>{};
    for (final m in [...r['am']!, ...r['pm']!]) {
      final pk = mapv(m['pk']);
      st[str(m['pid'])] = {'n': str(m['name']), 'p': pk['lat'] != null ? '${numv(pk['lat']).toStringAsFixed(5)},${numv(pk['lng']).toStringAsFixed(5)}' : '', 'o': busOffToday(m) ? td() : ''};
    }
    cur[str(x['id'])] = {'n': str(x['name']), 'r': str(x['route']), 's': st};
  }
  final o0 = Prefs.json(_snapK());
  Prefs.setJson(_snapK(), {'b': cur});
  if (o0 is! Map || o0['b'] is! Map) return;
  final old = Map<String, dynamic>.from(o0['b'] as Map);
  for (final id in cur.keys) {
    if (old[id] == null) drvPush('🔁', 'Bus assigned to you', str(cur[id]['n']));
  }
  for (final id in old.keys) {
    if (cur[id] == null) drvPush('🔁', 'Bus reassigned', '${mapv(old[id])['n']} is no longer on your name.');
  }
  for (final id in cur.keys) {
    final a = mapv(old[id]), c = mapv(cur[id]);
    if (a.isEmpty) continue;
    if (a['r'] != c['r']) drvPush('🛣️', 'Route changed', '${c['n']}: ${str(c['r']).isEmpty ? 'no route' : c['r']}');
    final aS = mapv(a["s"]), cs = mapv(c["s"]);
    for (final p in cs.keys) {
      final cp = mapv(cs[p]), ap = mapv(aS[p]);
      if (aS[p] == null) {
        drvPush('➕', 'Student added', '${cp['n']} · ${c['n']}');
      } else {
        if (ap['p'] != cp['p'] && str(cp['p']).isNotEmpty) drvPush('📍', 'Pickup point changed', '${cp['n']}${str(ap['p']).isNotEmpty ? ' has a new pickup point.' : ' has set a pickup point.'}');
        final o0s = str(ap['o']), o1 = str(cp['o']);
        if (o1.isNotEmpty && o1 != o0s) {
          drvPush('🏠', 'Not taking the bus today', '${cp['n']} · ${c['n']}. No need to stop for this child today.');
        } else if (o1.isEmpty && o0s == td()) {
          drvPush('🚌', 'Back on the bus today', '${cp['n']} · ${c['n']}');
        }
      }
    }
    for (final p in aS.keys) {
      if (cs[p] == null) drvPush('➖', 'Student removed', '${mapv(aS[p])["n"]} · ${c['n']}');
    }
  }
}

final List<StreamSubscription> _drvMU = [];
void drvWatch() {
  for (final u in _drvMU) {
    u.cancel();
  }
  _drvMU.clear();
  DrvDuty.reset();
  if (!S.isDrv) return;
  final seenK = 'sh-drvmsg-${S.sid}-${S.uid}';
  var seen = int.tryParse(Prefs.get(seenK)) ?? 0;
  final first = seen == 0;
  void got(QuerySnapshot<Map<String, dynamic>> s) {
    var mx = seen;
    for (final d in s.docs) {
      final m = d.data();
      final ts = intv(m['ts']);
      if (ts == 0 || ts <= seen) continue;
      if (ts > mx) mx = ts;
      final k = drvK[m['k']] ?? drvK['msg']!;
      drvPush(k[0], k[1], str(m['x']), 'm${d.id}', first && now() - ts > dayMs);
    }
    if (mx > seen) {
      seen = mx;
      Prefs.set(seenK, '$mx');
    }
  }

  for (final to in ['all', S.uid!]) {
    _drvMU.add(col('drvmsg').where('to', isEqualTo: to).limit(30).snapshots().listen(got, onError: (_) {}));
  }
  Listen.offs.add(() {
    for (final u in _drvMU) {
      u.cancel();
    }
    _drvMU.clear();
  });
  Timer(const Duration(seconds: 7), () {
    if (!S.isDrv) return;
    final t = td();
    for (final x in Bus.my.values) {
      dref('busveh', str(x['id'])).get().then((d) {
        final w = d.exists ? drvDocWarn(d.data()) : null;
        if (w != null) drvPush('🛠️', 'Vehicle papers · ${x['name']}', w.$2.replaceFirst('⚠️ ', ''), 'veh${x['id']}$t');
      }).catchError((_) {});
    }
    final t2 = ymd(DateTime.now().add(const Duration(days: 1)));
    for (final h in D['hol'].values) {
      if (h['date'] == t || h['date'] == t2) drvPush('🎉', 'School holiday ${h['date'] == t ? 'today' : 'tomorrow'}', str(h['title']), 'hol${h['date']}');
    }
  });
}

class DnotePage extends StatelessWidget {
  const DnotePage({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: DrvLog.I,
        builder: (_, __) {
          final L = drvLog();
          return fxBody([
            const FxHead('Alerts', sub: 'Messages from the school and changes to your bus: route, students, pickup points, holidays.'),
            if (L.isEmpty) const Empty('No alerts yet.', icon: '🔔'),
            for (final e in L)
              FxCard([
                Row(children: [Expanded(child: Text('${e['ic']} ${e['t']}', style: h3())), Text(ago(e['ts']), style: small())]),
                if (str(e['x']).isNotEmpty) Meta(str(e['x'])),
              ]),
          ]);
        },
      );
}

/// the Principal writes to the drivers
void drvMsgForm(BuildContext context, List<Doc> L) {
  final seen = <String>{};
  final D2 = [for (final x in L) if (str(x['driverUid']).isNotEmpty && seen.add(str(x['driverUid']))) x];
  fxForm(context, 'Message the drivers', "Reaches the driver's phone as an alert the next time the app is open.", [
    FF('to', 'To', type: 'select', opts: [('all', 'All drivers'), for (final x in D2) (str(x['driverUid']), '${str(x['driverName']).isEmpty ? 'Driver' : x['driverName']} · ${x['name']}')], val: 'all', req: true),
    const FF('k', 'Type', type: 'select', opts: [('msg', 'Message'), ('emg', '🚨 Emergency alert'), ('hol', 'School holiday'), ('svc', 'Vehicle service reminder')], val: 'msg', req: true),
    const FF('x', 'Message', type: 'area', ph: 'e.g. Tomorrow the school is closed. No trips.', req: true, max: 300),
  ], 'Send', (v) async {
    await fxAdd('drvmsg', {'to': v['to'], 'k': v['k'], 'x': v['x'], 'by': S.me!['name'], 'uid': S.uid});
    toast('✅', 'Sent', v['to'] == 'all' ? 'All drivers' : '');
  });
}

/* ---------- the driver's home ---------- */
class DrvHome extends StatefulWidget {
  const DrvHome({super.key});
  @override
  State<DrvHome> createState() => _DrvHomeState();
}

class _DrvHomeState extends State<DrvHome> {
  @override
  void initState() {
    super.initState();
    if (!DrvDuty.known) {
      DrvDuty.load().then((_) {
        if (mounted) setState(() {});
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    return ListenableBuilder(
      listenable: Listenable.merge([Bus.I, DrvLog.I, D.on(['ann', 'hol'])]),
      builder: (_, __) {
        final B = Bus.my.values.toList(), x = B.isNotEmpty ? B.first : null;
        final duty = DrvDuty.known ? DrvDuty.cached : null;
        final on = duty != null && intv(duty['in']) > 0 && intv(duty['out']) == 0;
        final L = drvLog().take(3).toList();
        final ann = (D['ann'].values.toList()..sort((a, b) => intv(b['ts']).compareTo(intv(a['ts'])))).firstOrNull;
        final H = (D['hol'].values.where((q) => str(q['date']).compareTo(td()) >= 0).toList()..sort((a, b) => str(a['date']).compareTo(str(b['date'])))).take(3).toList();
        final tiles = const [['🚐', 'Vehicle', 'veh'], ['🔧', 'Vehicle issue', 'vis'], ['📝', 'Incident', 'inc'], ['🔔', 'Alerts', 'dnote'], ['🕘', 'Trips', 'bus'], ['🗓️', 'Leave', 'svc:leave']];
        return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Enter(
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.only(bottom: 14),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: on ? LinearGradient(colors: [p.green.withOpacity(.18), p.green.withOpacity(.06)]) : null,
                color: on ? null : p.card,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: on ? p.green.withOpacity(.4) : p.line),
                boxShadow: p.shadow,
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Text(on ? '🟢 On duty since ${tm(duty['in'])}' : (!DrvDuty.known ? '🕘 Duty' : '⚪ Not checked in today'), style: h3()),
                const SizedBox(height: 2),
                Text(on ? 'The school can see that you are on duty.' : 'You check in with your PIN and a photo when you start the first trip.', style: meta()),
                if (DrvDuty.known && !on)
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Btn('Check in now', small: true, onTap: () async {
                      if (await drvDuty(context)) {
                        await DrvDuty.load(true);
                        if (mounted) setState(() {});
                      }
                    }),
                  ),
              ]),
            ),
          ),
          Enter(
            index: 1,
            child: AppCard(children: [
              if (!Bus.myOk)
                Text('Loading your bus…', style: meta())
              else if (x == null) ...[
                Text('🚌 No bus yet', style: h3()),
                Text('Send your bus number to the Principal.', style: meta()),
                const SizedBox(height: 10),
                Btn('Open My bus', small: true, onTap: () => openFx('bus')),
              ] else
                Builder(builder: (_) {
                  final run = busOn(x), R = Bus.tripR(x);
                  final q = run && R != null ? BusQ.of(x, R, Bus.pos(x)) : null;
                  return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    Row(children: [Expanded(child: Text('🚌 ${x['name']}', style: h2())), busLivePill(run)]),
                    if (str(x['route']).isNotEmpty) Meta('🛣️ ${x['route']}'),
                    if (q != null) busManifest(q.n, q.done.length, q.W.length + q.nop.length, q.abs.length, x['dir'] == 'pm'),
                    const SizedBox(height: 10),
                    run ? Btn('Open the trip', onTap: () => openFx('bus')) : Btn.g('▶ Start a trip', onTap: () => openFx('bus')),
                  ]);
                }),
            ]),
          ),
          Enter(
            index: 2,
            child: GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 1.15,
              padding: const EdgeInsets.only(bottom: 14),
              children: [
                for (final t in tiles)
                  Material(
                    color: p.card,
                    borderRadius: BorderRadius.circular(18),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(18),
                      onTap: () => t[2].contains(':') ? nav.go(t[2]) : openFx(t[2]),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(t[0], style: const TextStyle(fontSize: 26)), const SizedBox(height: 6), Text(t[1], style: small().copyWith(fontWeight: FontWeight.w700))]),
                    ),
                  ),
              ],
            ),
          ),
          if (L.isNotEmpty)
            AppCard(title: '🔔 Latest alerts', onTap: () => openFx('dnote'), children: [
              for (final e in L) Ex('${e['ic']} ${e['t']}', sub: '${str(e['x']).isNotEmpty ? '${e['x']} · ' : ''}${ago(e['ts'])}'),
            ]),
          if (ann != null) AppCard(title: 'Latest notice', children: [Text(str(ann['title']), style: h3()), Desc(str(ann['text']))]),
          if (H.isNotEmpty) AppCard(title: '🎉 Upcoming holidays', children: [for (final q in H) Meta('${q['date']} · ${q['title']}')]),
        ]);
      },
    );
  }
}

/// fxDone is used by the check-in in other places too
void drvOnDuty() => fxDone('You are on duty', '', false, 1400);
