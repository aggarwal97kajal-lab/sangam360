import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../../core/api.dart';
import '../../core/fs.dart';
import '../../core/perms.dart';
import '../../core/plan.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/media.dart';
import '../../ui/pick.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import 'company.dart';
import 'driver.dart';
import 'school.dart';
import 'school_bus.dart';
import 'society.dart';

/* ===== add-on pages ("More tools" in the side menu): each opens full screen and listens only while open ===== */

class FxDef {
  final String ic;
  final String Function() title;
  final bool Function()? show;
  final Widget Function() page;
  const FxDef(this.ic, this.title, this.page, {this.show});
}

final Map<String, FxDef> fxDefs = {
  'lf': FxDef('🔎', () => 'Lost & Found', () => const LfPage()),
  'ven': FxDef('🧰', () => 'Service directory', () => const VenPage()),
  'meet': FxDef('🗓️', () => 'Meetings & minutes', () => const MeetPage()),
  'exr': FxDef('📊', () => 'Expense report', () => const ExrPage(), show: () => !S.isGuard),
  'gp': FxDef('🚪', () => 'Gate pass', () => const GpPage(), show: () => S.isAdm || S.isGuard || S.isStu(S.me)),
  'ptm': FxDef('🤝', () => 'Parent–teacher meeting', () => const PtmPage(), show: () => S.isAdm || S.isStu(S.me)),
  'bday': FxDef('🎂', () => 'Birthdays & achievements', () => const BdayPage()),
  'task': FxDef('✅', () => 'Tasks', () => const TaskPage(), show: () => !S.isGuard),
  'shift': FxDef('🕒', () => 'Shift roster', () => const ShiftPage()),
  'pay': FxDef('📄', () => 'Payslips & letters', () => const PayPage(), show: () => S.kind == 'school' ? !S.isStu(S.me) : !S.isGuard),
  'asset': FxDef('💻', () => 'Assets', () => const AssetPage(), show: () => !S.isGuard),
  'claim': FxDef('🧾', () => 'Expense claims', () => const ClaimPage(), show: () => !S.isGuard),
  'res': FxDef('🏅', () => 'Exam results', () => const ResPage(), show: () => S.isAdm || S.isStu(S.me)),
  'bus': FxDef('🚌', () => S.me != null && S.isStu(S.me) && !S.isAdm ? "My child's bus" : S.me != null && !S.isAdm && S.isBusJob(S.me) ? 'My bus' : 'School buses', () => const BusPage()),
  'vis': FxDef('🔧', () => 'Vehicle issue', () => const DrvRepPage(kind: 'iss'), show: () => S.isDrv),
  'inc': FxDef('📝', () => 'Incident report', () => const DrvRepPage(kind: 'inc'), show: () => S.isDrv),
  'veh': FxDef('🚐', () => 'My vehicle', () => const MyVehPage(), show: () => S.isDrv),
  'vdoc': FxDef('📄', () => 'Vehicle papers', () => const VdocPage(), show: () => S.sch && S.isOwner),
  'dnote': FxDef('🔔', () => 'Alerts', () => const DnotePage(), show: () => S.isDrv),
};

List<String> fxList() {
  if (S.isDrv) return ['bus', 'veh', 'vis', 'inc', 'dnote', 'pay'];
  const L = {
    'society': ['lf', 'ven', 'meet', 'exr'],
    'school': ['res', 'gp', 'ptm', 'bus', 'pay', 'bday'],
    'company': ['task', 'shift', 'pay', 'asset', 'claim', 'bday'],
  };
  return [...(L[S.kind] ?? const []), if (S.kind == 'school') 'vdoc'];
}

bool fxShown(String k) {
  final F = fxDefs[k];
  if (F == null) return false;
  try {
    return F.show == null || F.show!();
  } catch (_) {
    return false;
  }
}

/// opens an add-on page
void openFx(String key) {
  final F = fxDefs[key];
  if (F == null || S.me == null) return;
  if (PlanSt.locked) {
    PlanSt.lockNudge();
    return;
  }
  navKey.currentState?.push(MaterialPageRoute(builder: (_) => FxPage(k: key)));
}

class FxPage extends StatelessWidget {
  final String k;
  const FxPage({super.key, required this.k});
  @override
  Widget build(BuildContext context) {
    final F = fxDefs[k]!;
    final p = pal;
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        titleSpacing: 0,
        title: Row(children: [Text(F.ic, style: const TextStyle(fontSize: 20)), const SizedBox(width: 8), Expanded(child: Text(F.title(), overflow: TextOverflow.ellipsis))]),
      ),
      body: F.page(),
    );
  }
}

/* ---------- the common parts of the add-on pages ---------- */
Doc fxMe() => {'uid': S.uid, 'name': str(S.me?['name']), 'flat': str(S.me?['flat'])};
ColRef fxc(String n) => col(n);
Future<DocRef> fxAdd(String n, Map<String, dynamic> o) => addDoc(col(n), {...o, 'ts': now()});

/// people that can be picked in a form: admins see the member list, everyone else the directory
List<Doc> fxPpl() {
  final src = S.isAdm ? D['mem'].values.where((x) => x['status'] == 'approved') : D['dir'].values;
  final r = src.map((x) => <String, dynamic>{'uid': str(x['uid'] ?? x['id']), 'name': str(x['name']), 'flat': str(x['flat']), 'role': x['role']}).where((x) => x['uid'] != '' && x['name'] != '').toList();
  r.sort((a, b) => str(a['name']).compareTo(str(b['name'])));
  return r;
}

/// a list from Firestore while the page is open: loading, error, empty and the list
class QList extends StatefulWidget {
  final Q query;
  final Widget Function(BuildContext context, List<Doc> l) builder;
  final String emptyIc, emptyText;
  final bool allowEmpty;
  const QList({super.key, required this.query, required this.builder, this.emptyIc = '📭', this.emptyText = 'Nothing here yet.', this.allowEmpty = false});
  @override
  State<QList> createState() => _QListState();
}

class _QListState extends State<QList> {
  StreamSubscription? _s;
  List<Doc>? L;
  Object? err;
  @override
  void initState() {
    super.initState();
    _s = widget.query.snapshots().listen((s) {
      if (mounted) setState(() => L = docsOf(s));
    }, onError: (e) {
      if (mounted) setState(() => err = e);
    });
  }

  @override
  void dispose() {
    _s?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final st = fxState(err, L, widget.emptyIc, widget.emptyText);
    if (st != null && !(widget.allowEmpty && L != null && L!.isEmpty)) return st;
    return widget.builder(context, L!);
  }
}

/// loading / error / empty, or null when the list can be drawn
Widget? fxState(Object? err, List? L, String ic, String empty) {
  if (err != null) {
    final den = err is FirebaseException && err.code == 'permission-denied';
    return Empty(
        den
            ? (S.isOwner ? 'This feature is not switched on in the database yet. Publish the latest Firestore rules (firestore.rules) in the Firebase console, then open this page again.' : 'This feature is not available yet. Please ask your admin.')
            : "Couldn't load. Check your internet and try again.",
        icon: '⚠️');
  }
  if (L == null) return const Skeleton(n: 3);
  if (L.isEmpty) return Empty(empty, icon: ic);
  return null;
}

/// a bold title with a line under it and a button
class FxHead extends StatelessWidget {
  final String title;
  final String? sub;
  final String? btn;
  final FutureOr<void> Function()? onTap;
  const FxHead(this.title, {super.key, this.sub, this.btn, this.onTap});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(gradient: LinearGradient(colors: [p.a.withOpacity(.10), p.a2.withOpacity(.05)], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(20), border: Border.all(color: p.a.withOpacity(.12))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(title, style: h2()),
        if (sub != null && sub!.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(sub!, style: meta())),
        if (btn != null) ...[const SizedBox(height: 12), Btn(btn!, onTap: onTap, busyDone: false)],
      ]),
    );
  }
}

/// a page body: scrolls, with padding at the bottom
Widget fxBody(List<Widget> children, {Future<void> Function()? refresh}) {
  final l = ListView(physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()), padding: const EdgeInsets.fromLTRB(16, 8, 16, 40), children: children);
  return refresh == null ? l : RefreshIndicator(onRefresh: refresh, child: l);
}

/* ---------- one form in a bottom sheet ---------- */
class FF {
  final String k, l;
  final String type; // text | area | select | file | date | time | number | tel | month
  final String? ph, val, min, accept;
  final List<(String, String)> opts;
  final bool req;
  final int? max;
  const FF(this.k, this.l, {this.type = 'text', this.ph, this.val, this.opts = const [], this.req = false, this.max, this.min, this.accept});
}

/// F = fields; fn gets the values (files as PFile, numbers as num?)
Future<void> fxForm(BuildContext context, String title, String sub, List<FF> F, String btn, Future<void> Function(Map<String, dynamic> v) fn) => sheet(context, (ctx) => _FxForm(title: title, sub: sub, F: F, btn: btn, fn: fn));

class _FxForm extends StatefulWidget {
  final String title, sub, btn;
  final List<FF> F;
  final Future<void> Function(Map<String, dynamic> v) fn;
  const _FxForm({required this.title, required this.sub, required this.F, required this.btn, required this.fn});
  @override
  State<_FxForm> createState() => _FxFormState();
}

class _FxFormState extends State<_FxForm> {
  final Map<String, TextEditingController> tc = {};
  final Map<String, String> sv = {};
  final Map<String, PFile?> fv = {};
  String err = '';
  @override
  void initState() {
    super.initState();
    for (final f in widget.F) {
      if (['text', 'area', 'number', 'tel'].contains(f.type)) tc[f.k] = TextEditingController(text: f.val ?? '');
      if (['select', 'date', 'time', 'month'].contains(f.type)) sv[f.k] = f.val ?? (f.type == 'select' && f.opts.isNotEmpty ? f.opts.first.$1 : '');
    }
  }

  Future<void> _go() async {
    setState(() => err = '');
    final v = <String, dynamic>{};
    for (final f in widget.F) {
      dynamic x;
      if (f.type == 'file') {
        x = fv[f.k];
      } else if (f.type == 'number') {
        final t = tc[f.k]!.text.trim();
        x = t.isEmpty ? null : num.tryParse(t);
      } else if (tc[f.k] != null) {
        x = tc[f.k]!.text.trim();
      } else {
        x = sv[f.k] ?? '';
      }
      v[f.k] = x;
      if (f.req && (x == null || x == '' || (f.type == 'number' && !(x is num && x > 0)))) {
        setState(() => err = 'Please fill in: ${f.l}');
        return;
      }
    }
    await widget.fn(v);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      SheetTitle(widget.title, sub: widget.sub),
      for (final f in widget.F) _field(f),
      if (err.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(err, style: TextStyle(color: p.red, fontWeight: FontWeight.w600))),
      Btn(widget.btn, onTap: _go, busyDone: false),
    ]);
  }

  Widget _field(FF f) {
    final lab = f.l + (f.req ? '' : ' (optional)');
    switch (f.type) {
      case 'select':
        return SelectField(lab, sv[f.k], f.opts, (v) => setState(() => sv[f.k] = v));
      case 'date':
        return DateField(lab, sv[f.k] ?? '', (v) => setState(() => sv[f.k] = v), min: f.min);
      case 'time':
        return TimeField(lab, sv[f.k] ?? '', (v) => setState(() => sv[f.k] = v));
      case 'month':
        return MonthField(lab, sv[f.k] ?? '', (v) => setState(() => sv[f.k] = v));
      case 'area':
        return Field(tc[f.k]!, lab, hint: f.ph, lines: 3, max: f.max ?? 600);
      case 'number':
        return Field(tc[f.k]!, lab, hint: f.ph, kb: const TextInputType.numberWithOptions(decimal: true));
      case 'tel':
        return Field(tc[f.k]!, lab, hint: f.ph, kb: TextInputType.phone, max: f.max ?? 15);
      case 'file':
        final cur = fv[f.k];
        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: pal.card2, borderRadius: BorderRadius.circular(14)),
          child: Row(children: [
            if (cur != null && cur.isImg) ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.memory(cur.bytes, width: 46, height: 46, fit: BoxFit.cover)) else Text(cur == null ? '📎' : '📄', style: const TextStyle(fontSize: 26)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(lab, style: h3()), Text(cur == null ? 'Nothing chosen' : '${cur.name} · ${fuSize(cur.size)}', maxLines: 1, overflow: TextOverflow.ellipsis, style: meta())])),
            if (cur != null) IconButton(onPressed: () => setState(() => fv[f.k] = null), icon: Icon(Icons.close_rounded, color: pal.muted)),
            mini(cur == null ? 'Choose' : 'Change', () async {
              final a = f.accept ?? 'image';
              PFile? x;
              if (a == 'image') {
                x = await pickPhotoSheet(context, title: f.l);
              } else if (a.contains('video')) {
                x = await pickPhotoSheet(context, title: f.l, video: true);
              } else if (a.contains('image')) {
                x = await pickPhotoSheet(context, title: f.l, pdf: true);
              } else {
                x = await pickDoc();
              }
              if (x == null) return;
              final bad = checkFile(x, ext: a == 'image' ? const ['jpg', 'jpeg', 'png'] : a.contains('video') ? const ['jpg', 'jpeg', 'png', 'mp4', 'mov', 'webm', '3gp'] : a.contains('image') ? const ['jpg', 'jpeg', 'png', 'pdf'] : const ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'csv', 'zip'], max: 10 * 1048576);
              if (bad != null) {
                toast('⚠️', bad);
                return;
              }
              setState(() => fv[f.k] = x);
            }),
          ]),
        );
    }
    return Field(tc[f.k]!, lab, hint: f.ph, max: f.max ?? 120);
  }
}

/* ---------- QR ---------- */
class FxQR extends StatelessWidget {
  final String text;
  final double size;
  const FxQR(this.text, {super.key, this.size = 200});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), boxShadow: pal.shadow),
        child: QrImageView(data: text, size: size, backgroundColor: Colors.white, eyeStyle: const QrEyeStyle(eyeShape: QrEyeShape.square, color: Color(0xFF111827)), dataModuleStyle: const QrDataModuleStyle(dataModuleShape: QrDataModuleShape.square, color: Color(0xFF111827))),
      );
}

/// camera scanner for a 6-digit pass code -> the code, or null
Future<String?> fxScan(BuildContext context, String title) async {
  if (!await askPerm('cam')) return null;
  if (!context.mounted) return null;
  return Navigator.of(context).push<String>(MaterialPageRoute(builder: (_) => _Scanner(title: title)));
}

class _Scanner extends StatefulWidget {
  final String title;
  const _Scanner({required this.title});
  @override
  State<_Scanner> createState() => _ScannerState();
}

class _ScannerState extends State<_Scanner> with SingleTickerProviderStateMixin {
  final MobileScannerController _c = MobileScannerController(detectionSpeed: DetectionSpeed.normal, facing: CameraFacing.back, formats: const [BarcodeFormat.qrCode]);
  late final AnimationController _line = AnimationController(vsync: this, duration: const Duration(milliseconds: 1600))..repeat(reverse: true);
  bool ok = false, torch = false;
  @override
  void dispose() {
    _c.dispose();
    _line.dispose();
    super.dispose();
  }

  void _hit(BarcodeCapture b) {
    if (ok) return;
    for (final x in b.barcodes) {
      final m = RegExp(r'(\d{6})').firstMatch(x.rawValue ?? '');
      if (m != null) {
        setState(() => ok = true);
        HapticFeedback.heavyImpact();
        Future.delayed(const Duration(milliseconds: 600), () {
          if (mounted) Navigator.pop(context, m.group(1));
        });
        return;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(widget.title, style: const TextStyle(color: Colors.white)),
        actions: [
          IconButton(
              onPressed: () {
                _c.toggleTorch();
                setState(() => torch = !torch);
              },
              icon: Icon(torch ? Icons.flash_on_rounded : Icons.flash_off_rounded)),
        ],
      ),
      body: Stack(children: [
        MobileScanner(controller: _c, onDetect: _hit, errorBuilder: (_, e, __) => Center(child: Padding(padding: const EdgeInsets.all(30), child: Text('Camera not available. Type the code instead.', textAlign: TextAlign.center, style: body(Colors.white))))),
        Center(
          child: SizedBox(
            width: 250,
            height: 250,
            child: Stack(children: [
              Positioned.fill(child: AnimatedContainer(duration: const Duration(milliseconds: 250), decoration: BoxDecoration(border: Border.all(color: ok ? p.green : Colors.white, width: 3), borderRadius: BorderRadius.circular(24)))),
              if (!ok) AnimatedBuilder(animation: _line, builder: (_, __) => Positioned(left: 16, right: 16, top: 16 + 218 * _line.value, child: Container(height: 2.5, decoration: BoxDecoration(color: p.a, boxShadow: [BoxShadow(color: p.a, blurRadius: 12)])))),
            ]),
          ),
        ),
        Positioned(
          left: 0,
          right: 0,
          bottom: 60,
          child: Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(99)),
              child: Text(ok ? 'Pass found ✓' : 'Hold the pass steady inside the frame', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
            ),
          ),
        ),
      ]),
    );
  }
}

/// pick a person (sheet with search)
Future<Doc?> pickPerson(BuildContext context, String title, List<Doc> L) async {
  final id = await pickFromList(context, title, [for (final x in L) (str(x['uid']), '${str(x['name'])}${str(x['flat']).isNotEmpty ? ' · ${str(x['flat'])}' : ''}')], null);
  if (id == null) return null;
  return L.firstWhere((x) => x['uid'] == id);
}

/// a confirm that returns true (sure)
Future<bool> fxSure(BuildContext context, String t, {bool danger = true, String ok = 'Yes'}) => confirmDlg(context, t, ok: ok, danger: danger);

/// an error the person can read
AppError fxBadE(String m) => AppError(m);

/// several Firestore lists while the page is open; the first one decides loading / error / empty
class QMulti extends StatefulWidget {
  final List<Q> queries;
  final Widget Function(BuildContext context, List<List<Doc>> l) builder;
  final String emptyIc, emptyText;
  final bool allowEmpty;
  const QMulti({super.key, required this.queries, required this.builder, this.emptyIc = '📭', this.emptyText = 'Nothing here yet.', this.allowEmpty = false});
  @override
  State<QMulti> createState() => _QMultiState();
}

class _QMultiState extends State<QMulti> {
  final List<StreamSubscription> _s = [];
  late final List<List<Doc>?> L = List.filled(widget.queries.length, null);
  Object? err;
  @override
  void initState() {
    super.initState();
    for (var i = 0; i < widget.queries.length; i++) {
      _s.add(widget.queries[i].snapshots().listen((s) {
        if (mounted) setState(() => L[i] = docsOf(s));
      }, onError: (e) {
        if (!mounted) return;
        if (i == 0) {
          setState(() => err = e);
        } else {
          setState(() => L[i] = const []);
        }
      }));
    }
  }

  @override
  void dispose() {
    for (final s in _s) {
      s.cancel();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final st = fxState(err, L[0], widget.emptyIc, widget.emptyText);
    if (st != null && !(widget.allowEmpty && L[0] != null && L[0]!.isEmpty)) return st;
    return widget.builder(context, [for (final x in L) x ?? const []]);
  }
}

/// the card of one record on an add-on page
class FxCard extends StatelessWidget {
  final List<Widget> children;
  final Color? bar;
  const FxCard(this.children, {super.key, this.bar});
  @override
  Widget build(BuildContext context) => Item(bar: bar, children: children);
}

/// buttons under a card
Widget fxActs(List<Widget?> b) {
  final l = b.whereType<Widget>().toList();
  return l.isEmpty ? const SizedBox.shrink() : Padding(padding: const EdgeInsets.only(top: 10), child: Wrap(spacing: 8, runSpacing: 8, children: l));
}

/// a picture in a card (tap to view)
Widget fxImg(BuildContext context, String ref) => Padding(
      padding: const EdgeInsets.only(top: 8),
      child: GestureDetector(
        onTap: () => openRef(context, ref, name: 'photo.jpg'),
        child: ClipRRect(borderRadius: BorderRadius.circular(14), child: RefImage(ref, height: 180, width: double.infinity, fit: BoxFit.cover)),
      ),
    );

/// a section title on an add-on page
Widget fxSec(String t) => Sec(t);
