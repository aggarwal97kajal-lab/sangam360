import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../../core/app.dart';
import '../../core/files.dart';
import '../../core/fs.dart';
import '../../core/kinds.dart';
import '../../core/pdfs.dart';
import '../../core/prefs.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/media.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import '../comm/chat_ctl.dart';
import 'fx.dart';

/* =============================== SCHOOL add-ons =============================== */
String fxRoll(dynamic f) {
  final p = str(f).split(' · ');
  return p.length > 1 ? p.skip(1).join(' · ') : '';
}

List<Doc> fxStuds(String cls) {
  final r = D['mem'].values.where((x) => x['status'] == 'approved' && S.isStu(x) && x['want'] == null && S.clsOf(x) == cls).map((x) => <String, dynamic>{'uid': str(x['uid'] ?? x['id']), 'name': str(x['name']), 'flat': str(x['flat'])}).toList();
  r.sort((a, b) => str(a['name']).compareTo(str(b['name'])));
  return r;
}

List<String> fxClasses() => S.isTeacher ? [S.myCls] : S.schClasses();
String fxGrade(num p) => p >= 90
    ? 'A+'
    : p >= 80
        ? 'A'
        : p >= 70
            ? 'B'
            : p >= 60
                ? 'C'
                : p >= 50
                    ? 'D'
                    : p >= 33
                        ? 'E'
                        : 'F';

class FxTot {
  final num got, max;
  final double pct;
  final String grade;
  const FxTot(this.got, this.max, this.pct, this.grade);
}

FxTot fxTot(Doc x) {
  final s = listv(x['subjects']).map(mapv).toList();
  final got = s.fold<num>(0, (a, q) => a + numv(q['got'])), mx = s.fold<num>(0, (a, q) => a + numv(q['max']));
  final pct = mx > 0 ? got / mx * 100 : 0.0;
  return FxTot(got, mx, pct.toDouble(), fxGrade(pct));
}

/* ---------- report card PDF ---------- */
Future<PdfDoc> reportCardPdf(Doc x) async {
  final f = await pdfFonts();
  final T = fxTot(x), K = kinds['school']!;
  PdfColor pc(Color c) => PdfColor.fromInt(c.value);
  final subs = listv(x['subjects']).map(mapv).toList();
  final doc = pw.Document(theme: pw.ThemeData.withFont(base: f.$1, bold: f.$3));
  pw.TextStyle st(double s, [int w = 0, PdfColor? c]) => pw.TextStyle(font: [f.$1, f.$2, f.$3, f.$4][w], fontSize: s, color: c ?? PdfColors.grey900);
  pw.Widget kv(String k, String v) => pw.Expanded(child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [pw.Text(k, style: st(9, 0, PdfColors.grey600)), pw.SizedBox(height: 3), pw.Text(v, style: st(12, 2))]));
  pw.Widget box(String t, String v, [PdfColor? c]) => pw.Expanded(
      child: pw.Container(
          margin: const pw.EdgeInsets.symmetric(horizontal: 5),
          padding: const pw.EdgeInsets.all(12),
          decoration: pw.BoxDecoration(color: PdfColors.grey100, borderRadius: pw.BorderRadius.circular(8)),
          child: pw.Column(children: [pw.Text(t, style: st(9, 0, PdfColors.grey600)), pw.SizedBox(height: 6), pw.Text(v, style: st(18, 3, c))])));
  pw.Widget cell(String t, {bool r = false, int w = 0, PdfColor? c}) => pw.Padding(padding: const pw.EdgeInsets.symmetric(vertical: 7, horizontal: 6), child: pw.Text(t, textAlign: r ? pw.TextAlign.right : pw.TextAlign.left, style: st(10.5, w, c)));
  doc.addPage(pw.Page(
    pageFormat: PdfPageFormat.a4,
    margin: pw.EdgeInsets.zero,
    build: (_) => pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.stretch, children: [
      pw.Container(
        height: 120,
        decoration: pw.BoxDecoration(gradient: pw.LinearGradient(colors: [pc(K.c1), pc(K.c2)])),
        child: pw.Column(mainAxisAlignment: pw.MainAxisAlignment.center, children: [
          pw.Text(str(S.soc?['name']), style: st(22, 3, PdfColors.white), maxLines: 1),
          pw.SizedBox(height: 6),
          pw.Text('REPORT CARD', style: st(13, 1, PdfColors.white)),
        ]),
      ),
      pw.Padding(
        padding: const pw.EdgeInsets.fromLTRB(36, 26, 36, 0),
        child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.stretch, children: [
          pw.Row(children: [kv('Student', str(x['studentName'])), kv('Exam', str(x['exam']))]),
          pw.SizedBox(height: 16),
          pw.Row(children: [kv('Class', str(x['cls'])), kv('Roll / admission no.', str(x['roll']).isEmpty ? '—' : str(x['roll']))]),
          pw.SizedBox(height: 20),
          pw.Table(
            columnWidths: const {0: pw.FlexColumnWidth(5), 1: pw.FlexColumnWidth(1.5), 2: pw.FlexColumnWidth(1.5), 3: pw.FlexColumnWidth(1.5)},
            border: const pw.TableBorder(horizontalInside: pw.BorderSide(color: PdfColors.grey300)),
            children: [
              pw.TableRow(decoration: const pw.BoxDecoration(color: PdfColors.grey100), children: [cell('Subject', w: 2), cell('Max', r: true, w: 2), cell('Marks', r: true, w: 2), cell('Grade', r: true, w: 2)]),
              for (final s in subs) pw.TableRow(children: [cell(str(s['n']), w: 1), cell('${s['max']}', r: true), cell('${s['got']}', r: true, w: 2), cell(fxGrade(numv(s['max']) > 0 ? numv(s['got']) / numv(s['max']) * 100 : 0), r: true, w: 1)]),
              pw.TableRow(decoration: const pw.BoxDecoration(color: PdfColors.grey50), children: [cell('Total', w: 3), cell('${T.max}', r: true, w: 3), cell('${T.got}', r: true, w: 3), cell(T.grade, r: true, w: 3)]),
            ],
          ),
          pw.SizedBox(height: 24),
          pw.Row(children: [box('Percentage', '${T.pct.toStringAsFixed(1)}%'), box('Overall grade', T.grade, pc(K.c1)), box('Result', T.pct >= 33 ? 'PASS' : 'NEEDS SUPPORT', T.pct >= 33 ? PdfColor.fromInt(0xFF059669) : PdfColor.fromInt(0xFFDC2626))]),
          if (str(x['remarks']).isNotEmpty) ...[
            pw.SizedBox(height: 24),
            pw.Text("Teacher's remarks", style: st(9, 0, PdfColors.grey600)),
            pw.SizedBox(height: 6),
            pw.Text(str(x['remarks']), style: st(11)),
          ],
        ]),
      ),
      pw.Spacer(),
      pw.Padding(
        padding: const pw.EdgeInsets.symmetric(horizontal: 36),
        child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
          for (final t in ['Class teacher${str(x['byName']).isNotEmpty ? ': ${x['byName']}' : ''}', 'Principal'])
            pw.Container(width: 190, padding: const pw.EdgeInsets.only(top: 6), decoration: const pw.BoxDecoration(border: pw.Border(top: pw.BorderSide(color: PdfColors.grey500))), child: pw.Text(t, style: st(9.5, 0, PdfColors.grey700), maxLines: 1)),
        ]),
      ),
      pw.SizedBox(height: 26),
      pw.Center(child: pw.Text('Generated with $brand on ${bdate(now())}', style: st(8.5, 0, PdfColors.grey500))),
      pw.SizedBox(height: 18),
    ]),
  ));
  final name = 'Report card - ${str(x['studentName'])} - ${str(x['exam'])}'.replaceAll(RegExp(r'[\\/:*?"<>|]+'), ' ');
  return PdfDoc(await doc.save(), '$name.pdf');
}

Future<void> _openReport(BuildContext context, Doc x) async {
  try {
    final d = await reportCardPdf(x);
    if (!context.mounted) return;
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => PdfViewer(bytes: d.bytes, name: d.name)));
  } catch (e) {
    fail(e, "Couldn't make the PDF");
  }
}

/* ---------- Gate pass ---------- */
const _gpc = {'Pending': Tone.a, 'Approved': Tone.g, 'Rejected': Tone.r, 'Left': Tone.m};

class GpPage extends StatefulWidget {
  const GpPage({super.key});
  @override
  State<GpPage> createState() => _GpPageState();
}

class _GpPageState extends State<GpPage> {
  String f = 'Pending';
  final code = TextEditingController();
  List<Doc> L = const [];
  bool get adm => S.isAdm;
  bool get grd => S.isGuard;
  bool get stu => !adm && !grd;

  List<Widget> _info(Doc x) => [
        KvRow('Student', str(x['name'])),
        KvRow('Class', '${str(x['cls'])}${fxRoll(x['flat']).isNotEmpty ? ' · ${fxRoll(x['flat'])}' : ''}'),
        KvRow('Leaving on', '${fxDate(str(x['date']))}${str(x['time']).isNotEmpty ? ' · ${fxT12(str(x['time']))}' : ''}'),
        KvRow('Picked up by', str(x['with']).isEmpty ? '—' : str(x['with'])),
        KvRow('Reason', str(x['reason'])),
      ];

  void _pass(Doc x) => sheet(context, (c) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
        const SheetTitle('🎟️ Gate pass', sub: 'Show this at the gate'),
        Center(child: FxQR('GP-${x['code']}', size: 190)),
        const SizedBox(height: 10),
        Center(child: Text(str(x['code']), style: TextStyle(fontSize: 30, letterSpacing: 6, fontWeight: FontWeight.w800, color: pal.a))),
        const SizedBox(height: 10),
        ..._info(x),
        Meta('Approved by ${str(x['byName']).isEmpty ? 'teacher' : x['byName']}'),
      ]));

  Future<void> _left(Doc x) async {
    await updateDoc(dref('gatepasses', str(x['id'])), {'status': 'Left', 'leftTs': now(), 'leftBy': S.me!['name']});
    toast('✅', '${str(x['name'])} has left', 'Gate pass used');
  }

  Future<void> _verify(String c0) async {
    final c = c0.trim();
    if (!RegExp(r'^\d{6}$').hasMatch(c)) {
      toast('ℹ️', 'Enter the 6-digit code');
      return;
    }
    Doc? x = L.where((p) => p['code'] == c).firstOrNull;
    if (x == null) {
      try {
        final s = await col('gatepasses').where('code', isEqualTo: c).limit(1).get();
        if (s.docs.isNotEmpty) x = {'id': s.docs.first.id, ...s.docs.first.data()};
      } catch (e) {
        fail(e);
        return;
      }
    }
    if (!mounted) return;
    final xx = x;
    sheet(context, (s) {
      if (xx == null) return SheetTitle('⛔ No pass found', sub: 'No gate pass has the code $c.');
      final ok = xx['status'] == 'Approved' && xx['date'] == td();
      return Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
        SheetTitle(
            ok
                ? '✅ Valid gate pass'
                : xx['status'] == 'Left'
                    ? 'ℹ️ Already used'
                    : xx['status'] == 'Approved'
                        ? '⚠️ Not for today'
                        : '⛔ Not approved',
            sub: ok
                ? 'Approved by ${str(xx['byName']).isEmpty ? 'teacher' : xx['byName']}'
                : xx['status'] == 'Left'
                    ? 'Left at ${tm(xx['leftTs'])} on ${dt(xx['leftTs'])}'
                    : xx['status'] == 'Approved'
                        ? 'This pass is for ${fxDate(str(xx['date']))}.'
                        : 'Status: ${xx['status']}'),
        ..._info(xx),
        if (ok)
          Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Btn('✓ Mark as left', onTap: () async {
                await _left(xx);
                if (s.mounted) Navigator.of(s).pop();
              })),
      ]);
    });
  }

  void _ask() => fxForm(context, 'Request a gate pass', 'Your class teacher approves it. Show the pass at the gate when you leave.', [
        FF('date', 'Date', type: 'date', req: true, val: td(), min: td()),
        const FF('time', 'Leaving at', type: 'time', req: true),
        const FF('with', 'Who will pick up the child?', ph: 'e.g. Father – Rajesh Gupta', req: true, max: 60),
        const FF('reason', 'Reason', type: 'area', ph: "e.g. Doctor's appointment", req: true, max: 200),
      ], 'Send request', (v) async {
        if (str(v['date']).compareTo(td()) < 0) throw fxBadE('Choose today or a later date.');
        await fxAdd('gatepasses', {...v, ...fxMe(), 'pid': S.pidv, 'cls': S.myCls, 'status': 'Pending', 'code': '${100000 + math.Random().nextInt(900000)}'});
        toast('✅', 'Request sent', 'Your teacher will approve it.');
      });

  Widget _vbox() => FxHead('Check a pass at the gate', sub: "Scan the QR on the parent's phone, or type the 6-digit code.");

  @override
  Widget build(BuildContext context) {
    final p = pal;
    final q = stu ? col('gatepasses').where('uid', isEqualTo: S.uid).limit(60) : col('gatepasses').orderBy('ts', descending: true).limit(300);
    return QList(
      query: q,
      allowEmpty: true,
      builder: (_, L0) {
        L = L0;
        var R = L0.where((x) => !S.isTeacher || x['cls'] == S.myCls).toList();
        final w = <Widget>[];
        if (stu) {
          w.add(FxHead('Leaving school early?', sub: 'Ask for a gate pass. Once your teacher approves, show the pass at the gate.', btn: '＋ Request a gate pass', onTap: _ask));
        } else {
          w.add(_vbox());
          w.add(Field(code, '6-digit code', max: 6, kb: TextInputType.number, digitsOnly: true, onSubmit: _verify));
          w.add(Row2(
            Btn('📷 Scan QR', small: true, onTap: () async {
              final c = await fxScan(context, 'Scan gate pass');
              if (c != null) _verify(c);
            }),
            Btn.o('Check code', small: true, onTap: () => _verify(code.text)),
          ));
          w.add(const SizedBox(height: 14));
        }
        if (L0.isEmpty) {
          w.add(Empty(stu ? 'No gate passes yet.' : 'No gate pass requests yet.', icon: '🚪'));
          return fxBody(w);
        }
        if (!stu) {
          final fs = grd ? const ['Approved', 'Left'] : const ['Pending', 'Approved', 'Left', 'Rejected', 'All'];
          if (!fs.contains(f)) f = fs.first;
          w.add(Chips([for (final k in fs) (k, '$k${k != 'All' ? ' · ${R.where((x) => x['status'] == k).length}' : ''}')], f, (v) => setState(() => f = v)));
          R = R.where((x) => f == 'All' || x['status'] == f).toList();
          if (R.isEmpty) {
            w.add(const Empty('Nothing here.', icon: '🚪'));
            return fxBody(w);
          }
        }
        R.sort((a, b) => intv(b['ts']).compareTo(intv(a['ts'])));
        for (final x in R) {
          final s = str(x['status']), id = str(x['id']);
          w.add(FxCard(bar: toneColor(_gpc[s] ?? Tone.m), [
            Row(children: [Pill(s, tone: _gpc[s] ?? Tone.m), const SizedBox(width: 8), Expanded(child: Text('${fxDate(str(x['date']))}${str(x['time']).isNotEmpty ? ' · ${fxT12(str(x['time']))}' : ''}', style: small()))]),
            const SizedBox(height: 6),
            Text(stu ? str(x['reason']) : str(x['name']), style: h3()),
            Meta('${stu ? '' : '${x['cls']} · ${x['reason']} · '}Pick-up: ${str(x['with']).isEmpty ? '—' : x['with']}'),
            if (s == 'Left') Meta('Left at ${tm(x['leftTs'])}${str(x['leftBy']).isNotEmpty ? ' · checked by ${x['leftBy']}' : ''}') else if (str(x['byName']).isNotEmpty && s != 'Pending') Meta('$s by ${x['byName']}'),
            fxActs([
              if (stu && s == 'Approved') mini('🎟️ Show pass', () => _pass(x), BtnKind.primary),
              if (stu && s == 'Pending')
                mini('Cancel request', () async {
                  if (await fxSure(context, 'Cancel this request?')) await delDoc(dref('gatepasses', id));
                }, BtnKind.red),
              if (adm && s == 'Pending') mini('Approve', () => updateDoc(dref('gatepasses', id), {'status': 'Approved', 'by': S.uid, 'byName': S.me!['name'], 'decTs': now()}), BtnKind.green),
              if (adm && s == 'Pending') mini('Reject', () => updateDoc(dref('gatepasses', id), {'status': 'Rejected', 'by': S.uid, 'byName': S.me!['name'], 'decTs': now()}), BtnKind.red),
              if (!stu && s == 'Approved' && x['date'] == td()) mini('✓ Mark as left', () => _left(x)),
              if (adm && s != 'Pending')
                mini('Delete', () async {
                  if (await fxSure(context, 'Delete this gate pass?')) await delDoc(dref('gatepasses', id));
                }, BtnKind.red),
            ]),
          ]));
        }
        if (p.dark) w.add(const SizedBox(height: 0));
        return fxBody(w);
      },
    );
  }
}

/* ---------- Parent–teacher meeting slots ---------- */
class PtmPage extends StatefulWidget {
  const PtmPage({super.key});
  @override
  State<PtmPage> createState() => _PtmPageState();
}

class _PtmPageState extends State<PtmPage> {
  List<Doc> L = const [];
  bool mine(Doc x) => x['by'] == S.uid;

  void _add() {
    final cl = S.isTeacher ? [(S.myCls, S.myCls)] : [('*', 'All classes'), ...S.schClasses().map((c) => (c, c))];
    fxForm(context, 'Open meeting slots', 'Parents pick one free slot each.', [
      FF('cls', 'For', type: 'select', opts: cl, val: cl.first.$1, req: true),
      FF('date', 'Date', type: 'date', req: true, val: td(), min: td()),
      const FF('time', 'First slot starts at', type: 'time', req: true, val: '09:00'),
      FF('n', 'Number of slots', type: 'select', opts: SelectField.same(const ['4', '6', '8', '10', '12', '16', '20']), val: '8', req: true),
      FF('mins', 'Minutes per slot', type: 'select', opts: SelectField.same(const ['10', '15', '20', '30']), val: '15', req: true),
    ], 'Open slots', (v) async {
      if (str(v['date']).compareTo(td()) < 0) throw fxBadE('Choose today or a later date.');
      final m = RegExp(r'^(\d{1,2}):(\d{2})').firstMatch(str(v['time']));
      if (m == null) throw fxBadE('Choose a start time.');
      final bt = Batch(), st = int.parse(m.group(1)!) * 60 + int.parse(m.group(2)!), mins = int.parse(str(v['mins'])), n0 = now();
      for (var i = 0; i < int.parse(str(v['n'])); i++) {
        final t = st + i * mins;
        if (t >= 1440) break;
        bt.set(col('ptm').doc(), {'teacherUid': S.uid, 'teacherName': S.me!['name'], 'cls': v['cls'] == '*' ? '' : v['cls'], 'date': v['date'], 'time': '${p2(t ~/ 60)}:${p2(t % 60)}', 'mins': mins, 'by': '', 'byName': '', 'byFlat': '', 'uid': S.uid, 'ts': n0 + i});
      }
      await bt.commit();
      toast('✅', 'Slots opened');
    });
  }

  Future<void> _book(Doc x) async {
    if (L.any((s) => mine(s) && s['teacherUid'] == x['teacherUid'] && s['date'] == x['date'])) throw fxBadE('You already have a slot that day. Cancel it first to choose another time.');
    await updateDoc(dref('ptm', str(x['id'])), {'by': S.uid, 'byName': S.me!['name'], 'byFlat': str(S.me!['flat']), 'byTs': now()});
    toast('✅', 'Slot booked', '${fxDate(str(x['date']))} · ${fxT12(str(x['time']))}');
  }

  @override
  Widget build(BuildContext context) {
    final adm = S.isAdm;
    return QList(
      query: col('ptm').where('date', isGreaterThanOrEqualTo: td()).limit(800),
      allowEmpty: true,
      builder: (_, L0) {
        L = L0;
        final R = L0.where((x) => adm ? (S.isOwner || x['teacherUid'] == S.uid) : (str(x['cls']).isEmpty || x['cls'] == S.myCls)).toList()..sort((a, b) => '${a['date']}${a['time']}'.compareTo('${b['date']}${b['time']}'));
        final G = <String, List<Doc>>{};
        for (final x in R) {
          (G['${x['date']}|${x['teacherUid']}'] ??= []).add(x);
        }
        return fxBody([
          FxHead('Parent–teacher meeting', sub: adm ? 'Open time slots for a day. Parents book one slot each, and you see who is coming when.' : 'Pick a free time to meet the teacher.', btn: adm ? '＋ Open slots' : null, onTap: _add),
          if (R.isEmpty) Empty(adm ? 'No slots are open.' : 'No meeting slots are open right now.', icon: '🤝'),
          for (final sl in G.values)
            FxCard([
              Row(children: [Pill(fxDate(str(sl.first['date'])), tone: Tone.b), const Spacer(), Text('${sl.where((s) => str(s['by']).isNotEmpty).length} of ${sl.length} booked', style: small())]),
              const SizedBox(height: 6),
              Text('${str(sl.first['teacherName'])}${str(sl.first['cls']).isNotEmpty ? ' · ${sl.first['cls']}' : ' · All classes'}', style: h3()),
              const SizedBox(height: 4),
              for (final x in sl)
                Ex('${fxT12(str(x['time']))} · ${x['mins']} min',
                    sub: str(x['by']).isNotEmpty ? (adm || mine(x) ? 'Booked by ${mine(x) ? 'you' : '${x['byName']}${str(x['byFlat']).isNotEmpty ? ' · ${x['byFlat']}' : ''}'}' : 'Booked') : 'Free',
                    right: adm
                        ? mini(str(x['by']).isNotEmpty ? 'Remove' : 'Delete', () async {
                            if (str(x['by']).isEmpty || await fxSure(context, 'Delete this booked slot?')) await delDoc(dref('ptm', str(x['id'])));
                          }, BtnKind.red)
                        : mine(x)
                            ? mini('Cancel', () => updateDoc(dref('ptm', str(x['id'])), {'by': '', 'byName': '', 'byFlat': '', 'byTs': now()}), BtnKind.red)
                            : str(x['by']).isEmpty
                                ? mini('Book', () => _book(x), BtnKind.green)
                                : null),
            ]),
        ]);
      },
    );
  }
}

/* ---------- Birthday & achievement wall (school + company) ---------- */
const fxMon = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

class BdayPage extends StatefulWidget {
  const BdayPage({super.key});
  @override
  State<BdayPage> createState() => _BdayPageState();
}

class _BdayPageState extends State<BdayPage> {
  String myBd() => str(D['pres'][S.uid]?['bd']);

  void _saveBd(String bd) {
    App.pset({'bd': bd});
    D['pres'][S.uid!] = {...?D['pres'][S.uid], 'bd': bd};
    D.bump('pres');
    setState(() {});
  }

  void _setBd() {
    final cur = myBd().split('-');
    var m = cur.length == 2 ? cur[0] : p2(DateTime.now().month), d = cur.length == 2 ? cur[1] : '01';
    sheet(context, (c) => StatefulBuilder(
        builder: (c, set) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
              const SheetTitle('My birthday', sub: 'Only the day and month are shown to others here. The year is never asked.'),
              Row2(
                SelectField('Month', m, [for (var i = 0; i < 12; i++) (p2(i + 1), fxMon[i])], (v) => set(() => m = v)),
                SelectField('Day', d, [for (var i = 1; i <= 31; i++) (p2(i), p2(i))], (v) => set(() => d = v)),
              ),
              Btn('Save', onTap: () {
                if (int.parse(d) > const [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][int.parse(m) - 1]) {
                  toast('ℹ️', 'That date does not exist');
                  return;
                }
                _saveBd('$m-$d');
                Navigator.of(c).pop();
                toast('🎂', 'Birthday saved');
              }),
              if (myBd().isNotEmpty)
                TextButton(
                    onPressed: () {
                      _saveBd('');
                      Navigator.of(c).pop();
                    },
                    child: const Text('Remove my birthday')),
            ])));
  }

  void _post() => fxForm(context, 'Share an achievement', 'A prize, a good result, a milestone – something worth cheering.', const [
        FF('who', 'Who?', ph: 'e.g. Aarav Gupta, Class 5-A', req: true, max: 60),
        FF('title', 'Achievement', ph: 'e.g. 1st prize in the science fair', req: true, max: 90),
        FF('text', 'A few words', type: 'area', max: 400),
        FF('img', 'Photo', type: 'file'),
      ], 'Share', (v) async {
        final img = v['img'] != null ? await up(v['img'].bytes, 'classifieds', 'p.jpg') : '';
        await fxAdd('wall', {'who': v['who'], 'title': v['title'], 'text': v['text'], 'img': img, 'uid': S.uid, 'byName': S.me!['name']});
        toast('🏆', 'Shared');
      });

  @override
  Widget build(BuildContext context) {
    final adm = S.isAdm;
    return ListenableBuilder(
      listenable: D.on(['pres', 'dir']),
      builder: (_, __) => QList(
        query: col('wall').orderBy('ts', descending: true).limit(60),
        allowEmpty: true,
        builder: (_, L) {
          final n = DateTime.now(), t0 = DateTime(n.year, n.month, n.day);
          final P = <Doc>[];
          for (final e in D['pres'].entries) {
            final pr = e.value, bd = str(pr['bd']);
            if (!RegExp(r'^\d{2}-\d{2}$').hasMatch(bd)) continue;
            final m = int.parse(bd.substring(0, 2)), d = int.parse(bd.substring(3));
            var nx = DateTime(n.year, m, d);
            if (nx.isBefore(t0)) nx = DateTime(n.year + 1, m, d);
            final u = str(pr['uid']).isNotEmpty ? str(pr['uid']) : e.key;
            final di = D['dir'][u] ?? {};
            final nm = str(di['name']).isNotEmpty ? str(di['name']) : str(pr['name']);
            if (nm.isEmpty) continue;
            P.add({'uid': u, 'name': nm, 'flat': str(di['flat']), 'days': nx.difference(t0).inHours ~/ 24, 'lbl': '$d ${fxMon[m - 1]}'});
          }
          P.sort((a, b) => intv(a['days']).compareTo(intv(b['days'])));
          final td0 = P.where((p) => p['days'] == 0).toList(), upc = P.where((p) => intv(p['days']) > 0 && intv(p['days']) <= 30).take(15).toList();
          Widget row(Doc p, bool today) => Ex('${p['name']}${p['uid'] == S.uid ? ' (you)' : ''}',
              sub: '${str(p['flat']).isNotEmpty ? '${p['flat']} · ' : ''}${today ? 'Today 🎉' : '${p['lbl']}${p['days'] == 1 ? ' · tomorrow' : ' · in ${p['days']} days'}'}',
              lead: Av(str(p['name']), photoOf(str(p['uid'])), size: 38),
              right: today && p['uid'] != S.uid ? mini('🎉 Wish', () => Chat.openDM(str(p['uid'])), BtnKind.primary) : null);
          final bd = myBd();
          return fxBody([
            AppCard(title: '🎂 Today', children: [if (td0.isEmpty) Text('No birthdays today.', style: meta()), for (final p in td0) row(p, true)]),
            if (upc.isNotEmpty) AppCard(title: 'Coming up', children: [for (final p in upc) row(p, false)]),
            FxHead(bd.isNotEmpty ? 'Your birthday: ${int.parse(bd.split('-')[1])} ${fxMon[int.parse(bd.split('-')[0]) - 1]}' : 'Add your birthday',
                sub: bd.isNotEmpty ? 'People here see it on this page.' : 'So that people here can wish you. Only the day and month are shown.', btn: bd.isNotEmpty ? 'Change' : 'Add my birthday', onTap: _setBd),
            fxSec('🏆 Achievements'),
            if (adm) Padding(padding: const EdgeInsets.only(bottom: 12), child: Btn('＋ Share an achievement', onTap: _post, busyDone: false)),
            if (L.isEmpty) const Empty('Nothing shared yet.', icon: '🏆'),
            for (final x in L)
              FxCard([
                Text('🏆 ${str(x['title'])}', style: h3()),
                Meta(str(x['who'])),
                if (str(x['text']).isNotEmpty) Desc(str(x['text'])),
                if (okImg(x['img'])) fxImg(context, str(x['img'])),
                Meta('Shared by ${str(x['byName']).isEmpty ? 'admin' : x['byName']} · ${dt(x['ts'])}'),
                if (adm)
                  fxActs([
                    mini('Delete', () async {
                      if (!await fxSure(context, 'Delete this post?')) return;
                      await delDoc(dref('wall', str(x['id'])));
                      rmFile(x['img']);
                    }, BtnKind.red),
                  ]),
              ]),
          ]);
        },
      ),
    );
  }
}

/* ---------- Exam results / report card ---------- */
class ResPage extends StatefulWidget {
  const ResPage({super.key});
  @override
  State<ResPage> createState() => _ResPageState();
}

class _ResPageState extends State<ResPage> {
  late String? navT = S.isTeacher ? S.uid : null;
  late String? navCls = S.isTeacher ? S.myCls : null;
  String? navStu;
  List<Doc> L = const [];
  String get lk => 'sh-res-last-${S.sid}';

  void _view(Doc x) {
    final T = fxTot(x);
    final subs = listv(x['subjects']).map(mapv).toList();
    sheet(context, (c) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
          SheetTitle(str(x['exam']), sub: '${str(x['studentName'])} · ${str(x['cls'])}${str(x['roll']).isNotEmpty ? ' · ${x['roll']}' : ''}'),
          Table(
            columnWidths: const {0: FlexColumnWidth(4), 1: FlexColumnWidth(1.4), 2: FlexColumnWidth(1.4), 3: FlexColumnWidth(1.4)},
            border: TableBorder(horizontalInside: BorderSide(color: pal.line)),
            children: [
              TableRow(decoration: BoxDecoration(color: pal.card2), children: [for (final h in const ['Subject', 'Max', 'Marks', 'Grade']) _td(h, b: true, r: h != 'Subject')]),
              for (final s in subs) TableRow(children: [_td(str(s['n'])), _td('${s['max']}', r: true), _td('${s['got']}', r: true), _td(fxGrade(numv(s['max']) > 0 ? numv(s['got']) / numv(s['max']) * 100 : 0), r: true)]),
              TableRow(children: [_td('Total', b: true), _td('${T.max}', b: true, r: true), _td('${T.got}', b: true, r: true), _td(T.grade, b: true, r: true)]),
            ],
          ),
          const SizedBox(height: 12),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [Pill('${T.pct.toStringAsFixed(1)}%', tone: Tone.b), const SizedBox(width: 8), Pill('Grade ${T.grade}', tone: T.pct >= 33 ? Tone.g : Tone.r)]),
          if (str(x['remarks']).isNotEmpty) ...[const Sec("Teacher's remarks"), Desc(str(x['remarks']))],
          Meta('${str(x['byName']).isNotEmpty ? 'By ${x['byName']} · ' : ''}${dt(x['ts'])}'),
          const SizedBox(height: 12),
          Btn('⬇ Report card (PDF)', onTap: () {
            Navigator.of(c).pop();
            return _openReport(context, x);
          }),
        ]));
  }

  Widget _td(String t, {bool b = false, bool r = false}) => Padding(padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4), child: Text(t, textAlign: r ? TextAlign.right : TextAlign.left, style: body().copyWith(fontWeight: b ? FontWeight.w700 : FontWeight.w500, fontSize: 13.5)));

  void _edit(Doc? x, {String? preCls, String? preUid}) {
    final cl = fxClasses();
    if (cl.isEmpty) {
      toast('ℹ️', 'Add a class first');
      return;
    }
    final P0 = Prefs.json(lk);
    final P = P0 is Map ? Map<String, dynamic>.from(P0) : <String, dynamic>{};
    var cls = x != null
        ? str(x['cls'])
        : preCls != null && cl.contains(preCls)
            ? preCls
            : cl.contains(P['cls'])
                ? str(P['cls'])
                : (cl.where((c) => fxStuds(c).isNotEmpty).firstOrNull ?? cl.first);
    var stu = x != null ? str(x['studentUid']) : (preUid ?? '');
    final ex = TextEditingController(text: x != null ? str(x['exam']) : str(P['exam']));
    final rm = TextEditingController(text: str(x?['remarks']));
    final rows = <(TextEditingController, TextEditingController, TextEditingController)>[];
    void addRow(Doc s) => rows.add((TextEditingController(text: str(s['n'])), TextEditingController(text: s['max'] != null ? '${s['max']}' : ''), TextEditingController(text: s['got'] != null ? '${s['got']}' : '')));
    final init = x != null ? listv(x['subjects']).map(mapv).toList() : (listv(P['subs']).isNotEmpty ? listv(P['subs']).map(mapv).toList() : [for (final n in const ['English', 'Hindi', 'Mathematics', 'Science', 'Social Science']) <String, dynamic>{'n': n, 'max': 100}]);
    for (final s in init) {
      addRow(s);
    }
    var err = '';
    sheet(context, (c) => StatefulBuilder(builder: (c, set) {
          final st = fxStuds(cls);
          if (x == null && stu.isNotEmpty && !st.any((p) => p['uid'] == stu)) stu = '';
          if (x == null && stu.isEmpty && st.isNotEmpty) stu = str(st.first['uid']);
          final pal0 = pal;
          return Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
            SheetTitle(x != null ? 'Edit result' : 'Add a result', sub: 'The student sees it as soon as you save.'),
            if (x != null) ...[KvRow('Class', cls), KvRow('Student', str(x['studentName'])), const SizedBox(height: 8)] else ...[
              SelectField('Class', cls, SelectField.same(cl.contains(cls) ? cl : [...cl, cls]), (v) => set(() {
                    cls = v;
                    stu = '';
                  })),
              SelectField('Student', stu, st.isEmpty ? const [('', 'No students in this class yet')] : [for (final p in st) (str(p['uid']), '${p['name']}${fxRoll(p['flat']).isNotEmpty ? ' · ${fxRoll(p['flat'])}' : ''}')], (v) => set(() => stu = v)),
            ],
            Field(ex, 'Exam', hint: 'e.g. Unit Test 1, Half Yearly, Annual', max: 50),
            const Sec('Subjects · max marks · marks obtained'),
            for (var i = 0; i < rows.length; i++)
              Row(children: [
                Expanded(flex: 5, child: Field(rows[i].$1, 'Subject', max: 30)),
                const SizedBox(width: 6),
                Expanded(flex: 2, child: Field(rows[i].$2, 'Max', kb: const TextInputType.numberWithOptions(decimal: true))),
                const SizedBox(width: 6),
                Expanded(flex: 2, child: Field(rows[i].$3, 'Marks', kb: const TextInputType.numberWithOptions(decimal: true))),
                IconButton(tooltip: 'Remove subject', onPressed: () => set(() => rows.removeAt(i)), icon: Icon(Icons.close_rounded, color: pal0.muted)),
              ]),
            Align(
                alignment: Alignment.centerLeft,
                child: TextButton(
                    onPressed: () {
                      if (rows.length >= 12) {
                        toast('ℹ️', 'Up to 12 subjects');
                        return;
                      }
                      set(() => addRow({'max': 100}));
                    },
                    child: const Text('＋ Add a subject'))),
            Field(rm, 'Remarks (optional)', lines: 3, max: 300),
            if (err.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(err, style: TextStyle(color: pal0.red, fontWeight: FontWeight.w600))),
            Btn('Save result', busyDone: false, onTap: () async {
              set(() => err = '');
              final subs = <Doc>[];
              for (final r in rows) {
                final nm = r.$1.text.trim();
                if (nm.isEmpty && r.$2.text.isEmpty && r.$3.text.isEmpty) continue;
                final mx = num.tryParse(r.$2.text) ?? 0, gt = num.tryParse(r.$3.text);
                if (nm.isEmpty || mx <= 0 || gt == null || gt < 0 || gt > mx) {
                  set(() => err = 'Check the marks for ${nm.isEmpty ? 'each subject' : nm} (0 to max).');
                  return;
                }
                subs.add({'n': nm, 'max': mx, 'got': gt});
              }
              final s0 = st.where((p) => p['uid'] == stu).firstOrNull, exam = ex.text.trim();
              if (x == null && s0 == null) {
                set(() => err = 'Choose a student.');
                return;
              }
              if (exam.isEmpty) {
                set(() => err = 'Enter the exam name.');
                return;
              }
              if (subs.isEmpty) {
                set(() => err = 'Add at least one subject.');
                return;
              }
              Prefs.setJson(lk, {'cls': cls, 'exam': exam, 'subs': [for (final s in subs) {'n': s['n'], 'max': s['max']}]});
              final dup = x ?? L.where((r) => r['studentUid'] == s0!['uid'] && str(r['exam']).toLowerCase() == exam.toLowerCase()).firstOrNull;
              if (dup != null) {
                await updateDoc(dref('results', str(dup['id'])), {'exam': exam, 'subjects': subs, 'remarks': rm.text.trim(), 'byName': S.me!['name'], 'ts': now()});
              } else {
                await fxAdd('results', {'exam': exam, 'cls': cls, 'studentUid': s0!['uid'], 'studentName': s0['name'], 'roll': fxRoll(s0['flat']), 'subjects': subs, 'remarks': rm.text.trim(), 'uid': S.uid, 'byName': S.me!['name']});
              }
              if (c.mounted) Navigator.of(c).pop();
              toast('✅', 'Result saved', '${x != null ? x['studentName'] : s0!['name']} · $exam');
            }),
          ]);
        }));
  }

  Widget _card(Doc x) {
    final T = fxTot(x), adm = S.isAdm;
    return GestureDetector(
      onTap: () => _view(x),
      child: FxCard(bar: T.pct >= 33 ? pal.green : pal.red, [
        Wrap(spacing: 6, children: [Pill(str(x['exam']), tone: Tone.b), Pill('${T.pct.toStringAsFixed(0)}% · ${T.grade}', tone: T.pct >= 33 ? Tone.g : Tone.r)]),
        const SizedBox(height: 6),
        Text(adm ? str(x['studentName']) : str(x['exam']), style: h3()),
        Meta('${adm ? '${x['cls']}${str(x['roll']).isNotEmpty ? ' · ${x['roll']}' : ''} · ' : ''}${T.got} / ${T.max} marks · ${dt(x['ts'])}'),
        fxActs([
          mini('View', () => _view(x), BtnKind.primary),
          mini('⬇ PDF', () => _openReport(context, x)),
          if (adm) mini('Edit', () => _edit(x)),
          if (adm)
            mini('Delete', () async {
              if (await fxSure(context, 'Delete this result?')) await delDoc(dref('results', str(x['id'])));
            }, BtnKind.red),
        ]),
      ]),
    );
  }

  Widget _tile(Widget lead, String t, String s, VoidCallback fn, [Widget? extra]) => FxCard([
        Ex(t, sub: s, lead: lead, onTap: fn, right: Icon(Icons.chevron_right_rounded, color: pal.muted)),
        if (extra != null) extra,
      ]);
  Widget _ico(String e) => Container(width: 40, height: 40, alignment: Alignment.center, decoration: BoxDecoration(color: pal.tint, shape: BoxShape.circle), child: Text(e, style: const TextStyle(fontSize: 20)));
  Widget _back(String t, VoidCallback fn) => Align(alignment: Alignment.centerLeft, child: TextButton(onPressed: fn, child: Text('← $t')));

  @override
  Widget build(BuildContext context) {
    final adm = S.isAdm;
    final q = adm ? col('results').orderBy('ts', descending: true).limit(600) : col('results').where('studentUid', isEqualTo: S.pidv).limit(100);
    return PopScope(
      canPop: !adm || (navT == null || (S.isTeacher && navStu == null)),
      onPopInvokedWithResult: (did, _) {
        if (did) return;
        setState(() {
          if (navStu != null) {
            navStu = null;
          } else if (navCls != null && !S.isTeacher) {
            navCls = null;
          } else {
            navT = null;
          }
        });
      },
      child: QList(
        query: q,
        allowEmpty: true,
        builder: (_, L0) {
          L = L0;
          final w = <Widget>[
            FxHead(adm ? 'Exam results' : 'My results',
                sub: adm ? '${S.isOwner ? 'Choose a teacher, then the class, then a student.' : 'Your class. Tap a student to see or add results.'} Each student sees only their own result.' : 'Your marks for every exam, with a report card you can download.',
                btn: adm ? '＋ Add a result' : null,
                onTap: () => _edit(null, preCls: navCls, preUid: navStu)),
          ];
          if (!adm) {
            if (L0.isEmpty) return fxBody([...w, const Empty('No results have been shared with you yet.', icon: '🏅')]);
            final s = [...L0]..sort((a, b) => intv(b['ts']).compareTo(intv(a['ts'])));
            return fxBody([...w, for (final x in s) _card(x)]);
          }
          final mem = D['mem'].values.where((x) => x['status'] == 'approved').toList();
          final T = mem.where((x) => x['role'] == 'COMMITTEE_MEMBER' && S.clsOf(x).isNotEmpty && S.clsOf(x) != 'Teacher').toList()..sort((a, b) => natCmp(S.clsOf(a), S.clsOf(b)));
          final tcls = T.map(S.clsOf).toList();
          int nRes(String c) => L0.where((x) => x['cls'] == c).length;
          final other = {...S.schClasses(), ...L0.map((x) => str(x['cls']))}.where((c) => c.isNotEmpty && !tcls.contains(c)).toList()..sort(natCmp);
          if (navT == null) {
            if (T.isEmpty && other.isEmpty) return fxBody([...w, const Empty('No teachers or classes yet.', icon: '🏅')]);
            w.add(fxSec('Teachers'));
            for (final t in T) {
              w.add(_tile(Av(str(t['name']), photoOf(str(t['id'])), size: 40), str(t['name']), '${S.clsOf(t)} · ${fxStuds(S.clsOf(t)).length} students · ${nRes(S.clsOf(t))} results', () => setState(() {
                    navT = str(t['id']);
                    navCls = null;
                    navStu = null;
                  })));
            }
            if (other.isNotEmpty) {
              w.add(_tile(_ico('📚'), 'Other classes', '${other.length} class${other.length == 1 ? '' : 'es'} without a class teacher', () => setState(() {
                    navT = '_';
                    navCls = null;
                    navStu = null;
                  })));
            }
            return fxBody(w);
          }
          final tch = T.where((t) => t['id'] == navT).firstOrNull;
          final tname = navT == '_'
              ? 'Other classes'
              : tch != null
                  ? str(tch['name'])
                  : S.isTeacher
                      ? str(S.me?['name'])
                      : 'Teacher';
          if (navCls == null) {
            w.add(_back('Teachers', () => setState(() => navT = null)));
            w.add(fxSec(tname));
            final cls = navT == '_' ? other : (tch != null ? [S.clsOf(tch)] : <String>[]);
            if (cls.isEmpty) w.add(const Empty('No class.', icon: '🏅'));
            for (final c in cls) {
              w.add(_tile(_ico('🏫'), c, '${fxStuds(c).length} students · ${nRes(c)} results', () => setState(() {
                    navCls = c;
                    navStu = null;
                  })));
            }
            return fxBody(w);
          }
          final R = L0.where((x) => x['cls'] == navCls).toList();
          final st = fxStuds(navCls!);
          for (final x in R) {
            if (!st.any((p) => p['uid'] == x['studentUid'])) st.add({'uid': x['studentUid'], 'name': x['studentName'], 'flat': '$navCls${str(x['roll']).isNotEmpty ? ' · ${x['roll']}' : ''}'});
          }
          if (navStu == null) {
            if (S.isOwner) w.add(_back(tname, () => setState(() => navCls = null)));
            w.add(fxSec('$navCls · ${st.length} students'));
            if (st.isEmpty) w.add(const Empty('No students in this class yet.', icon: '🏅'));
            for (final p in st) {
              final mine = R.where((x) => x['studentUid'] == p['uid']).toList()..sort((a, b) => intv(b['ts']).compareTo(intv(a['ts'])));
              w.add(_tile(Av(str(p['name']), photoOf(str(p['uid'])), size: 40), str(p['name']), '${fxRoll(p['flat']).isNotEmpty ? '${fxRoll(p['flat'])} · ' : ''}${mine.isNotEmpty ? '${mine.length} result${mine.length == 1 ? '' : 's'}' : 'No result yet'}', () => setState(() => navStu = str(p['uid'])),
                  mine.isEmpty
                      ? null
                      : Padding(
                          padding: const EdgeInsets.only(top: 6),
                          child: Wrap(spacing: 6, runSpacing: 6, children: [
                            for (final x in mine.take(4))
                              Builder(builder: (_) {
                                final T2 = fxTot(x);
                                return Pill('${x['exam']} · ${T2.pct.toStringAsFixed(0)}%', tone: T2.pct >= 33 ? Tone.g : Tone.r);
                              }),
                          ]))));
            }
            return fxBody(w);
          }
          final p = st.where((q) => q['uid'] == navStu).firstOrNull ?? {'name': 'Student'};
          final mine = R.where((x) => x['studentUid'] == navStu).toList()..sort((a, b) => intv(b['ts']).compareTo(intv(a['ts'])));
          w.add(_back(navCls!, () => setState(() => navStu = null)));
          w.add(fxSec('${p['name']}${fxRoll(p['flat']).isNotEmpty ? ' · ${fxRoll(p['flat'])}' : ''}'));
          if (mine.isEmpty) w.add(Empty('No result for ${p['name']} yet. Use “Add a result”.', icon: '🏅'));
          for (final x in mine) {
            w.add(_card(x));
          }
          return fxBody(w);
        },
      ),
    );
  }
}
