import 'dart:async';
import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/app.dart';
import '../../core/csv.dart';
import '../../core/fs.dart';
import '../../core/geo.dart';
import '../../core/listen.dart';
import '../../core/live.dart';
import '../../core/perms.dart';
import '../../core/prefs.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/media.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import '../maps.dart';
import 'driver.dart';
import 'fx.dart';
import 'school.dart';
import '../../l10n/l10n.dart';

/* =====================================================================================================
   SCHOOL BUS
   - the school gives each student a morning / evening bus (busmap/{student id})
   - the parent sets the child's pickup point once (busmap/{student id}.pk = {lat,lng,a,ts}); nobody types stops
   - the driver only starts and ends the trip; the phone shares the position (buses/{id}.live) and marks each
     pickup point when the bus stops within 120 m of it (buses/{id}.arr.{key of the student})
   - every parent's app compares the bus with its own child's pickup point: nearby (1 km), approaching (400 m), arrived
   ===================================================================================================== */

String busKey(dynamic s) => str(s).toLowerCase().replaceAll(RegExp('[^a-z0-9]'), '');
({double lat, double lng})? llOf(dynamic p) {
  final m = mapv(p);
  if (m['lat'] == null) return null;
  return (lat: numv(m['lat']).toDouble(), lng: numv(m['lng']).toDouble());
}

bool busOffToday(Doc? m) => m != null && str(m['off']).isNotEmpty && m['off'] == td();
int busAbsT(Doc x, Doc m) => busOffToday(m) ? 1 : busArr({'arr': x['abs'], 'startTs': x['startTs']}, busK(str(m['pid'])));
bool hasPk(Doc m) => mapv(m['pk'])['lat'] != null;
String busGeo(Doc x, String dir, List<Doc> R) {
  final l = [for (final m in R) if (hasPk(m) && !busOffToday(m)) '${busK(str(m['pid']))},${mapv(m['pk'])['lat']},${mapv(m['pk'])['lng']}'];
  final sc = mapv(x['sch']);
  if (dir == 'am' && sc['lat'] != null) l.add('sch,${sc['lat']},${sc['lng']}');
  return l.join(';');
}

/// a driver who joined with "Bus driver" sends the bus number; the Principal's app turns it into a bus
Future<String> busFromMember(Doc r) async {
  final B = mapv(r['bus']);
  if (str(B['name']).isEmpty || B['done'] == true || !S.sch) return '';
  var res = '';
  final q = await col('buses').limit(200).get();
  final all = [for (final d in q.docs) <String, dynamic>{'id': d.id, ...d.data()}];
  final o = {'driverUid': r['id'], 'driverName': str(r['name']), 'phone': str(r['mobile']), 'edAt': now(), 'edBy': S.uid};
  final sc = all.where((x) => mapv(x['sch'])['lat'] != null).map((x) => x['sch']).firstOrNull;
  if (!all.any((x) => x['driverUid'] == r['id'])) {
    final same = all.where((x) => busKey(x['name']) == busKey(B['name'])).firstOrNull;
    if (same != null && str(same['driverUid']).isNotEmpty && same['driverUid'] != r['id'] && D['mem'][same['driverUid']]?['status'] == 'approved') {
      res = 'taken';
    } else if (same != null) {
      await updateDoc(dref('buses', str(same['id'])), {...o, if (str(same['route']).isEmpty && str(B['route']).isNotEmpty) 'route': B['route']});
      res = 'linked';
    } else {
      await fxAdd('buses', {'name': cut(str(B['name']), 40), 'route': cut(str(B['route']), 120), ...o, 'sch': sc, 'on': false, 'lid': '', 'until': 0, 'riders': [], 'uid': S.uid});
      res = 'added';
    }
  }
  await updateDoc(memRef(str(r['id'])), {
    'bus': {'name': B['name'], 'route': str(B['route']), 'done': true}
  }).catchError((_) {});
  if (res == 'taken') {
    toast('ℹ️', trf('{0} already has a driver', [B['name']]), trf('Open School buses to change the driver to {0}.', [(str(r['name']).isEmpty ? tr('this person') : r['name'])]));
  } else if (res.isNotEmpty) {
    toast('🚌', res == 'added' ? tr('Bus added') : tr('Bus linked'), '${B['name']} · ${str(r['name'])}');
  }
  return res;
}

/// the Principal's phone: drivers who sent their bus number but have no bus yet
void busFromAll() {
  if (!(S.sch && S.isOwner)) return;
  for (final e in D['mem'].entries) {
    final m = e.value;
    if (m['status'] == 'approved' && str(mapv(m['bus'])['name']).isNotEmpty && mapv(m['bus'])['done'] != true && !S.isStu(m)) busFromMember({'id': e.key, ...m}).catchError((_) => '');
  }
}

/// each bus keeps the logins of its students' parents (riders): the database lets a parent read only those buses
Timer? _busRT;
void busRiders(List<Doc>? L, List<Doc>? MAP) {
  _busRT?.cancel();
  if (!S.isAdm || L == null || MAP == null) return;
  _busRT = Timer(const Duration(milliseconds: 700), () {
    for (final x in L) {
      final want = {for (final m in MAP) if (m['amBus'] == x['id'] || m['pmBus'] == x['id']) str(m['puid']).isNotEmpty ? str(m['puid']) : Session.auid(str(m['pid']))}.where((e) => e.isNotEmpty).toList()..sort();
      final has = strList(x['riders'])..sort();
      if (want.join(',') != has.join(',')) updateDoc(dref('buses', str(x['id'])), {'riders': want}).catchError((_) {});
    }
  });
}

/// once a day on the Principal's phone: make sure every bus lists its riders
Future<void> busRidersDaily() async {
  final k = 'sh-busr-${S.sid}', t = td();
  if (Prefs.get(k) == t) return;
  final r = await Future.wait([col('buses').limit(200).get(), col('busmap').limit(3000).get()]);
  if (r[0].docs.isNotEmpty) busRiders(docsOf(r[0]), docsOf(r[1]));
  Prefs.set(k, t);
}

/* ---------- the pickup point of one student ---------- */
bool pkByParent(Doc? m) => m != null && mapv(m['pk'])['lat'] != null && (str(mapv(m['pk'])['by']).isEmpty || mapv(m['pk'])['by'] == (str(m['puid']).isNotEmpty ? m['puid'] : Session.auid(str(m['pid']))));
const pkLock = 'This pickup point was set by the parent. Only the parent can change it.';

Future<Doc> busPkSave(String pid, String name, String cls, PickedPlace p, bool has) async {
  final n0 = now();
  final pk = {'lat': fix6(p.lat), 'lng': fix6(p.lng), 'a': cut(p.name, 60), 'ts': n0, 'by': S.uid};
  if (Session.auid(pid) != S.uid) {
    Doc? cur;
    try {
      final d = await dref('busmap', pid).get();
      if (d.exists) cur = {'pid': pid, ...d.data()!};
    } catch (_) {}
    if (pkByParent(cur)) throw fxBadE(pkLock);
  }
  try {
    if (has) {
      await updateDoc(dref('busmap', pid), {'pk': pk, 'ts': n0});
    } else {
      await setDoc(dref('busmap', pid), {'pid': pid, 'puid': Session.auid(pid), 'name': name, 'cls': cls, 'pk': pk, 'ts': n0});
    }
  } on FirebaseException catch (e) {
    if (e.code == 'permission-denied') throw fxBadE(S.isOwner ? tr('Publish the latest Firestore rules (firestore.rules) in the Firebase console, then try again.') : tr('The pickup point could not be saved yet. Please ask the school to update the app.'));
    rethrow;
  }
  toast('✅', tr('Pickup point saved'), tr('It is used every day until you change it.'));
  return pk;
}

class BusPkBox extends StatefulWidget {
  final String pid, name, cls;
  final Doc? pk;
  final bool has;
  final ({double lat, double lng})? near;
  const BusPkBox({super.key, required this.pid, required this.name, required this.cls, this.pk, required this.has, this.near});
  @override
  State<BusPkBox> createState() => _BusPkBoxState();
}

class _BusPkBoxState extends State<BusPkBox> {
  bool open = false;
  Future<void> _save(PickedPlace p) async {
    await busPkSave(widget.pid, widget.name, widget.cls, p, widget.has);
    if (mounted) setState(() => open = false);
  }

  Future<void> _pick(bool f) async {
    final v = await locPick(context, title: trf('Pickup point · {0}', [widget.name.split(' ').first]), at: llOf(widget.pk), near: widget.near, focus: f);
    if (v != null) await _save(v);
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    final pk = widget.pk != null && widget.pk!['lat'] != null ? widget.pk : null;
    return Container(
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: p.tint, borderRadius: BorderRadius.circular(16)),
      child: AnimatedSize(
        duration: const Duration(milliseconds: 220),
        alignment: Alignment.topCenter,
        child: pk != null && !open
            ? Row(children: [
                Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(tr('📍 Pickup point'), style: h3()),
                  Text(busPkTxt(pk), style: small()),
                  Text(trf('Saved{0} · used every day, also for the evening drop', [(intv(pk['ts']) > 0 ? trf(' on {0}', [fxDate(ymd(dtOf(pk['ts'])))]) : '')]), style: small()),
                ])),
                mini(tr('Change'), () => setState(() => open = true)),
              ])
            : Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Text(pk != null ? tr('📍 Change pickup point') : tr('📍 Set pickup point'), style: h3()),
                Text(pk != null ? tr('Choose the new place. It replaces the saved one.') : tr('Do this once. The bus alerts use this place every day — for the morning pickup and the evening drop.'), style: small()),
                const SizedBox(height: 10),
                Btn(tr('📍 Use current location'), small: true, onTap: () async {
                  if (!await askPerm('loc')) return;
                  final c = await here();
                  if (c.accuracy > 150) {
                    toast('ℹ️', trf('GPS is weak here (±{0} m)', [c.accuracy.round()]), tr('Step outside and try again, or use Select on map.'));
                    return;
                  }
                  final r = await lpkRev(c.latitude, c.longitude).timeout(const Duration(seconds: 4)).catchError((_) => null);
                  await _save(PickedPlace(c.latitude, c.longitude, r != null && r.name.isNotEmpty ? '${r.name}${r.sub.isNotEmpty ? ', ${r.sub.split(', ').first}' : ''}' : ''));
                }),
                const SizedBox(height: 8),
                Row2(Btn.o(tr('🗺️ Select on map'), small: true, onTap: () => _pick(false)), Btn.o(tr('🔍 Search address'), small: true, onTap: () => _pick(true))),
                if (pk != null) TextButton(onPressed: () => setState(() => open = false), child:  Text(tr('Keep the saved place'))),
              ]),
      ),
    );
  }
}

/* =============================== the bus engine (alerts for parents, the driver's trip) =============================== */
class BusLive {
  final String pid, kid, dir;
  final Doc bus;
  const BusLive(this.pid, this.kid, this.bus, this.dir);
}

class Bus extends ChangeNotifier {
  static final Bus I = Bus._();
  Bus._();
  void ping() => notifyListeners();

  static void wire() {
    App.onStart.add(() {
      watch();
      drive();
      drvWatch();
    });
    Live.busSelf = (id) => my[id];
  }

  /* ----- parents: alerts while the app is open ----- */
  static final List<StreamSubscription> _wu = [];
  static Timer? _wt;
  static List<BusLive> now0 = [];
  static List<(String, String)> need = [];
  static String _sig = '';

  static Map<String, dynamic> _mem() {
    final j = Prefs.json('sh-busn');
    return j is Map ? Map<String, dynamic>.from(j) : <String, dynamic>{};
  }

  static bool seen(String k) => _mem()[k] != null;
  static bool once(String k) {
    final M = _mem();
    if (M[k] != null) return false;
    final n = now();
    M.removeWhere((_, v) => n - intv(v) > 3 * dayMs);
    M[k] = n;
    Prefs.setJson('sh-busn', M);
    return true;
  }

  static void note(String ic, String t, String x, [String open = 'bus']) {
    Bell.I.add(ic, t, x);
    beep();
    toast(ic, t, x);
    Toasts.I.stickLast(() => openFx(open));
  }

  static void _watchOff() {
    for (final u in _wu) {
      u.cancel();
    }
    _wu.clear();
    _wt?.cancel();
    now0 = [];
    need = [];
    _sig = '';
  }

  static void watch() {
    _watchOff();
    if (!(S.sch && S.me != null && S.prim != null && S.isStu(S.prim) && !S.isAdm)) return;
    final P = S.myProfiles().where((k) => k['status'] == 'approved' || k['id'] == S.uid).toList();
    final A = <String, Doc>{}, B = <String, Doc?>{}, Z = <String, Map<String, dynamic>>{}, subs = <String>{};
    String first(dynamic n) => str(n).split(' ').first;
    void chk() {
      final n0 = now(), live = <BusLive>[], nd = <(String, String)>[];
      for (final k in P) {
        final pid = str(k['id']), a = A[pid];
        if (a == null) continue;
        final kid = first(str(a['name']).isNotEmpty ? a['name'] : k['name']), pk = mapv(a['pk'])['lat'] != null ? mapv(a['pk']) : null;
        if ((str(a['amBus']).isNotEmpty || str(a['pmBus']).isNotEmpty) && pk == null) nd.add((pid, kid));
        if (busOffToday(a)) continue;
        for (final dir in const ['am', 'pm']) {
          final x = B[str(a['${dir}Bus'])];
          if (x == null || !busOn(x) || x['dir'] != dir || str(x['tripId']).isEmpty) continue;
          final key = '${x['tripId']}|$pid', pm = dir == 'pm', what = pm ? 'drop' : 'pickup';
          live.add(BusLive(pid, kid, x, dir));
          if (once('$key|s')) note('🚌', trf('School bus update · {0}', [kid]), trf('{0}{1}{2} Started {3}.{4}', [x['name'], (pm ? tr(' has left the school.') : tr(' has started its journey.')), (str(x['route']).isNotEmpty ? trf(' Route: {0}.', [x['route']]) : ''), (tm(intv(x['startTs']) > 0 ? x['startTs'] : n0)), (pk != null ? tr(' Tap to track it live.') : trf(' Set the {0} point to get alerts when the bus is near.', [what]))]));
          final l = busLive(x), st = Z[key] ??= {};
          double? km;
          if (l != null && pk != null) {
            km = busKm(numv(l['lat']), numv(l['lng']), numv(pk['lat']), numv(pk['lng']));
            if (intv(l['ts']) != intv(st['ts'])) {
              final dt0 = intv(st['ts']) > 0 ? (intv(l['ts']) - intv(st['ts'])) / 1000 : 0;
              st['closing'] = st['km'] != null && km < (st['km'] as double) - .015;
              st['spd'] = l['spd'] is num && (l['spd'] as num) >= 0 ? (l['spd'] as num).toDouble() : (dt0 > 2 && st['lat'] != null ? busKm(st['lat'], st['lng'], numv(l['lat']), numv(l['lng'])) * 1000 / dt0 : null);
              st['km'] = km;
              st['ts'] = intv(l['ts']);
              st['lat'] = numv(l['lat']);
              st['lng'] = numv(l['lng']);
              if (km <= busZarr) {
                if (intv(st['in']) == 0) st['in'] = n0;
              } else {
                st['in'] = 0;
              }
            }
          }
          final spd = st['spd'] as double?;
          var at = busArr(x, busK(pid));
          if (at == 0 && km != null && km <= busZarr && ((spd != null && spd <= busSlow) || (intv(st['in']) > 0 && n0 - intv(st['in']) >= 30000))) at = n0;
          if (at > 0) {
            if (once('$key|a')) note('🔴', trf('{0} has arrived', [x['name']]), trf('at {0}\'s {1} point · {2}', [kid, what, tm(at)]));
          } else if (km != null && st['closing'] == true && !seen('$key|a')) {
            if (km <= busZappr) {
              if (once('$key|p')) note('🟡', trf('Bus is approaching · {0}', [busFmt(km)]), trf('{0} is about {1} min from {2}\'s {3} point. Please be ready.', [x['name'], busEta(km), kid, what]));
            } else if (km <= busZnear && !seen('$key|p') && once('$key|n')) {
              note('🟢', trf('Bus is nearby · {0}', [busFmt(km)]), trf('{0} is about {1} min from {2}\'s {3} point.', [x['name'], busEta(km), kid, what]));
            }
          }
          if (!pm) {
            final sc0 = mapv(x['sch']);
            var sc = busArr(x, 'sch');
            if (sc == 0 && l != null && sc0['lat'] != null && busKm(numv(l['lat']), numv(l['lng']), numv(sc0['lat']), numv(sc0['lng'])) <= busZarr) sc = intv(l['ts']) > 0 ? intv(l['ts']) : n0;
            if (sc > 0 && once('$key|d')) note('🏫', trf('{0} has reached school', [kid]), trf('{0} reached the school at {1}.', [x['name'], tm(sc)]));
          }
        }
      }
      final sig = '${live.map((n) => n.pid + n.dir).join()}|${nd.map((n) => n.$1).join()}';
      now0 = live;
      need = nd;
      if (sig != _sig) {
        _sig = sig;
        I.ping();
      }
    }

    void subB(String id, int n) {
      if (subs.contains(id)) return;
      subs.add(id);
      _wu.add(dref('buses', id).snapshots().listen((s) {
        B[id] = s.exists ? {'id': id, ...s.data()!} : null;
        chk();
      }, onError: (_) {
        subs.remove(id);
        if (n < 6) Timer(const Duration(seconds: 60), () => subB(id, n + 1));
      }));
    }

    for (final k in P) {
      final kid = str(k['id']);
      _wu.add(dref('busmap', kid).snapshots().listen((s) {
        if (s.exists) {
          A[kid] = s.data()!;
          for (final id in [A[kid]!['amBus'], A[kid]!['pmBus']]) {
            if (str(id).isNotEmpty) subB(str(id), 0);
          }
        } else {
          A.remove(kid);
        }
        chk();
      }, onError: (_) {}));
    }
    _wt = Timer.periodic(const Duration(seconds: 10), (_) => chk());
    Listen.offs.add(_watchOff);
  }

  /* ----- the driver's phone during a trip ----- */
  static Map<String, Doc> my = {};
  static bool myOk = false;
  static StreamSubscription? _mu;
  static Timer? _mt;
  static final Map<String, Map<String, List<Doc>>> ro = {};
  static final Map<String, StreamSubscription> _tu = {};
  static Map<String, num>? _prev;
  static final Set<String> _did = {}, _res = {}, _fix = {};
  static final Map<String, String> _nx = {};
  static bool hand = false;
  static int _t0 = 0;

  static List<Doc>? tripR(Doc x) => ro[x['id']]?[str(x['dir']).isEmpty ? 'am' : str(x['dir'])];
  static ({double lat, double lng})? pos(Doc x) {
    final s = Live.s, c = Live.pos;
    if (s != null && s.bus == x['id'] && !s.nat && c != null) return (lat: c.latitude, lng: c.longitude);
    final l = busLive(x);
    return l != null ? (lat: numv(l['lat']).toDouble(), lng: numv(l['lng']).toDouble()) : null;
  }

  static void _drvNote(String ic, String t, String tx) => note(ic, t, tx);

  /// tells the driver the next pickup each time it changes
  static void nextNote(Doc x) {
    if (!busOn(x) || str(x['tripId']).isEmpty || x['driverUid'] != S.uid) return;
    final R = tripR(x);
    if (R == null) return;
    final q = BusQ.of(x, R, pos(x)), nx = q.W.isNotEmpty ? q.W.first : null, pm = x['dir'] == 'pm';
    final id = nx != null ? (nx.km == null ? '' : str(nx.m['pid'])) : (q.done.isNotEmpty ? 'done' : '');
    if (id.isEmpty || _nx[x['tripId']] == id) return;
    _nx[str(x['tripId'])] = id;
    if (id == 'done') {
      _drvNote('✅', pm ? tr('All children dropped') : tr('All pickups done'), pm ? tr('You can end the trip.') : tr('Go to the school.'));
    } else {
      _drvNote('➡️', '${pm ? tr('Next drop: ') : tr('Next pickup: ')}${nx!.m['name']}', trf('{0} away · about {1} min', [busFmt(nx.km!), busEta(nx.km!)]));
    }
  }

  /// when this app (not the Android service) follows the trip: mark a pickup point once the bus is within 120 m and slow
  static void _auto() {
    final s = Live.s;
    for (final x in my.values) {
      try {
        nextNote(x);
      } catch (_) {}
      if (s == null && now() - _t0 > 9000) resume(x).catchError((_) => false);
    }
    double? lat, lng, acc, spd0;
    if (s != null && s.bus != null && s.nat) {
      final l = busLive(my[s.bus]);
      if (l != null && now() - intv(l['ts']) < 45000) {
        lat = numv(l['lat']).toDouble();
        lng = numv(l['lng']).toDouble();
        acc = numv(l['acc']).toDouble();
        spd0 = l['spd'] is num && (l['spd'] as num) >= 0 ? (l['spd'] as num).toDouble() : null;
      }
    } else if (Live.pos != null) {
      final c = Live.pos!;
      lat = c.latitude;
      lng = c.longitude;
      acc = c.accuracy;
      spd0 = c.speed >= 0 ? c.speed : null;
    }
    if (s == null || s.bus == null || lat == null || lng == null) {
      _prev = null;
      return;
    }
    final x = my[s.bus];
    if (x == null || !busOn(x) || x['lid'] != s.lid || (acc ?? 0) > 150) return;
    final n0 = now(), pv = _prev;
    _prev = {'lat': lat, 'lng': lng, 't': n0};
    final spd = spd0 ?? (pv != null && n0 - pv['t']! > 2000 ? busKm(pv['lat']!, pv['lng']!, lat, lng) * 1000 / ((n0 - pv['t']!) / 1000) : null);
    if (spd == null || spd > busSlow) return;
    final dir = str(x['dir']).isEmpty ? 'am' : str(x['dir']);
    final R0 = tripR(x);
    final geo = R0 != null ? busGeo(x, dir, R0.where((m) => m['${dir}Bus'] == x['id']).toList()) : str(s.geo);
    final up = <String, dynamic>{};
    for (final g in geo.split(';')) {
      final p = g.split(',');
      if (p.length < 3) continue;
      final k = p[0];
      if (k.isEmpty || busArr(x, k) > 0 || _did.contains('${x['tripId']}$k')) continue;
      if (busKm(lat, lng, double.parse(p[1]), double.parse(p[2])) <= busZarr) {
        up['arr.$k'] = n0;
        _did.add('${x['tripId']}$k');
      }
    }
    if (up.isNotEmpty) {
      updateDoc(dref('buses', str(x['id'])), up).catchError((_) {
        for (final k in up.keys) {
          _did.remove('${x['tripId']}${k.substring(4)}');
        }
      });
    }
  }

  /// a trip of mine is running but this phone is not sharing: share again
  static Future<bool> resume(Doc x, [bool manual = false]) async {
    if (!busOn(x) || x['driverUid'] != S.uid || str(x['tripId']).isEmpty) return false;
    var s = Live.s;
    if (s != null && s.bus == x['id'] && s.lid == x['lid']) return true;
    if (!manual && (s != null || _res.contains(x['tripId']))) return false;
    if (!manual) {
      final l = busLive(x);
      if (l != null && now() - intv(l['ts']) < 90000) return false;
    }
    final R = tripR(x);
    if (R == null) return false;
    _res.add(str(x['tripId']));
    if (!await askPerm('loc')) return false;
    final c = await here();
    s = Live.s;
    if (s != null && s.bus == x['id'] && s.lid == x['lid']) return true;
    final dir = str(x['dir']).isEmpty ? 'am' : str(x['dir']);
    final L = R.where((m) => m['${dir}Bus'] == x['id']).toList();
    final gn = {for (final m in L) if (hasPk(m)) busK(str(m['pid'])): cut(str(m['name']).split(' ').first, 18)};
    Live.start(LiveS(lid: str(x['lid']), until: intv(x['until']), bus: str(x['id']), trip: str(x['tripId']), geo: busGeo(x, dir, L), gn: jsonEncode(gn), gl: dir == 'pm' ? tr('Next drop') : tr('Next pickup'), t0: intv(x['startTs']) > 0 ? intv(x['startTs']) : now()), c);
    toast('🚌', tr('Location sharing is on again'), str(x['name']));
    return true;
  }

  /// a trip ended by the phone itself (Stop in the notification, time over, log-out): close its line in the history
  static void _close(Doc x) {
    if (x['on'] == true || str(x['tripId']).isEmpty || intv(x['endTs']) == 0 || _fix.contains(x['tripId']) || x['driverUid'] != S.uid) return;
    _fix.add(str(x['tripId']));
    dref('bustrips', str(x['tripId'])).get().then((d) {
      if (d.exists && intv(d.data()!['end']) == 0) return updateDoc(dref('bustrips', str(x['tripId'])), {'end': x['endTs']});
    }).catchError((_) {});
  }

  static void _trips() {
    for (final x in my.values) {
      for (final dir in const ['am', 'pm']) {
        final k = '${x['id']}|$dir';
        if (_tu.containsKey(k)) continue;
        _tu[k] = col('busmap').where('${dir}Bus', isEqualTo: x['id']).limit(400).snapshots().listen((s) {
          (ro[str(x['id'])] ??= {})[dir] = docsOf(s);
          final b = my[x['id']];
          if (b != null) {
            try {
              nextNote(b);
            } catch (_) {}
          }
          drvDiff();
          I.ping();
        }, onError: (_) {});
      }
    }
    for (final k in _tu.keys.toList()) {
      final id = k.split('|').first;
      if (!my.containsKey(id)) {
        _tu.remove(k)?.cancel();
        ro.remove(id);
      }
    }
  }

  static void _driveOff() {
    myOk = false;
    _mu?.cancel();
    _mu = null;
    _mt?.cancel();
    my = {};
    for (final s in _tu.values) {
      s.cancel();
    }
    _tu.clear();
    ro.clear();
    _prev = null;
  }

  static void drive() {
    _driveOff();
    _t0 = now();
    if (!(S.sch && S.me != null && S.me!['status'] == 'approved' && S.pidv == S.uid && !S.isStu(S.me))) return;
    _mu = col('buses').where('driverUid', isEqualTo: S.uid).limit(10).snapshots().listen((s) {
      my = {for (final d in s.docs) d.id: {'id': d.id, ...d.data()}};
      myOk = true;
      _trips();
      for (final x in my.values) {
        try {
          nextNote(x);
          _close(x);
        } catch (_) {}
      }
      drvDiff();
      I.ping();
    }, onError: (_) {});
    _mt = Timer.periodic(const Duration(seconds: 6), (_) => _auto());
    Listen.offs.add(_driveOff);
    if (S.isOwner) {
      Timer(const Duration(seconds: 5), () {
        try {
          busFromAll();
          busRidersDaily().catchError((_) {});
        } catch (_) {}
      });
    }
  }
}

/// students of a running trip: W = still to reach (nearest first), done = reached, nop = no pickup point yet
class BusW {
  final Doc m;
  final double? km;
  const BusW(this.m, this.km);
}

class BusQ {
  final List<BusW> W;
  final List<(Doc, int)> done;
  final List<Doc> nop, abs;
  final int n;
  const BusQ(this.W, this.done, this.nop, this.abs, this.n);
  static BusQ of(Doc x, List<Doc> R, ({double lat, double lng})? pos) {
    final dir = str(x['dir']).isEmpty ? 'am' : str(x['dir']);
    final L = R.where((m) => m['${dir}Bus'] == x['id']).toList();
    final W = <BusW>[], done = <(Doc, int)>[], nop = <Doc>[], abs = <Doc>[];
    for (final m in L) {
      final at = busArr(x, busK(str(m['pid'])));
      if (at > 0) {
        done.add((m, at));
      } else if (busAbsT(x, m) > 0) {
        abs.add(m);
      } else if (hasPk(m)) {
        W.add(BusW(m, pos != null ? busKm(pos.lat, pos.lng, numv(mapv(m['pk'])['lat']), numv(mapv(m['pk'])['lng'])) : null));
      } else {
        nop.add(m);
      }
    }
    W.sort((a, b) {
      final c = (a.km ?? 1e9).compareTo(b.km ?? 1e9);
      return c != 0 ? c : str(a.m['name']).compareTo(str(b.m['name']));
    });
    done.sort((a, b) => a.$2.compareTo(b.$2));
    return BusQ(W, done, nop, abs, L.length);
  }
}

/* ---------- home: "set the pickup point" until it is done, and a card while a child's bus is on its way ---------- */
List<Widget> busHomeCards(BuildContext context) {
  final p = pal;
  Widget card(String t, String s, bool needIt) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(20),
            onTap: () => openFx('bus'),
            child: Ink(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: needIt ? LinearGradient(colors: [p.amber.withOpacity(.16), p.amber.withOpacity(.06)]) : LinearGradient(colors: [p.green.withOpacity(.18), p.a.withOpacity(.08)]),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: (needIt ? p.amber : p.green).withOpacity(.35)),
              ),
              child: Row(children: [
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(t, style: h3()), const SizedBox(height: 2), Text(s, style: meta())])),
                Icon(Icons.chevron_right_rounded, color: p.muted),
              ]),
            ),
          ),
        ),
      );
  return [
    for (final n in Bus.need) card(trf('📍 Set {0}\'s pickup point', [n.$2]), tr('One time only · then the app tells you when the bus is near'), true),
    for (final n in Bus.now0) card(trf('🚌 {0} is on the way', [n.bus['name']]), trf('{0} · {1} · tap to track live', [n.kid, (n.dir == 'am' ? tr('to school') : tr('back home'))]), false),
  ];
}

/* =============================== the "School buses" page =============================== */
class BusPage extends StatelessWidget {
  const BusPage({super.key});
  @override
  Widget build(BuildContext context) => !S.isAdm && S.isStu(S.me) ? const _BusParent() : const _BusSchool();
}

/* ---------- parents: only their own children's buses ---------- */
class _BusParent extends StatefulWidget {
  const _BusParent();
  @override
  State<_BusParent> createState() => _BusParentState();
}

class _BusParentState extends State<_BusParent> {
  final List<StreamSubscription> _s = [];
  final Map<String, Doc> A = {};
  final Map<String, Doc?> B = {};
  final Set<String> subs = {};
  int ready = 0;
  bool denied = false;
  Timer? _iv;
  late final List<Doc> P = S.myProfiles().where((k) => k['status'] == 'approved' || k['id'] == S.uid).toList();

  @override
  void initState() {
    super.initState();
    for (final k in P) {
      var f = true;
      final id = str(k['id']);
      void got() {
        if (f) {
          f = false;
          ready++;
        }
      }

      _s.add(dref('busmap', id).snapshots().listen((s) {
        got();
        if (s.exists) {
          A[id] = s.data()!;
          for (final b in [A[id]!['amBus'], A[id]!['pmBus']]) {
            if (str(b).isNotEmpty) _subB(str(b));
          }
        } else {
          A.remove(id);
        }
        if (mounted) setState(() {});
      }, onError: (e) {
        got();
        if (e is FirebaseException && e.code == 'permission-denied') denied = true;
        if (mounted) setState(() {});
      }));
    }
    _iv = Timer.periodic(const Duration(seconds: 10), (_) {
      if (mounted && ready >= P.length) setState(() {});
    });
  }

  void _subB(String id) {
    if (subs.contains(id)) return;
    subs.add(id);
    _s.add(dref('buses', id).snapshots().listen((s) {
      B[id] = s.exists ? {'id': id, ...s.data()!} : null;
      if (mounted) setState(() {});
    }, onError: (_) => subs.remove(id)));
  }

  @override
  void dispose() {
    for (final s in _s) {
      s.cancel();
    }
    _iv?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    final head =  FxHead(tr("My child's bus"), sub: tr('Set the pickup point once. You see only the bus of your own child, and the app tells you when it is near.'));
    if (denied) return fxBody([head, fxState(FirebaseException(plugin: 'cloud_firestore', code: 'permission-denied'), const [], '', '')!]);
    if (ready < P.length) return fxBody([head, const Skeleton(n: 3)]);
    return fxBody([
      head,
      for (final k in P)
        Builder(builder: (_) {
          final id = str(k['id']), a = A[id];
          final pk = a != null && mapv(a['pk'])['lat'] != null ? mapv(a['pk']) : null;
          final first = str(k['name']).split(' ').first;
          final w = <Widget>[
            Row(children: [
              Av(str(k['name']), k['id'] == S.uid ? photoOf(S.uid) : (okImgS(k['photoUrl'])), size: 38),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(str(k['name']), style: h3()), Text(str(k['flat']), style: small())])),
            ]),
            BusPkBox(pid: id, name: str(k['name']), cls: S.clsOf(k), pk: pk, has: a != null),
          ];
          if (a != null && (str(a['amBus']).isNotEmpty || str(a['pmBus']).isNotEmpty)) {
            final off = busOffToday(a);
            w.add(ToggleRow(tr('Not taking the bus today'), off, (v) async {
              try {
                await updateDoc(dref('busmap', id), {'off': v ? td() : '', 'offAt': now(), 'ts': now()});
                toast(v ? '🏠' : '🚌', v ? trf('{0} will not take the bus today', [first]) : tr('Back on the bus list'), tr('The driver has been told.'));
              } catch (e) {
                fail(e);
              }
            }));
          }
          if (a == null || (str(a['amBus']).isEmpty && str(a['pmBus']).isEmpty)) {
            w.add(Meta(trf('No bus has been assigned yet — the school office does that.{0}', [(pk != null ? tr(' Your pickup point is saved and will be used.') : '')])));
            return FxCard(w);
          }
          for (final dir in const ['am', 'pm']) {
            final bid = str(a['${dir}Bus']);
            if (bid.isEmpty) continue;
            final x = B[bid], run = x != null && busOn(x) && x['dir'] == dir, l = run ? busLive(x) : null, what = dir == 'am' ? 'pickup' : 'drop';
            w.add(Sec(dir == 'am' ? 'Morning · to school' : 'Evening · back home'));
            w.add(Row(children: [
              Expanded(child: Text('🚌 ${str(x?['name']).isNotEmpty ? x!['name'] : (str(a['${dir}Name']).isNotEmpty ? a['${dir}Name'] : tr('Bus'))}', style: h3())),
              _LivePill(run),
              if (l != null) Padding(padding: const EdgeInsets.only(left: 6), child: Text(trf('updated {0}', [ago(l['ts'])]), style: small())),
            ]));
            w.add(KvRow(tr('Route'), str(x?['route']).isEmpty ? '—' : str(x!['route'])));
            w.add(KvRow(tr('Driver'), x != null ? '${str(x['driverName']).isEmpty ? '—' : x['driverName']}${str(x['phone']).isNotEmpty ? ' · ${x['phone']}' : ''}' : '—'));
            if (!run) continue;
            if (busOffToday(a)) {
              w.add(_Zone('', trf('🏠 Not taking the bus today. The driver\'s list shows {0} as absent.', [first])));
              continue;
            }
            final at = busArr(x, busK(id));
            final km = l != null && pk != null ? busKm(numv(l['lat']), numv(l['lng']), numv(pk['lat']), numv(pk['lng'])) : null;
            (String, String) z;
            if (at > 0 && (km == null || km > busZarr)) {
              z = ('d', trf('✅ The bus reached your {0} point at {1}', [what, tm(at)]));
            } else if (at > 0 || (km != null && km <= busZarr)) {
              z = ('r', trf('🔴 The bus is at your {0} point', [what]));
            } else if (km != null && km <= busZappr) {
              z = ('y', trf('🟡 Approaching · {0} · about {1} min', [busFmt(km), busEta(km)]));
            } else if (km != null && km <= busZnear) {
              z = ('g', trf('🟢 Nearby · {0} · about {1} min', [busFmt(km), busEta(km)]));
            } else if (km != null) {
              z = ('', trf('📍 {0} away · ⏱ about {1} min', [busFmt(km), busEta(km)]));
            } else {
              final lv = mapv(x['live']);
              z = ('', l == null ? (lv['lid'] == x['lid'] && intv(lv['end']) > 0 ? tr("The driver's phone is not sharing the bus's location right now.") : tr('The bus has started. Waiting for its location…')) : tr('Set the pickup point above to see how far the bus is.'));
            }
            w.add(_Zone(z.$1, z.$2));
            if (l != null && now() - intv(l['ts']) > 180000) w.add(Meta(trf('Last seen {0}. The driver\'s phone is not sending its location right now (no network, or the phone is off).', [ago(l['ts'])])));
            if (l != null) {
              void open() => busTrack(context, bid, pk: pk, kid: first, what: what);
              w.add(Padding(padding: const EdgeInsets.only(top: 10), child: MiniMap(l: l, pk: pk, h: 150, onTap: open)));
              w.add(Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Row(children: [
                  Expanded(child: Btn(tr('🗺️ LIVE TRACK'), onTap: open)),
                  if (str(x['phone']).isNotEmpty) ...[const SizedBox(width: 8), Btn.o(tr('📞 Driver'), full: false, onTap: () => launchUrl(Uri.parse('tel:${str(x['phone']).replaceAll(RegExp(r'[^\d+]'), '')}')))],
                ]),
              ));
            }
            if (dir == 'am') {
              final ts = busArr(x, 'sch');
              if (ts > 0) w.add(Note(trf('🏫 Reached school at {0}', [tm(ts)]), tone: Tone.g));
            }
          }
          if (p.dark) w.add(const SizedBox.shrink());
          return FxCard(w);
        }),
    ]);
  }
}

String? okImgS(dynamic v) => v is String && v.isNotEmpty ? v : null;

class _LivePill extends StatefulWidget {
  final bool on;
  const _LivePill(this.on);
  @override
  State<_LivePill> createState() => _LivePillState();
}

class _LivePillState extends State<_LivePill> with SingleTickerProviderStateMixin {
  late final AnimationController c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))..repeat(reverse: true);
  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.on ? FadeTransition(opacity: Tween(begin: .55, end: 1.0).animate(c), child:  Pill(tr('● LIVE'), tone: Tone.g, solid: true)) :  Pill(tr('Not running'), tone: Tone.m);
}

class _Zone extends StatelessWidget {
  final String k, t;
  const _Zone(this.k, this.t);
  @override
  Widget build(BuildContext context) {
    final p = pal;
    final c = k == 'r'
        ? p.red
        : k == 'y'
            ? p.amber
            : k == 'g'
                ? p.green
                : k == 'd'
                    ? p.blue
                    : p.muted;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: c.withOpacity(.12), borderRadius: BorderRadius.circular(14), border: Border.all(color: c.withOpacity(.35))),
      child: Text(t, style: body().copyWith(fontWeight: FontWeight.w700, fontSize: 14)),
    );
  }
}

/* ---------- school side: buses, students, the driver's trip, history ---------- */
class _BusSchool extends StatefulWidget {
  const _BusSchool();
  @override
  State<_BusSchool> createState() => _BusSchoolState();
}

class _BusSchoolState extends State<_BusSchool> {
  final List<StreamSubscription> _s = [];
  List<Doc>? L, ISS, INC;
  Object? err;
  List<Doc> MAP = [], TR = [];
  bool mapOk = false;
  String view = 'bus', hb = 'All';
  final Map<String, List<Doc>> MP = {};
  final Map<String, Doc> VEH = {};
  final Map<String, Doc?> DUTY = {};
  final Set<String> subs = {};
  Timer? _iv;
  bool get adm => S.isAdm;
  bool get own => S.isOwner;
  bool mine(Doc x) => x['driverUid'] == S.uid;

  void _up() {
    if (mounted) setState(() {});
  }

  @override
  void initState() {
    super.initState();
    _s.add(col('buses').limit(80).snapshots().listen((s) {
      L = docsOf(s);
      err = null;
      if (!adm) {
        for (final x in L!.where(mine)) {
          for (final dir in const ['am', 'pm']) {
            final k = '$dir${x['id']}';
            if (subs.contains(k)) continue;
            subs.add(k);
            _s.add(col('busmap').where('${dir}Bus', isEqualTo: x['id']).limit(400).snapshots().listen((r) {
              MP[k] = docsOf(r);
              final seen = <String>{};
              MAP = [for (final m in MP.values.expand((e) => e)) if (seen.add(str(m['pid']))) m];
              _up();
            }, onError: (_) {}));
          }
        }
      }
      if (own) {
        for (final q in L!) {
          final u = str(q['driverUid']);
          if (u.isEmpty || subs.contains('d$u')) continue;
          subs.add('d$u');
          _s.add(dref('attendance', '${u}_${td()}').snapshots().listen((s) {
            DUTY[u] = s.exists ? s.data() : null;
            _up();
          }, onError: (_) {}));
        }
      }
      if (adm && mapOk) busRiders(L, MAP);
      if (own) {
        final sc = _schOf();
        if (sc != null) {
          for (final q in L!.where((q) => mapv(q['sch'])['lat'] == null)) {
            updateDoc(dref('buses', str(q['id'])), {'sch': sc}).catchError((_) {});
          }
        }
      }
      _up();
    }, onError: (e) {
      err = e;
      L ??= [];
      _up();
    }));
    if (own) busFromAll();
    if (adm) {
      _s.add(col('busmap').limit(3000).snapshots().listen((s) {
        MAP = docsOf(s);
        mapOk = true;
        if (L != null) busRiders(L, MAP);
        _up();
      }, onError: (_) {}));
    }
    if (own) {
      _s.add(col('bustrips').orderBy('start', descending: true).limit(400).snapshots().listen((s) {
        TR = docsOf(s);
        _up();
      }, onError: (_) {}));
      _s.add(col('busveh').limit(200).snapshots().listen((s) {
        for (final v in docsOf(s)) {
          VEH[str(v['id'])] = v;
        }
        _up();
      }, onError: (_) {}));
      _s.add(col('busissues').limit(300).snapshots().listen((s) {
        ISS = docsOf(s);
        _up();
      }, onError: (_) {}));
      _s.add(col('businc').limit(300).snapshots().listen((s) {
        INC = docsOf(s);
        _up();
      }, onError: (_) {}));
    } else {
      _s.add(col('bustrips').where('uid', isEqualTo: S.uid).limit(300).snapshots().listen((s) {
        TR = docsOf(s);
        _up();
      }, onError: (_) {}));
    }
    _iv = Timer.periodic(const Duration(seconds: 8), (_) {
      if (L != null && view == 'bus' && L!.any((x) => x['on'] == true)) _up();
    });
    Bus.I.addListener(_up);
  }

  @override
  void dispose() {
    for (final s in _s) {
      s.cancel();
    }
    _iv?.cancel();
    Bus.I.removeListener(_up);
    super.dispose();
  }

  int _byN(Doc p, Doc q) => natCmp('${p['cls']}${p['name']}', '${q['cls']}${q['name']}');
  List<Doc> riders(Doc x, String dir) => MAP.where((m) => m['${dir}Bus'] == x['id']).toList()..sort(_byN);
  List<Doc> onBus(Doc x) => MAP.where((m) => m['amBus'] == x['id'] || m['pmBus'] == x['id']).toList()..sort(_byN);
  Doc? _schOf() => (L ?? []).where((z) => mapv(z['sch'])['lat'] != null).map((z) => mapv(z['sch'])).firstOrNull;

  /* --- bus form --- */
  void _edit([Doc? x]) {
    var P = fxPpl();
    final d = P.where((p) => S.isBusJob(D['mem'][p['uid']] ?? p)).toList(), st = P.where((p) => !S.isStu(p)).toList();
    P = d.isNotEmpty ? [...d, ...st.where((p) => !d.contains(p))] : (st.isNotEmpty ? st : P);
    final v0 = x != null ? (VEH[x['id']] ?? {}) : <String, dynamic>{};
    fxForm(context, x != null ? tr('Edit bus') : tr('Add a bus'), tr('The driver only starts and ends the trip on their own phone. A driver who joins with Join as staff → Bus driver enters the bus number himself, and the bus is added here when you approve him.'), [
      FF('name', tr('Bus number / name'), ph: tr('e.g. BUS-04 · DL1PC 1234'), req: true, val: x?['name'], max: 40),
      FF('route', tr('Route'), ph: tr('e.g. Rohini → School'), val: x?['route'], max: 120),
      FF('driverUid', tr('Driver (the person who carries the phone)'), type: 'select', opts: [for (final p in P) (str(p['uid']), '${p['name']} · ${str(p['flat']).isNotEmpty ? p['flat'] : S.roleLbl(p['role'])}')], val: x != null ? str(x['driverUid']) : (P.isNotEmpty ? str(P.first['uid']) : ''), req: true),
      FF('phone', tr("Driver's phone"), type: 'tel', val: x?['phone'], max: 15),
      FF('reg', tr('Vehicle registration no.'), ph: tr('e.g. DL1PC 1234'), val: v0['reg'], max: 20),
      FF('ins', tr('Insurance valid until'), type: 'date', val: v0['ins']),
      FF('puc', tr('PUC valid until'), type: 'date', val: v0['puc']),
      FF('svc', tr('Next service due'), type: 'date', val: v0['svc']),
    ], tr('Save'), (v) async {
      final p = P.where((q) => q['uid'] == v['driverUid']).firstOrNull;
      if (p == null) throw fxBadE(tr('Choose the driver.'));
      final o = {'name': v['name'], 'route': v['route'], 'driverUid': p['uid'], 'driverName': p['name'], 'phone': v['phone'], 'edAt': now(), 'edBy': S.uid};
      var id = str(x?['id']);
      if (x != null) {
        await updateDoc(dref('buses', id), o);
      } else {
        id = (await fxAdd('buses', {...o, 'sch': _schOf(), 'on': false, 'lid': '', 'until': 0, 'riders': [], 'uid': S.uid})).id;
      }
      await setDoc(dref('busveh', id), {'busId': id, 'busName': v['name'], 'reg': str(v['reg']).toUpperCase(), 'ins': str(v['ins']), 'puc': str(v['puc']), 'svc': str(v['svc']), 'ts': now()}, merge: true).catchError((_) {});
      toast('✅', tr('Saved'));
    });
  }

  void _myBus(Doc mb) => fxForm(context, tr('My bus'), '', [
        FF('name', tr('Bus number'), ph: tr('e.g. BUS-04 · DL1PC 1234'), req: true, val: mb['name'], max: 40),
        FF('route', tr('Route'), ph: tr('e.g. Rohini → School'), val: mb['route'], max: 120),
      ], tr('Send to the Principal'), (v) async {
        final o = {'name': v['name'], 'route': str(v['route'])};
        await updateDoc(memRef(S.uid!), {'bus': o});
        S.me!['bus'] = o;
        toast('✅', tr('Sent'), tr("The bus appears under My bus once the Principal's app adds it."));
        _up();
      });

  Future<void> _schSet() async {
    final v = await locPick(context, title: tr('School gate'), at: llOf(_schOf()));
    if (v == null) return;
    final sch = {'lat': v.lat, 'lng': v.lng, 'a': cut(v.name, 60)};
    await Future.wait((L ?? []).map((q) => updateDoc(dref('buses', str(q['id'])), {'sch': sch})));
    toast('✅', tr('School location saved'));
  }

  /* --- which student takes which bus (several students of a class at once) --- */
  void _assign(Doc? x, [Doc? cur]) {
    final cl = S.schClasses();
    final B2 = [...(L ?? <Doc>[])]..sort((p, q) => natCmp(str(p['name']), str(q['name'])));
    if (cur == null && cl.isEmpty) {
      toast('ℹ️', tr('No classes yet'));
      return;
    }
    final sel = <String>{};
    var cls = cl.where((c) => fxStuds(c).isNotEmpty).firstOrNull ?? (cl.isNotEmpty ? cl.first : '');
    var am = cur != null ? str(cur['amBus']) : str(x?['id']), pm = cur != null ? str(cur['pmBus']) : str(x?['id']);
    final opts = [('', tr('No bus')), for (final q in B2) (str(q['id']), str(q['name']))];
    String bn(String id) => str(B2.where((v) => v['id'] == id).firstOrNull?['name']);
    sheet(context, (c) => StatefulBuilder(builder: (c, set) {
          final st = cur == null ? fxStuds(cls) : <Doc>[];
          return Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
            SheetTitle(cur != null ? trf(S.skE('Bus for {0}'), [cur['name']]) : 'Assign students', sub: "Choose the morning and the evening bus. Each parent sets the child's pickup point once in their own app — you don't enter any stops."),
            if (cur != null)
              Meta('${cur['name']} · ${str(cur['cls'])}', pad: const EdgeInsets.only(bottom: 10))
            else ...[
              SelectField('Class', cls, SelectField.same(cl), (v) => set(() {
                    cls = v;
                    sel.clear();
                  })),
              if (st.isEmpty)
                Meta(tr('No students in this class yet.'), pad: const EdgeInsets.only(bottom: 10))
              else ...[
                Align(
                    alignment: Alignment.centerLeft,
                    child: TextButton(
                        onPressed: () => set(() {
                              final on = sel.length < st.length;
                              sel.clear();
                              if (on) sel.addAll(st.map((p) => str(p['uid'])));
                            }),
                        child: Text(sel.length >= st.length ? tr('Clear all') : tr('Select all')))),
                for (final p in st)
                  Builder(builder: (_) {
                    final m = MAP.where((q) => q['pid'] == p['uid']).firstOrNull;
                    final names = {str(m?['amName']), str(m?['pmName'])}.where((e) => e.isNotEmpty).join(' / ');
                    return CheckboxListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      value: sel.contains(p['uid']),
                      onChanged: (v) => set(() => v == true ? sel.add(str(p['uid'])) : sel.remove(p['uid'])),
                      title: Text('${p['name']}${fxRoll(p['flat']).isNotEmpty ? ' · ${fxRoll(p['flat'])}' : ''}', style: body().copyWith(fontWeight: FontWeight.w600)),
                      subtitle: Text(m != null && (str(m['amBus']).isNotEmpty || str(m['pmBus']).isNotEmpty) ? '🚌 $names' : tr('no bus yet'), style: small()),
                    );
                  }),
              ],
            ],
            Row2(SelectField('Morning · to school', am, opts, (v) => set(() => am = v)), SelectField('Evening · back home', pm, opts, (v) => set(() => pm = v))),
            Btn(tr('Save'), onTap: () async {
              final T = cur != null
                  ? [<String, dynamic>{'uid': cur['pid'], 'name': cur['name'], 'cls': str(cur['cls']), 'roll': str(cur['roll'])}]
                  : [for (final p in st) if (sel.contains(p['uid'])) <String, dynamic>{'uid': p['uid'], 'name': p['name'], 'cls': cls, 'roll': fxRoll(p['flat'])}];
              if (T.isEmpty) {
                toast('ℹ️', tr('Tick the students first'));
                return;
              }
              final n0 = now();
              await Future.wait(T.map((t) => setDoc(dref('busmap', str(t['uid'])), {'pid': t['uid'], 'puid': Session.auid(str(t['uid'])), 'name': t['name'], 'cls': t['cls'], 'roll': t['roll'], 'amBus': am, 'amName': bn(am), 'pmBus': pm, 'pmName': bn(pm), 'asAt': n0, 'ts': n0}, merge: true)));
              if (c.mounted) Navigator.of(c).pop();
              toast('✅', tr('Saved'), T.length == 1 ? str(T.first['name']) : trf('{0} students', [T.length]));
            }),
          ]);
        }));
  }

  void _students(Doc x) {
    sheet(context, (c) {
      final R = onBus(x), n = R.where(hasPk).length;
      return Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
        SheetTitle(trf(S.skE('Students · {0}'), [x['name']]), sub: trf(S.skE('{0} student{1} on this bus · {2} with a pickup point{3}'), [R.length, (R.length == 1 ? '' : 's'), n, (R.length > n ? trf(S.skE(' · {0} still to set it (the parent does it in the app)'), [R.length - n]) : '')])),
        for (final m in R)
          Ex('${m['name']} · ${str(m['cls'])}',
              sub: '${[if (m['amBus'] == x['id']) tr('Morning'), if (m['pmBus'] == x['id']) tr('Evening')].join(' + ')} · ${hasPk(m) ? '📍 ${busPkTxt(mapv(m['pk']))}${pkByParent(m) ? tr(' · set by the parent') : tr(' · set by the school')}' : tr('⚠️ no pickup point yet')}',
              right: own
                  ? Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(
                        tooltip: pkByParent(m) ? tr('Set by the parent') : (hasPk(m) ? tr('Change') : tr('Set')),
                        icon: Text(pkByParent(m) ? '🔒' : '📍', style: const TextStyle(fontSize: 18)),
                        onPressed: () async {
                          if (pkByParent(m)) {
                            final pk = mapv(m['pk']);
                            placeShow(context, numv(pk['lat']).toDouble(), numv(pk['lng']).toDouble(), title: trf('Pickup point · {0}', [m['name']]), lbl: tr('Set by the parent · only the parent can change it'));
                            return;
                          }
                          final v = await locPick(context, title: trf('Pickup point · {0}', [m['name']]), at: hasPk(m) ? llOf(m['pk']) : null, near: llOf(_schOf()));
                          if (v == null) return;
                          try {
                            await busPkSave(str(m['pid']), str(m['name']), str(m['cls']), v, true);
                            if (c.mounted) Navigator.of(c).pop();
                          } catch (e) {
                            fail(e);
                          }
                        },
                      ),
                      mini(tr('Change bus'), () => _assign(x, m)),
                    ])
                  : null),
        if (own) Padding(padding: const EdgeInsets.only(top: 12), child: Btn(tr('＋ Assign students'), onTap: () => _assign(x))),
      ]);
    });
  }

  /* --- the driver's trip: start, end, and the next pickup --- */
  void _startSheet(Doc x) {
    var dir = DateTime.now().hour < 12 ? 'am' : 'pm';
    var mins = 120;
    sheet(context, (c) => StatefulBuilder(builder: (c, set) {
          final R = riders(x, dir), n = R.where(hasPk).length;
          return Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
            SheetTitle(trf(S.skE('Start trip · {0}'), [x['name']]), sub: 'That is all you do: start the trip now and end it when you are done. Your location is shared with the school and the parents of this bus, also when this phone is locked, and the app shows you the next pickup.'),
            SelectField('Trip', dir, const [('am', 'Morning · picking children up'), ('pm', 'Evening · dropping children home')], (v) => set(() => dir = v)),
            Meta(R.isNotEmpty ? trf('{0} of {1} students have a pickup point.{2}', [n, R.length, (n < R.length ? tr(' The others are not shown on your list until their parents set it.') : '')]) : tr('No students are on this trip yet.'), pad: const EdgeInsets.only(bottom: 10)),
            Text(tr('Stop automatically after'), style: meta()),
            const SizedBox(height: 6),
            Chips(const [('60', '1 hour'), ('120', '2 hours'), ('180', '3 hours')], '$mins', (v) => set(() => mins = int.parse(v))),
            Btn.g(tr('▶ START TRIP'), onTap: () async {
              if (!await drvDuty(c)) return;
              if (!await askPerm('loc')) return;
              final cp = await here(fresh: true);
              final sc = mapv(x['sch'])['lat'] != null ? mapv(x['sch']) : _schOf();
              if (sc == null) throw fxBadE(tr('The school location is not set. Ask the Principal to set it first.'));
              final dk = busKm(cp.latitude, cp.longitude, numv(sc['lat']), numv(sc['lng'])), lim = .3 + (cp.accuracy / 1000).clamp(0, .2);
              if (dk > lim) throw fxBadE(trf('You are {0} from the school. Start the trip at the school.', [busFmt(dk)]));
              final n0 = now(), lid = rid(), until = n0 + mins * 60000, tripId = rid(), R2 = riders(x, dir);
              final gn = {for (final m in R2) if (hasPk(m)) busK(str(m['pid'])): cut(str(m['name']).split(' ').first, 18)};
              await setDoc(dref('bustrips', tripId), {'busId': x['id'], 'busName': x['name'], 'route': str(x['route']), 'dir': dir, 'uid': S.uid, 'driverName': S.me!['name'], 'start': n0, 'end': 0, 'until': until, 'ts': n0});
              await updateDoc(dref('buses', str(x['id'])), {
                'on': true,
                'lid': lid,
                'until': until,
                'startTs': n0,
                'dir': dir,
                'tripId': tripId,
                'at': null,
                'arr': {},
                'live': {'lid': lid, 'until': until, 'end': 0, 'lat': fix6(cp.latitude), 'lng': fix6(cp.longitude), 'acc': cp.accuracy.round(), 'spd': -1, 'ts': n0}
              });
              Live.start(LiveS(lid: lid, until: until, bus: str(x['id']), trip: tripId, geo: busGeo(x, dir, R2), gn: jsonEncode(gn), gl: dir == 'pm' ? tr('Next drop') : tr('Next pickup'), t0: n0), cp);
              if (c.mounted) Navigator.of(c).pop();
              toast('🚌', tr('Trip started'), tr('Parents of this bus can now see it.'));
            }),
          ]);
        }));
  }

  Future<void> _stop(Doc x) async {
    final q = busOn(x) ? BusQ.of(x, MAP, Bus.pos(x)) : null, rem = q != null ? q.W.length + q.nop.length : 0, pm = x['dir'] == 'pm';
    if (!await fxSure(context, trf('{0}End this trip?', [(rem > 0 ? trf('⚠️ {0} student{1} not been marked as {2}. Please verify before ending trip.\n\n', [rem, (rem == 1 ? ' has' : tr('s have')), (pm ? 'dropped' : tr('picked up'))]) : '')]), ok: tr('End trip'))) return;
    final n0 = now();
    if (Live.s != null && Live.s!.bus == x['id']) {
      Live.stop();
    } else if (mine(x)) {
      Live.natStop();
    }
    if (str(x['tripId']).isNotEmpty) await updateDoc(dref('bustrips', str(x['tripId'])), {'end': n0, if (q != null) ...{'n': q.n, 'ok': q.done.length, 'abs': q.abs.length, 'left': rem}}).catchError((_) {});
    await updateDoc(dref('buses', str(x['id'])), {'on': false, 'endTs': n0, 'live.end': n0});
    toast('🚌', tr('Trip ended'));
  }

  List<Widget> _tripPanel(Doc x, bool me) {
    final p = pal;
    final dir = str(x['dir']).isEmpty ? 'am' : str(x['dir']), pm = dir == 'pm';
    final q = BusQ.of(x, MAP, Bus.pos(x)), nx = q.W.isNotEmpty ? q.W.first : null, rem = q.W.length + q.nop.length;
    String key(Doc m) => busK(str(m['pid']));
    Widget mark(Doc m, String f) => mini(f == 'arr' ? (pm ? tr('✓ Dropped') : tr('✓ Picked')) : tr('Absent'), () => updateDoc(dref('buses', str(x['id'])), {'$f.${key(m)}': now()}), f == 'arr' ? BtnKind.green : BtnKind.outline);
    Widget row(String name, String cls, String right, [List<Widget>? btns]) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(name, style: body().copyWith(fontWeight: FontWeight.w600)), if (cls.isNotEmpty) Text(cls, style: small())])),
            if (right.isNotEmpty) Padding(padding: const EdgeInsets.only(left: 6), child: Text(right, style: small().copyWith(fontWeight: FontWeight.w700))),
            if (me && btns != null) ...btns.map((b) => Padding(padding: const EdgeInsets.only(left: 6), child: b)),
          ]),
        );
    final w = <Widget>[
      Sec(trf(S.skE('{0} · started {1}'), [busDirL(dir), tm(x['startTs'])])),
      _Manifest(q.n, q.done.length, rem, q.abs.length, pm),
      if (rem > 0 && q.done.length + q.abs.length > 0 && q.W.isEmpty) _Zone('y', trf('⚠️ {0} student{1} not been marked as {2}. Please verify before ending trip.', [rem, (rem == 1 ? ' has' : tr('s have')), (pm ? 'dropped' : 'picked')])),
    ];
    if (me && !(Live.s != null && Live.s!.bus == x['id'])) {
      w.add(_Zone('y', tr("This phone is not sharing the bus's location.")));
      w.add(Padding(
          padding: const EdgeInsets.only(top: 8, bottom: 6),
          child: Btn(tr('▶ Share location from this phone'), onTap: () async {
            if (!await Bus.resume(x, true)) toast('ℹ️', tr("Couldn't start sharing"), tr('Allow location for the app and try again.'));
            _up();
          })));
    }
    w.add(Container(
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(gradient: LinearGradient(colors: [p.a.withOpacity(.14), p.a2.withOpacity(.06)]), borderRadius: BorderRadius.circular(18), border: Border.all(color: p.a.withOpacity(.25))),
      child: nx != null
          ? Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Text(pm ? tr('Next drop') : tr('Next pickup'), style: small()),
              Text(str(nx.m['name']), style: h2()),
              Text(nx.km == null ? tr("Waiting for the bus's location…") : trf('📍 {0} away · ⏱ about {1} min', [busFmt(nx.km!), busEta(nx.km!)]), style: meta()),
              if (me) ...[
                const SizedBox(height: 10),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  mini(tr('🧭 Navigate'), () => busTrack(context, str(x['id']), pk: mapv(nx.m['pk']), kid: str(nx.m['name']).split(' ').first, what: pm ? 'drop' : 'pickup', drv: true), BtnKind.primary),
                  if (Bus.hand) mark(nx.m, 'arr'),
                  if (Bus.hand) mark(nx.m, 'abs'),
                ]),
                const SizedBox(height: 6),
                Text(trf('✨ Marks itself as {0} when the bus stops here. Nothing to tap.', [(pm ? 'dropped' : 'picked')]), style: small()),
                Align(alignment: Alignment.centerLeft, child: TextButton(onPressed: () => setState(() => Bus.hand = !Bus.hand), child: Text(Bus.hand ? tr('Hide the buttons') : tr('✋ Mark by hand')))),
              ],
            ])
          : Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Text(
                  q.done.isNotEmpty || q.abs.isNotEmpty
                      ? (rem > 0
                          ? tr('Check the students below')
                          : pm
                              ? tr('✅ All children dropped')
                              : tr('✅ All pickups done'))
                      : q.n > 0
                          ? tr('No pickup points yet')
                          : tr('No students on this trip'),
                  style: h3()),
              Text(
                  q.done.isNotEmpty || q.abs.isNotEmpty
                      ? (rem > 0
                          ? tr('They have no pickup point; tick them yourself.')
                          : pm
                              ? tr('The trip can be ended.')
                              : tr('Next: the school.'))
                      : q.n > 0
                          ? tr('The parents have not set them yet.')
                          : tr('The school assigns students to this bus.'),
                  style: meta()),
            ]),
    ));
    if (q.W.length > 1) {
      w.add(const Sec('Upcoming'));
      for (final e in q.W.skip(1)) {
        w.add(row(str(e.m['name']), str(e.m['cls']), e.km == null ? '—' : busFmt(e.km!), Bus.hand ? [mark(e.m, 'arr'), mark(e.m, 'abs')] : null));
      }
    }
    if (q.nop.isNotEmpty) {
      w.add(Sec(trf(S.skE('No pickup point yet · {0}'), [q.nop.length])));
      for (final m in q.nop) {
        w.add(row(str(m['name']), str(m['cls']), me ? '' : tr('parent has not set it'), [mark(m, 'arr'), mark(m, 'abs')]));
      }
    }
    if (q.done.isNotEmpty) {
      w.add(Sec('${pm ? 'Dropped' : 'Picked'} · ${q.done.length}'));
      for (final e in q.done) {
        w.add(row('✅ ${e.$1['name']}', str(e.$1['cls']), tm(e.$2)));
      }
    }
    if (q.abs.isNotEmpty) {
      w.add(Sec(trf(S.skE('Absent · {0}'), [q.abs.length])));
      for (final m in q.abs) {
        w.add(row('❌ ${m['name']}', str(m['cls']), busOffToday(m) ? tr('parent: not today') : '', busOffToday(m) ? null : [mini(tr('Undo'), () => updateDoc(dref('buses', str(x['id'])), {'abs.${key(m)}': 0}))]));
      }
    }
    if (!pm) {
      final ts = busArr(x, 'sch');
      if (ts > 0) {
        w.add(Note(trf('🏫 Reached school at {0}', [tm(ts)]), tone: Tone.g));
      } else if (mapv(x['sch'])['lat'] == null) {
        w.add(Meta(trf('🏫 The school\'s location is not set yet, so "reached school" cannot be told.{0}', [(own ? tr(' Set it above.') : tr(' The Principal sets it once.'))])));
      }
    }
    return w;
  }

  Widget _busCard(Doc x) {
    final p = pal;
    final l = busLive(x), run = busOn(x), me = mine(x), R = onBus(x);
    final w = <Widget>[
      Row(children: [
        _LivePill(run),
        if (run) ...[const SizedBox(width: 6), Pill(x['dir'] == 'pm' ? tr('Evening') : tr('Morning'), tone: Tone.b)],
        const Spacer(),
        if (l != null) Text(trf('updated {0}', [ago(l['ts'])]), style: small()),
      ]),
      const SizedBox(height: 8),
      Text('🚌 ${x['name']}', style: h2()),
      if (str(x['route']).isNotEmpty) Meta('🛣️ ${x['route']}'),
      Meta(trf('Driver: {0}{1}{2}', [(str(x['driverName']).isEmpty ? '—' : x['driverName']), (str(x['phone']).isNotEmpty ? ' · ${x['phone']}' : ''), (adm || me ? trf(' · {0} students{1}', [R.length, (R.isNotEmpty ? trf(' · {0} with a pickup point', [R.where(hasPk).length]) : '')]) : '')])),
    ];
    if (own) {
      final d = DUTY[x['driverUid']], v = VEH[x['id']] ?? {}, wn = drvDocWarn(v);
      w.add(Meta(d != null && intv(d['in']) > 0 ? trf('🟢 Driver on duty since {0}{1}{2}', [tm(d['in']), (d['via'] == 'pin' ? tr(' · PIN checked') : ''), (intv(d['out']) > 0 ? trf(' · checked out {0}', [tm(d['out'])]) : '')]) : tr('⚪ Driver has not checked in today')));
      if (d != null && str(d['selfie']).isNotEmpty) w.add(Align(alignment: Alignment.centerLeft, child: TextButton(onPressed: () => openRef(context, str(d['selfie']), name: 'check-in.jpg'), child:  Text(tr('View check-in photo')))));
      if (str(v['reg']).isNotEmpty || str(v['ins']).isNotEmpty || str(v['puc']).isNotEmpty) w.add(Meta('🚐 ${[str(v['reg']), if (str(v['ins']).isNotEmpty) trf('Insurance till {0}', [fxDate(str(v['ins']))]), if (str(v['puc']).isNotEmpty) trf('PUC till {0}', [fxDate(str(v['puc']))])].where((e) => e.isNotEmpty).join(' · ')}'));
      final dl = vehDocLinks(context, v);
      if (dl != null) w.add(dl);
      if (wn != null) w.add(_Zone(wn.$1 ? 'r' : 'y', wn.$2));
      w.add(Align(
          alignment: Alignment.centerLeft,
          child: TextButton(onPressed: () => busPapers(context, x, v), child: Text('📄 ${str(v['reg']).isNotEmpty || str(v['ins']).isNotEmpty || str(v['puc']).isNotEmpty || v['docs'] != null ? tr('Vehicle papers') : tr('Add vehicle papers (RC, insurance, PUC)')}'))));
    }
    if (l != null) w.add(Padding(padding: const EdgeInsets.only(top: 10), child: MiniMap(l: l, h: 150, onTap: () => busTrack(context, str(x['id']), drv: me))));
    if ((me || adm) && run && str(x['tripId']).isNotEmpty) w.addAll(_tripPanel(x, me));
    w.add(fxActs([
      if (me && !run) SizedBox(width: double.infinity, child: Btn.g(tr('▶ START TRIP'), onTap: () => _startSheet(x))),
      if (me && run) mini(tr('■ END TRIP'), () => _stop(x), BtnKind.red),
      if (l != null && !me) mini(tr('🗺️ Track live'), () => busTrack(context, str(x['id'])), BtnKind.primary),
      if (str(x['phone']).isNotEmpty && !me) mini(tr('📞 Driver'), () => launchUrl(Uri.parse('tel:${str(x['phone']).replaceAll(RegExp(r'[^\d+]'), '')}'))),
      if (adm || (me && !run)) mini(tr('👥 Students'), () => _students(x)),
      if (own) mini(tr('Edit'), () => _edit(x)),
      if (own)
        mini(tr('Delete'), () async {
          if (await fxSure(context, trf('Remove {0}? Students of this bus will have no bus.', [x['name']]))) await delDoc(dref('buses', str(x['id'])));
        }, BtnKind.red),
      if (own && run && !me) mini(tr('■ End trip'), () => _stop(x), BtnKind.red),
      if (own && str(x['driverUid']).isNotEmpty)
        mini(tr('Reset driver PIN'), () async {
          if (await fxSure(context, trf('Clear the duty PIN of {0}? They choose a new one at the next check-in.', [(str(x['driverName']).isEmpty ? tr('this driver') : x['driverName'])]))) {
            await updateDoc(memRef(str(x['driverUid'])), {'pinH': ''});
            toast('✅', tr('PIN cleared'));
          }
        }),
    ]));
    return FxCard(bar: run ? p.green : null, w);
  }

  List<Widget> _history() {
    final T = TR.where((t) => hb == 'All' || t['busId'] == hb).toList()..sort((a, b) => intv(b['start']).compareTo(intv(a['start'])));
    final w = <Widget>[];
    if (own) {
      final ids = TR.map((t) => str(t['busId'])).toSet().toList();
      if (ids.length > 1) w.add(SelectField('Bus', hb, [('All', 'All buses'), for (final i in ids) (i, str(TR.firstWhere((t) => t['busId'] == i)['busName']).isEmpty ? i : str(TR.firstWhere((t) => t['busId'] == i)['busName']))], (v) => setState(() => hb = v)));
    }
    if (T.isEmpty) return [...w, const Empty('No trips yet.', icon: '🕘')];
    final tot = T.fold<int>(0, (s, t) => s + busDur(t));
    int endOf(Doc t) => intv(t['end']) > 0 ? intv(t['end']) : (intv(t['until']) < now() ? intv(t['until']) : 0);
    w.add(FxHead(trf('{0} trip{1} · {2}', [T.length, (T.length == 1 ? '' : 's'), busHrs(tot)]),
        sub: own ? tr('Every trip of every bus. Export it as a spreadsheet for your records.') : tr('Every trip you have driven.'),
        btn: own ? tr('⬇ Export CSV') : null,
        onTap: () => exportCSV('bus-trips-${td()}', const ['Date', 'Bus', 'Route', 'Driver', 'Trip', 'Start', 'End', 'Hours', 'Students', 'Picked / dropped', 'Absent', 'Not marked'], [
              for (final t in T)
                [
                  ymd(dtOf(t['start'])),
                  t['busName'],
                  str(t['route']),
                  str(t['driverName']),
                  t['dir'] == 'pm' ? 'Evening' : 'Morning',
                  tm(t['start']),
                  endOf(t) > 0 ? tm(endOf(t)) : 'running',
                  endOf(t) > 0 ? ((endOf(t) - intv(t['start'])) / 3600000).toStringAsFixed(2) : '',
                  t['n'] ?? '',
                  t['ok'] ?? '',
                  t['abs'] ?? '',
                  t['left'] ?? '',
                ]
            ], raw: true)));
    for (final t in T.take(150)) {
      final e = endOf(t);
      w.add(FxCard([
        Wrap(spacing: 6, crossAxisAlignment: WrapCrossAlignment.center, children: [Pill(t['dir'] == 'pm' ? tr('Evening') : tr('Morning'), tone: Tone.b), Pill(e > 0 ? busHrs(e - intv(t['start'])) : tr('Running'), tone: e > 0 ? Tone.m : Tone.g), Text(fxDate(ymd(dtOf(t['start']))), style: small())]),
        const SizedBox(height: 6),
        Text('🚌 ${t['busName']}', style: h3()),
        Meta('${own ? '${str(t['driverName'])} · ' : ''}${tm(t['start'])} – ${e > 0 ? '${tm(e)}${intv(t['end']) > 0 ? '' : tr(' (stopped automatically)')}' : 'now'}${t['n'] != null ? trf(' · {0} of {1} students{2}{3}', [t['ok'], t['n'], (intv(t['abs']) > 0 ? trf(' · {0} absent', [t['abs']]) : ''), (intv(t['left']) > 0 ? trf(' · {0} not marked', [t['left']]) : '')]) : ''}'),
      ]));
    }
    return w;
  }

  @override
  Widget build(BuildContext context) {
    final drv = (L ?? []).any(mine);
    final w = <Widget>[
      FxHead(
          adm
              ? tr('School buses')
              : drv
                  ? tr('My bus')
                  : tr('School buses'),
          sub: own
              ? tr('Add the buses and put the students on them. Parents set their own pickup points; drivers only start and end the trip.')
              : drv
                  ? tr('Start the trip when you leave and end it when you are done. The app shows the next pickup by itself.')
                  : tr('Buses of the school and where they are now.'),
          btn: own && view == 'bus' ? tr('＋ Add a bus') : null,
          onTap: () => _edit()),
    ];
    if (own || drv) {
      final oi = (ISS ?? []).where((r) => r['status'] == 'Open').length, oc = (INC ?? []).where((r) => r['status'] == 'Open').length;
      w.add(Chips(own ? [('bus', 'Buses'), ('hist', 'Trip history'), ('iss', 'Vehicle issues${oi > 0 ? ' · $oi' : ''}'), ('inc', 'Incidents${oc > 0 ? ' · $oc' : ''}')] : const [('bus', 'My bus'), ('hist', 'Trip history')], view, (v) => setState(() => view = v)));
    }
    if (L != null && err == null && !adm && !drv && S.isBusJob(S.me)) {
      final mb = mapv(S.me!['bus']);
      w.add(FxCard([
        Text(str(mb['name']).isNotEmpty ? '🚌 ${mb['name']}' : tr('🚌 Your bus'), style: h3()),
        Meta(str(mb['name']).isNotEmpty
            ? (mb['done'] == true ? tr("This bus is not in the school's list right now. Send the number again, or ask the Principal.") : tr("Sent to the Principal. The bus appears here as soon as the Principal's app adds it."))
            : tr("Enter your bus number. The Principal's app then adds the bus for you.")),
        const SizedBox(height: 10),
        Btn(str(mb['name']).isNotEmpty ? tr('Change bus details') : tr('＋ Add my bus'), onTap: () => _myBus(mb)),
      ]));
      return fxBody(w);
    }
    final st = fxState(err, L, '🚌', adm ? tr('No buses have been added yet.') : tr('No bus has been given to you yet. Ask the Principal.'));
    if (st != null) return fxBody([...w, st]);
    if (view == 'hist') return fxBody([...w, ..._history()]);
    if (view == 'iss' || view == 'inc') return fxBody([...w, ...drvRepList(context, view == 'iss' ? 'busissues' : 'businc', view == 'iss' ? ISS : INC, true)]);
    if (own) {
      w.add(Padding(padding: const EdgeInsets.only(bottom: 12), child: Btn.o(tr('📣 Message the drivers'), small: true, onTap: () => drvMsgForm(context, L!))));
      final sc = _schOf();
      w.add(FxCard([
        Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(tr('🏫 School location'), style: h3()), Text(sc != null ? trf('{0} · used to tell parents "reached school"', [busPkTxt(sc)]) : tr('Not set yet. Set it once, for all buses, so parents are told when the bus reaches the school.'), style: small())])),
          mini(sc != null ? tr('Change') : tr('Set'), _schSet, sc != null ? BtnKind.outline : BtnKind.primary),
        ]),
      ]));
    }
    final R = (adm ? L! : (drv ? L!.where(mine).toList() : L!)).toList()
      ..sort((p, q) {
        final c = (mine(q) ? 1 : 0) - (mine(p) ? 1 : 0);
        return c != 0 ? c : natCmp(str(p['name']), str(q['name']));
      });
    w.addAll(R.map(_busCard));
    return fxBody(w);
  }
}

class _Manifest extends StatelessWidget {
  final int n, done, rem, abs;
  final bool pm;
  const _Manifest(this.n, this.done, this.rem, this.abs, this.pm);
  @override
  Widget build(BuildContext context) {
    final p = pal;
    Widget c(String i, int v, String t, Color col) => Expanded(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 3),
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(color: col.withOpacity(.10), borderRadius: BorderRadius.circular(14)),
            child: Column(children: [Text('$i $v', style: h3()), Text(t, style: small())]),
          ),
        );
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Row(children: [c('🧒', n, 'expected', p.blue), c('✅', done, pm ? 'dropped' : 'picked', p.green), c('⏳', rem, 'remaining', p.amber), c('❌', abs, 'absent', p.red)]),
    );
  }
}

/// the manifest for the driver's home card
Widget busManifest(int n, int done, int rem, int abs, bool pm) => _Manifest(n, done, rem, abs, pm);
Widget busLivePill(bool on) => _LivePill(on);
Widget busZone(String k, String t) => _Zone(k, t);
