import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/files.dart';
import '../../core/fs.dart';
import '../../core/kinds.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/media.dart';
import '../../ui/pick.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import '../comm/chat_ctl.dart';
import 'fx.dart';

/* =============================== SOCIETY add-ons =============================== */

/* ---------- Lost & Found ---------- */
class LfPage extends StatefulWidget {
  const LfPage({super.key});
  @override
  State<LfPage> createState() => _LfPageState();
}

class _LfPageState extends State<LfPage> {
  String f = 'all';

  void _post() => fxForm(context, 'Post an item', 'Lost something, or found something that is not yours?', const [
        FF('kind', 'Type', type: 'select', opts: [('lost', 'I lost something'), ('found', 'I found something')], req: true),
        FF('title', 'What is it?', ph: 'e.g. Black wallet, car keys', req: true, max: 80),
        FF('where', 'Where?', ph: 'e.g. Near Tower B lift', max: 80),
        FF('desc', 'Details', type: 'area', ph: 'Colour, brand, when…', max: 400),
        FF('img', 'Photo', type: 'file'),
      ], 'Post', (v) async {
        final img = v['img'] != null ? await up(v['img'].bytes, 'classifieds', 'p.jpg') : '';
        await fxAdd('lostfound', {'kind': v['kind'], 'title': v['title'], 'where': v['where'], 'desc': v['desc'], 'img': img, 'status': 'open', ...fxMe()});
        toast('✅', 'Posted');
      });

  @override
  Widget build(BuildContext context) {
    return QList(
      query: col('lostfound').orderBy('ts', descending: true).limit(150),
      allowEmpty: true,
      builder: (_, L) {
        final p = pal;
        final R = L.where((x) => f == 'all' || (f == 'mine' ? x['uid'] == S.uid : x['kind'] == f)).toList();
        return fxBody([
          FxHead('Lost something? Found something?', sub: 'Post it here so that it reaches everyone.', btn: '＋ Post an item', onTap: _post),
          Chips(const [('all', 'All'), ('lost', 'Lost'), ('found', 'Found'), ('mine', 'My posts')], f, (x) => setState(() => f = x)),
          if (L.isEmpty) const Empty('Nothing has been posted yet.', icon: '🔎') else if (R.isEmpty) const Empty('Nothing here.', icon: '🔎'),
          for (final x in R)
            Builder(builder: (_) {
              final lost = x['kind'] == 'lost', closed = x['status'] == 'closed', mine = x['uid'] == S.uid;
              return FxCard(bar: lost ? p.red : p.green, [
                Wrap(spacing: 6, children: [Pill(lost ? 'Lost' : 'Found', tone: lost ? Tone.r : Tone.g), if (closed) Pill(lost ? 'Got it back ✓' : 'Returned ✓', tone: Tone.m)]),
                const SizedBox(height: 6),
                Text(str(x['title']), style: h3()),
                if (str(x['where']).isNotEmpty) Meta('📍 ${x['where']}'),
                if (str(x['desc']).isNotEmpty) Desc(str(x['desc'])),
                if (okImg(x['img'])) fxImg(context, str(x['img'])),
                Meta('${str(x['name'])}${str(x['flat']).isNotEmpty ? ' · ${x['flat']}' : ''} · ${dt(x['ts'])}'),
                fxActs([
                  if (!mine && !closed) mini('💬 Message', () => Chat.openDM(str(x['uid'])), BtnKind.primary),
                  if ((mine || S.isAdm) && !closed) mini(lost ? '✓ I got it back' : '✓ Returned to owner', () => updateDoc(dref('lostfound', str(x['id'])), {'status': 'closed'}), BtnKind.green),
                  if (mine || S.isAdm)
                    mini('Delete', () async {
                      if (!await fxSure(context, 'Delete this post?')) return;
                      await delDoc(dref('lostfound', str(x['id'])));
                      rmFile(x['img']);
                    }, BtnKind.red),
                ]),
              ]);
            }),
        ]);
      },
    );
  }
}

/* ---------- Vendor / service directory with ratings ---------- */
class VenPage extends StatefulWidget {
  const VenPage({super.key});
  @override
  State<VenPage> createState() => _VenPageState();
}

class _VenPageState extends State<VenPage> {
  String cat = 'All';

  void _edit([Doc? x]) => fxForm(context, x != null ? 'Edit contact' : 'Add a service contact', 'A plumber, electrician or any service you trust. Everyone can see and rate it.', [
        FF('name', 'Name', ph: 'e.g. Ramesh Plumbing', req: true, val: x?['name'], max: 60),
        FF('cat', 'Service', type: 'select', opts: SelectField.same(vcats), val: x != null ? str(x['cat']) : vcats.first, req: true),
        FF('phone', 'Phone number', type: 'tel', ph: '10-digit mobile', req: true, val: x?['phone'], max: 15),
        FF('note', 'Note', ph: 'Timings, charges, area…', val: x?['note'], max: 160),
      ], 'Save', (v) async {
        if (str(v['phone']).replaceAll(RegExp(r'\D'), '').length < 8) throw fxBadE('Enter a valid phone number.');
        if (x != null) {
          await updateDoc(dref('vendors', str(x['id'])), v);
        } else {
          await fxAdd('vendors', {...v, 'uid': S.uid, 'byName': S.me!['name']});
        }
        toast('✅', 'Saved');
      });

  void _rate(Doc x, List<Doc> R) {
    final my = R.where((r) => r['pid'] == x['id'] && r['uid'] == S.uid).firstOrNull;
    var n = intv(my?['v']);
    final tx = TextEditingController(text: str(my?['text']));
    sheet(context, (c) => StatefulBuilder(
        builder: (c, set) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
              SheetTitle('Rate ${str(x['name'])}', sub: str(x['cat'])),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                for (var i = 1; i <= 5; i++)
                  IconButton(
                    iconSize: 40,
                    tooltip: '$i star${i > 1 ? 's' : ''}',
                    onPressed: () => set(() => n = i),
                    icon: AnimatedScale(scale: i <= n ? 1.12 : 1, duration: const Duration(milliseconds: 160), child: Icon(i <= n ? Icons.star_rounded : Icons.star_outline_rounded, color: i <= n ? const Color(0xFFF59E0B) : pal.faint)),
                  ),
              ]),
              const SizedBox(height: 8),
              Field(tx, 'How was the work? (optional)', lines: 3, max: 300),
              Btn('Save rating', onTap: () async {
                if (n == 0) {
                  toast('ℹ️', 'Tap a star first');
                  return;
                }
                await setDoc(dref('responses', '${x['id']}_${S.uid}'), {'pid': x['id'], 'k': 'rate', 'uid': S.uid, 'name': S.me!['name'], 'v': n, 'text': tx.text.trim(), 'ts': now()});
                if (c.mounted) Navigator.of(c).pop();
              }),
            ])));
  }

  void _reviews(Doc x, List<Doc> R) {
    final rs = R.where((r) => r['pid'] == x['id']).toList()..sort((a, b) => intv(b['ts']).compareTo(intv(a['ts'])));
    sheet(context, (c) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
          SheetTitle(str(x['name']), sub: '${rs.length} rating${rs.length == 1 ? '' : 's'}'),
          for (final r in rs) Ex(str(r['name']), sub: str(r['text']).isEmpty ? null : str(r['text']), right: Text('★ ${r['v']}', style: const TextStyle(color: Color(0xFFF59E0B), fontWeight: FontWeight.w800))),
        ]));
  }

  @override
  Widget build(BuildContext context) {
    return QMulti(
      queries: [col('vendors').orderBy('ts', descending: true).limit(300), col('responses').where('k', isEqualTo: 'rate').limit(2000)],
      allowEmpty: true,
      builder: (_, ls) {
        final L = ls[0], R = ls[1];
        final cats = ['All', ...vcats.where((c) => L.any((x) => x['cat'] == c))];
        if (!cats.contains(cat)) cat = 'All';
        (int, double) avg(dynamic id) {
          final rs = R.where((r) => r['pid'] == id).toList();
          return (rs.length, rs.isEmpty ? 0 : rs.fold<num>(0, (s, r) => s + numv(r['v'])) / rs.length);
        }

        final V = L.where((x) => cat == 'All' || x['cat'] == cat).map((x) => (x, avg(x['id']))).toList()
          ..sort((p, q) {
            var c = q.$2.$2.compareTo(p.$2.$2);
            if (c == 0) c = q.$2.$1.compareTo(p.$2.$1);
            if (c == 0) c = intv(q.$1['ts']).compareTo(intv(p.$1['ts']));
            return c;
          });
        return fxBody([
          FxHead('Trusted services near you', sub: 'Numbers shared and rated by people here.', btn: '＋ Add a contact', onTap: () => _edit()),
          if (L.isEmpty) const Empty('No contacts yet. Add the first one.', icon: '🧰') else Chips([for (final c in cats) (c, c)], cat, (x) => setState(() => cat = x)),
          for (final e in V)
            Builder(builder: (_) {
              final x = e.$1, r = e.$2;
              final mine = x['uid'] == S.uid;
              return FxCard([
                Row(children: [
                  Pill(str(x['cat']), tone: Tone.b),
                  const Spacer(),
                  if (r.$1 > 0) GestureDetector(onTap: () => _reviews(x, R), child: Text('★ ${r.$2.toStringAsFixed(1)} (${r.$1})', style: const TextStyle(color: Color(0xFFF59E0B), fontWeight: FontWeight.w800))) else Text('No ratings yet', style: small()),
                ]),
                const SizedBox(height: 6),
                Text(str(x['name']), style: h3()),
                Meta('📞 ${str(x['phone'])}${str(x['note']).isNotEmpty ? ' · ${x['note']}' : ''}'),
                if (str(x['byName']).isNotEmpty) Meta('Added by ${x['byName']}'),
                fxActs([
                  mini('📞 Call', () => launchUrl(Uri.parse('tel:${str(x['phone']).replaceAll(RegExp(r'[^\d+]'), '')}')), BtnKind.primary),
                  mini(R.any((q) => q['pid'] == x['id'] && q['uid'] == S.uid) ? '★ Change my rating' : '★ Rate', () => _rate(x, R)),
                  if (mine || S.isAdm) mini('Edit', () => _edit(x)),
                  if (mine || S.isAdm)
                    mini('Delete', () async {
                      if (await fxSure(context, 'Remove ${str(x['name'])}?')) await delDoc(dref('vendors', str(x['id'])));
                    }, BtnKind.red),
                ]),
              ]);
            }),
        ]);
      },
    );
  }
}

/* ---------- Meetings: agenda, RSVP, minutes ---------- */
class MeetPage extends StatefulWidget {
  const MeetPage({super.key});
  @override
  State<MeetPage> createState() => _MeetPageState();
}

class _MeetPageState extends State<MeetPage> {
  void _edit([Doc? x]) => fxForm(context, x != null ? 'Edit meeting' : 'Schedule a meeting', 'Everyone gets to see the agenda and can say if they are coming.', [
        FF('title', 'Title', ph: 'e.g. Annual General Meeting', req: true, val: x?['title'], max: 80),
        FF('date', 'Date', type: 'date', req: true, val: x != null ? str(x['date']) : td()),
        FF('time', 'Time', type: 'time', req: true, val: x != null ? str(x['time']) : '18:00'),
        FF('place', 'Place', ph: 'e.g. Clubhouse', val: x?['place'], max: 80),
        FF('agenda', 'Agenda', type: 'area', ph: '1. Accounts for the year\n2. Lift repair\n3. Any other matter', val: x?['agenda'], max: 1500),
      ], x != null ? 'Save' : 'Schedule', (v) async {
        if (x != null) {
          await updateDoc(dref('meetings', str(x['id'])), v);
        } else {
          await fxAdd('meetings', {...v, 'minutes': null, 'uid': S.uid, 'byName': S.me!['name']});
        }
        toast('✅', x != null ? 'Saved' : 'Meeting scheduled');
      });

  Future<void> _addMin(Doc x) async {
    final f = await pickDocOrPhoto(context);
    if (f == null) return;
    try {
      final url = await up(f.bytes, 'docs', f.name);
      final m = mapv(x['minutes']);
      if (str(m['url']).isNotEmpty) rmFile(m['url']);
      await updateDoc(dref('meetings', str(x['id'])), {'minutes': {'url': url, 'name': f.name, 'type': f.mime, 'ts': now()}});
      toast('✅', 'Minutes uploaded');
    } catch (e) {
      fail(e, "Couldn't upload");
    }
  }

  void _who(Doc x, List<Doc> R) => sheet(context, (c) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
        SheetTitle('Responses', sub: str(x['title'])),
        for (final k in const [['yes', 'Coming'], ['maybe', 'Maybe'], ['no', 'Not coming']]) ...[
          Builder(builder: (_) {
            final rs = R.where((r) => r['pid'] == x['id'] && r['v'] == k[0]).toList();
            return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Sec('${k[1]} (${rs.length})'),
              if (rs.isEmpty) Text('—', style: meta()),
              for (final r in rs) Text('${str(r['name'])}${str(r['flat']).isNotEmpty ? ' · ${r['flat']}' : ''}', style: meta()),
            ]);
          }),
        ],
      ]));

  Widget _card(Doc x, List<Doc> R) {
    final p = pal, adm = S.isAdm;
    final past = str(x['date']).compareTo(td()) < 0;
    final rs = R.where((r) => r['pid'] == x['id']).toList();
    final my = rs.where((r) => r['uid'] == S.uid).firstOrNull;
    int cnt(String k) => rs.where((r) => r['v'] == k).length;
    final mn = mapv(x['minutes']);
    return FxCard(bar: past ? p.faint : p.a, [
      Text(str(x['title']), style: h3()),
      Meta('📅 ${fxDate(str(x['date']))} · ${fxT12(str(x['time']))}${str(x['place']).isNotEmpty ? ' · 📍 ${x['place']}' : ''}'),
      if (str(x['agenda']).isNotEmpty) ...[const Sec('Agenda'), Desc(str(x['agenda']))],
      if (!past) ...[
        const Sec('Are you coming?'),
        Chips([for (final k in const [['yes', '👍 Yes'], ['maybe', '🤔 Maybe'], ['no', '👎 No']]) (k[0], '${k[1]} · ${cnt(k[0])}')], str(my?['v']), (k) {
          setDoc(dref('responses', '${x['id']}_${S.uid}'), {'pid': x['id'], 'k': 'rsvp', 'uid': S.uid, 'name': S.me!['name'], 'flat': str(S.me!['flat']), 'v': k, 'ts': now()}).catchError((e) => fail(e));
        }, pad: EdgeInsets.zero),
      ] else
        Meta('${cnt('yes')} said they would come'),
      fxActs([
        if (str(mn['url']).isNotEmpty) mini('📄 Minutes', () => openRef(context, str(mn['url']), name: str(mn['name']).isEmpty ? 'minutes.pdf' : str(mn['name']), mime: str(mn['type'])), BtnKind.primary),
        if (adm) mini('👥 Responses', () => _who(x, R)),
        if (adm) mini(mn.isNotEmpty ? 'Replace minutes' : '⬆ Upload minutes', () => _addMin(x)),
        if (adm) mini('Edit', () => _edit(x)),
        if (adm)
          mini('Delete', () async {
            if (!await fxSure(context, 'Delete this meeting?')) return;
            await delDoc(dref('meetings', str(x['id'])));
            if (str(mn['url']).isNotEmpty) rmFile(mn['url']);
          }, BtnKind.red),
      ]),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final adm = S.isAdm;
    return QMulti(
      queries: [col('meetings').orderBy('ts', descending: true).limit(100), col('responses').where('k', isEqualTo: 'rsvp').limit(2000)],
      allowEmpty: true,
      builder: (_, ls) {
        final L = ls[0], R = ls[1], t = td();
        final upc = L.where((x) => str(x['date']).compareTo(t) >= 0).toList()..sort((a, b) => '${a['date']}${a['time']}'.compareTo('${b['date']}${b['time']}'));
        final old = L.where((x) => str(x['date']).compareTo(t) < 0).toList()..sort((a, b) => str(b['date']).compareTo(str(a['date'])));
        return fxBody([
          FxHead('Meetings', sub: adm ? 'Schedule a meeting, see who is coming, and upload the minutes afterwards.' : 'See the agenda, tell the committee if you are coming, and read the minutes afterwards.', btn: adm ? '＋ Schedule a meeting' : null, onTap: () => _edit()),
          if (L.isEmpty) const Empty('No meetings yet.', icon: '🗓️'),
          if (upc.isNotEmpty) ...[fxSec('Upcoming'), for (final x in upc) _card(x, R)],
          if (old.isNotEmpty) ...[fxSec('Earlier meetings'), for (final x in old) _card(x, R)],
        ]);
      },
    );
  }
}

/// a PDF or a photo
Future<PFile?> pickDocOrPhoto(BuildContext context, [String title = 'Minutes']) => pickPhotoSheet(context, pdf: true, title: title);

/* ---------- Expense report with a donut chart ---------- */
class ExrPage extends StatefulWidget {
  const ExrPage({super.key});
  @override
  State<ExrPage> createState() => _ExrPageState();
}

class _ExrPageState extends State<ExrPage> {
  String mon = td().substring(0, 7);
  @override
  Widget build(BuildContext context) {
    return QList(
      query: col('expenses').orderBy('ts', descending: true).limit(600),
      allowEmpty: true,
      builder: (_, L) {
        final p = pal;
        String ym(dynamic t) {
          final d = dtOf(t);
          return '${d.year}-${p2(d.month)}';
        }

        final R = L.where((x) => ym(x['ts']) == mon).toList()..sort((a, b) => intv(b['ts']).compareTo(intv(a['ts'])));
        final tot = R.fold<num>(0, (s, x) => s + numv(x['amount']));
        final lbl = mname(mon);
        final by = <String, num>{};
        for (final x in R) {
          final k = str(x['category']).isEmpty ? 'Other' : str(x['category']);
          by[k] = (by[k] ?? 0) + numv(x['amount']);
        }
        final parts = by.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
        return fxBody([
          FxHead('Where the money went', sub: 'Every expense recorded by the committee, month by month.${S.canFin ? ' Add expenses in Finance → Expenses.' : ''}'),
          MonthField('Month', mon, (v) => setState(() => mon = v), max: td().substring(0, 7)),
          if (L.isEmpty)
            const Empty('No expenses have been recorded yet.', icon: '📊')
          else if (R.isEmpty)
            Empty('No expenses recorded for $lbl.', icon: '📊')
          else ...[
            AppCard(children: [
              Text('Total spent in $lbl', style: meta()),
              CountUp(tot, money: true, style: h1()),
              const SizedBox(height: 14),
              Row(children: [
                SizedBox(width: 130, height: 130, child: Donut([for (var i = 0; i < parts.length; i++) (parts[i].value.toDouble(), fxCols[i % fxCols.length])], hole: Text(rs(tot), style: small().copyWith(fontWeight: FontWeight.w800)))),
                const SizedBox(width: 16),
                Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  for (var i = 0; i < parts.length; i++)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 3),
                      child: Row(children: [
                        Container(width: 10, height: 10, decoration: BoxDecoration(color: fxCols[i % fxCols.length], borderRadius: BorderRadius.circular(3))),
                        const SizedBox(width: 6),
                        Expanded(child: Text(parts[i].key, style: small(), overflow: TextOverflow.ellipsis)),
                        Text('${rs(parts[i].value)} · ${(parts[i].value / tot * 100).round()}%', style: small().copyWith(fontWeight: FontWeight.w700)),
                      ]),
                    ),
                ])),
              ]),
            ]),
            fxSec('All expenses · ${R.length}'),
            AppCard(children: [
              for (final x in R)
                Ex(str(x['reason']).isNotEmpty ? str(x['reason']) : (str(x['category']).isNotEmpty ? str(x['category']) : 'Expense'),
                    sub: '${str(x['category']).isEmpty ? 'Other' : x['category']} · ${dt(x['ts'])}', right: Text(rs(x['amount']), style: TextStyle(color: p.red, fontWeight: FontWeight.w800))),
            ]),
          ],
        ]);
      },
    );
  }
}

/// a donut chart that draws itself in
class Donut extends StatelessWidget {
  final List<(double, Color)> parts;
  final Widget? hole;
  const Donut(this.parts, {super.key, this.hole});
  @override
  Widget build(BuildContext context) => TweenAnimationBuilder<double>(
        tween: Tween(begin: 0, end: 1),
        duration: const Duration(milliseconds: 900),
        curve: Curves.easeOutCubic,
        builder: (_, t, __) => CustomPaint(painter: _DonutP(parts, t, pal.line), child: Center(child: hole)),
      );
}

class _DonutP extends CustomPainter {
  final List<(double, Color)> parts;
  final double t;
  final Color bg;
  _DonutP(this.parts, this.t, this.bg);
  @override
  void paint(Canvas c, Size s) {
    final r = math.min(s.width, s.height) / 2 - 10;
    final rect = Rect.fromCircle(center: s.center(Offset.zero), radius: r);
    final pn = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 18;
    c.drawCircle(s.center(Offset.zero), r, pn..color = bg);
    final tot = parts.fold<double>(0, (a, x) => a + x.$1);
    if (tot <= 0) return;
    var a = -math.pi / 2;
    for (final x in parts) {
      final sw = x.$1 / tot * 2 * math.pi * t;
      c.drawArc(rect, a, math.max(0, sw - .02), false, pn..color = x.$2);
      a += sw;
    }
  }

  @override
  bool shouldRepaint(covariant _DonutP o) => o.t != t || o.parts != parts;
}
