import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import '../core/app.dart';
import '../core/kinds.dart';
import '../core/nav.dart';
import '../core/plan.dart';
import '../core/session.dart';
import '../core/store.dart';
import '../core/util.dart';
import '../ui/anim.dart';
import '../ui/kit.dart';
import '../ui/media.dart';
import '../ui/sheets.dart';
import '../ui/theme.dart';
import 'boot.dart';
import 'fin/sub.dart';
import 'fx/driver.dart';
import 'fx/fx.dart';
import 'fx/school_bus.dart';
import 'services/vis.dart';
import 'shell.dart';

/// the home screen: the hero, quick actions, today's numbers, the collection ring, the latest notice ...
class HomeTab extends StatelessWidget {
  const HomeTab({super.key});
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([D.anySlow, S, SubHist.I]),
      builder: (_, __) {
        final kids = <Widget>[];
        if (PlanSt.locked) {
          kids.add(const LockHome());
        } else {
          kids.add(const HomeHero());
          kids.add(const PlanHome());
          final kc = _kidChips();
          if (kc != null) kids.add(kc);
          if (S.isMgr && SubHist.I.list().isNotEmpty) kids.add(const PlanInvCard());
          if (S.isDrv) {
            kids.add(const DrvHome());
          } else {
            kids.addAll(_body(context));
          }
        }
        return RefreshIndicator(
          onRefresh: () async {
            App.startApp();
          },
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 120),
            children: [for (final (i, w) in kids.indexed) Enter(index: i, child: w)],
          ),
        );
      },
    );
  }

  Widget? _kidChips() {
    final P = S.myProfiles().where((k) => k['status'] == 'approved' || k['id'] == S.uid).toList();
    if (!(S.sch && S.prim != null && S.isStu(S.prim)) || P.length < 2) return null;
    return Chips([for (final k in P) (str(k['id']), '${firstName(str(k['name']))} · ${S.clsOf(k)}')], S.pidv, (id) => Kids.switchKid(id));
  }

  List<Widget> _body(BuildContext context) {
    final p = pal;
    final V = D['vis'].values.where(visShown).toList(), dl = D['del'].values.toList(), today = td();
    final open = D['comp'].values.where((c) => !const ['Resolved', 'Closed'].contains(c['status'])).length;
    final bal = D['inc'].values.fold<num>(0, (a, c) => a + numv(c['amount'])) - D['exp'].values.fold<num>(0, (a, c) => a + numv(c['amount']));
    final pend = D['mem'].values.where((m) => m['status'] == 'pending').length;
    final exp = V.where((v) => v['status'] == 'Expected' && v['date'] == today).length, inside = V.where((v) => v['status'] == 'Inside').length, wait = V.where((v) => v['status'] == 'Waiting').length, parc = dl.where((d) => d['status'] == 'Received').length;
    final Q = S.isGuard
        ? [('✅', 'Verify visitor', 'svc:vis', Icons.verified_rounded), ('🚶', 'New visitor', 'svc:vis', Icons.directions_walk_rounded), ('📦', 'Parcel', 'svc:del', Icons.inventory_2_rounded), ('🚗', 'Vehicle', 'svc:veh', Icons.directions_car_rounded)]
        : [
            ('🛠️', 'Complaint', 'svc:comp', Icons.build_rounded),
            ('🎟️', 'Invite visitor', 'svc:vis', Icons.confirmation_number_rounded),
            ('📦', 'Parcels', 'svc:del', Icons.inventory_2_rounded),
            ('🚗', 'Vehicles', 'svc:veh', Icons.directions_car_rounded),
            ('📢', 'Notices', 'comm', Icons.campaign_rounded),
            if (S.isAdm) ('💰', 'Fund', 'fin', Icons.account_balance_wallet_rounded),
            if (fxList().contains('pay') && fxShown('pay')) ('📄', 'Payslips', 'fx:pay', Icons.description_rounded),
          ];
    final payN = S.isAdm ? D['bills'].values.where((b) => b['status'] == 'Pending').length : 0;
    final st = S.isGuard
        ? [('🚪', exp as num, 'Verified at gate', false), ('🟢', inside as num, 'Inside now', false), ('⏳', wait as num, 'Waiting approval', false), ('📦', parc as num, 'Parcels at desk', false)]
        : [
            ('🛠️', open as num, 'Open complaints', false),
            ('🎟️', exp as num, S.staff ? 'Passes verified today' : 'Visitors expected today', false),
            ('📦', parc as num, 'Parcels waiting', false),
            if (S.isAdm) ...[('💰', bal, S.sk('Society fund'), true), ('🙋', pend as num, 'Pending approvals', false), ('🟢', inside as num, 'Visitors inside', false)],
            if (payN > 0) ('💸', payN as num, 'Payments to confirm', false),
          ];
    final w = <Widget>[];
    w.add(Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: GridView.count(
        crossAxisCount: 4,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: .86,
        children: [for (final (i, q) in Q.indexed) _QuickTile(q.$1, S.sk(q.$2), q.$4, () => nav.go(q.$3), i)],
      ),
    ));
    w.add(GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      childAspectRatio: 2.05,
      padding: const EdgeInsets.only(bottom: 14),
      children: [
        for (final s in st)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(18), border: Border.all(color: p.line), boxShadow: p.shadow),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
              Row(children: [Text(s.$1, style: const TextStyle(fontSize: 17)), const SizedBox(width: 6), Flexible(child: CountUp(s.$2, money: s.$4, style: h2().copyWith(fontSize: 19)))]),
              const SizedBox(height: 2),
              Text(s.$3, maxLines: 1, overflow: TextOverflow.ellipsis, style: small()),
            ]),
          ),
      ],
    ));
    final ring = _ring();
    if (ring != null) w.add(ring);
    final anns = D['ann'].values.toList()..sort((x, y) => intv(y['ts']).compareTo(intv(x['ts'])));
    if (anns.isNotEmpty) {
      final a = anns.first;
      w.add(AppCard(
        title: 'Latest notice',
        trailing: TextButton(
            onPressed: () {
              nav.goTab('comm');
              nav.setComm('ann');
            },
            child: Text('All ›', style: TextStyle(color: p.a, fontWeight: FontWeight.w700))),
        children: [
          Row(children: [Pill(str(a['type']).isEmpty ? 'General' : str(a['type']), tone: a['type'] == 'Emergency' ? Tone.r : Tone.a), const Spacer(), Text(dt(a['ts']), style: small())]),
          const SizedBox(height: 8),
          Text(str(a['title']), style: h3().copyWith(fontSize: 16)),
          Desc(str(a['text'])),
        ],
      ));
    }
    if (S.kind != 'society') {
      final H = D['hol'].values.where((x) => str(x['date']).compareTo(td()) >= 0).toList()..sort((a, b) => str(a['date']).compareTo(str(b['date'])));
      if (H.isNotEmpty) {
        w.add(AppCard(title: '🎉 Upcoming holidays', children: [for (final x in H.take(3)) Ex(str(x['title']), sub: fxDate(str(x['date'])), lead: const Text('🎉', style: TextStyle(fontSize: 20)))]));
      }
    }
    w.addAll(busHomeCards(context));
    return w;
  }

  /// how much of this month's bills is paid (admins: everyone's, others: their own)
  Widget? _ring() {
    if (S.isGuard) return null;
    final all = D['bills'].values.toList();
    if (all.isEmpty) return null;
    final ms = all.map((b) => str(b['month'])).toList()..sort();
    final mon = ms.last;
    final B = all.where((b) => str(b['month']) == mon && (S.isAdm || b['flat'] == S.me?['flat'])).toList();
    if (B.isEmpty) return null;
    final tot = B.fold<num>(0, (s, b) => s + numv(b['amount']));
    final paidB = B.where((b) => b['status'] == 'Paid').toList();
    final paid = paidB.fold<num>(0, (s, b) => s + numv(b['amount']));
    final pc = tot > 0 ? (paid / tot * 100).round() : 0;
    final fee = S.K.fee;
    final p = pal;
    return AppCard(
      onTap: () => nav.go('fin'),
      child: Row(children: [
        Ring(pc / 100, size: 86, stroke: 9, center: CountUp(pc, suffix: '%', style: h3().copyWith(fontSize: 17))),
        const SizedBox(width: 16),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(
                S.isAdm
                    ? (fee == 'fees'
                        ? 'Fees collected'
                        : fee == 'billing'
                            ? 'Bills paid'
                            : 'Maintenance collected')
                    : (fee == 'fees'
                        ? 'Your fees'
                        : fee == 'billing'
                            ? 'Your bills'
                            : 'Your maintenance'),
                style: h3().copyWith(fontSize: 16)),
            Text(RegExp(r'^\d{4}-\d{2}$').hasMatch(mon) ? mname(mon) : mon, style: meta()),
            const SizedBox(height: 4),
            Text('${rs(paid)} of ${rs(tot)}${S.isAdm ? ' · ${paidB.length} of ${B.length} paid' : pc >= 100 ? ' · all paid ✓' : ''}', style: meta(p.text)),
          ]),
        ),
        Icon(Icons.chevron_right_rounded, color: p.faint),
      ]),
    );
  }
}

class _QuickTile extends StatefulWidget {
  final String ic, label;
  final IconData icon;
  final VoidCallback onTap;
  final int i;
  const _QuickTile(this.ic, this.label, this.icon, this.onTap, this.i);
  @override
  State<_QuickTile> createState() => _QuickTileState();
}

class _QuickTileState extends State<_QuickTile> {
  double s = 1;
  static const cols = [Color(0xFF6D5DFC), Color(0xFFFF6B9D), Color(0xFF00A8E8), Color(0xFFF59E0B), Color(0xFF10B981), Color(0xFF8B5CF6), Color(0xFFEF4444)];
  @override
  Widget build(BuildContext context) {
    final p = pal, c = cols[widget.i % cols.length];
    return GestureDetector(
      onTapDown: (_) => setState(() => s = .93),
      onTapCancel: () => setState(() => s = 1),
      onTapUp: (_) => setState(() => s = 1),
      onTap: () {
        HapticFeedback.selectionClick();
        widget.onTap();
      },
      child: AnimatedScale(
        scale: s,
        duration: const Duration(milliseconds: 120),
        child: Container(
          decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(20), border: Border.all(color: p.line), boxShadow: p.shadow),
          padding: const EdgeInsets.all(6),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(gradient: LinearGradient(colors: [c.withOpacity(.18), c.withOpacity(.08)], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(14)),
              alignment: Alignment.center,
              child: Icon(widget.icon, color: c, size: 22),
            ),
            const SizedBox(height: 6),
            Text(widget.label, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: p.text, height: 1.15)),
          ]),
        ),
      ),
    );
  }
}

/* ============================== the hero ============================== */
class HomeHero extends StatefulWidget {
  const HomeHero({super.key});
  @override
  State<HomeHero> createState() => _HomeHeroState();
}

class _HomeHeroState extends State<HomeHero> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 14))..repeat();
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  (String, String) _greet() {
    final h = DateTime.now().hour;
    if (h < 5) return ('🌙', 'Good night');
    if (h < 12) return ('☀️', 'Good morning');
    if (h < 17) return ('🌤️', 'Good afternoon');
    if (h < 21) return ('🌇', 'Good evening');
    return ('🌙', 'Good night');
  }

  @override
  Widget build(BuildContext context) {
    final p = pal, me = S.me ?? {};
    final g = _greet();
    final st = PlanSt.state();
    String pt = '🎁 Free trial';
    if (st.kind == 'paid') {
      pt = '${PlanSt.tier(st.p).$1} ${st.p != null ? '${st.p!.name} plan' : 'Active plan'}';
    } else if (st.kind == 'trial') {
      pt = '🎁 Trial · ${st.left} day${st.left == 1 ? '' : 's'} left';
    }
    final dir = D['pres'].values.where((x) => now() - intv(x['seen']) < 130000).length;
    final unread = D['dmc'].values.where((c) => intv(c['lastTs']) > intv(mapv(c['reads'])[S.uid]) && c['lastFrom'] != S.uid && str(c['lastFrom']).isNotEmpty).length;
    final tiles = <(IconData, num, String, VoidCallback)>[
      if (!S.isGuard && !S.noChat) (Icons.mark_chat_unread_rounded, unread, 'Unread chats', () => nav.goTab('comm')),
      (Icons.wifi_tethering_rounded, dir, 'Online now', () => nav.goTab(S.isGuard ? 'more' : 'comm')),
      (Icons.campaign_rounded, D['ann'].values.where((a) => now() - intv(a['ts']) < 7 * dayMs).length, 'Notices this week', () => nav.goTab(S.isGuard ? 'home' : 'comm')),
    ];
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: LinearGradient(colors: [p.a, Color.lerp(p.a, p.a2, .6)!, p.rc], begin: Alignment.topLeft, end: Alignment.bottomRight, stops: const [0, .6, 1]),
        boxShadow: [BoxShadow(color: p.a.withOpacity(.35), blurRadius: 34, offset: const Offset(0, 16))],
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(children: [
        Positioned.fill(
          child: RepaintBoundary(
            child: AnimatedBuilder(
              animation: _c,
              builder: (_, __) => CustomPaint(painter: _HeroOrbs(_c.value)),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              _glass(Text('${g.$1} ${g.$2}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12.5))),
              const Spacer(),
              Text(DateFormat('EEE, d MMM').format(DateTime.now()), style: TextStyle(color: Colors.white.withOpacity(.85), fontWeight: FontWeight.w600, fontSize: 12.5)),
            ]),
            const SizedBox(height: 16),
            Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Hi, ${firstName(str(me['name']))} 👋', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.w800, letterSpacing: -.6, height: 1.1)),
                  const SizedBox(height: 6),
                  Text('${S.K.ico} ${str(S.soc?['name'])}', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(.95), fontSize: 14.5, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 2),
                  Text(_sub(), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(.8), fontSize: 12.5)),
                ]),
              ),
              const SizedBox(width: 12),
              GestureDetector(
                onTap: () => nav.go('more'),
                child: Container(
                  padding: const EdgeInsets.all(3),
                  decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white.withOpacity(.7), width: 2)),
                  child: Av(str(me['name']), myPhoto(), size: 58),
                ),
              ),
            ]),
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 6, children: [
              _glass(Text(pt, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12))),
              if (S.kidMany)
                GestureDetector(onTap: () => kidSheet(context), child: _glass(const Text('⇅ Switch student', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12)))),
              if (S.swCan)
                GestureDetector(onTap: () => sheet(context, (_) => const SocRows(title: true)), child: _glass(const Text('⇄ Workspaces', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12)))),
            ]),
            const SizedBox(height: 16),
            Row(children: [
              for (final (i, t) in tiles.indexed) ...[
                if (i > 0) const SizedBox(width: 10),
                Expanded(
                  child: GestureDetector(
                    onTap: t.$4,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                      decoration: BoxDecoration(color: Colors.white.withOpacity(.16), borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white.withOpacity(.22))),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Icon(t.$1, color: Colors.white, size: 18),
                        const SizedBox(height: 6),
                        CountUp(t.$2, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
                        Text(t.$3, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(.85), fontSize: 10.5, fontWeight: FontWeight.w600)),
                      ]),
                    ),
                  ),
                ),
              ],
            ]),
          ]),
        ),
      ]),
    );
  }

  String _sub() {
    final me = S.me;
    if (me == null) return '';
    final rl = S.roleLbl(me['role']);
    if (S.kind == 'school') return str(me['flat']).toLowerCase() == rl.toLowerCase() ? rl : '${str(me['flat'])} · ${rl.toLowerCase()}';
    return '${str(me['flat'])} · ${str(me['role']).replaceFirst('_', ' ').toLowerCase()}';
  }

  Widget _glass(Widget c) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), decoration: BoxDecoration(color: Colors.white.withOpacity(.18), borderRadius: BorderRadius.circular(99), border: Border.all(color: Colors.white.withOpacity(.25))), child: c);
}

class _HeroOrbs extends CustomPainter {
  final double t;
  _HeroOrbs(this.t);
  @override
  void paint(Canvas c, Size s) {
    final a = t * 2 * pi;
    void orb(Offset o, double r, double op) {
      c.drawCircle(o, r, Paint()..shader = RadialGradient(colors: [Colors.white.withOpacity(op), Colors.white.withOpacity(0)]).createShader(Rect.fromCircle(center: o, radius: r)));
    }

    orb(Offset(s.width * (.85 + .06 * sin(a)), s.height * (.1 + .08 * cos(a))), s.width * .45, .22);
    orb(Offset(s.width * (.1 + .08 * cos(a * .8)), s.height * (.95 + .05 * sin(a * 1.2))), s.width * .5, .16);
    orb(Offset(s.width * (.55 + .1 * sin(a * .6)), s.height * (.45 + .1 * cos(a * .9))), s.width * .25, .10);
    // fine rings
    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..color = Colors.white.withOpacity(.12);
    c.drawCircle(Offset(s.width * .92, s.height * .18), 70 + 6 * sin(a), ring);
    c.drawCircle(Offset(s.width * .92, s.height * .18), 110 + 8 * cos(a), ring);
  }

  @override
  bool shouldRepaint(_HeroOrbs o) => o.t != t;
}

/* ============================== plan cards ============================== */
class PlanHome extends StatelessWidget {
  const PlanHome({super.key});
  @override
  Widget build(BuildContext context) {
    final p = pal, st = PlanSt.state();
    final tr = st.kind == 'paid' ? PlanSt.tier(st.p) : null;
    final c = tr?.$2 ?? p.a;
    String b, s1, s2 = '';
    if (st.kind == 'paid') {
      b = st.p != null ? '${st.p!.name} plan' : 'Active plan';
      s1 = st.p != null ? 'You are a member of the ${st.p!.name} plan' : 'Your plan is active';
      s2 = 'Valid till ${bdate(st.until)}';
    } else if (st.kind == 'trial') {
      b = 'Free trial';
      s1 = '${st.left} day${st.left == 1 ? '' : 's'} left of your $trialDays-day free trial';
      s2 = 'Ends on ${bdate(st.until)}';
    } else {
      b = 'Free trial';
      s1 = 'You are on the $trialDays-day free trial';
    }
    return AppCard(
      padding: const EdgeInsets.all(14),
      child: Row(children: [
        Container(width: 48, height: 48, decoration: BoxDecoration(color: c.withOpacity(.12), borderRadius: BorderRadius.circular(16)), alignment: Alignment.center, child: Text(tr?.$1 ?? '🎁', style: const TextStyle(fontSize: 24))),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(b, style: h3().copyWith(color: c)),
            Text(s1, style: meta(p.text)),
            if (s2.isNotEmpty) Text(s2, style: small()),
          ]),
        ),
        if (st.kind != 'paid' && S.isMgr) mini('Upgrade', () => nav.go('sub'), BtnKind.primary),
      ]),
    );
  }
}

/// the whole home screen once the trial (or a paid plan) has run out
class LockHome extends StatelessWidget {
  const LockHome({super.key});
  @override
  Widget build(BuildContext context) {
    final st = PlanSt.state(), own = S.isMgr;
    return AppCard(
      padding: const EdgeInsets.all(22),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Center(child: Text('🔒', style: TextStyle(fontSize: 56))),
        const SizedBox(height: 10),
        Text(st.why == 'expired' ? 'Your plan has expired' : 'Your trial period has ended', textAlign: TextAlign.center, style: h2().copyWith(fontSize: 20)),
        const SizedBox(height: 6),
        Text(own ? 'Kindly upgrade to continue.' : 'Kindly ask your admin to upgrade the plan to continue.', textAlign: TextAlign.center, style: body()),
        const SizedBox(height: 6),
        Text('${st.why == 'expired' ? 'The plan ended on ' : 'The free trial ended on '}${bdate(st.until)}. Nothing has been deleted: everything is back as soon as a plan is active.', textAlign: TextAlign.center, style: meta()),
        const SizedBox(height: 16),
        if (own) Btn('Upgrade now', onTap: () => nav.go('sub')),
        if (S.swCan) ...[const SizedBox(height: 8), Btn.o('Switch workspace', small: true, onTap: () => sheet(context, (_) => const SocRows(title: true)))],
        const SizedBox(height: 4),
        TextButton(onPressed: App.logout, child: Text('Log out', style: TextStyle(color: pal.muted, fontWeight: FontWeight.w700))),
      ]),
    );
  }
}
