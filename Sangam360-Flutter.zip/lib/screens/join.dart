import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/app.dart';
import '../core/files.dart';
import '../core/fs.dart';
import '../core/kinds.dart';
import '../core/nav.dart';
import '../core/plan.dart' show gF;
import '../core/session.dart';
import '../core/store.dart';
import '../core/toast.dart';
import '../core/util.dart';
import '../ui/brand.dart';
import '../ui/fields.dart';
import '../ui/kit.dart';
import '../ui/pick.dart';
import '../ui/theme.dart';
import 'boot.dart';

/// A school has two kinds of code: the Principal's code (for teachers and staff) and each teacher's class code (for students).
/// Returns an error text, or null when BootCtl.join is set.
Future<String?> findJoin(String c0, {bool needP = false, bool needC = false}) async {
  final c = c0.trim().toUpperCase();
  if (c.length < 4) return 'Not found';
  final s = await fs.collection('joinCodes').doc(c).get();
  if (!s.exists) return needP ? 'This code was not found. Check it with your Principal.' : 'Not found';
  final j = {...s.data()!, 'code': c};
  final jt0 = str(j['type']).isEmpty ? 'society' : str(j['type']);
  if (S.soc != null) {
    final mt = str(S.soc!['type']).isEmpty ? 'society' : str(S.soc!['type']);
    if (mt != jt0) {
      final k = kinds[mt]!;
      return 'This email is already registered with a ${k.word} (${k.person} account). Use a different email to join a ${kinds[jt0]!.word}.';
    }
  }
  if (jt0 != S.kind) return 'This code is for a ${kinds[jt0]!.word}. Go back and choose "${kinds[jt0]!.card}".';
  final isClass = str(j['teacherUid']).isNotEmpty;
  if (needP && isClass) return "This is a class code for students. Ask your Principal for the Principal's code.";
  if (needC && S.kind == 'school' && !isClass) return "This is the Principal's code, which is only for teachers. Ask your class teacher for your class code.";
  if (!(BootCtl.joinKid && S.me != null && S.me!['status'] == 'approved' && S.sid == j['societyId'] && isClass)) {
    final ex = await App.memCheck(str(j['societyId']), str(j['name']));
    if (ex.isNotEmpty) return ex;
  }
  BootCtl.join = j;
  BootCtl.joinAs = S.kind == 'school' && !isClass ? (BootCtl.joinWant == 'staff' ? 'staff' : 'teacher') : 'student';
  return null;
}

class JoinScreen extends StatefulWidget {
  const JoinScreen({super.key});
  @override
  State<JoinScreen> createState() => _JoinScreenState();
}

class _JoinScreenState extends State<JoinScreen> {
  final jc = TextEditingController(), jsec = TextEditingController(), jx = TextEditingController(), jnm = TextEditingController(), jm = TextEditingController();
  final jbus = TextEditingController(), jroute = TextEditingController();
  String err = '';
  String? jt, jfl;
  String job = staffJobs.first;
  String? idRef, phRef;
  int slotKey = 0;

  @override
  void initState() {
    super.initState();
    jnm.text = S.user?.displayName ?? '';
    if (BootCtl.join != null) _prep();
  }

  Doc get J => BootCtl.join!;
  List<Doc> get towers => listv(J['towers']).map(mapv).toList();
  bool get T => S.kind == 'school' && BootCtl.joinAs == 'teacher';
  bool get ST => S.kind == 'school' && BootCtl.joinAs == 'staff';
  bool get fixed => S.kind == 'school' && str(J['teacherUid']).isNotEmpty;
  bool get kid => BootCtl.kidMode();

  void _prep() {
    jt = towers.isEmpty ? null : str(towers.first['name']);
    _flats();
    if (jnm.text.isEmpty) jnm.text = S.user?.displayName ?? '';
    if (kid) {
      jnm.text = '';
      jm.text = str((S.prim ?? S.me)?['mobile']);
    }
    idRef = null;
    phRef = null;
    slotKey++;
  }

  void _flats() {
    final t = towers.where((x) => x['name'] == jt);
    final l = t.isEmpty ? <String>[] : gF(t.first, towers.length == 1);
    jfl = l.isEmpty ? null : l.first;
  }

  Future<void> _find() async {
    setState(() => err = '');
    final e = await findJoin(jc.text, needP: BootCtl.joinWant == 'teacher' || BootCtl.joinWant == 'staff', needC: BootCtl.joinWant == 'student');
    if (!mounted) return;
    if (e != null) {
      setState(() => err = e);
      return;
    }
    setState(_prep);
  }

  Future<String> _upId(PFile f) async {
    if (kid) {
      final us = await fs.collection('userSociety').doc(S.uid).get();
      final cur = strList(mapv(us.exists ? us.data()!['kids'] : null)[S.sid]);
      var n = 2;
      while (cur.contains('${S.uid}_k$n')) {
        n++;
      }
      return upID(S.sid!, f.bytes, f.name, 'idproofs', sfx: '_k$n');
    }
    return upID(str(J['societyId']), f.bytes, f.name, 'idproofs');
  }

  Future<String> _upPh(PFile f) async {
    if (kid) return up(f.bytes, 'avatars', 'kid.jpg');
    return upID(str(J['societyId']), f.bytes, f.name, 'idphotos', sq: true);
  }

  Future<void> _submit() async {
    setState(() => err = '');
    final nm = jnm.text.trim(), mo = jm.text.trim(), xv = jx.text.trim();
    void e(String t) => setState(() => err = t);
    if (nm.isEmpty || mo.length < 8) return e('Enter your name and mobile number.');
    if (S.isOrg && xv.isEmpty && !T && !ST) return e('Enter your ${S.K.grp!.idp.split(' (')[0]}.');
    if (kid) return _kidSubmit(nm, mo, xv);
    Map<String, dynamic>? busj;
    if (ST && job == 'Bus driver') {
      final b = jbus.text.trim();
      if (b.length < 2) return e('Enter your bus number.');
      busj = {'name': cut(b, 40), 'route': cut(jroute.text.trim(), 120)};
    }
    if (idRef == null || phRef == null) return e('ID proof and your photo are both required to sign up.');
    final sid = str(J['societyId']);
    final ex = await App.memCheck(sid, str(J['name']));
    if (ex.isNotEmpty) return e(ex);
    final sec = jsec.text.trim().toUpperCase().replaceAll(RegExp('[^A-Z0-9]'), '');
    final fl = S.isOrg
        ? (ST
            ? job + (xv.isNotEmpty ? ' · $xv' : '')
            : T
                ? '${jt ?? ''}${sec.isNotEmpty ? '-$sec' : ''}${xv.isNotEmpty ? ' · $xv' : ''}'
                : '${str(J['cls']).isNotEmpty ? str(J['cls']) : (jt ?? '')} · $xv')
        : '${towers.length == 1 ? '' : '${jt ?? ''} · '}Flat ${jfl ?? ''}';
    final keep = S.me != null && S.me!['status'] == 'approved' && S.sid != null && S.sid != sid;
    try {
      await setDoc(memRef(S.uid!, sid), {
        'uid': S.uid,
        'name': nm,
        'mobile': mo,
        'flat': fl,
        'role': 'RESIDENT',
        'status': 'pending',
        'ts': now(),
        'idUrl': idRef,
        'photoUrl': phRef,
        if (T) 'want': 'COMMITTEE_MEMBER',
        if (ST) ...{'want': staffWant(job), 'job': job, if (busj != null) 'bus': busj},
        if (str(J['teacherUid']).isNotEmpty) 'tUid': J['teacherUid'],
      });
    } on FirebaseException catch (x) {
      if (x.code == 'permission-denied') {
        final mm = await App.memCheck(sid, str(J['name']));
        throw AppError(mm.isNotEmpty ? mm : "Couldn't send your request. Please try again in a moment.");
      }
      rethrow;
    }
    try {
      final ids = S.sid != null && S.sid != sid ? [S.sid, sid] : [sid];
      await setDoc(fs.collection('userSociety').doc(S.uid), keep ? {'list': FieldValue.arrayUnion(ids)} : {'societyId': sid, 'list': FieldValue.arrayUnion(ids)}, merge: true);
    } catch (x) {
      if (!keep) rethrow;
    }
    SocRows.cache = null;
    if (keep) {
      S.addMode = false;
      S.go(Phase.main);
      toast('✅', 'Request sent', 'It will appear under My societies once the admin approves you.');
    } else {
      S.addMode = false;
      App.boot();
    }
  }

  Future<void> _kidSubmit(String nm, String mo, String xv) async {
    if (idRef == null || phRef == null) {
      setState(() => err = "This child's own ID proof and photo are both required.");
      return;
    }
    final us = await fs.collection('userSociety').doc(S.uid).get();
    final cur = strList(mapv(us.exists ? us.data()!['kids'] : null)[S.sid]);
    var n = 2;
    while (cur.contains('${S.uid}_k$n')) {
      n++;
    }
    final id = '${S.uid}_k$n';
    final fl = '${str(J['cls']).isNotEmpty ? str(J['cls']) : str(towers.first['name'])} · $xv';
    if (S.myProfiles().any((k) => k['flat'] == fl)) {
      setState(() => err = 'This student is already on your login.');
      return;
    }
    await setDoc(memRef(id), {'uid': id, 'puid': S.uid, 'kid': true, 'name': nm, 'mobile': mo, 'flat': fl, 'role': 'RESIDENT', 'status': 'pending', 'ts': now(), 'idUrl': idRef, 'photoUrl': phRef, 'tUid': J['teacherUid']});
    await setDoc(fs.collection('userSociety').doc(S.uid), {
      'kids': {S.sid!: FieldValue.arrayUnion([id])}
    }, merge: true);
    updateDoc(memRef(S.uid!), {
      'flats': FieldValue.arrayUnion([fl])
    }).catchError((_) {});
    BootCtl.joinKid = false;
    await Kids.load(keep: true);
    Kids.watch();
    S.addMode = false;
    S.go(Phase.main);
    nav.go('more');
    toast('✅', 'Request sent', '$nm appears under My students once the class teacher approves.');
  }

  void _back() {
    final k = BootCtl.joinKid;
    BootCtl.join = null;
    if (k && S.me != null && S.me!['status'] == 'approved') {
      BootCtl.joinKid = false;
      S.addMode = false;
      S.go(Phase.main);
      return;
    }
    S.go(Phase.choice);
  }

  @override
  Widget build(BuildContext context) {
    final p = pal, K = S.K;
    if (BootCtl.join == null) {
      String h, sb, bt;
      if (BootCtl.joinKid) {
        h = 'Add another student';
        sb = "Enter the class code of this child's class teacher. Both children stay on this login and you can switch between them.";
        bt = 'Find my class';
      } else if (BootCtl.joinWant == 'teacher') {
        h = "Enter the Principal's code";
        sb = 'Your Principal gets this code after creating the school. Ask your Principal for it.';
        bt = 'Verify code';
      } else if (BootCtl.joinWant == 'staff') {
        h = 'Enter the school code';
        sb = 'Staff join with the same code that the Principal gives to teachers. Ask your Principal for it.';
        bt = 'Verify code';
      } else if (BootCtl.joinWant == 'student') {
        h = 'Enter your class code';
        sb = 'Ask your class teacher for the class code or invitation link.';
        bt = 'Find my class';
      } else {
        h = 'Enter society code';
        sb = 'Ask your society admin for the code or invitation link.';
        bt = 'Find society';
      }
      return BootPage(
        head: BrandHead(title: S.sk('Join your society')),
        children: [
          Text(S.sk(h), style: h2()),
          const SizedBox(height: 4),
          Text(S.sk(sb), style: meta()),
          const SizedBox(height: 16),
          Field(jc, 'e.g. K7M2QX', max: 8, upper: true, center: true, spacing: 3, action: TextInputAction.done, onSubmit: (_) => _find()),
          Btn(bt, onTap: _find, busyDone: false),
          ErrText(err),
          Lnk('← Back', onTap: _back),
        ],
      );
    }
    final tw = towers;
    String sub, info = '', jxPh = K.grp?.idp ?? '';
    if (ST) {
      sub = 'Choose your job and tell us who you are.';
      info = "🧹 You are joining as Staff with the Principal's code. The Principal approves your request.";
      jxPh = 'Staff / employee ID (optional)';
    } else if (T) {
      sub = 'Choose your class, add the section, and tell us who you are.';
      info = "🧑‍🏫 You are joining as a Teacher with the Principal's code. After the Principal approves you, you get your own class code for your students.";
      jxPh = 'Teacher / employee ID (optional)';
    } else if (fixed) {
      sub = 'Tell us who you are.';
      info = '🎓 ${str(J['cls']).isNotEmpty ? str(J['cls']) : str(tw.first['name'])} · Class teacher: ${str(J['teacherName']).isEmpty ? '—' : str(J['teacherName'])}. Your class teacher approves your request.';
    } else if (S.isOrg) {
      sub = K.grp!.jl;
    } else {
      sub = 'Choose your flat and tell us who you are.';
    }
    if (kid) info = '➕ Adding another student to your login · ${str(J['cls'])} · Class teacher: ${str(J['teacherName']).isEmpty ? '—' : str(J['teacherName'])}. The class teacher approves the request.';
    final showT = !fixed && !ST && !(!S.isOrg && tw.length == 1);
    final flats = !S.isOrg ? gF(tw.firstWhere((x) => x['name'] == jt, orElse: () => tw.first), tw.length == 1) : <String>[];
    return BootPage(
      head: BrandHead(title: S.sk('Join your society')),
      children: [
        Text('${K.ico} ${str(J['name'])}', style: h2().copyWith(fontSize: 19)),
        const SizedBox(height: 4),
        Text(S.sk(sub), style: meta()),
        if (info.isNotEmpty) Note(info, margin: const EdgeInsets.only(top: 10, bottom: 4)),
        const SizedBox(height: 12),
        if (ST) SelectField('Your job', job, SelectField.same(staffJobs), (v) => setState(() => job = v)),
        if (ST && job == 'Bus driver' && !kid) ...[
          Field(jbus, 'Bus number', max: 40),
          Field(jroute, 'Route (optional)', max: 120),
          Padding(padding: const EdgeInsets.only(bottom: 12), child: Text("You only start and end the trip. Parents set their child's pickup point themselves, and the app tells you the next pickup.", style: meta())),
        ],
        if (showT || (!S.isOrg && !fixed))
          Row(children: [
            if (showT)
              Expanded(
                child: SelectField(S.isOrg ? K.grp!.one[0].toUpperCase() + K.grp!.one.substring(1) : 'Tower', jt, SelectField.same(tw.map((t) => str(t['name'])).toList()), (v) => setState(() {
                      jt = v;
                      _flats();
                    })),
              ),
            if (showT && !S.isOrg) const SizedBox(width: 10),
            if (!S.isOrg) Expanded(child: SelectField('Flat', jfl, SelectField.same(flats), (v) => setState(() => jfl = v))),
          ]),
        if (T) Field(jsec, 'Section (optional, e.g. A)', max: 6, upper: true),
        if (S.isOrg) Field(jx, jxPh, max: 30),
        Field(jnm, 'Your name', max: 40, kb: TextInputType.name),
        Field(jm, 'Mobile number', max: 15, kb: TextInputType.phone),
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Text(kid ? "Upload this child's own ID proof (photo or PDF) and a photo of the child — both are required." : 'Upload your ID proof (photo or PDF) and a photo of yourself — both are required.', style: meta()),
        ),
        FileSlot(key: ValueKey('jid$slotKey'), label: '🪪 ID proof', icon: '🪪', pdf: true, upload: _upId, onRef: (r) => idRef = r),
        FileSlot(key: ValueKey('jph$slotKey'), label: kid ? '🤳 Photo of the child' : '🤳 Your photo', icon: '🤳', front: !kid, upload: _upPh, onRef: (r) => phRef = r),
        const SizedBox(height: 6),
        Btn(kid ? 'Add this student' : T ? 'Request to join as Teacher' : ST ? 'Request to join as Staff' : 'Request to join', onTap: _submit, busyDone: false),
        ErrText(err),
        Lnk('← Back', onTap: () => setState(() {
              BootCtl.join = null;
              err = '';
            })),
      ],
    );
  }
}

