import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/fs.dart';
import '../core/kinds.dart';
import '../core/prefs.dart';
import '../core/push.dart';
import '../core/session.dart';
import '../core/util.dart';
import '../l10n/l10n.dart';
import '../ui/kit.dart';
import '../ui/theme.dart';

/* =====================================================================================================
   LANGUAGE: the picker shown once on a new phone, the same page under Profile → Language, and the
   one place that changes the language (instantly, without a restart or a new login).
   ===================================================================================================== */

/// where the choice came from: 'user' (picked on this phone) or 'auto' (the English default of a phone
/// that used the app before languages existed). An 'auto' phone follows the language saved on the profile.
const _srcKey = 'sh-lang-src';

/// is this the first start of the app on this phone (so the language picker comes first)?
bool get langNeedsPick => !Prefs.has(L10n.prefKey);

/// phones that used the app before languages existed keep English, without being asked
void langDefaultForExisting() {
  if (Prefs.has(L10n.prefKey)) return;
  final used = Prefs.keys().any((k) => k != L10n.prefKey && k != _srcKey);
  if (used) {
    Prefs.set(L10n.prefKey, defaultLang);
    Prefs.set(_srcKey, 'auto');
  }
}

/// changes the app's language now
Future<void> setAppLang(String code, {bool fromProfile = false}) async {
  await L10n.I.set(code);
  Prefs.set(L10n.prefKey, code);
  Prefs.set(_srcKey, fromProfile ? 'auto' : 'user');
  L10n.I.touch();
  // every screen already built shows its text again in the new language
  ThemeCtl.repaintAll();
  if (!fromProfile) unawaited(_saveToProfile(code));
}

/// the choice goes with the person to their other phones, and the server writes their notifications in it
Future<void> _saveToProfile(String code) async {
  if (S.uid == null || S.sid == null || S.me == null) return;
  try {
    if (str(S.me!['lang']) != code) {
      await updateDoc(memRef(S.uid!), {'lang': code});
      S.me!['lang'] = code;
    }
  } catch (_) {}
  try {
    await Push.setup(force: true);
  } catch (_) {}
}

/// after logging in: a phone that never picked a language takes the one saved on the profile
Future<void> langFromProfile() async {
  final p = str(S.me?['lang']);
  if (p.isEmpty || !langs.any((l) => l.code == p)) {
    // the profile has none yet: save this phone's choice when the person made one here
    if (Prefs.get(_srcKey) == 'user') unawaited(_saveToProfile(L10n.I.code));
    return;
  }
  if (Prefs.get(_srcKey) == 'user' || p == L10n.I.code) return;
  await setAppLang(p, fromProfile: true);
}

/// shows the language picker before anything else on a new phone
class LangGate extends StatelessWidget {
  final Widget child;
  const LangGate({super.key, required this.child});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: L10n.I,
        builder: (_, __) => langNeedsPick ? const LanguagePage(first: true) : child,
      );
}

void openLangPage(BuildContext context) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const LanguagePage()));

/// the language picker
class LanguagePage extends StatefulWidget {
  /// [first]: shown on the first start, with a Continue button and no back arrow
  final bool first;
  const LanguagePage({super.key, this.first = false});
  @override
  State<LanguagePage> createState() => _LanguagePageState();
}

class _LanguagePageState extends State<LanguagePage> {
  late String sel = L10n.I.code;
  bool busy = false;

  Future<void> _pick(String code) async {
    if (busy || code == sel) return;
    HapticFeedback.selectionClick();
    setState(() {
      sel = code;
      busy = true;
    });
    // the page itself switches at once, so the person sees the language before going on
    await L10n.I.set(code);
    if (!widget.first) await setAppLang(code);
    if (mounted) setState(() => busy = false);
  }

  Future<void> _continue() async {
    await setAppLang(sel);
  }

  @override
  Widget build(BuildContext context) {
    final p = pal, mq = MediaQuery.of(context);
    final cols = mq.size.width >= 600 ? 3 : 2;
    return Scaffold(
      backgroundColor: p.bg,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(
            child: Container(
              padding: EdgeInsets.fromLTRB(20, mq.padding.top + (widget.first ? 28 : 8), 20, 26),
              decoration: BoxDecoration(
                gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [p.a, Color.lerp(p.a, p.a2, .8)!]),
                borderRadius: const BorderRadius.vertical(bottom: Radius.circular(28)),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (!widget.first)
                  IconButton(
                    padding: EdgeInsets.zero,
                    alignment: Alignment.centerLeft,
                    onPressed: () => Navigator.of(context).maybePop(),
                    icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                    tooltip: tr('Back'),
                  ),
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(color: Colors.white.withOpacity(.18), borderRadius: BorderRadius.circular(16)),
                  alignment: Alignment.center,
                  child: const Icon(Icons.translate_rounded, color: Colors.white, size: 28),
                ),
                const SizedBox(height: 16),
                Text(tr('Choose your language'), style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800, height: 1.25)),
                if (sel != 'en') Padding(padding: const EdgeInsets.only(top: 2), child: Text('Choose your language', style: TextStyle(color: Colors.white.withOpacity(.75), fontSize: 14, fontWeight: FontWeight.w600))),
                const SizedBox(height: 8),
                Text(tr('The app shows its menus, buttons and messages in this language. What people write stays as they wrote it. You can change this any time in Profile → Language.'),
                    style: TextStyle(color: Colors.white.withOpacity(.9), fontSize: 13.5, height: 1.45)),
              ]),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 8),
            sliver: SliverGrid(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: cols, mainAxisSpacing: 12, crossAxisSpacing: 12, mainAxisExtent: 104),
              delegate: SliverChildBuilderDelegate(
                (_, i) => _LangCard(lang: langs[i], on: langs[i].code == sel, onTap: () => _pick(langs[i].code)),
                childCount: langs.length,
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(16, 6, 16, mq.padding.bottom + 24),
              child: Column(children: [
                if (widget.first) Btn(tr('Continue'), onTap: busy ? null : _continue, busyDone: false),
                const SizedBox(height: 10),
                Text(trf('{0} of {1} texts translated', [L10n.I.translatedCount, L10n.I.totalCount]), style: small(), textAlign: TextAlign.center),
                const SizedBox(height: 4),
                Text('$brand · ${tr(tagline)}', style: small(), textAlign: TextAlign.center),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class _LangCard extends StatelessWidget {
  final Lang lang;
  final bool on;
  final VoidCallback onTap;
  const _LangCard({required this.lang, required this.on, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    return Semantics(
      button: true,
      selected: on,
      label: '${lang.native}, ${lang.name}',
      child: Material(
        color: on ? p.a.withOpacity(.10) : p.card,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.fromLTRB(14, 12, 12, 12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: on ? p.a : p.line, width: on ? 2 : 1),
              boxShadow: on ? [BoxShadow(color: p.a.withOpacity(.18), blurRadius: 14, offset: const Offset(0, 4))] : null,
            ),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                  FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(lang.native, maxLines: 1, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: p.text, height: 1.3))),
                  const SizedBox(height: 2),
                  Text(lang.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: p.muted)),
                  const SizedBox(height: 4),
                  Text(lang.hello, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12.5, color: on ? p.a : p.faint, height: 1.3)),
                ]),
              ),
              AnimatedOpacity(
                duration: const Duration(milliseconds: 200),
                opacity: on ? 1 : 0,
                child: Container(width: 24, height: 24, decoration: BoxDecoration(color: p.a, shape: BoxShape.circle), child: const Icon(Icons.check_rounded, color: Colors.white, size: 16)),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

/// a small "🌐 हिन्दी" button for the screens before login
class LangChip extends StatelessWidget {
  final Color? color;
  const LangChip({super.key, this.color});
  @override
  Widget build(BuildContext context) {
    final c = color ?? pal.text;
    return TextButton.icon(
      onPressed: () => openLangPage(context),
      style: TextButton.styleFrom(foregroundColor: c, padding: const EdgeInsets.symmetric(horizontal: 10)),
      icon: const Icon(Icons.translate_rounded, size: 18),
      label: Text(L10n.I.lang.native, style: const TextStyle(fontWeight: FontWeight.w700)),
    );
  }
}
