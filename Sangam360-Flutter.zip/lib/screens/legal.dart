import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/kinds.dart';
import '../ui/theme.dart';
import '../l10n/l10n.dart';

/// Privacy Policy / Terms & Conditions (assets/legal/*.html), with the [PLACEHOLDERS] filled from [legal]
Future<void> openLegal(BuildContext context, String k) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => LegalPage(k)));

class LegalPage extends StatelessWidget {
  final String k;
  const LegalPage(this.k, {super.key});

  Future<String> _load() async {
    var s = await rootBundle.loadString('assets/legal/${k == 'terms' ? 'terms' : 'privacy'}.html');
    final sup = legal['support']!.isNotEmpty ? legal['support']! : supportEmail;
    String or(String a, String b) => a.isNotEmpty ? a : b;
    final m = {
      '[LEGAL ENTITY / DEVELOPER NAME]': legal['entity']!,
      '[FULL ADDRESS]': legal['address']!,
      '[CITY, STATE, INDIA]': legal['city']!,
      '[SUPPORT EMAIL]': sup,
      '[PRIVACY / SUPPORT EMAIL]': or(legal['privacy']!, sup),
      '[PRIVACY EMAIL]': legal['privacy']!,
      '[PRIVACY / GRIEVANCE EMAIL]': or(legal['grievance']!, legal['privacy']!),
      '[LEGAL / GRIEVANCE EMAIL]': or(legal['legal']!, legal['grievance']!),
      '[GRIEVANCE OFFICER NAME / EMAIL, IF APPLICABLE]': legal['grievance']!,
    };
    m.forEach((q, v) {
      if (v.isNotEmpty) s = s.split(q).join(v);
    });
    return s;
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    return Scaffold(
      appBar: AppBar(title: Text(k == 'terms' ? tr('Terms & Conditions') : tr('Privacy Policy'))),
      body: FutureBuilder<String>(
        future: _load(),
        builder: (_, s) {
          if (!s.hasData) return Center(child: CircularProgressIndicator(color: p.a));
          return ListView(padding: const EdgeInsets.fromLTRB(18, 6, 18, 40), children: htmlBlocks(s.data!));
        },
      ),
    );
  }
}

String _ent(String s) => s
    .replaceAll(RegExp(r'<br\s*/?>'), '\n')
    .replaceAll('&nbsp;', ' ')
    .replaceAll('&amp;', '&')
    .replaceAll('&lt;', '<')
    .replaceAll('&gt;', '>')
    .replaceAll('&quot;', '"')
    .replaceAll('&#39;', "'")
    .replaceAll(RegExp(r'\s+\n'), '\n')
    .replaceAll(RegExp(r'[ \t]+'), ' ');

/// inline: <strong>/<b> bold, <a> coloured, every other tag dropped
List<InlineSpan> _inline(String h, TextStyle base) {
  final out = <InlineSpan>[];
  final re = RegExp(r'<(strong|b|a|em|i)\b[^>]*>(.*?)</\1>', dotAll: true);
  var i = 0;
  for (final m in re.allMatches(h)) {
    if (m.start > i) out.add(TextSpan(text: _ent(h.substring(i, m.start).replaceAll(RegExp(r'<[^>]+>'), ''))));
    final t = m.group(1)!, inner = _ent(m.group(2)!.replaceAll(RegExp(r'<[^>]+>'), ''));
    out.add(TextSpan(
        text: inner,
        style: t == 'a'
            ? TextStyle(color: pal.a, fontWeight: FontWeight.w600)
            : (t == 'em' || t == 'i')
                ? const TextStyle(fontStyle: FontStyle.italic)
                : const TextStyle(fontWeight: FontWeight.w700)));
    i = m.end;
  }
  if (i < h.length) out.add(TextSpan(text: _ent(h.substring(i).replaceAll(RegExp(r'<[^>]+>'), ''))));
  return out;
}

/// a small HTML renderer for the legal pages (h1, h2, h3, p, ul/ol/li, table, div)
List<Widget> htmlBlocks(String html) {
  final p = pal;
  final w = <Widget>[];
  html = html.replaceAll(RegExp(r'</?div\b[^>]*>', caseSensitive: false), '');
  final re = RegExp(r'<(h1|h2|h3|p|ul|ol|table)\b([^>]*)>(.*?)</\1>', dotAll: true, caseSensitive: false);
  for (final m in re.allMatches(html)) {
    final tag = m.group(1)!.toLowerCase(), attrs = m.group(2) ?? '', inner = m.group(3)!.trim();
    final base = TextStyle(fontSize: 14.5, height: 1.55, color: p.text, fontFamily: fontFam);
    switch (tag) {
      case 'h1':
        w.add(Padding(padding: const EdgeInsets.only(top: 10, bottom: 8), child: Text(_ent(inner.replaceAll(RegExp(r'<[^>]+>'), '')), style: h1().copyWith(fontSize: 23))));
        break;
      case 'h2':
      case 'h3':
        w.add(Padding(padding: const EdgeInsets.only(top: 18, bottom: 6), child: Text(_ent(inner.replaceAll(RegExp(r'<[^>]+>'), '')), style: h2())));
        break;
      case 'p':
        final sm = attrs.contains('small');
        w.add(Padding(padding: const EdgeInsets.only(bottom: 10), child: Text.rich(TextSpan(style: sm ? base.copyWith(fontSize: 12.5, color: p.muted) : base, children: _inline(inner, base)))));
        break;
      case 'ul':
      case 'ol':
        var n = 0;
        for (final li in RegExp(r'<li\b[^>]*>(.*?)</li>', dotAll: true).allMatches(inner)) {
          n++;
          w.add(Padding(
            padding: const EdgeInsets.only(bottom: 6, left: 4),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SizedBox(width: 22, child: Text(tag == 'ol' ? '$n.' : '•', style: base.copyWith(color: p.a, fontWeight: FontWeight.w800))),
              Expanded(child: Text.rich(TextSpan(style: base, children: _inline(li.group(1)!.trim(), base)))),
            ]),
          ));
        }
        w.add(const SizedBox(height: 6));
        break;
      case 'table':
        final rows = RegExp(r'<tr\b[^>]*>(.*?)</tr>', dotAll: true).allMatches(inner).map((r) => RegExp(r'<(td|th)\b[^>]*>(.*?)</\1>', dotAll: true).allMatches(r.group(1)!).map((c) => (c.group(1) == 'th', c.group(2)!.trim())).toList()).toList();
        w.add(Container(
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(border: Border.all(color: p.line), borderRadius: BorderRadius.circular(12)),
          clipBehavior: Clip.antiAlias,
          child: Column(children: [
            for (final r in rows)
              Container(
                decoration: BoxDecoration(color: r.isNotEmpty && r.first.$1 ? p.card2 : null, border: Border(bottom: BorderSide(color: p.line))),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  for (final c in r)
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.all(8),
                        child: Text.rich(TextSpan(style: base.copyWith(fontSize: 12.5, fontWeight: c.$1 ? FontWeight.w700 : FontWeight.w400), children: _inline(c.$2, base))),
                      ),
                    ),
                ]),
              ),
          ]),
        ));
        break;
    }
  }
  return w;
}
