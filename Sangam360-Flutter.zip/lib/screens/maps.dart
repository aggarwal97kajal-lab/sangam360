import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' hide Path;
import 'package:url_launcher/url_launcher.dart';

import '../core/fs.dart';
import '../core/geo.dart';
import '../core/kinds.dart';
import '../core/live.dart';
import '../core/nav.dart';
import '../core/perms.dart';
import '../core/session.dart';
import '../core/store.dart';
import '../core/toast.dart';
import '../core/util.dart';
import '../ui/kit.dart';
import '../ui/media.dart';
import '../ui/theme.dart';
import '../l10n/l10n.dart';

/* ===== maps inside the app (CARTO tiles with the app's key): choose a place, follow a bus or a live location, show a place ===== */

TileLayer mapTiles() {
  final dark = pal.dark;
  return TileLayer(
    // CARTO basemaps (needs the key; commercial use is free up to 1 million tiles a month). Without a key: OpenStreetMap.
    urlTemplate: cartoKey.isEmpty
        ? 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
        : 'https://{s}.basemaps.cartocdn.com/rastertiles/${dark ? 'dark_all' : 'voyager'}/{z}/{x}/{y}{r}.png?key=$cartoKey',
    subdomains: const ['a', 'b', 'c', 'd'],
    userAgentPackageName: 'com.sangam360.app',
    maxNativeZoom: cartoKey.isEmpty ? 19 : 20,
    maxZoom: 20,
    tileBuilder: dark && cartoKey.isEmpty ? darkModeTileBuilder : null,
  );
}

Widget mapAttribution() => Positioned(
      right: 6,
      bottom: 4,
      child: Container(padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1), color: Colors.white70, child: Text(cartoKey.isEmpty ? tr('© OpenStreetMap contributors') : tr('© OpenStreetMap contributors · © CARTO'), style: TextStyle(fontSize: 9, color: Colors.black87))),
    );

Future<void> openUrl(String u) => launchUrl(Uri.parse(u), mode: LaunchMode.externalApplication).then((_) {}).catchError((_) => toast('ℹ️', tr("Couldn't open"), u));

/// a round marker with an emoji
Widget emojiPin(String e, {Color? ring, double size = 40}) => Container(
      width: size,
      height: size,
      decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, border: Border.all(color: ring ?? pal.a, width: 3), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.25), blurRadius: 8, offset: const Offset(0, 3))]),
      alignment: Alignment.center,
      child: Text(e, style: TextStyle(fontSize: size * .5)),
    );

Widget meDot() => Container(width: 18, height: 18, decoration: BoxDecoration(color: const Color(0xFF2563EB), shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 3), boxShadow: [BoxShadow(color: const Color(0xFF2563EB).withOpacity(.4), blurRadius: 10, spreadRadius: 4)]));

/* ---------- the full-screen frame: map, back, zoom, re-centre, a card at the bottom ---------- */
class MapFrame extends StatelessWidget {
  final String title;
  final MapController ctl;
  final Widget map;
  final Widget footer;
  final bool showRecentre;
  final VoidCallback? onRecentre;
  final Widget? centerPin;
  final Widget? topExtra;
  const MapFrame({super.key, required this.title, required this.ctl, required this.map, required this.footer, this.showRecentre = false, this.onRecentre, this.centerPin, this.topExtra});

  void _zoom(int d) {
    try {
      ctl.move(ctl.camera.center, (ctl.camera.zoom + d).clamp(2, 19).toDouble());
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    return Scaffold(
      backgroundColor: p.bg,
      body: Stack(children: [
        Positioned.fill(child: map),
        if (centerPin != null) Center(child: Padding(padding: const EdgeInsets.only(bottom: 40), child: centerPin)),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(children: [
              Row(children: [
                IconBtn(Icons.arrow_back_rounded, onTap: () => Navigator.maybePop(context)),
                const SizedBox(width: 10),
                Expanded(child: Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11), decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(99), boxShadow: p.shadow, border: Border.all(color: p.line)), child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: h3()))),
              ]),
              if (topExtra != null) topExtra!,
            ]),
          ),
        ),
        Positioned(
          right: 12,
          top: MediaQuery.of(context).padding.top + 140,
          child: Column(children: [
            IconBtn(Icons.add_rounded, onTap: () => _zoom(1)),
            const SizedBox(height: 8),
            IconBtn(Icons.remove_rounded, onTap: () => _zoom(-1)),
          ]),
        ),
        Positioned(
          left: 0,
          right: 0,
          bottom: 0,
          child: SafeArea(
            top: false,
            child: Container(
              margin: const EdgeInsets.all(12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(24), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.15), blurRadius: 30, offset: const Offset(0, 10))]),
              child: Stack(clipBehavior: Clip.none, children: [
                footer,
                if (showRecentre) Positioned(right: 0, top: -64, child: IconBtn(Icons.my_location_rounded, onTap: onRecentre, bg: p.card)),
              ]),
            ),
          ),
        ),
      ]),
    );
  }
}

/* ============================== choose a place ============================== */
class PickedPlace {
  final double lat, lng;
  final String name;
  const PickedPlace(this.lat, this.lng, this.name);
}

({double lat, double lng})? _lpkLast;

/// Full-screen "choose a place": the map moves under a fixed pin, the address of the pin is shown, search lists places near you.
Future<PickedPlace?> locPick(BuildContext context, {String title = 'Choose the location', ({double lat, double lng})? at, ({double lat, double lng})? near, bool focus = false, String? pill}) =>
    Navigator.of(context).push<PickedPlace>(MaterialPageRoute(builder: (_) => _LocPick(title: title, at: at, near: near, focus: focus, pill: pill)));

class _LocPick extends StatefulWidget {
  final String title;
  final ({double lat, double lng})? at, near;
  final bool focus;
  final String? pill;
  const _LocPick({required this.title, this.at, this.near, this.focus = false, this.pill});
  @override
  State<_LocPick> createState() => _LocPickState();
}

class _LocPickState extends State<_LocPick> {
  final ctl = MapController();
  final q = TextEditingController();
  final qf = FocusNode();
  ({double lat, double lng})? cur, mine, hit;
  String name = '', sub = '';
  bool busy = false, panel = false, drag = false, searching = false;
  List<Place> nr = [], results = [];
  String msg = '';
  int rq = 0, nq = 0, seq = 0;
  Timer? _rt, _qt;

  @override
  void initState() {
    super.initState();
    cur = widget.at;
    if (cur != null) _rev();
    if (pHint('loc')) {
      _here(true).then((ok) {
        if (ok && mounted && cur == null && mine != null) _setAt(mine!, '', '');
      });
    }
    qf.addListener(() {
      if (qf.hasFocus) setState(() => panel = true);
    });
    if (widget.focus) Future.delayed(const Duration(milliseconds: 300), () => qf.requestFocus());
  }

  @override
  void dispose() {
    _rt?.cancel();
    _qt?.cancel();
    super.dispose();
  }

  Future<bool> _here(bool quiet) async {
    try {
      if (!quiet && !await askPerm('loc')) return false;
      final c = await here();
      if (!mounted) return false;
      setState(() => mine = (lat: c.latitude, lng: c.longitude));
      return true;
    } catch (e) {
      if (!quiet) fail(e);
      return false;
    }
  }

  void _near() {
    if (cur == null) return;
    final n = ++nq, p = cur!;
    lpkNear(p.lat, p.lng).then((L) {
      if (n != nq || !mounted) return;
      setState(() => nr = L.where((r) => busKm(p.lat, p.lng, r.lat, r.lng) > .008).toList());
    });
  }

  void _rev() {
    _rt?.cancel();
    if (cur == null) return;
    if (hit != null) {
      _near();
      return;
    }
    final n = ++rq, p = cur!;
    setState(() => busy = true);
    _rt = Timer(const Duration(milliseconds: 450), () async {
      final r = await lpkRev(p.lat, p.lng);
      if (n != rq || !mounted) return;
      setState(() {
        busy = false;
        if (r != null) {
          name = r.name;
          sub = r.sub;
        }
      });
      _near();
    });
  }

  void _setAt(({double lat, double lng}) p, String nm, String sb, [double zoom = 17]) {
    setState(() {
      cur = (lat: fix6(p.lat), lng: fix6(p.lng));
      name = nm;
      sub = nm.isNotEmpty ? sb : '';
      hit = nm.isNotEmpty ? cur : null;
      rq++;
      busy = false;
    });
    try {
      ctl.move(LatLng(cur!.lat, cur!.lng), zoom);
    } catch (_) {}
    _rev();
  }

  Future<void> _find() async {
    final t = q.text.trim();
    if (t.length < 2) {
      setState(() {
        results = [];
        msg = '';
        panel = true;
      });
      return;
    }
    final pp = busParse(t);
    if (pp != null) {
      setState(() => panel = false);
      _setAt(pp, '', '');
      return;
    }
    final n = ++seq;
    ({double lat, double lng})? ref = mine;
    try {
      if (ref == null && ctl.camera.zoom >= 9) ref = (lat: ctl.camera.center.latitude, lng: ctl.camera.center.longitude);
    } catch (_) {}
    ref ??= widget.at ?? widget.near ?? _lpkLast;
    setState(() {
      searching = true;
      msg = tr('Searching near you…');
    });
    try {
      final L = await lpkFind(t, near: ref);
      if (n != seq || !mounted) return;
      setState(() {
        results = L;
        searching = false;
        msg = L.isEmpty ? tr('No place found. Try the area or a landmark, or move the map yourself.') : '';
      });
    } catch (_) {
      if (n == seq && mounted) {
        setState(() {
          searching = false;
          msg = tr("Couldn't search right now. Check the internet, or move the map yourself.");
        });
      }
    }
  }

  void _choose(Place r) {
    setState(() => panel = false);
    q.text = r.name;
    qf.unfocus();
    _setAt((lat: r.lat, lng: r.lng), r.name, r.sub);
  }

  void _moved(MapCamera c, bool gesture) {
    if (!gesture) return;
    final p = (lat: fix6(c.center.latitude), lng: fix6(c.center.longitude));
    if (cur == null && c.zoom < 12) return;
    if (cur != null && busKm(cur!.lat, cur!.lng, p.lat, p.lng) < .004) return;
    if (hit != null && busKm(hit!.lat, hit!.lng, p.lat, p.lng) <= .15) {
      setState(() => cur = p);
      return;
    }
    setState(() {
      hit = null;
      name = '';
      sub = '';
      cur = p;
    });
    _rev();
  }

  void _ok() {
    if (cur == null) return;
    var z = 17.0;
    try {
      z = ctl.camera.zoom;
    } catch (_) {}
    if (z < 14) {
      toast('ℹ️', tr('Zoom in closer'), tr('Bring the pin to the exact spot, then tap Confirm location.'));
      return;
    }
    _lpkLast = cur;
    final label = name.isNotEmpty ? cut('$name${sub.isNotEmpty ? ', ${sub.split(', ').first}' : ''}', 60) : '';
    if (name.isNotEmpty) lpkRemember(Place(name, sub, cur!.lat, cur!.lng));
    Navigator.pop(context, PickedPlace(cur!.lat, cur!.lng, label));
  }

  Widget _row(String ic, String t, String s, double? km, VoidCallback fn) => Ex(t, sub: s, lead: Text(ic, style: const TextStyle(fontSize: 18)), right: km == null ? null : Text(busFmt(km), style: small()), onTap: fn);

  @override
  Widget build(BuildContext context) {
    final p = pal;
    final st = cur ?? widget.near ?? _lpkLast;
    final R = lpkRecent();
    final map = FlutterMap(
      mapController: ctl,
      options: MapOptions(initialCenter: LatLng(st?.lat ?? 22.6, st?.lng ?? 79), initialZoom: st == null ? 4 : (cur != null ? 17 : 14), onPositionChanged: (c, g) {
        if (g != drag) setState(() => drag = g);
        _moved(c, g);
      }, onMapEvent: (e) {
        if (e is MapEventMoveEnd && drag) setState(() => drag = false);
      }),
      children: [
        mapTiles(),
        if (mine != null) MarkerLayer(markers: [Marker(point: LatLng(mine!.lat, mine!.lng), width: 24, height: 24, child: meDot())]),
      ],
    );
    final footer = Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
      Row(children: [
        Expanded(child: Text(widget.title, style: small(p.a).copyWith(fontWeight: FontWeight.w700))),
        IconBtn(Icons.my_location_rounded, size: 38, onTap: () async {
          if (await _here(false) && mine != null) _setAt(mine!, '', '');
        }),
      ]),
      Text(
          cur == null
              ? tr('Move the map or search')
              : busy && name.isEmpty
                  ? tr('Finding the address…')
                  : name.isNotEmpty
                      ? name
                      : tr('Pinned place'),
          style: h2()),
      const SizedBox(height: 2),
      Text(cur == null ? tr('Bring the pin to the exact spot. You can search, or tap ◎ for where you are now.') : '${sub.isNotEmpty ? '$sub · ' : ''}${cur!.lat.toStringAsFixed(5)}, ${cur!.lng.toStringAsFixed(5)}', style: meta()),
      if (nr.isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: SizedBox(
            height: 34,
            child: ListView(scrollDirection: Axis.horizontal, children: [
              Center(child: Text(tr('Nearby  '), style: small())),
              for (final r in nr.take(6))
                Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: ActionChip(label: Text('${r.name} · ${busFmt(r.km ?? 0)}', style: const TextStyle(fontSize: 12)), onPressed: () => _setAt((lat: r.lat, lng: r.lng), r.name, r.sub), visualDensity: VisualDensity.compact),
                ),
            ]),
          ),
        ),
      const SizedBox(height: 12),
      Btn(tr('Confirm location'), onTap: cur == null ? null : _ok, busyDone: false),
    ]);
    final search = Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Column(children: [
        Container(
          decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(16), boxShadow: p.shadow, border: Border.all(color: p.line)),
          child: TextField(
            controller: q,
            focusNode: qf,
            textInputAction: TextInputAction.search,
            onChanged: (_) {
              _qt?.cancel();
              _qt = Timer(const Duration(milliseconds: 380), _find);
              setState(() {});
            },
            onSubmitted: (_) => _find(),
            decoration: InputDecoration(
              hintText: tr('Search for a place or area'),
              prefixIcon: const Icon(Icons.search_rounded),
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              suffixIcon: q.text.isEmpty
                  ? null
                  : IconButton(
                      onPressed: () => setState(() {
                            q.clear();
                            results = [];
                          }),
                      icon: const Icon(Icons.close_rounded)),
            ),
          ),
        ),
        if (panel)
          Container(
            margin: const EdgeInsets.only(top: 8),
            constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * .5),
            decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(16), boxShadow: p.shadow),
            child: ListView(shrinkWrap: true, padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), children: [
              if (q.text.trim().length < 2) ...[
                _row('◎', tr('Use my current location'), tr('GPS of this phone'), null, () async {
                  setState(() => panel = false);
                  qf.unfocus();
                  if (await _here(false) && mine != null) _setAt(mine!, '', '');
                }),
                if (nr.isNotEmpty) ...[const Sec('Nearby'), for (final r in nr) _row('📍', r.name, r.sub, r.km, () => _choose(r))],
                if (R.isNotEmpty) ...[const Sec('Recent'), for (final r in R) _row('🕘', r.name, r.sub, mine == null ? null : busKm(mine!.lat, mine!.lng, r.lat, r.lng), () => _choose(r))],
              ] else ...[
                if (msg.isNotEmpty) Padding(padding: const EdgeInsets.all(12), child: Text(msg, style: meta())),
                for (final r in results) _row('📍', r.name, r.sub, r.km, () => _choose(r)),
              ],
              TextButton(
                  onPressed: () {
                    setState(() => panel = false);
                    qf.unfocus();
                  },
                  child:  Text(tr('Close'))),
            ]),
          ),
      ]),
    );
    return PopScope(
      canPop: !panel,
      onPopInvokedWithResult: (did, _) {
        if (!did && panel) {
          setState(() => panel = false);
          qf.unfocus();
        }
      },
      child: MapFrame(
        title: widget.pill ?? widget.title.split(' · ').first,
        ctl: ctl,
        map: Stack(children: [map, mapAttribution()]),
        footer: footer,
        topExtra: search,
        centerPin: AnimatedSlide(offset: Offset(0, drag ? -.15 : 0), duration: const Duration(milliseconds: 150), child: const Text('📍', style: TextStyle(fontSize: 44))),
      ),
    );
  }
}

/* ============================== a chat location (live or one-time) ============================== */
void openLocShow(BuildContext context, Doc loc, Doc? m) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => LocShowPage(loc: loc, m: m, cid: nav.dmc?.cid)));

class LocShowPage extends StatefulWidget {
  final Doc loc;
  final Doc? m;
  final String? cid;
  const LocShowPage({super.key, required this.loc, this.m, this.cid});
  @override
  State<LocShowPage> createState() => _LocShowPageState();
}

class _LocShowPageState extends State<LocShowPage> {
  final ctl = MapController();
  final List<LatLng> trail = [];
  bool free = false, ready = false;
  ({double lat, double lng})? me;
  Place? place;
  ({double lat, double lng})? geoAt;
  int geoT = 0;
  Timer? _iv;

  bool get live => widget.loc['live'] == true && widget.m != null;
  bool get mine => widget.m?['uid'] == S.uid;

  ({double lat, double lng, int ts, int acc, bool ended}) info() {
    final l = widget.loc;
    if (!live) return (lat: numv(l['lat']).toDouble(), lng: numv(l['lng']).toDouble(), ts: intv(widget.m?['ts']), acc: intv(l['acc']), ended: false);
    final m = widget.m!;
    final src = widget.cid != null ? mapv(mapv(D['dmc'][widget.cid]?['live'])[m['uid']]) : mapv(D['pres'][m['uid']]?['live']);
    final cur = src.isNotEmpty && src['lid'] == l['lid'] ? src : null;
    return (
      lat: numv(cur != null && cur['lat'] != null ? cur['lat'] : l['lat']).toDouble(),
      lng: numv(cur != null && cur['lng'] != null ? cur['lng'] : l['lng']).toDouble(),
      ts: intv(cur?['ts'] ?? m['ts']),
      acc: intv(cur != null && cur['lat'] != null ? cur['acc'] : l['acc']),
      ended: (cur != null && intv(cur['end']) > 0) || now() >= intv(l['until']) || (src.isNotEmpty && src['lid'] != l['lid'] && intv(src['ts']) > intv(m['ts'])),
    );
  }

  @override
  void initState() {
    super.initState();
    _iv = Timer.periodic(const Duration(seconds: 2), (_) => _tick());
    D.rev(widget.cid != null ? 'dmc' : 'pres').addListener(_tick);
    if (!mine && pHint('loc')) {
      here().then((c) {
        if (mounted) setState(() => me = (lat: c.latitude, lng: c.longitude));
      }).catchError((_) {});
    }
    _tick();
  }

  @override
  void dispose() {
    _iv?.cancel();
    D.rev(widget.cid != null ? 'dmc' : 'pres').removeListener(_tick);
    super.dispose();
  }

  void _tick() {
    if (!mounted) return;
    final I = info();
    final z = trail.isEmpty ? null : trail.last;
    if (live && (z == null || busKm(z.latitude, z.longitude, I.lat, I.lng) > .008)) {
      trail.add(LatLng(I.lat, I.lng));
      if (trail.length > 400) trail.removeAt(0);
    }
    if (geoAt == null || (busKm(geoAt!.lat, geoAt!.lng, I.lat, I.lng) >= .08 && now() - geoT >= 15000)) {
      geoAt = (lat: I.lat, lng: I.lng);
      geoT = now();
      lpkRev(I.lat, I.lng).then((r) {
        if (mounted && r != null) setState(() => place = r);
      });
    }
    if (ready && !free) {
      try {
        ctl.move(LatLng(I.lat, I.lng), ctl.camera.zoom);
      } catch (_) {}
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final p = pal, I = info(), m = widget.m;
    final name = m == null ? '' : (str(m['name']).isNotEmpty ? str(m['name']) : str(D['dir'][m['uid']]?['name'] ?? 'Member'));
    final first = firstName(name).isEmpty ? 'Member' : firstName(name);
    final on = live && !I.ended, old = on && now() - I.ts > 150000;
    final b = <String>[];
    if (place != null && place!.sub.isNotEmpty) b.add(place!.sub.split(', ').take(2).join(', '));
    if (live) b.add(I.ended ? trf('last seen {0}', [ago(I.ts)]) : trf('updated {0}', [ago(I.ts)]));
    if (I.acc > 40) b.add(trf('accurate to about {0} m', [I.acc]));
    if (me != null && !mine) b.add(trf('{0} from you', [busFmt(busKm(me!.lat, me!.lng, I.lat, I.lng))]));
    if (b.isEmpty) b.add('${I.lat.toStringAsFixed(5)}, ${I.lng.toStringAsFixed(5)}');
    final ph = m == null ? null : (m['pid'] != null ? str(m['ph']) : photoOf(str(m['uid'])));
    final map = FlutterMap(
      mapController: ctl,
      options: MapOptions(initialCenter: LatLng(I.lat, I.lng), initialZoom: 16, onMapReady: () => ready = true, onPositionChanged: (c, g) {
        if (g && !free) setState(() => free = true);
      }),
      children: [
        mapTiles(),
        if (trail.length > 1) PolylineLayer(polylines: [Polyline(points: trail, strokeWidth: 4, color: p.a.withOpacity(.7))]),
        MarkerLayer(markers: [
          if (me != null && !mine) Marker(point: LatLng(me!.lat, me!.lng), width: 24, height: 24, child: meDot()),
          Marker(
            point: LatLng(I.lat, I.lng),
            width: 56,
            height: 56,
            child: live
                ? Opacity(opacity: on ? 1 : .55, child: Container(decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: on ? p.green : p.muted, width: 3), boxShadow: [BoxShadow(color: (on ? p.green : p.muted).withOpacity(.35), blurRadius: 14, spreadRadius: 3)]), child: Av(name, ph, size: 50)))
                : emojiPin('📍'),
          ),
        ]),
      ],
    );
    return MapFrame(
      title: '📍 ${m == null ? tr('Location') : (mine ? tr('You') : name)}',
      ctl: ctl,
      map: Stack(children: [map, mapAttribution()]),
      showRecentre: free,
      onRecentre: () {
        setState(() => free = false);
        try {
          ctl.move(LatLng(I.lat, I.lng), 16);
        } catch (_) {}
      },
      footer: Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
        Row(children: [
          if (live) Container(width: 9, height: 9, margin: const EdgeInsets.only(right: 6), decoration: BoxDecoration(color: on ? (old ? p.amber : p.green) : p.muted, shape: BoxShape.circle)),
          Expanded(
            child: Text(
                live
                    ? (I.ended
                        ? tr('Live location ended')
                        : old
                            ? tr('Live · waiting for a new position')
                            : trf('Live · sharing until {0}', [tm(widget.loc['until'])]))
                    : trf('Shared location{0}', [(m != null ? ' · ${dt(m['ts'])}, ${tm(m['ts'])}' : '')]),
                style: small(p.a).copyWith(fontWeight: FontWeight.w700)),
          ),
        ]),
        const SizedBox(height: 4),
        Text(
            place != null
                ? place!.name
                : live
                    ? (mine ? tr('Your location') : trf('{0}\'s location', [first]))
                    : tr('Pinned place'),
            style: h2()),
        Text(b.join(' · '), style: meta()),
        const SizedBox(height: 12),
        Row(children: [
          if (on && mine) ...[
            Expanded(
              child: Btn.r(tr('Stop sharing'), small: true, onTap: () async {
                locStop(widget.loc, widget.cid);
                _tick();
              }),
            ),
            const SizedBox(width: 8),
          ],
          Expanded(child: Btn.o(tr('Open in Google Maps'), small: true, onTap: () => openUrl('https://www.google.com/maps?q=${I.lat},${I.lng}'))),
        ]),
      ]),
    );
  }
}

/// stops my live location of this message
void locStop(Doc l, String? cid) {
  if (Live.s != null && Live.s!.lid == l['lid']) {
    Live.stop();
  } else {
    Live.s = LiveS(lid: str(l['lid']), until: intv(l['until']), cid: cid);
    Live.stop();
  }
  toast('📍', tr('Live location stopped'));
}

/* ============================== follow a school bus ============================== */
void busTrack(BuildContext context, String id, {Doc? pk, String? kid, String what = 'pickup', bool drv = false}) =>
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => _BusTrack(id: id, pk: pk, kid: kid, what: what, drv: drv)));

class _BusTrack extends StatefulWidget {
  final String id;
  final Doc? pk;
  final String? kid;
  final String what;
  final bool drv;
  const _BusTrack({required this.id, this.pk, this.kid, required this.what, required this.drv});
  @override
  State<_BusTrack> createState() => _BusTrackState();
}

class _BusTrackState extends State<_BusTrack> {
  final ctl = MapController();
  StreamSubscription? _s;
  Timer? _iv;
  Doc? x;
  bool free = false, ready = false, first = true, gone = false;
  String err = '';

  Doc? get pk => widget.pk != null && widget.pk!['lat'] != null ? widget.pk : null;

  @override
  void initState() {
    super.initState();
    _s = dref('buses', widget.id).snapshots().listen((s) {
      if (!s.exists) {
        if (mounted) Navigator.maybePop(context);
        return;
      }
      setState(() => x = {...s.data()!, 'id': widget.id});
      _fit();
    }, onError: (_) {
      if (mounted) setState(() => err = tr('This bus cannot be shown right now.'));
    });
    _iv = Timer.periodic(const Duration(seconds: 8), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _s?.cancel();
    _iv?.cancel();
    super.dispose();
  }

  void _fit() {
    final l = busLive(x);
    if (!ready || l == null || free) return;
    try {
      final a = LatLng(numv(l['lat']).toDouble(), numv(l['lng']).toDouble());
      if (pk != null && busKm(numv(l['lat']), numv(l['lng']), numv(pk!['lat']), numv(pk!['lng'])) > .03) {
        ctl.fitCamera(CameraFit.bounds(bounds: LatLngBounds.fromPoints([a, LatLng(numv(pk!['lat']).toDouble(), numv(pk!['lng']).toDouble())]), padding: const EdgeInsets.fromLTRB(60, 140, 60, 260)));
      } else {
        ctl.move(a, first ? 16 : ctl.camera.zoom);
      }
      first = false;
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final p = pal, l = busLive(x);
    String ad, cd = '';
    if (x == null) {
      ad = err.isNotEmpty ? err : tr('Loading…');
    } else if (!busOn(x)) {
      ad = tr('The trip has ended');
    } else if (l == null) {
      ad = tr("Waiting for the bus's location…");
      cd = intv(mapv(x!['live'])['end']) > 0 ? tr("The driver's phone is not sharing right now.") : '';
    } else {
      final km = pk != null ? busKm(numv(l['lat']), numv(l['lng']), numv(pk!['lat']), numv(pk!['lng'])) : null;
      ad = km != null ? (km <= busZarr ? trf('The bus is at the {0} point', [widget.what]) : trf('{0} away · about {1} min', [busFmt(km), busEta(km)])) : tr('On the way');
      cd = trf('{0}updated {1}{2}', [(widget.kid != null && !widget.drv ? trf('{0}\'s {1} point · ', [widget.kid, widget.what]) : ''), ago(l['ts']), (numv(l['spd']) > 0 ? trf(' · {0} km/h', [(numv(l['spd']) * 3.6).round()]) : '')]);
    }
    final center = l != null ? LatLng(numv(l['lat']).toDouble(), numv(l['lng']).toDouble()) : (pk != null ? LatLng(numv(pk!['lat']).toDouble(), numv(pk!['lng']).toDouble()) : const LatLng(22.6, 79));
    final map = FlutterMap(
      mapController: ctl,
      options: MapOptions(initialCenter: center, initialZoom: l != null || pk != null ? 16 : 4, onMapReady: () {
        ready = true;
        _fit();
      }, onPositionChanged: (c, g) {
        if (g && !free) setState(() => free = true);
      }),
      children: [
        mapTiles(),
        if (l != null && pk != null) PolylineLayer(polylines: [Polyline(points: [LatLng(numv(l['lat']).toDouble(), numv(l['lng']).toDouble()), LatLng(numv(pk!['lat']).toDouble(), numv(pk!['lng']).toDouble())], strokeWidth: 3, color: p.a.withOpacity(.6))]),
        MarkerLayer(markers: [
          if (pk != null) Marker(point: LatLng(numv(pk!['lat']).toDouble(), numv(pk!['lng']).toDouble()), width: 44, height: 44, child: emojiPin(widget.what == 'drop' ? '🏠' : '📍', ring: p.green)),
          if (l != null) Marker(point: LatLng(numv(l['lat']).toDouble(), numv(l['lng']).toDouble()), width: 48, height: 48, child: emojiPin('🚌', size: 48)),
        ]),
      ],
    );
    final t = widget.drv && pk != null ? pk : l;
    return MapFrame(
      title: x == null ? tr('Bus') : '🚌 ${str(x!['name'])}',
      ctl: ctl,
      map: Stack(children: [map, mapAttribution()]),
      showRecentre: free,
      onRecentre: () {
        setState(() => free = false);
        _fit();
      },
      footer: Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
        Text(widget.drv ? '${widget.what == 'drop' ? tr('Next drop') : tr('Next pickup')}${widget.kid != null ? ' · ${widget.kid}' : ''}' : tr('Live tracking'), style: small(p.a).copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        Text(ad, style: h2()),
        if (cd.isNotEmpty) Text(cd, style: meta()),
        const SizedBox(height: 12),
        Row(children: [
          if (x != null && str(x!['phone']).isNotEmpty && !widget.drv) ...[Expanded(child: Btn.o(tr('📞 Driver'), small: true, onTap: () => openUrl(telOf(str(x!['phone']))))), const SizedBox(width: 8)],
          if (t != null)
            Expanded(
              flex: 2,
              child: Btn.o(widget.drv && pk != null ? tr('🧭 Turn-by-turn in Google Maps') : tr('Open in Google Maps'),
                  small: true, onTap: () => openUrl(widget.drv && pk != null ? 'https://www.google.com/maps/dir/?api=1&destination=${pk!['lat']},${pk!['lng']}&travelmode=driving' : 'https://www.google.com/maps?q=${t['lat']},${t['lng']}')),
            ),
        ]),
      ]),
    );
  }
}

/* ============================== one place (where an incident was reported) ============================== */
void placeShow(BuildContext context, double lat, double lng, {String title = 'Place', String lbl = 'Reported here'}) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => _PlaceShow(lat: lat, lng: lng, title: title, lbl: lbl)));

class _PlaceShow extends StatefulWidget {
  final double lat, lng;
  final String title, lbl;
  const _PlaceShow({required this.lat, required this.lng, required this.title, required this.lbl});
  @override
  State<_PlaceShow> createState() => _PlaceShowState();
}

class _PlaceShowState extends State<_PlaceShow> {
  final ctl = MapController();
  Place? r;
  @override
  void initState() {
    super.initState();
    lpkRev(widget.lat, widget.lng).then((x) {
      if (mounted) setState(() => r = x);
    });
  }

  @override
  Widget build(BuildContext context) {
    final pt = LatLng(widget.lat, widget.lng);
    return MapFrame(
      title: widget.title,
      ctl: ctl,
      map: Stack(children: [
        FlutterMap(mapController: ctl, options: MapOptions(initialCenter: pt, initialZoom: 16), children: [mapTiles(), MarkerLayer(markers: [Marker(point: pt, width: 44, height: 44, child: emojiPin('📍'))])]),
        mapAttribution(),
      ]),
      footer: Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
        Text(widget.lbl, style: small(pal.a).copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        Text(r?.name ?? '${widget.lat.toStringAsFixed(5)}, ${widget.lng.toStringAsFixed(5)}', style: h2()),
        if (r != null) Text('${r!.sub.isNotEmpty ? '${r!.sub} · ' : ''}${widget.lat.toStringAsFixed(5)}, ${widget.lng.toStringAsFixed(5)}', style: meta()),
        const SizedBox(height: 12),
        Btn.o(tr('Open in Google Maps'), small: true, onTap: () => openUrl('https://www.google.com/maps?q=${widget.lat},${widget.lng}')),
      ]),
    );
  }
}

/* ============================== a small live map inside a card ============================== */
class MiniMap extends StatelessWidget {
  final Doc? l, pk;
  final double h;
  final VoidCallback? onTap;
  const MiniMap({super.key, this.l, this.pk, this.h = 150, this.onTap});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    if (l == null || l!['lat'] == null) return GestureDetector(onTap: onTap, child: MapArt(h: h, live: true));
    final a = LatLng(numv(l!['lat']).toDouble(), numv(l!['lng']).toDouble());
    final b = pk != null && pk!['lat'] != null ? LatLng(numv(pk!['lat']).toDouble(), numv(pk!['lng']).toDouble()) : null;
    final fit = b != null && busKm(a.latitude, a.longitude, b.latitude, b.longitude) > .03;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: h,
        margin: const EdgeInsets.only(top: 10),
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), border: Border.all(color: p.line)),
        child: AbsorbPointer(
          child: FlutterMap(
            key: ValueKey('${a.latitude},${a.longitude},${b?.latitude}'),
            options: MapOptions(
              initialCenter: a,
              initialZoom: 16,
              initialCameraFit: fit ? CameraFit.bounds(bounds: LatLngBounds.fromPoints([a, b!]), padding: const EdgeInsets.all(40)) : null,
              interactionOptions: const InteractionOptions(flags: InteractiveFlag.none),
            ),
            children: [
              mapTiles(),
              MarkerLayer(markers: [
                if (b != null) Marker(point: b, width: 34, height: 34, child: emojiPin('📍', ring: p.green, size: 34)),
                Marker(point: a, width: 38, height: 38, child: emojiPin('🚌', size: 38)),
              ]),
            ],
          ),
        ),
      ),
    );
  }
}

/// the little drawn map of a location card
class MapArt extends StatelessWidget {
  final double h;
  final bool live;
  const MapArt({super.key, this.h = 96, this.live = false});
  @override
  Widget build(BuildContext context) => Container(
        height: h,
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(14)),
        child: CustomPaint(painter: _MapArtP(pal.dark), child: Center(child: _Pulse(live: live))),
      );
}

class _MapArtP extends CustomPainter {
  final bool dark;
  _MapArtP(this.dark);
  @override
  void paint(Canvas c, Size s) {
    c.drawRect(Offset.zero & s, Paint()..color = dark ? const Color(0xFF1E2638) : const Color(0xFFE3EBF6));
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(0, 0, s.width * .24, s.height * .35), const Radius.circular(4)), Paint()..color = dark ? const Color(0xFF233D2E) : const Color(0xFFCFE9D6));
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(s.width * .73, s.height * .6, s.width * .27, s.height * .4), const Radius.circular(4)), Paint()..color = dark ? const Color(0xFF2B3A24) : const Color(0xFFD8E7C9));
    final road = Paint()
      ..color = dark ? const Color(0xFF34405A) : Colors.white
      ..style = PaintingStyle.stroke;
    final p1 = Path()
      ..moveTo(0, s.height * .69)
      ..quadraticBezierTo(s.width * .25, s.height * .35, s.width * .5, s.height * .6)
      ..quadraticBezierTo(s.width * .75, s.height * .85, s.width, s.height * .4);
    c.drawPath(p1, road..strokeWidth = 10);
    final p2 = Path()
      ..moveTo(s.width * .3, 0)
      ..quadraticBezierTo(s.width * .38, s.height * .46, s.width * .34, s.height);
    c.drawPath(p2, road..strokeWidth = 6);
    final p3 = Path()
      ..moveTo(s.width * .72, 0)
      ..quadraticBezierTo(s.width * .62, s.height * .52, s.width * .74, s.height);
    c.drawPath(p3, road..strokeWidth = 6);
  }

  @override
  bool shouldRepaint(_MapArtP o) => o.dark != dark;
}

class _Pulse extends StatefulWidget {
  final bool live;
  const _Pulse({required this.live});
  @override
  State<_Pulse> createState() => _PulseState();
}

class _PulseState extends State<_Pulse> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1600));
  @override
  void initState() {
    super.initState();
    if (widget.live) _c.repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) => Stack(alignment: Alignment.center, children: [
        if (widget.live) Container(width: 22 + 30 * _c.value, height: 22 + 30 * _c.value, decoration: BoxDecoration(shape: BoxShape.circle, color: p.red.withOpacity(.35 * (1 - _c.value)))),
        const Text('📍', style: TextStyle(fontSize: 28)),
      ]),
    );
  }
}
