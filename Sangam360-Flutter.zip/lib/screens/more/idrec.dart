import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../../core/files.dart';
import '../../core/img.dart';
import '../../core/plan.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/kit.dart';
import '../../ui/media.dart';
import '../../ui/theme.dart';
import '../services/att.dart';

/* ===== ID proof & photo records (admins): society > building > flat > residents ===== */

/// the ID proof and the photo of one member as two small cards (view / download)
class IdThumbs extends StatelessWidget {
  final Doc r;
  const IdThumbs(this.r, {super.key});
  @override
  Widget build(BuildContext context) {
    if (!okImg(r['idUrl']) && !okImg(r['photoUrl'])) return Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text('No ID uploaded', style: meta()));
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Row(children: [
        for (final k in const [['idUrl', 'ID proof'], ['photoUrl', 'Photo']])
          if (okImg(r[k[0]])) Expanded(child: Padding(padding: const EdgeInsets.only(right: 8), child: _IdCard(r, k[0], k[1]))),
      ]),
    );
  }
}

class _IdCard extends StatefulWidget {
  final Doc r;
  final String k, label;
  const _IdCard(this.r, this.k, this.label);
  @override
  State<_IdCard> createState() => _IdCardState();
}

class _IdCardState extends State<_IdCard> {
  String info = 'Loading…';
  Uint8List? bytes;
  String mime = '';

  String get ref => str(widget.r[widget.k]);
  bool get ph => widget.k == 'photoUrl';
  String get base => widget.label.replaceAll(RegExp(r'\s+'), '-') + (str(widget.r['name']).isNotEmpty ? '-${str(widget.r['name']).trim().replaceAll(RegExp(r'[^\w]+'), '-')}' : '');

  @override
  void initState() {
    super.initState();
    refBytes(ref).then((r) {
      if (!mounted) return;
      final b = r.$1;
      bytes = b;
      mime = r.$2.isNotEmpty ? r.$2 : sniff(b);
      setState(() => info = '${mime == 'application/pdf' ? 'PDF' : 'Photo'} · ${fsz(b.length)}');
    }).catchError((_) {
      if (mounted) setState(() => info = 'File unavailable');
    });
  }

  Future<void> _dl() async {
    var b = bytes ?? (await refBytes(ref)).$1;
    var m = sniff(b), fn = base;
    if (m.startsWith('image/') && !ph) {
      b = await imgToPdf(b);
      m = 'application/pdf';
    }
    fn += m == 'application/pdf' ? '.pdf' : '.${m.split('/').last.replaceAll('jpeg', 'jpg')}';
    await saveBytes(fn, b, m);
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    final pdf = mime == 'application/pdf';
    return Container(
      decoration: BoxDecoration(color: p.card2, borderRadius: BorderRadius.circular(14), border: Border.all(color: p.line)),
      clipBehavior: Clip.antiAlias,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        SizedBox(
          height: 96,
          child: pdf || (!ph && bytes == null)
              ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [const Text('📄', style: TextStyle(fontSize: 30)), Text('PDF file', style: small())]))
              : RefImage(ref, fit: BoxFit.cover),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(10, 8, 10, 0),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(widget.label, style: h3().copyWith(fontSize: 13.5)), Text(info, style: small())]),
        ),
        Padding(
          padding: const EdgeInsets.all(8),
          child: Row(children: [
            Expanded(child: Btn.o('👁 View', small: true, onTap: () => openRef(context, ref, name: '$base${pdf ? '.pdf' : '.jpg'}'))),
            const SizedBox(width: 6),
            Expanded(child: Btn('⬇️', small: true, onTap: () => _dl().catchError((x) => fail(x, "Couldn't download")))),
          ]),
        ),
      ]),
    );
  }
}

class _P {
  final String b, f, c;
  const _P(this.b, this.f, [this.c = '']);
}

void openIdPages(BuildContext context) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const IdPages()));

class IdPages extends StatefulWidget {
  const IdPages({super.key});
  @override
  State<IdPages> createState() => _IdPagesState();
}

class _IdPagesState extends State<IdPages> {
  final List<Map<String, String?>> st = [];
  Map<String, String?> cur = {'t': 'soc'};

  bool get org => S.isOrg;
  bool get sch => S.sch;
  bool _stu(Doc x) => !atStaff.contains(x['role']);

  _P par(Doc m) {
    final z = str(m['flat']);
    if (org) {
      final i = z.indexOf(' · ');
      if (sch && m['role'] == 'COMMITTEE_MEMBER') return _P('Teachers', i > 0 ? z.substring(i + 3) : '—', i > 0 ? z.substring(0, i) : z);
      if (sch && !_stu(m)) return _P('Admin & staff', z.isEmpty ? '—' : z);
      return i > 0 ? _P(z.substring(0, i), z.substring(i + 3)) : _P('Admin & staff', z.isEmpty ? '—' : z);
    }
    final x = RegExp(r'^(?:(.*) · )?Flat (.+)$').firstMatch(z);
    final tw = listv(S.soc?['towers']);
    return x != null ? _P(x.group(1) ?? (tw.isNotEmpty ? str(mapv(tw.first)['name']) : ''), x.group(2)!) : _P('Admin & staff', z.isEmpty ? '—' : z);
  }

  List<(Doc, _P)> mem() => [
        for (final x in D['mem'].values)
          if (x['status'] != 'rejected' && (!sch || S.isOwner || _stu(x))) (x, par(x))
      ];

  void go(Map<String, String?> n) => setState(() {
        st.add(cur);
        cur = n;
      });

  Widget row(String t, String s, VoidCallback fn, [bool dim = false]) => Opacity(opacity: dim ? .55 : 1, child: Ex(t, sub: s, onTap: fn, right: Icon(Icons.chevron_right_rounded, color: pal.muted)));

  @override
  Widget build(BuildContext context) {
    final GR = S.K.grp;
    return PopScope(
      canPop: st.isEmpty,
      onPopInvokedWithResult: (did, _) {
        if (!did && st.isNotEmpty) setState(() => cur = st.removeLast());
      },
      child: Scaffold(
        appBar: AppBar(
            title: Text(cur['t'] == 'soc'
                ? '🪪 Residents ID proof'
                : cur['t'] == 'bld'
                    ? (org ? GR?.t ?? 'Groups' : 'Buildings')
                    : cur['t'] == 'flat'
                        ? '${cur['b']} · Flats'
                        : (org ? cur['b']! : '${cur['b']} · Flat ${cur['f']}'))),
        body: ListenableBuilder(
          listenable: D.on(['mem']),
          builder: (_, __) {
            final M = mem();
            int idn(Iterable<(Doc, _P)> a) => a.where((x) => okImg(x.$1['idUrl'])).length;
            final w = <Widget>[];
            if (cur['t'] == 'soc') {
              w.add(Text('Select society', style: h2()));
              w.add(row(str(S.soc?['name']), '${str(S.soc?['city']).isNotEmpty ? '${S.soc!['city']} · ' : ''}${M.length} members · ${idn(M)} with ID', () => go({'t': 'bld'})));
            } else if (cur['t'] == 'bld') {
              w.add(Text('${str(S.soc?['name'])} · select ${org ? GR?.one ?? 'group' : 'building'}', style: h2()));
              final names = <String>[...(sch ? (S.isTeacher ? [S.myCls] : S.schClasses()) : listv(S.soc?['towers']).map((t) => str(mapv(t)['name'])))];
              if (org) {
                for (final x in M) {
                  if (x.$2.b != 'Admin & staff' && !names.contains(x.$2.b)) names.add(x.$2.b);
                }
              }
              if (sch && names.contains('Teachers')) {
                names.remove('Teachers');
                names.insert(0, 'Teachers');
              }
              if (M.any((x) => x.$2.b == 'Admin & staff')) names.add('Admin & staff');
              for (final b in names) {
                final L = M.where((x) => x.$2.b == b).toList();
                final ic = org
                    ? (S.kind == 'school'
                        ? (b == 'Teachers'
                            ? '🧑‍🏫 '
                            : b == 'Admin & staff'
                                ? '🗂️ '
                                : '🎓 ')
                        : '💼 ')
                    : '🏢 ';
                w.add(row('$ic$b', '${sch && b != 'Teachers' && b != 'Admin & staff' && S.tOf(b).isNotEmpty ? 'Class teacher: ${S.tOf(b)} · ' : ''}${L.length} member${L.length == 1 ? '' : 's'} · ${idn(L)} with ID', () => go({'t': org ? 'res' : 'flat', 'b': b}), L.isEmpty));
              }
            } else if (cur['t'] == 'flat') {
              w.add(Text('Select flat', style: h2()));
              final tws = listv(S.soc?['towers']).map(mapv).toList();
              final tw = tws.where((t) => t['name'] == cur['b']).firstOrNull;
              final fl = tw != null ? gF(tw, tws.length == 1).toList() : <String>[];
              for (final x in M) {
                if (x.$2.b == cur['b'] && !fl.contains(x.$2.f)) fl.add(x.$2.f);
              }
              for (final f in fl) {
                final L = M.where((x) => x.$2.b == cur['b'] && x.$2.f == f).toList();
                w.add(row('Flat $f', L.isNotEmpty ? '${L.map((x) => str(x.$1['name'])).join(', ')} · ${idn(L)}/${L.length} ID' : 'No residents', () => go({'t': 'res', 'b': cur['b'], 'f': f}), L.isEmpty));
              }
            } else {
              final L = M.where((x) => x.$2.b == cur['b'] && (org || x.$2.f == cur['f'])).toList();
              w.add(Text(
                  '${org ? (sch && cur['b'] == 'Teachers' ? 'Teachers' : sch && cur['b'] == 'Admin & staff' ? 'Staff' : '${S.K.person}s') : 'Residents'} (${L.length})',
                  style: h2()));
              if (sch && cur['b'] != 'Teachers' && cur['b'] != 'Admin & staff') w.add(Meta('${cur['b']}${S.tOf(cur['b']!).isNotEmpty ? ' · Class teacher: ${S.tOf(cur['b']!)}' : ''}'));
              if (L.isEmpty) w.add(Empty(org ? 'Nobody here yet' : 'No residents in this flat'));
              for (final e in L) {
                final x = e.$1, P = e.$2;
                w.add(Item(children: [
                  Row(children: [
                    Av(str(x['name']), okImg(x['photoUrl']) ? str(x['photoUrl']) : null, size: 46),
                    const SizedBox(width: 12),
                    Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(str(x['name']), style: h3()),
                      Text('${str(x['role']).replaceFirst('_', ' ').toLowerCase()}${str(x['mobile']).isNotEmpty ? ' · ${x['mobile']}' : ''}', style: small()),
                      Text('${P.c.isNotEmpty ? 'Class: ${P.c} · ' : ''}${org && P.b != 'Admin & staff' && P.f != '—' ? 'ID: ${P.f} · ' : ''}Status: ${str(x['status'])}', style: small()),
                    ])),
                  ]),
                  if (okImg(x['idUrl']) || okImg(x['photoUrl'])) IdThumbs(x) else Meta('No ID on file (joined before ID upload was required)'),
                ]));
              }
            }
            return ListView(padding: const EdgeInsets.all(16), children: [AppCard(children: [for (final x in w) Padding(padding: const EdgeInsets.only(bottom: 6), child: x)])]);
          },
        ),
      ),
    );
  }
}
