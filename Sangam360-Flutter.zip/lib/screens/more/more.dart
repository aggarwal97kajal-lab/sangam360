import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/api.dart';
import '../../core/app.dart';
import '../../core/files.dart';
import '../../core/fs.dart';
import '../../core/kinds.dart';
import '../../core/listen.dart';
import '../../core/native.dart';
import '../../core/plan.dart';
import '../../core/push.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/anim.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/media.dart';
import '../../ui/pick.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import '../boot.dart';
import '../comm/actions.dart';
import '../comm/editor.dart';
import '../fx/fx.dart';
import '../fx/school_bus.dart';
import '../legal.dart';
import '../shell.dart';
import 'idrec.dart';
import '../../l10n/l10n.dart';
import '../lang.dart';

/* ===================== the Me / People tab ===================== */

class MoreTab extends StatelessWidget {
  const MoreTab({super.key});
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([S, D.on(['mem', 'rep', 'dir', 'sos', 'amn', 'bk', 'pol', 'docu', 'stf', 'inc', 'exp', 'comp'])]),
      builder: (_, __) {
        if (S.me == null || S.soc == null) return const SizedBox();
        var i = 0;
        Widget e(Widget w) => Enter(index: i++ < 6 ? i : 6, child: w);
        final adm = S.isAdm;
        return ListView(physics: const BouncingScrollPhysics(), padding: const EdgeInsets.fromLTRB(16, 4, 16, 110), children: [
          if (adm) e(const _IdCardEntry()),
          ...p4(context).map(e),
          ...p3(context).map(e),
          if (adm) ...[
            e(const _InviteCard()),
            e(const _PendingCard()),
            if (D['rep'].isNotEmpty) e(const _ReportsCard()),
            e(PeopleCard(D['mem'].values.where((x) => x['status'] == 'approved').toList())),
          ],
          e(const _ProfileCard()),
          e(const MySocCard()),
        ]);
      },
    );
  }
}

class _IdCardEntry extends StatelessWidget {
  const _IdCardEntry();
  @override
  Widget build(BuildContext context) => AppCard(title: '🪪 Resident records', children: [
        Text(S.kind == 'school' ? (S.isOwner ? tr('ID proof and photo of every student and teacher, class by class.') : tr('ID proof and photo of the students, class by class.')) : tr('ID proof and photo of every resident, by building and flat.'), style: meta()),
        const SizedBox(height: 10),
        Btn(S.sch && S.isOwner ? tr('🪪 Teachers & students ID proof') : tr('🪪 Residents ID proof'), onTap: () => openIdPages(context)),
      ]);
}

String _joinCode() => S.isTeacher ? str(S.me?['code']) : str(S.soc?['code']);

/* ---------- invite ---------- */
class _InviteCard extends StatelessWidget {
  const _InviteCard();
  @override
  Widget build(BuildContext context) {
    final p = pal;
    final T = S.isTeacher, P = S.sch && S.isOwner, code = _joinCode();
    final txt = P
        ? inviteText(code, org: str(S.soc?['name']), teacher: true)
        : T
            ? trf('Join {0} of {1} on {2}{3} (class code: {4}). Install {5}, choose Join as a student and enter the code.', [S.myCls, (str(S.soc?['name'])), brand, (inviteLink(code).isEmpty ? '' : ': ${inviteLink(code)}'), code, brand])
            : trf('Join our {0} on {1}{2} (code: {3}). Install {4}, choose Join and enter the code.', [S.K.word, brand, (inviteLink(code).isEmpty ? '' : ': ${inviteLink(code)}'), code, brand]);
    return AppCard(title: P ? 'Invite teachers' : T ? trf(S.skE('Invite your class · {0}'), [S.myCls]) : 'Invite residents', children: [
      if (P) Text(tr("This is your Principal's code. Share it only with teachers: they choose Join as a teacher and enter it. Students join with their class teacher's code."), style: meta()),
      if (T) Text(code.isNotEmpty ? trf('This is the class code for {0}. Your students choose Join as a student and enter it.', [S.myCls]) : tr('Your class code is being prepared. Open this tab again in a moment.'), style: meta()),
      const SizedBox(height: 12),
      GestureDetector(
        onTap: code.isEmpty
            ? null
            : () {
                Clipboard.setData(ClipboardData(text: code));
                toast('📋', tr('Code copied'), code);
              },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          alignment: Alignment.center,
          decoration: BoxDecoration(color: p.tint, borderRadius: BorderRadius.circular(18), border: Border.all(color: p.a.withOpacity(.3), width: 1.4)),
          child: Text(code.isEmpty ? '· · ·' : code, style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, letterSpacing: 6, color: p.a)),
        ),
      ),
      if (code.isNotEmpty) ...[
        const SizedBox(height: 12),
        Row2(
          Btn.o(tr('Copy invitation'), small: true, onTap: () {
            Clipboard.setData(ClipboardData(text: txt));
            toast('📋', tr('Copied'), tr('Paste it anywhere to invite'));
          }),
          Btn.g(tr('Share on WhatsApp'), small: true, onTap: () => launchUrl(Uri.parse('https://wa.me/?text=${Uri.encodeComponent(txt)}'), mode: LaunchMode.externalApplication)),
        ),
      ],
    ]);
  }
}

/* ---------- pending approvals ---------- */
class _PendingCard extends StatelessWidget {
  const _PendingCard();
  @override
  Widget build(BuildContext context) {
    final pend = D['mem'].values.where((x) => x['status'] == 'pending').toList();
    return AppCard(title: trf(S.skE('Pending approvals ({0})'), [pend.length]), children: [
      if (pend.isEmpty) Text(tr('No pending requests.'), style: meta()),
      for (final r in pend)
        Item(bar: pal.amber, children: [
          Text(str(r['name']), style: h3()),
          Meta(trf('Joining as {0} · {1} · {2}', [(S.roleLbl(r['want'] ?? r['role'])), str(r['flat']), str(r['mobile'])])),
          IdThumbs(r),
          const SizedBox(height: 8),
          Row2(
            Btn.g(tr('Approve'), small: true, onTap: () async {
              final w = str(r['want']);
              await updateDoc(memRef(str(r['id'])), S.isOwner && const ['COMMITTEE_MEMBER', 'STAFF', 'SECURITY_GUARD', 'ACCOUNTANT'].contains(w) ? {'status': 'approved', 'role': w} : {'status': 'approved'});
              rtdb.ref('soc/${S.sid}/members/${r['id']}').set(true).catchError((_) {});
              if (r['bus'] != null && S.isOwner) busFromMember({...r, 'status': 'approved'}).catchError((_) => '');
              toast('✅', tr('Approved'), str(r['name']));
            }),
            Btn.r(tr('Reject'), small: true, onTap: () => updateDoc(memRef(str(r['id'])), {'status': 'rejected'})),
          ),
        ]),
    ]);
  }
}

/* ---------- reported chat messages ---------- */
class _ReportsCard extends StatelessWidget {
  const _ReportsCard();
  @override
  Widget build(BuildContext context) {
    final reps = D['rep'].values.toList()..sort((a, b) => intv(b['ts']).compareTo(intv(a['ts'])));
    return AppCard(title: trf(S.skE('🚩 Reported messages ({0})'), [reps.length]), children: [
      for (final r in reps)
        Item(bar: pal.red, children: [
          Text(str(r['name']), style: h3()),
          Desc(str(r['text'])),
          Meta(trf('Reported by {0} · {1}', [str(r['by']), dt(r['ts'])])),
          const SizedBox(height: 8),
          Row2(
            Btn.r(tr('Delete message'), small: true, onTap: () async {
              try {
                final ms = await dref('messages', str(r['msgId'])).get();
                if (ms.exists) {
                  final m0 = ms.data()!;
                  for (final f in [m0['img'], m0['voice'], mapv(m0['file'])['url']]) {
                    rmFile(f);
                  }
                }
              } catch (_) {}
              await delDoc(dref('messages', str(r['msgId']))).catchError((_) {});
              await delDoc(dref('reports', str(r['id'])));
            }),
            Btn.o(tr('Dismiss'), small: true, onTap: () => delDoc(dref('reports', str(r['id'])))),
          ),
        ]),
    ]);
  }
}

/* ---------- people ---------- */
const _pplRoles = ['RESIDENT', 'TENANT', 'COMMITTEE_MEMBER', 'ACCOUNTANT', 'SECURITY_GUARD', 'STAFF'];
List<List<String>> _pplG() => S.kind == 'school'
    ? const [['T', '🧑‍🏫', 'Teachers'], ['S', '🧹', 'Staff'], ['M', '🎓', 'Students']]
    : S.kind == 'company'
        ? const [['T', '👔', 'Managers'], ['S', '🧰', 'Staff'], ['M', '💼', 'Employees']]
        : const [['T', '🏛️', 'Committee'], ['S', '🛡️', 'Staff'], ['M', '🏠', 'Residents']];
String _pplGrp(Doc x) => const ['SOCIETY_ADMIN', 'COMMITTEE_MEMBER'].contains(x['role'])
    ? 'T'
    : const ['ACCOUNTANT', 'SECURITY_GUARD', 'STAFF'].contains(x['role'])
        ? 'S'
        : 'M';

class PeopleCard extends StatefulWidget {
  final List<Doc> list;
  const PeopleCard(this.list, {super.key});
  static String? g, of, c1, c2;
  @override
  State<PeopleCard> createState() => _PeopleCardState();
}

class _PeopleCardState extends State<PeopleCard> {
  List<Doc> _srt(List<Doc> a) => [...a]..sort((x, y) {
      final c = natCmp(str(x['flat']), str(y['flat']));
      return c != 0 ? c : str(x['name']).compareTo(str(y['name']));
    });

  Widget _row(Doc r, [VoidCallback? onTap]) {
    final p = pal;
    final can = S.isMgr && r['id'] != S.uid && r['id'] != S.soc?['adminUid'];
    return Ex(
      str(r['name']),
      sub: '${str(r['flat'])} · ${S.roleLbl(r['role'])}${S.sch && S.isOwner && str(r['code']).isNotEmpty ? trf(' · class code {0}', [r['code']]) : ''}',
      lead: Av(str(r['name']), photoOf(str(r['id'])), size: 38),
      onTap: onTap ?? () => profileOf(context, str(r['id'])),
      right: Row(mainAxisSize: MainAxisSize.min, children: [
        if (onTap != null) Icon(Icons.chevron_right_rounded, color: p.muted),
        if (can)
          IconButton(
            icon: Icon(Icons.more_vert_rounded, color: p.muted),
            tooltip: trf('Manage {0}', [str(r['name'])]),
            onPressed: () => _manage(r),
          ),
      ]),
    );
  }

  Future<void> _manage(Doc r) async {
    final roles = [..._pplRoles, if (S.kind == 'school') 'SOCIETY_ADMIN'];
    final v = await pickFromList(context, str(r['name']), [
      if (r['kid'] != true) for (final x in roles) (x, '${x == r['role'] ? '✓ ' : ''}${S.roleLbl(x)}'),
      ('__del', tr('🗑 Delete')),
    ], str(r['role']));
    if (v == null || !mounted) return;
    if (v == '__del') return delMember(context, r);
    if (v == r['role']) return;
    if (v == 'SOCIETY_ADMIN' && !await confirmDlg(context, trf('Make {0} the Principal? They will get full rights in this school.', [str(r['name'])]))) return;
    try {
      await updateDoc(memRef(str(r['id'])), {'role': v});
      toast('✅', tr('Role updated'));
    } catch (e) {
      fail(e);
    }
  }

  /* Employees -> department -> people; Students -> class -> section (when a class has more than one) -> students;
     Residents -> building (when there is more than one) -> residents */
  static final _secRe = RegExp(r'^(.*\d)\s*[-–/ ]?\s*([A-Za-z])$');
  (String, String) _clsSec(String c) {
    final m = _secRe.firstMatch(c.trim());
    return m == null ? (c, '') : (m.group(1)!.trim(), m.group(2)!.toUpperCase());
  }

  String _unitOf(Doc x) {
    final f = str(x['flat']);
    if (S.kind == 'society') {
      final m = RegExp(r'^(.*) · Flat ').firstMatch(f);
      return m != null ? m.group(1)! : '';
    }
    final c = S.clsOf(x);
    return c.isEmpty ? 'Others' : c;
  }

  Widget _tile(String ic, String t, String sub, VoidCallback onTap) => Ex(
        t,
        sub: sub,
        lead: Container(width: 38, height: 38, alignment: Alignment.center, decoration: BoxDecoration(color: pal.tint, shape: BoxShape.circle), child: Text(ic, style: const TextStyle(fontSize: 18))),
        onTap: onTap,
        right: Icon(Icons.chevron_right_rounded, color: pal.muted),
      );

  Widget _back(String t, VoidCallback fn) => Align(alignment: Alignment.centerLeft, child: TextButton(onPressed: () => setState(fn), child: Text('← $t')));

  List<Widget> _drillMembers(List<Doc> L, String lbl) {
    final w = <Widget>[];
    final who = lbl.toLowerCase();
    String n(int k) => '$k ${k == 1 ? who.replaceFirst(RegExp(r's$'), '') : who}';
    // the units (departments / classes / buildings)
    final units = <String, List<Doc>>{};
    for (final x in L) {
      (units[_unitOf(x)] ??= []).add(x);
    }
    if (S.kind == 'society' && units.length <= 1) {
      w.addAll(L.map((r) => _row(r)));
      return w;
    }
    final c1 = PeopleCard.c1;
    if (S.kind == 'school') {
      // class -> sections
      final cls = <String, Map<String, List<Doc>>>{};
      units.forEach((u, a) {
        final cs = _clsSec(u);
        ((cls[cs.$1] ??= {})[cs.$2] ??= []).addAll(a);
      });
      final names = cls.keys.toList()..sort(natCmp);
      if (c1 == null || !cls.containsKey(c1)) {
        w.add(Sec(trf(S.skE('{0} class{1}'), [names.length, (names.length == 1 ? '' : 'es')])));
        for (final c in names) {
          final secs = cls[c]!, tot = secs.values.fold<int>(0, (a, b) => a + b.length);
          final ns = secs.keys.where((k) => k.isNotEmpty).length;
          w.add(_tile('🏫', c, '${n(tot)}${ns > 1 ? trf(' · {0} sections', [ns]) : ''}', () => setState(() {
                PeopleCard.c1 = c;
                PeopleCard.c2 = null;
              })));
        }
        return w;
      }
      final secs = cls[c1]!;
      final sk = secs.keys.toList()..sort();
      if (sk.length > 1 && (PeopleCard.c2 == null || !secs.containsKey(PeopleCard.c2))) {
        w.add(_back(tr('All classes'), () => PeopleCard.c1 = null));
        w.add(Sec(trf(S.skE('{0} · {1} sections'), [c1, sk.length])));
        for (final k in sk) {
          final t = S.tOf(_unitOf(secs[k]!.first));
          w.add(_tile('📚', k.isEmpty ? c1 : trf('Section {0}', [k]), '${n(secs[k]!.length)}${t.isNotEmpty ? ' · $t' : ''}', () => setState(() => PeopleCard.c2 = k)));
        }
        return w;
      }
      final k = sk.length > 1 ? PeopleCard.c2! : sk.first;
      final a = _srt(secs[k]!);
      if (sk.length > 1) {
        w.add(_back(c1, () => PeopleCard.c2 = null));
      } else {
        w.add(_back(tr('All classes'), () => PeopleCard.c1 = null));
      }
      w.add(Sec('$c1${k.isNotEmpty ? trf(S.skE(' · Section {0}'), [k]) : ''} · ${n(a.length)}'));
      w.addAll(a.map((r) => _row(r)));
      return w;
    }
    // company departments, society buildings
    final names = units.keys.toList()..sort(natCmp);
    final ic = S.kind == 'company' ? '🗂️' : '🏢';
    final unitW = S.kind == 'company' ? 'department' : 'building';
    if (c1 == null || !units.containsKey(c1)) {
      w.add(Sec('${names.length} ${unitW}${names.length == 1 ? '' : 's'}'));
      for (final u in names) {
        w.add(_tile(ic, u.isEmpty ? tr('Others') : u, n(units[u]!.length), () => setState(() => PeopleCard.c1 = u)));
      }
      return w;
    }
    final a = _srt(units[c1]!);
    w.add(_back(trf('All {0}s', [unitW]), () => PeopleCard.c1 = null));
    w.add(Sec('${c1.isEmpty ? 'Others' : c1} · ${n(a.length)}'));
    w.addAll(a.map((r) => _row(r)));
    return w;
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    final list = widget.list, G = _pplG();
    final by = <String, List<Doc>>{'T': [], 'S': [], 'M': []};
    for (final x in list) {
      by[_pplGrp(x)]!.add(x);
    }
    final shown = G.where((g) => by[g[0]]!.isNotEmpty || g[0] == PeopleCard.g).toList();
    if (PeopleCard.g != null && by[PeopleCard.g]!.isEmpty && PeopleCard.of == null) PeopleCard.g = null;
    if (PeopleCard.g == null && (shown.length == 1 || (S.isTeacher && by['M']!.isNotEmpty))) PeopleCard.g = shown.length == 1 ? shown.first[0] : 'M';
    final w = <Widget>[];
    w.add(Row(children: [
      for (final g in G)
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Material(
              color: PeopleCard.g == g[0] ? p.a : p.card2,
              borderRadius: BorderRadius.circular(16),
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: by[g[0]]!.isEmpty
                    ? null
                    : () => setState(() {
                          if (PeopleCard.g == g[0] && PeopleCard.of == null) {
                            PeopleCard.g = null;
                          } else {
                            PeopleCard.g = g[0];
                          }
                          PeopleCard.of = null;
                          PeopleCard.c1 = null;
                          PeopleCard.c2 = null;
                        }),
                child: Opacity(
                  opacity: by[g[0]]!.isEmpty ? .45 : 1,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: Column(children: [
                      Text(g[1], style: const TextStyle(fontSize: 20)),
                      Text('${by[g[0]]!.length}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: PeopleCard.g == g[0] ? Colors.white : p.text)),
                      Text(g[2], style: TextStyle(fontSize: 12, color: PeopleCard.g == g[0] ? Colors.white70 : p.muted)),
                    ]),
                  ),
                ),
              ),
            ),
          ),
        ),
    ]));
    if (PeopleCard.g == null) {
      w.add(Meta(trf('Tap a card to see the list.{0}', [(S.isMgr ? tr(' Use ⋮ next to a person to change their role or delete them.') : '')]), pad: const EdgeInsets.only(top: 10)));
    } else {
      final lbl = G.firstWhere((g) => g[0] == PeopleCard.g)[2], drill = S.kind != 'society' && PeopleCard.g == 'T';
      if (PeopleCard.of != null) {
        final tch = list.where((x) => x['id'] == PeopleCard.of).firstOrNull;
        final c = tch != null ? S.clsOf(tch) : '';
        final L = _srt(by['M']!.where((x) => S.clsOf(x) == c).toList());
        w.add(Align(alignment: Alignment.centerLeft, child: TextButton(onPressed: () => setState(() => PeopleCard.of = null), child: Text('← $lbl'))));
        w.add(Sec('${str(tch?['name'])} · $c · ${L.length} ${G[2][2].toLowerCase()}'));
        if (L.isEmpty) w.add(Meta(trf('Nobody in this {0} yet.', [(S.kind == 'school' ? 'class' : 'department')])));
        w.addAll(L.map((r) => _row(r)));
      } else {
        final L = _srt(by[PeopleCard.g]!);
        if (PeopleCard.g == 'M') {
          w.addAll(_drillMembers(L, lbl));
        } else {
          for (final r in L) {
            w.add(_row(r, drill && r['role'] == 'COMMITTEE_MEMBER' ? () => setState(() => PeopleCard.of = str(r['id'])) : null));
          }
        }
        if (drill) w.add(Meta(trf('Tap a {0}', [(S.kind == 'school' ? tr('teacher to see the students of their class.') : tr('manager to see their department.'))])));
      }
    }
    return AppCard(title: trf(S.skE('👥 People ({0})'), [list.length]), children: [AnimatedSize(duration: const Duration(milliseconds: 220), alignment: Alignment.topCenter, child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: w))]);
  }
}

/// the public profile of a member (the chat profile sheet)
void profileOf(BuildContext context, String uid) => profile(context, uid);

Future<void> delMember(BuildContext context, Doc r) async {
  final id = str(r['id']);
  if (RegExp(r'_k\d+$').hasMatch(id)) {
    if (!await confirmDlg(context, trf('Remove {0} from the school?\nThe parent\'s login and their other children stay.', [str(r['name'])]), ok: tr('Remove'), danger: true)) return;
    try {
      await delDoc(memRef(id));
      col('attendance').where('uid', isEqualTo: id).get().then((q) {
        for (final d in q.docs) {
          d.reference.delete();
        }
      }).catchError((_) {});
      delDoc(dref('busmap', id)).catchError((_) {});
      dropFile(r['photoUrl']);
      toast('🗑️', tr('Removed'), str(r['name']));
    } catch (e) {
      fail(e);
    }
    return;
  }
  if (!await confirmDlg(context, trf('Delete {0}\'s profile permanently?\nAll their data is erased. They can no longer log in and must sign up again.', [str(r['name'])]), ok: tr('Delete'), danger: true)) return;
  try {
    final sid = S.sid!, uid = id;
    try {
      await fs.collection('deletedUsers').doc(uid).set({'sid': sid, 'by': S.uid, 'ts': now()});
    } on FirebaseException catch (e) {
      if (e.code == 'permission-denied') {
        toast('🔒', tr("Couldn't delete"), tr("You don't have permission to delete this profile."));
        return;
      }
      rethrow;
    }
    for (final f in [r['idUrl'], r['photoUrl'], D['dir'][uid]?['photo']]) {
      dropFile(f);
    }
    if (str(r['code']).isNotEmpty) fs.collection('joinCodes').doc(str(r['code'])).delete().catchError((_) {});
    await Future.wait(['complaints', 'visitors', 'vehicles', 'leaves', 'rooms', 'messages', 'classifieds', 'bookings', 'attendance'].map((c) => col(c).where('uid', isEqualTo: uid).get().then((q) => Future.wait(q.docs.map((d) => d.reference.delete()))).catchError((_) => <void>[])));
    await Future.wait([delDoc(dref('directory', uid)).catchError((_) {}), delDoc(dref('presence', uid)).catchError((_) {})]);
    await delDoc(memRef(uid));
    toast('🗑️', tr('Profile deleted'), trf('{0} can no longer log in.', [str(r['name'])]));
  } catch (e) {
    fail(e);
  }
}

/* ---------- my profile ---------- */
class _ProfileCard extends StatelessWidget {
  const _ProfileCard();

  Future<void> _photo(BuildContext context) async {
    final f = await pickPhotoSheet(context, front: true, title: tr('Profile photo'));
    if (f == null || !context.mounted) return;
    final p0 = await cropImage(context, f.bytes, ratios: const [1], circle: true, out: 640, q: .9);
    if (p0 == null) return;
    try {
      if (S.pid != null && S.pid != S.uid) {
        final pid = S.pid!, was = S.me?['photoUrl'];
        final p = await up(p0, 'avatars', 'kid.jpg');
        try {
          await updateDoc(memRef(pid), {'photoUrl': p});
        } catch (x) {
          rmFile(p);
          rethrow;
        }
        if (S.pid == pid) S.me!['photoUrl'] = p;
        for (final k in S.kids) {
          if (k['id'] == pid) k['photoUrl'] = p;
        }
        if (was != null && was != p) rmFile(was);
        S.touch();
        toast('✅', tr('Profile photo updated'), str(S.me?['name']));
        return;
      }
      final old = D['dir'][S.uid]?['photo'];
      final p = await up(p0, 'avatars', 'a.jpg');
      await setDoc(dref('directory', S.uid!), {'uid': S.uid, 'name': S.me!['name'], 'flat': S.me!['flat'], 'role': S.me!['role'], 'photo': p}, merge: true);
      D['dir'][S.uid!] = {...?D['dir'][S.uid], 'photo': p};
      D.bump('dir');
      if (old != null && old != p) rmFile(old);
      fxDone(tr('Profile photo updated'), '', false, 1400);
    } catch (x) {
      fail(x, tr('Could not update photo'));
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = pal, me = S.me!;
    return AppCard(children: [
      Center(
        child: GestureDetector(
          onTap: () => _photo(context),
          child: Stack(children: [
            Container(padding: const EdgeInsets.all(3), decoration: BoxDecoration(shape: BoxShape.circle, gradient: p.grad), child: Container(padding: const EdgeInsets.all(3), decoration: BoxDecoration(shape: BoxShape.circle, color: p.card), child: Av(str(me['name']), myPhoto(), size: 92))),
            Positioned(right: 2, bottom: 2, child: Container(width: 30, height: 30, decoration: BoxDecoration(color: p.a, shape: BoxShape.circle, border: Border.all(color: p.card, width: 2)), child: const Icon(Icons.photo_camera_rounded, color: Colors.white, size: 16))),
          ]),
        ),
      ),
      const SizedBox(height: 8),
      Center(child: TextButton.icon(onPressed: () => _photo(context), icon: const Icon(Icons.photo_camera_outlined, size: 18), label:  Text(tr('Change profile photo')))),
      Text(str(me['name']), style: h2(), textAlign: TextAlign.center),
      const SizedBox(height: 4),
      Text(trf('{0} · {1} · {2} · Plan {3}', [(str(S.soc?['name'])), str(me['flat']), S.roleLbl(me['role']), PlanSt.name()]), style: meta(), textAlign: TextAlign.center),
      const SizedBox(height: 14),
      StatefulBuilder(
        builder: (c, set) => Ex(tr('🔕 Mute notifications'), right: Text('${muteSum()} ›', style: small()), onTap: () => muteSheet(context, () => set(() {}))),
      ),
      Ex(tr('🌐 Language'), right: Text('${L10n.I.lang.native} ›', style: small()), onTap: () => openLangPage(context)),
      const SizedBox(height: 10),
      Btn.r(tr('Log out'), small: true, onTap: () async {
        if (await confirmDlg(context, trf('Log out of {0} on this phone?', [brand]), ok: tr('Log out'))) await App.logout();
      }),
      if (S.isMgr)
        Padding(
          padding: const EdgeInsets.only(top: 10),
          child: Btn.o(trf('🗑️ Delete this {0}', [S.K.word]), small: true, color: p.red, onTap: () => delOrg(context)),
        ),
      Center(child: TextButton(onPressed: () => delMe(context), child: Text(tr('🗑️ Delete my account'), style: TextStyle(color: p.red)))),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        TextButton(onPressed: () => openLegal(context, 'privacy'), child:  Text(tr('Privacy Policy'))),
        Text('·', style: meta()),
        TextButton(onPressed: () => openLegal(context, 'terms'), child:  Text(tr('Terms & Conditions'))),
      ]),
    ]);
  }
}

/* ---------- my societies / students ---------- */
class MySocCard extends StatelessWidget {
  const MySocCard({super.key});
  @override
  Widget build(BuildContext context) {
    final kid = S.sch && S.prim != null && S.isStu(S.prim);
    final sw = S.swCan;
    final w = 'society', ws = S.sch ? 'school' : w;
    final create = S.sch ? S.isOwner : S.isAdm;
    final join = !S.sch;
    if (!kid && !sw && !create && !join) return const SizedBox();
    return AppCard(children: [
      if (kid) ...[
        Text(tr('👨‍👩‍👧 My students'), style: h2()),
        Text(tr('More than one child in this school? Add them here and switch between them — no second login needed.'), style: meta()),
        const SizedBox(height: 8),
        const KidRows(),
        Padding(padding: const EdgeInsets.only(top: 10, bottom: 16), child: Btn(tr('➕ Add another student'), small: true, onTap: BootCtl.addKid)),
      ],
      if (sw) ...[
        Text(trf('🏘️ My {0}', [(S.sch ? 'schools' : 'societies')]), style: h2()),
        if (S.isAdm) Text(S.sch ? tr('You can be an admin in more than one school and switch anytime.') : tr('You can be an admin or resident in more than one society and switch anytime.'), style: meta()),
        const SizedBox(height: 8),
        const SocRows(),
      ],
      if (create || join) const SizedBox(height: 10),
      if (create && join)
        Row2(
          Btn(trf('➕ Create another {0}', [ws]), small: true, onTap: () {
            S.addMode = true;
            BootCtl.gotoCreate();
          }),
          Btn.o(trf('🔑 Join another {0}', [ws]), small: true, onTap: () {
            S.addMode = true;
            BootCtl.gotoJoin();
          }),
        )
      else if (create)
        Btn(trf('➕ Create another {0}', [ws]), small: true, onTap: () {
          S.addMode = true;
          BootCtl.gotoCreate();
        })
      else if (join)
        Btn.o(trf('🔑 Join another {0}', [ws]), small: true, onTap: () {
          S.addMode = true;
          BootCtl.gotoJoin();
        }),
    ]);
  }
}

/* ---------- mute notifications ---------- */
List<List<String>> muteKinds() => muteK.where((k) => k[0] == 'bill' ? !S.isGuard : k[0] == 'leave' ? S.kind != 'society' : k[0] == 'join' ? S.isAdm : true).map((k) => [k[0], k[1], tr(k[2]), tr(k[3])]).toList();
String muteSum() {
  if (Mute.all) return tr('All muted');
  final L = muteKinds().where((k) => Mute.kinds.contains(k[0])).toList();
  return L.isEmpty
      ? 'Off'
      : L.length == 1
          ? L.first[2]
          : trf('{0} kinds muted', [L.length]);
}

void _muteSave() {
  Mute.save();
  Push.setup();
}

void muteSheet(BuildContext context, [VoidCallback? done]) {
  sheet(context, (c) => StatefulBuilder(builder: (c, set) {
        void ch(VoidCallback f) {
          f();
          _muteSave();
          set(() {});
          done?.call();
        }

        return Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
          const SheetTitle('🔕 Mute notifications', sub: 'Choose which alerts you do not want on this phone. A muted alert makes no sound, shows no pop-up and is not added to the bell.'),
          ToggleRow(tr('🌙 Mute all notifications'), Mute.all, (v) => ch(() => Mute.all = v), hint: tr('Every sound, pop-up and bell alert')),
          const Sec('Or mute only some'),
          for (final k in muteKinds())
            Opacity(
              opacity: Mute.all ? .5 : 1,
              child: ToggleRow('${k[1]} ${k[2]}', Mute.all || Mute.kinds.contains(k[0]), (v) {
                if (Mute.all) return;
                ch(() => v ? Mute.kinds.add(k[0]) : Mute.kinds.remove(k[0]));
              }, hint: k[3].isEmpty ? null : k[3]),
            ),
          Text(trf('A message that mentions you by name{0} always shown.', [(S.sch ? tr(' and the school-bus alerts are') : ' is')]), style: meta()),
          const SizedBox(height: 12),
          Btn.o(tr('🔧 Check notifications'), small: true, onTap: () => pushCheck(c)),
        ]);
      }));
}

/// goes through every step a notification needs on this phone and says which one fails; then a test notification
void pushCheck(BuildContext context) {
  final lines = <(bool, String, String?)>[];
  var done = false;
  StateSetter? up0;
  void add(bool ok, String t, [String? hint]) {
    lines.add((ok, t, hint));
    up0?.call(() {});
  }

  Future<void> run() async {
    try {
      Map<String, dynamic>? st;
      try {
        st = await Native.pushStatus();
      } catch (_) {
        add(false, tr('This app version has no notifications'), tr('Install the newest APK (GitHub → Actions → the newest build).'));
        return;
      }
      add(true, tr('This app version has notifications'));
      if (st?['granted'] != true || st?['enabled'] != true) {
        try {
          await Native.pushRegister();
        } catch (_) {}
        st = await Native.pushStatus();
      }
      if (st?['granted'] != true || st?['enabled'] != true) {
        add(false, trf('Notifications are turned off for {0}', [brand]), trf('Turn them on: phone Settings → Apps → {0} → Notifications → Allow. Then check again.', [brand]));
        return;
      }
      add(true, tr('Notifications are allowed on this phone'));
      Map<String, dynamic>? t;
      try {
        t = await Native.pushRegister();
      } catch (e) {
        add(false, tr('No push token from Google'), trf('{0}. Google Play services must be on the phone, and the internet must work.', [e]));
        return;
      }
      if (t == null || str(t['token']).isEmpty) {
        add(false, tr('No push token from Google'), tr('Try again with a working internet connection.'));
        return;
      }
      add(true, tr('Push token received from Google'));
      if (payApi.isEmpty) {
        add(false, tr('No server address in this app'), tr('PAY_API is empty.'));
        return;
      }
      try {
        final r = await api('/v1/push/register', {'sid': S.sid, 'token': t['token'], 'mute': {'all': Mute.all, 'kinds': Mute.kinds.toList()}, 'name': str(S.me?['name'])}, 90000);
        Push.token = str(t['token']);
        await Native.pushSetAuth({'server': payApi, 'device': str(r['device']), 'key': str(r['key']), 'sid': S.sid, 'uid': S.uid, 'name': str(S.me?['name'])});
      } on AppError catch (e) {
        add(false, e.http == 404 ? tr('The server does not know notifications yet') : tr('The server did not register this phone'), e.http == 404 ? tr('Upload push.js, app.js and index.js to the payments server (src folder) on GitHub, and wait until Render shows the deploy as live.') : e.message);
        return;
      }
      add(true, tr('This phone is registered on the server'));
      if (Mute.all) add(false, tr('All notifications are muted on this phone'), tr('Switch off “Mute all notifications” above.'));
      Map<String, dynamic> x;
      try {
        x = await api('/v1/push/test', {}, 90000);
      } on AppError catch (e) {
        add(false, tr('The test could not be sent'), e.http == 404 ? tr('The server is older than this app: upload the newest push.js and app.js to the payments server.') : e.message);
        return;
      }
      if (x['sending'] != true) {
        add(false, tr('The server cannot send notifications'), tr('Firebase Messaging did not start on the server. Look for “push notifications are off” in the Render logs.'));
        return;
      }
      final sent = intv(x['sent']);
      if (sent == 0) {
        add(false, tr('Firebase did not accept the test notification'), listv(x['errors']).join(', ').isEmpty ? tr('No phone registered for you.') : listv(x['errors']).join(', '));
        return;
      }
      add(true, trf('Test notification sent to {0} phone{1}', [sent, (sent == 1 ? '' : 's')]), trf('It should appear within a few seconds, also while the app is open. If it does not: give {0} “Autostart” and set its battery use to “No restrictions” (Xiaomi, Redmi, Oppo, Vivo, Realme), then check again.', [brand]));
    } catch (e) {
      add(false, tr('The check stopped'), fr(e));
    } finally {
      done = true;
      up0?.call(() {});
    }
  }

  run();
  sheet(context, (c) => StatefulBuilder(builder: (c, set) {
        up0 = set;
        return Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
          const SheetTitle('🔧 Check notifications', sub: 'Checks each step on this phone, then sends you a test notification.'),
          for (final l in lines) ...[
            Ex('${l.$1 ? '✅' : '❌'} ${l.$2}'),
            if (l.$3 != null) Note(l.$3!, tone: l.$1 ? Tone.g : Tone.y, margin: const EdgeInsets.only(bottom: 8)),
          ],
          if (!done) Padding(padding: const EdgeInsets.all(12), child: Text(tr('Checking…'), style: meta(), textAlign: TextAlign.center)),
          if (done)
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Btn.o(tr('📋 Copy report'), small: true, onTap: () {
                Clipboard.setData(ClipboardData(text: '${lines.map((l) => '${l.$1 ? 'OK   ' : 'FAIL '}${l.$2}${l.$3 != null ? ' | ${l.$3}' : ''}').join('\n')}\n${DateTime.now().toIso8601String()}'));
                toast('📋', tr('Report copied'));
              }),
            ),
        ]);
      })).whenComplete(() => up0 = null);
}

/* ---------- delete organisation / account ---------- */
Future<void> _restart() async {
  try {
    await FirebaseAuth.instance.currentUser?.reload();
    if (FirebaseAuth.instance.currentUser == null) throw 'gone';
    D.clearAll();
    await App.boot();
  } catch (_) {
    await App.logout();
  }
}

Future<void> delOrg(BuildContext context) async {
  final w = S.K.word, name = str(S.soc?['name']);
  final n = await promptDlg(context, trf('This permanently deletes this {0} and ALL its data: every record, every uploaded photo, ID proof and PDF, and the login of every member who is in no other workspace.\nIt cannot be undone.\n\nType its name to confirm:\n\n{1}', [w, name]), ok: tr('Delete'), max: 120);
  if (n == null) return;
  if (n.trim() != name) {
    toast('ℹ️', tr('Name did not match'), tr('Nothing was deleted'));
    return;
  }
  if (payApi.isNotEmpty && await _orgWipe(n.trim())) return;
  try {
    Listen.stop();
    final sid = S.sid!;
    Future<void> wipe(String c) async {
      final q = await col(c).get();
      for (var i = 0; i < q.docs.length; i += 400) {
        final bt = Batch();
        for (final d in q.docs.sublist(i, i + 400 > q.docs.length ? q.docs.length : i + 400)) {
          final x = d.data();
          if (c == 'members') {
            dropFile(x['idUrl']);
            dropFile(x['photoUrl']);
          }
          bt.delete(d.reference);
        }
        await bt.commit();
      }
    }

    for (final c in const ['announcements', 'contributions', 'expenses', 'complaints', 'messages', 'reports', 'visitors', 'deliveries', 'vehicles', 'parking', 'bills', 'helpers', 'classifieds', 'alerts', 'presence', 'directory', 'amenities', 'documents', 'staff', 'sos', 'bookings', 'polls', 'leaves', 'rooms', 'timetable', 'homework', 'attendance']) {
      await wipe(c).catchError((_) {});
    }
    await Future.wait(D['mem'].values.where((x) => str(x['code']).isNotEmpty).map((x) => fs.collection('joinCodes').doc(str(x['code'])).delete().catchError((_) {})));
    await fs.collection('societies').doc(sid).delete();
    if (str(S.soc?['code']).isNotEmpty) await fs.collection('joinCodes').doc(str(S.soc!['code'])).delete().catchError((_) {});
    await fs.collection('userSociety').doc(S.uid).delete().catchError((_) {});
    await wipe('members');
    toast('🗑️', tr('Deleted'), trf('Your {0} and its data are gone.', [w]));
    Timer(const Duration(milliseconds: 1200), _restart);
  } catch (e) {
    fail(e);
  }
}

Future<bool> _orgWipe(String name) async {
  final w = S.K.word;
  final ov = _busyOverlay(tr('Deleting…'), tr('All data, files and logins are being removed. Please keep the app open.'));
  try {
    Listen.stop();
    final r = await api('/v1/orgs/delete', {'sid': S.sid, 'confirm': name}, 280000);
    ov.remove();
    toast('🗑️', tr('Deleted'), trf('Your {0} is gone: all data{1} and {2} login{3}.', [w, (r['files'] == false ? '' : tr(', every uploaded file')), intv(r['loginsDeleted']), (intv(r['loginsDeleted']) == 1 ? '' : 's')]));
    Timer(const Duration(milliseconds: 1800), _restart);
    return true;
  } on AppError catch (x) {
    ov.remove();
    if (x.http == 404 && x.code == 'not-found') {
      App.startApp();
      return false;
    }
    if (x.net) {
      toast('ℹ️', tr('Still deleting'), tr('The server is finishing it. Open the app again in a few minutes.'));
      Timer(const Duration(milliseconds: 1800), _restart);
      return true;
    }
    fail(x);
    App.startApp();
    return true;
  } catch (x) {
    ov.remove();
    fail(x);
    App.startApp();
    return true;
  }
}

OverlayEntry _busyOverlay(String t, String s) {
  final e = OverlayEntry(
      builder: (_) => Material(
            color: Colors.black54,
            child: Center(
              child: Container(
                margin: const EdgeInsets.all(32),
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(color: pal.card, borderRadius: BorderRadius.circular(24)),
                child: Column(mainAxisSize: MainAxisSize.min, children: [const CircularProgressIndicator(), const SizedBox(height: 16), Text(t, style: h2()), const SizedBox(height: 6), Text(s, style: meta(), textAlign: TextAlign.center)]),
              ),
            ),
          ));
  navKey.currentState?.overlay?.insert(e);
  return e;
}

void delMe(BuildContext context) {
  if (payApi.isEmpty) {
    toast('ℹ️', tr('Not available'), trf('Deleting an account needs the {0} server.', [brand]));
    return;
  }
  final w = S.K.word, t = TextEditingController();
  final p = pal;
  sheet(context, (c) => StatefulBuilder(
      builder: (c, set) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
            SheetTitle('🗑️ Delete my account', sub: trf(S.skE('This removes you from {0} for good. It cannot be undone.'), [brand])),
            for (final x in [
              'Your profile${S.kidMany ? ' and every student on this login' : ''}, in every workspace you belong to',
              'Everything you uploaded: photo, ID proof, documents, chat photos and voice notes',
              'Your chat messages and private chats, complaints, leave, visitors and bookings',
              'Your login: this e-mail and password stop working',
            ])
              Padding(padding: const EdgeInsets.only(bottom: 6), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('•  ', style: TextStyle(color: p.red, fontWeight: FontWeight.w800)), Expanded(child: Text(x, style: body()))])),
            const SizedBox(height: 6),
            Text(trf('Bills and payment receipts stay with the {0} as its accounts.{1}', [w, (S.isOwner ? trf(' You are the main admin: delete the {0} itself first, or make someone else its main admin.', [w]) : '')]), style: meta()),
            const SizedBox(height: 12),
            Field(t, 'Type DELETE to confirm', max: 10, upper: true, onChanged: (_) => set(() {})),
            Btn.r(tr('Delete my account permanently'), onTap: t.text.trim().toUpperCase() != 'DELETE'
                ? null
                : () async {
                    Map<String, dynamic> r;
                    try {
                      r = await api('/v1/account/delete', {'confirm': 'DELETE'}, 280000);
                    } on AppError catch (x) {
                      if (x.http == 404 && x.code == 'not-found') throw AppError(trf('This needs the latest {0} server. Please try again after it has been updated.', [brand]));
                      rethrow;
                    }
                    Listen.stop();
                    if (c.mounted) Navigator.of(c).pop();
                    toast('🗑️', tr('Account deleted'), r['files'] == false ? tr('Your profile and login are removed.') : tr('Your profile, your files and your login are removed.'));
                    Timer(const Duration(milliseconds: 1600), () => App.logout());
                  }),
          ])));
}

/* ===================== phase 4: join QR, super admin ===================== */
List<Widget> p4(BuildContext context) {
  final w = <Widget>[];
  if (S.isAdm) {
    final jcd = _joinCode();
    if (jcd.isNotEmpty) {
      final l = inviteLink(jcd);
      w.add(AppCard(title: '📱 Join QR code', children: [
        Center(child: FxQR(l.isEmpty ? jcd : l, size: 170)),
        const SizedBox(height: 10),
        Text(S.sch ? (S.isTeacher ? trf('Your students scan this to join {0} · class code {1}', [S.myCls, jcd]) : trf('Teachers scan this to join · Principal\'s code {0}', [jcd])) : trf('Residents scan this to join · code {0}', [jcd]), style: meta(), textAlign: TextAlign.center),
      ]));
    }
  }
  if (S.isSuper && payApi.isNotEmpty) w.add(const _MigrateCard());
  if (S.isSuper) w.add(const _SuperCard());
  return w;
}

class _MigrateCard extends StatefulWidget {
  const _MigrateCard();
  @override
  State<_MigrateCard> createState() => _MigrateCardState();
}

class _MigrateCardState extends State<_MigrateCard> {
  String st = '';
  @override
  Widget build(BuildContext context) => AppCard(title: '☁️ Move files to Cloudflare', children: [
        Text(tr('Copies every photo, ID proof, PDF and voice note that is still in the Realtime Database to Cloudflare R2, checks the copy, then removes it from the Realtime Database. The app keeps working meanwhile. You can stop and start again; it continues where it stopped.'), style: meta()),
        const SizedBox(height: 10),
        Btn(tr('Start moving'), small: true, onTap: () async {
          Map<String, dynamic> r;
          do {
            r = await api('/v1/admin/files/migrate', {}, 150000);
            if (!mounted) return;
            setState(() => st = trf('Moved {0} file{1} ({2}){3}{4}', [intv(r['moved']), (intv(r['moved']) == 1 ? '' : 's'), fuSize(intv(r['bytes'])), (intv(r['skipped']) > 0 ? trf(' · {0} could not be moved', [r['skipped']]) : ''), (r['done'] == true ? tr(' · All done ✅') : tr(' · still working…'))]));
          } while (r['done'] != true && mounted);
          if (r['done'] == true) toast('✅', tr('Files moved to Cloudflare'), trf('{0} in total', [r['moved']]));
        }),
        if (st.isNotEmpty) Meta(st, pad: const EdgeInsets.only(top: 8)),
      ]);
}

class _SuperCard extends StatefulWidget {
  const _SuperCard();
  @override
  State<_SuperCard> createState() => _SuperCardState();
}

class _SuperCardState extends State<_SuperCard> {
  late final Future<List<Doc>> f = fs.collection('societies').limit(200).get().then((sn) => [for (final d in sn.docs) {'id': d.id, ...d.data()}]);
  @override
  Widget build(BuildContext context) => AppCard(title: '🛡️ Super admin · all societies', children: [
        FutureBuilder<List<Doc>>(
          future: f,
          builder: (_, s) {
            if (s.hasError) return Text(trf('Could not load: {0}', [fr(s.error)]), style: meta());
            if (!s.hasData) return Text(tr('Loading…'), style: meta());
            final all = s.data!;
            final paid = all.where((x) => intv(mapv(x['subscription'])['until']) > now()).length;
            return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Row2(_stat('Societies', all.length), _stat(tr('Active paid'), paid)),
              const SizedBox(height: 8),
              for (final x in all)
                Builder(builder: (_) {
                  final u = intv(mapv(x['subscription'])['until']);
                  return Ex(str(x['name']),
                      sub: trf('Code {0} · {1}', [str(x['code']), (u > 0 ? (u > now() ? trf('paid till {0}', [dt(u)]) : 'expired') : 'trial')]),
                      right: mini('+30d', () async {
                        await api('/v1/admin/extend-subscription', {'sid': x['id'], 'days': 30});
                        toast('✅', tr('Extended'), str(x['name']));
                      }));
                }),
            ]);
          },
        ),
      ]);

  Widget _stat(String l, int n) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: pal.card2, borderRadius: BorderRadius.circular(14)),
        child: Column(children: [Text('$n', style: h2()), Text(l, style: small())]),
      );
}

/* ===================== phase 3: SOS, amenities, polls, documents, staff, reports ===================== */
List<Doc> _V(String k) => D[k].values.toList()..sort((a, b) => intv(b['ts']).compareTo(intv(a['ts'])));
Future<void> _add(String n, Doc o) async {
  try {
    await addDoc(col(n), {...o, 'ts': now(), 'by': S.uid});
    toast('✅', tr('Saved'));
  } catch (x) {
    fail(x);
  }
}

Future<void> _del(String n, String id) => delDoc(dref(n, id)).catchError((x) => fail(x));
Widget _rm(String n, String id) => Align(alignment: Alignment.centerLeft, child: TextButton(onPressed: () => _del(n, id), style: TextButton.styleFrom(padding: EdgeInsets.zero, minimumSize: const Size(0, 30)), child: Text(tr('Remove'), style: TextStyle(color: pal.red, fontSize: 13))));

List<Widget> p3(BuildContext context) {
  final adm = S.isAdm;
  return [
    const _SosCard(),
    const _AmnCard(),
    const _PollCard(),
    const _DocCard(),
    const _StaffCard(),
    if (adm || S.role == 'ACCOUNTANT') const _ReportCard(),
  ];
}

/// what the alert tells about the person: the flat in a society, the class in a school, the department in a company
String _sosWhat() => S.kind == 'school'
    ? (S.isStu(S.me) ? tr('your name and class') : tr('your name and role'))
    : S.kind == 'company'
        ? tr('your name and department')
        : tr('your flat number');

void _call(String ph) => launchUrl(Uri.parse('tel:$ph'));

class _SosCard extends StatefulWidget {
  const _SosCard();
  @override
  State<_SosCard> createState() => _SosCardState();
}

class _SosCardState extends State<_SosCard> {
  final n = TextEditingController(), ph = TextEditingController();

  void _send() {
    sheet(context, (c) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
          SheetTitle('Send emergency alert?', sub: trf(S.skE('Security and the admin will be notified instantly with {0}.'), [_sosWhat()])),
          Btn.r(tr('Yes, send SOS'), onTap: () async {
            await addDoc(col('alerts'), {'uid': S.uid, 'name': S.me!['name'], 'flat': S.me!['flat'], 'ts': now()});
            if (c.mounted) Navigator.of(c).pop();
            HapticFeedback.heavyImpact();
            fxDone(tr('Emergency alert sent'), trf('Alerting your {0}…', [S.K.word]), false, 5600, '🚨');
            Timer(const Duration(milliseconds: 1600), () => toast('🛡️', tr('Security notified'), trf('Guards and admin have {0}', [_sosWhat()])));
            Timer(const Duration(milliseconds: 3200), () => toast('🚑', tr('Help is on the way'), tr('Stay calm. Someone is coming.')));
          }),
        ]));
  }

  @override
  Widget build(BuildContext context) {
    final p = pal, adm = S.isAdm;
    final sos = _V('sos');
    return AppCard(title: '🆘 Emergency contacts', children: [
      if (!S.isGuard) _SosButton(onTap: _send),
      if (sos.isEmpty) Text(tr('No contacts added yet.'), style: meta()),
      for (final x in sos) ...[
        Ex(str(x['name']), sub: str(x['phone']), right: Btn.r(tr('📞 Call'), small: true, full: false, onTap: () => _call(str(x['phone'])))),
        if (adm) _rm('sos', str(x['id'])),
      ],
      if (adm) ...[
        const SizedBox(height: 8),
        Field(n, 'Name (Police, Fire, Ambulance…)', max: 60),
        Field(ph, 'Phone', kb: TextInputType.phone, max: 20),
        Btn(tr('Add contact'), small: true, onTap: () async {
          if (n.text.trim().isEmpty || ph.text.trim().isEmpty) return;
          await _add('sos', {'name': n.text.trim(), 'phone': ph.text.trim()});
          n.clear();
          ph.clear();
        }),
      ],
      if (p.dark) const SizedBox.shrink(),
    ]);
  }
}

/// the big red SOS button with a slow pulse
class _SosButton extends StatefulWidget {
  final VoidCallback onTap;
  const _SosButton({required this.onTap});
  @override
  State<_SosButton> createState() => _SosButtonState();
}

class _SosButtonState extends State<_SosButton> with SingleTickerProviderStateMixin {
  late final AnimationController c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1600))..repeat();
  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: AnimatedBuilder(
          animation: c,
          builder: (_, child) => Container(
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), boxShadow: [BoxShadow(color: const Color(0xFFEF4444).withOpacity(.45 * (1 - c.value)), blurRadius: 4 + 22 * c.value, spreadRadius: 6 * c.value)]),
            child: child,
          ),
          child: Material(
            borderRadius: BorderRadius.circular(18),
            color: Colors.transparent,
            child: Ink(
              decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFFEF4444), Color(0xFFDC2626)]), borderRadius: BorderRadius.circular(18)),
              child: InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: widget.onTap,
                child:  Padding(padding: EdgeInsets.symmetric(vertical: 18), child: Center(child: Text(tr('🚨 SOS — Send emergency alert'), style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16)))),
              ),
            ),
          ),
        ),
      );
}

class _AmnCard extends StatefulWidget {
  const _AmnCard();
  @override
  State<_AmnCard> createState() => _AmnCardState();
}

class _AmnCardState extends State<_AmnCard> {
  final n = TextEditingController(), o = TextEditingController(), cl = TextEditingController();
  final Map<String, String> date = {}, slot = {};

  @override
  Widget build(BuildContext context) {
    final adm = S.isAdm, today = td();
    final am = _V('amn'), bkAll = _V('bk');
    final bk = bkAll.where((b) => str(b['date']).compareTo(today) >= 0 && (adm || b['uid'] == S.uid)).toList()..sort((a, b) => '${a['date']}${a['slot']}'.compareTo('${b['date']}${b['slot']}'));
    bool taken(String id, String d, String s) => bkAll.any((b) => b['amn'] == id && b['date'] == d && b['slot'] == s);
    return AppCard(title: '🏊 Amenity booking', children: [
      if (am.isEmpty) Text(tr('No amenities yet.'), style: meta()),
      for (final a in am)
        Builder(builder: (_) {
          final id = str(a['id']), op = intv(a['open']), clh = intv(a['close']);
          final d = date[id] ?? today;
          final slots = [for (var h = op; h < clh; h++) '$h:00'];
          final free = slots.where((s) => !taken(id, d, s)).toList();
          var s = slot[id];
          if (s == null || !free.contains(s)) s = free.isNotEmpty ? free.first : '';
          return Item(children: [
            Text(str(a['name']), style: h3()),
            Meta(trf('{0}:00 – {1}:00 · 1-hour slots', [op, clh])),
            if (!S.isGuard) ...[
              const SizedBox(height: 8),
              Row2(
                DateField(tr('Date'), d, (v) => setState(() => date[id] = v), min: td()),
                SelectField('Slot', s, [for (final x in slots) (x, '$x${taken(id, d, x) ? ' (booked)' : ''}')], (v) {
                  if (taken(id, d, v)) {
                    toast('ℹ️', tr('Slot taken'));
                    return;
                  }
                  setState(() => slot[id] = v);
                }),
              ),
              Btn(tr('Book'), small: true, onTap: () async {
                if (s!.isEmpty) return;
                if (taken(id, d, s)) {
                  toast('ℹ️', tr('Slot taken'));
                  return;
                }
                await _add('bookings', {'amn': id, 'an': a['name'], 'date': d, 'slot': s, 'name': S.me!['name'], 'flat': S.me!['flat'], 'uid': S.uid});
              }),
            ],
            if (adm) _rm('amenities', id),
          ]);
        }),
      if (bk.isNotEmpty) ...[
        const Sec('Upcoming bookings'),
        for (final b in bk)
          Ex('${str(b['an'])} · ${str(b['date'])} ${str(b['slot'])}',
              sub: '${str(b['name'])} · ${str(b['flat'])}',
              right: adm || b['uid'] == S.uid ? TextButton(onPressed: () => _del('bookings', str(b['id'])), child:  Text(tr('Cancel'))) : null),
      ],
      if (adm) ...[
        const SizedBox(height: 8),
        Field(n, 'New amenity (Clubhouse, Gym…)', max: 60),
        Row2(Field(o, 'Opens at hour (0-23)', kb: TextInputType.number, max: 2), Field(cl, 'Closes at hour (1-24)', kb: TextInputType.number, max: 2)),
        Btn(tr('Add amenity'), small: true, onTap: () async {
          final a = int.tryParse(o.text) ?? -1, b = int.tryParse(cl.text) ?? -1;
          if (n.text.trim().isEmpty || a < 0 || b > 24 || !(b > a)) {
            toast('ℹ️', tr('Enter name and valid hours'));
            return;
          }
          await _add('amenities', {'name': n.text.trim(), 'open': a, 'close': b});
          n.clear();
          o.clear();
          cl.clear();
        }),
      ],
    ]);
  }
}

class _PollCard extends StatefulWidget {
  const _PollCard();
  @override
  State<_PollCard> createState() => _PollCardState();
}

class _PollCardState extends State<_PollCard> {
  final q = TextEditingController(), o = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final p = pal, adm = S.isAdm;
    final po = _V('pol');
    return AppCard(title: '🗳️ Polls', children: [
      if (po.isEmpty) Text(tr('No polls yet.'), style: meta()),
      for (final x in po)
        Builder(builder: (_) {
          final vs = mapv(x['votes']), tot = vs.length, my = vs[S.uid];
          final closed = x['closed'] == true;
          final opts = listv(x['opts']).map((e) => str(e)).toList();
          return Item(children: [
            Text(str(x['q']), style: h3()),
            Meta(trf('{0} vote{1}{2}', [tot, (tot == 1 ? '' : 's'), (closed ? tr(' · closed') : '')])),
            const SizedBox(height: 6),
            for (var i = 0; i < opts.length; i++)
              Builder(builder: (_) {
                final n = vs.values.where((v) => intv(v) == i).length, pc = tot > 0 ? n / tot : 0.0;
                final show = my != null || closed || adm;
                final mine = my != null && intv(my) == i;
                return Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Material(
                    color: p.card2,
                    borderRadius: BorderRadius.circular(12),
                    clipBehavior: Clip.antiAlias,
                    child: InkWell(
                      onTap: closed || S.isGuard ? null : () => updateDoc(dref('polls', str(x['id'])), {'votes.${S.uid}': i}).catchError((e) => fail(e)),
                      child: Stack(children: [
                        if (show)
                          Positioned.fill(
                              child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: TweenAnimationBuilder<double>(
                                      tween: Tween(begin: 0, end: pc.toDouble()),
                                      duration: const Duration(milliseconds: 600),
                                      curve: Curves.easeOutCubic,
                                      builder: (_, v, __) => FractionallySizedBox(widthFactor: v, child: Container(color: mine ? p.a.withOpacity(.22) : p.a.withOpacity(.10)))))),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), border: Border.all(color: mine ? p.a : p.line, width: mine ? 1.5 : 1)),
                          child: Row(children: [
                            if (mine) Padding(padding: const EdgeInsets.only(right: 6), child: Icon(Icons.check_circle_rounded, size: 18, color: p.a)),
                            Expanded(child: Text(opts[i], style: body().copyWith(fontWeight: mine ? FontWeight.w700 : FontWeight.w500))),
                            if (show) Text('${(pc * 100).round()}% ($n)', style: small()),
                          ]),
                        ),
                      ]),
                    ),
                  ),
                );
              }),
            if (adm)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Row2(
                  Btn.o(closed ? tr('Reopen') : tr('Close poll'), small: true, onTap: () => updateDoc(dref('polls', str(x['id'])), {'closed': !closed})),
                  Btn.r(tr('Delete'), small: true, onTap: () => _del('polls', str(x['id']))),
                ),
              ),
          ]);
        }),
      if (adm) ...[
        const SizedBox(height: 8),
        Field(q, 'Poll question', max: 160),
        Field(o, 'Options, one per line (2–6)', lines: 4),
        Btn(tr('Create poll'), small: true, onTap: () async {
          final op = o.text.split('\n').map((x) => x.trim()).where((x) => x.isNotEmpty).take(6).toList();
          if (q.text.trim().isEmpty || op.length < 2) {
            toast('ℹ️', tr('Add a question and 2+ options'));
            return;
          }
          await _add('polls', {'q': q.text.trim(), 'opts': op, 'votes': {}});
          q.clear();
          o.clear();
        }),
      ],
    ]);
  }
}

class _DocCard extends StatefulWidget {
  const _DocCard();
  @override
  State<_DocCard> createState() => _DocCardState();
}

class _DocCardState extends State<_DocCard> {
  final t = TextEditingController(), u = TextEditingController();
  static final _pdf = RegExp(r'\.pdf(\?|#|$)', caseSensitive: false);
  @override
  Widget build(BuildContext context) {
    final p = pal, adm = S.isAdm;
    final dc = _V('docu');
    return AppCard(title: '📄 Documents', children: [
      if (dc.isEmpty) Text(tr('No documents shared yet.'), style: meta()),
      for (final x in dc) ...[
        Ex('📎 ${str(x['title'])}', onTap: () {
          final url = str(x['url']);
          if (_pdf.hasMatch(url)) {
            openRef(context, url, name: '${str(x['title']).isEmpty ? 'document' : str(x['title'])}.pdf', mime: 'application/pdf');
          } else if (RegExp(r'^https?:').hasMatch(url)) {
            launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
          } else if (url.startsWith('data:')) {
            openRef(context, url, name: str(x['title']));
          }
        }, right: Icon(Icons.open_in_new_rounded, size: 18, color: p.a)),
        if (adm) _rm('documents', str(x['id'])),
      ],
      if (adm) ...[
        const SizedBox(height: 8),
        Field(t, 'Title (Bye-laws, AGM minutes…)', max: 80),
        Field(u, 'Link (Google Drive / PDF URL)', kb: TextInputType.url),
        Btn(tr('Share document'), small: true, onTap: () async {
          if (t.text.trim().isEmpty || !RegExp(r'^https?:').hasMatch(u.text.trim())) {
            toast('ℹ️', tr('Enter a title and a valid link'));
            return;
          }
          await _add('documents', {'title': t.text.trim(), 'url': u.text.trim()});
          t.clear();
          u.clear();
        }),
      ],
    ]);
  }
}

class _StaffCard extends StatefulWidget {
  const _StaffCard();
  @override
  State<_StaffCard> createState() => _StaffCardState();
}

class _StaffCardState extends State<_StaffCard> {
  final n = TextEditingController(), r = TextEditingController(), ph = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final adm = S.isAdm;
    final sf = _V('stf');
    return AppCard(title: '🧹 Staff directory', children: [
      if (sf.isEmpty) Text(tr('No staff listed.'), style: meta()),
      for (final x in sf) ...[
        Ex(str(x['name']), sub: '${str(x['role'])}${str(x['phone']).isNotEmpty ? ' · ${x['phone']}' : ''}', lead: Av(str(x['name']), null, size: 36), right: str(x['phone']).isNotEmpty ? Btn.g('📞', small: true, full: false, onTap: () => _call(str(x['phone']))) : null),
        if (adm) _rm('staff', str(x['id'])),
      ],
      if (adm) ...[
        const SizedBox(height: 8),
        Field(n, 'Name', max: 60),
        Field(r, 'Role (Maid, Plumber, Electrician…)', max: 40),
        Field(ph, 'Phone', kb: TextInputType.phone, max: 20),
        Btn(tr('Add staff'), small: true, onTap: () async {
          if (n.text.trim().isEmpty) return;
          await _add('staff', {'name': n.text.trim(), 'role': r.text.trim().isEmpty ? 'Staff' : r.text.trim(), 'phone': ph.text.trim()});
          n.clear();
          r.clear();
          ph.clear();
        }),
      ],
    ]);
  }
}

class _ReportCard extends StatelessWidget {
  const _ReportCard();

  static List<(String, num, String)> _grp(Iterable<Doc> o) {
    final g = <String, num>{};
    for (final x in o) {
      g[str(x['category'])] = (g[str(x['category'])] ?? 0) + numv(x['amount']);
    }
    final e = g.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return [for (final x in e) (x.key, x.value, rs(x.value))];
  }

  Widget _bars(List<(String, num, String)> pairs, Color c) {
    final mx = pairs.fold<num>(1, (a, x) => x.$2 > a ? x.$2 : a);
    return Column(children: [
      for (final x in pairs)
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 5),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${x.$1} · ${x.$3}', style: small()),
            const SizedBox(height: 4),
            ClipRRect(
              borderRadius: BorderRadius.circular(9),
              child: Container(
                height: 10,
                color: pal.card2,
                alignment: Alignment.centerLeft,
                child: TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0, end: (x.$2 / mx).toDouble()),
                  duration: const Duration(milliseconds: 700),
                  curve: Curves.easeOutCubic,
                  builder: (_, v, __) => FractionallySizedBox(widthFactor: v, child: Container(decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(9)))),
                ),
              ),
            ),
          ]),
        ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    final inc = D['inc'].values, exp = D['exp'].values;
    final ic = _grp(inc), ec = _grp(exp);
    final n = DateTime.now();
    final mo = [for (var i = 5; i >= 0; i--) DateTime(n.year, n.month - i, 1)];
    num sm(Iterable<Doc> o, DateTime d) => o.where((x) {
          final t = dtOf(x['ts']);
          return t.year == d.year && t.month == d.month;
        }).fold<num>(0, (a, x) => a + numv(x['amount']));
    final mx = mo.fold<num>(1, (a, d) => [a, sm(inc, d), sm(exp, d)].reduce((x, y) => x > y ? x : y));
    final cs = <String, int>{};
    for (final x in D['comp'].values) {
      final s = str(x['status']).isEmpty ? 'Open' : str(x['status']);
      cs[s] = (cs[s] ?? 0) + 1;
    }
    const mn = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return AppCard(title: '📊 Reports', children: [
      const Sec('Income by category'),
      if (ic.isEmpty) Text(tr('No data'), style: meta()) else _bars(ic, p.green),
      const Sec('Expenses by category'),
      if (ec.isEmpty) Text(tr('No data'), style: meta()) else _bars(ec, p.red),
      const Sec('Last 6 months: collected vs spent'),
      SizedBox(
        height: 150,
        child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          for (final d in mo)
            Expanded(
              child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                Expanded(
                  child: Row(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
                    for (final z in [(sm(inc, d), p.green), (sm(exp, d), p.red)])
                      TweenAnimationBuilder<double>(
                        tween: Tween(begin: 0, end: (z.$1 / mx).toDouble().clamp(.02, 1.0)),
                        duration: const Duration(milliseconds: 800),
                        curve: Curves.easeOutCubic,
                        builder: (_, v, __) => FractionallySizedBox(heightFactor: v, child: Container(width: 11, margin: const EdgeInsets.symmetric(horizontal: 1.5), decoration: BoxDecoration(color: z.$2, borderRadius: const BorderRadius.vertical(top: Radius.circular(5))))),
                      ),
                  ]),
                ),
                const SizedBox(height: 4),
                Text(mn[d.month - 1], style: small()),
              ]),
            ),
        ]),
      ),
      Text(tr('🟩 Collected  🟥 Spent'), style: meta()),
      const Sec('Complaints by status'),
      if (cs.isEmpty) Text(tr('No complaints'), style: meta()) else _bars([for (final e in cs.entries) (e.key, e.value, '${e.value}')], p.a),
    ]);
  }
}
