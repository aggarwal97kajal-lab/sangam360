import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../core/api.dart';
import '../../core/csv.dart';
import '../../core/fs.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import '../fx/driver.dart';
import 'svc.dart';

const atStaff = ['SOCIETY_ADMIN', 'COMMITTEE_MEMBER', 'ACCOUNTANT', 'SECURITY_GUARD', 'STAFF'];
String attCls(Doc? x) => str(x?['flat']).split(' · ').first;
String atf(dynamic x) => intv(x) > 0 ? tm(x) : '—';
String ahr(Doc? x) => x != null && intv(x['in']) > 0 && intv(x['out']) > intv(x['in']) ? '${((intv(x['out']) - intv(x['in'])) / 3600000).toStringAsFixed(1)} h' : '';

class AttGroup {
  final String k, t;
  final String? l;
  final bool Function(Doc x) f;
  AttGroup(this.k, this.t, this.f, [this.l]);
}

List<AttGroup> attGroups() {
  final sch = S.kind == 'school';
  final mem = D['mem'].values.where((x) => x['status'] == 'approved').toList();
  final names = sch ? (S.isTeacher ? [S.myCls] : S.schClasses()) : listv(S.soc?['towers']).map((t) => str(mapv(t)['name'])).toList();
  final G = <AttGroup>[];
  if (sch) {
    if (S.isOwner) G.add(AttGroup('@T', 'Teachers', (x) => x['role'] == 'COMMITTEE_MEMBER'));
    for (final n in names) {
      final t = S.tOf(n);
      G.add(AttGroup(n, n, (x) => !atStaff.contains(x['role']) && attCls(x) == n, n + (t.isNotEmpty ? ' · $t' : '')));
    }
    bool oth(Doc x) => !atStaff.contains(x['role']) && !names.contains(attCls(x));
    if (S.isOwner && mem.any(oth)) G.add(AttGroup('@O', 'Other students', oth));
    if (S.isOwner) {
      bool st(Doc x) => const ['ACCOUNTANT', 'SECURITY_GUARD', 'STAFF'].contains(x['role']);
      if (mem.any(st)) G.add(AttGroup('@S', 'Other staff', st));
    }
  } else {
    G.add(AttGroup('@A', 'All ${S.K.person.toLowerCase()}s', (x) => x['role'] != 'SECURITY_GUARD'));
    for (final n in names) {
      G.add(AttGroup(n, n, (x) => x['role'] != 'SECURITY_GUARD' && attCls(x) == n));
    }
  }
  return G;
}

class AttPage extends StatefulWidget {
  const AttPage({super.key});
  @override
  State<AttPage> createState() => _AttPageState();
}

class _AttPageState extends State<AttPage> {
  static String? attGrp, attDay;
  Doc? cur;
  bool loaded = false, perm = false;
  List<Doc> hist = [];
  Map<String, Doc> reg = {};
  bool regLoading = false;
  String regErr = '';

  ColRef get c => col('attendance');
  String get day => td();
  DocRef get ref => c.doc('${S.pidv}_$day');

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final x = await ref.get();
      cur = x.exists ? x.data() : null;
    } on FirebaseException catch (e) {
      perm = e.code == 'permission-denied';
    } catch (_) {}
    try {
      final q = await c.where('uid', isEqualTo: S.pidv).limit(62).get();
      hist = q.docs.map((d) => d.data()).toList()..sort((x, y) => str(y['date']).compareTo(str(x['date'])));
      hist = hist.take(14).toList();
    } catch (_) {}
    if (mounted) setState(() => loaded = true);
    if (S.isAdm) _reg();
  }

  Future<void> _mine() async {
    final n = now(), out = cur != null && intv(cur!['in']) > 0;
    try {
      if (out) {
        await updateDoc(ref, {'out': n});
      } else {
        Map<String, dynamic> dv = {};
        if (S.isDrv) {
          final v = await drvVerify(context);
          if (v == null) return;
          dv = v;
          DrvDuty.reset();
        }
        await setDoc(ref, {'uid': S.uid, 'name': S.me!['name'], 'flat': str(S.me!['flat']), 'role': str(S.me!['role']), 'date': day, 'in': now(), ...dv});
      }
    } on FirebaseException catch (e) {
      if (e.code == 'permission-denied') throw AppError('Attendance is not allowed right now. Please contact your admin.');
      rethrow;
    }
    toast('✅', out ? 'Checked out' : 'Checked in', tm(n));
    await _load();
  }

  AttGroup? _g(List<AttGroup> G) {
    if (G.isEmpty) return null;
    final mine = attCls(S.me);
    final k = G.any((g) => g.k == attGrp) ? attGrp : (S.sch && !S.isOwner && G.any((g) => g.k == mine) ? mine : G.first.k);
    return G.firstWhere((g) => g.k == k);
  }

  Future<void> _reg() async {
    setState(() {
      regLoading = true;
      regErr = '';
    });
    final d0 = attDay != null && attDay!.compareTo(day) <= 0 ? attDay! : day;
    try {
      final q = await c.where('date', isEqualTo: d0).get();
      reg = {for (final d in q.docs) str(d.data()['uid']): d.data()};
    } catch (_) {
      regErr = "Couldn't load the list.";
    }
    if (mounted) setState(() => regLoading = false);
  }

  Future<void> _mark(Doc x, String kind) async {
    final u = str(x['uid']), rf = c.doc('${u}_$day'), n = now();
    try {
      if (kind == 'in') {
        await setDoc(rf, {'uid': u, 'name': x['name'], 'flat': str(x['flat']), 'role': str(x['role']), 'date': day, 'in': n, 'by': S.uid});
      } else {
        await updateDoc(rf, {'out': n, 'by': S.uid});
      }
    } on FirebaseException catch (e) {
      if (e.code == 'permission-denied') throw AppError('Not allowed. The database rules must let teachers mark attendance.');
      rethrow;
    }
    toast('✅', kind == 'in' ? 'Checked in' : 'Checked out', str(x['name']));
    await _reg();
  }

  @override
  Widget build(BuildContext context) {
    final p = pal, sch = S.sch;
    if (!loaded) return svcBody(const [Skeleton(n: 2)]);
    final hasIn = cur != null && intv(cur!['in']) > 0, done = hasIn && intv(cur!['out']) > 0;
    return svcBody([
      AppCard(title: '🕘 My attendance', children: [
        Text('Today · $day · In: ${atf(cur?['in'])} · Out: ${atf(cur?['out'])}${ahr(cur).isNotEmpty ? ' · ${ahr(cur)}' : ''}', style: meta()),
        const SizedBox(height: 12),
        if (sch && !S.isAdm && S.isStu(S.me))
          Text('Your attendance is marked by your school. It appears here once your teacher or principal checks you in or out.', style: meta())
        else
          Btn(
              hasIn
                  ? (done ? 'Done for today ✅' : 'Check out')
                  : 'Check in',
              onTap: done ? null : _mine,
              busyDone: false),
        if (perm) Padding(padding: const EdgeInsets.only(top: 8), child: Text("⚠️ Attendance isn't available for your account right now. Please contact your admin.", style: meta())),
      ]),
      AppCard(title: '📅 My recent attendance', children: [
        if (hist.isEmpty) Text('Nothing yet.', style: meta()),
        for (final x in hist) Ex(str(x['date']), sub: 'In ${atf(x['in'])}${intv(x['out']) > 0 ? ' · Out ${atf(x['out'])}${ahr(x).isNotEmpty ? ' · ${ahr(x)}' : ''}' : ' · not checked out'}'),
      ]),
      if (S.isAdm) _register(p, sch),
    ]);
  }

  Widget _register(Pal p, bool sch) {
    return ListenableBuilder(
      listenable: D.on(['mem']),
      builder: (_, __) {
        final G = attGroups();
        final g = _g(G);
        final d0 = attDay != null && attDay!.compareTo(day) <= 0 ? attDay! : day;
        final kids = <Widget>[];
        if (g == null) {
          kids.add(Text('Nothing to show yet.', style: meta()));
        } else if (regLoading) {
          kids.add(const Skeleton(n: 1));
        } else if (regErr.isNotEmpty) {
          kids.add(Text(regErr, style: meta()));
        } else {
          final M = D['mem'].values.where((x) => x['status'] == 'approved' && g.f(x)).map((x) => <String, dynamic>{...x, 'uid': str(x['id'] ?? x['uid'])}).toList();
          final ids = M.map((x) => x['uid']).toSet();
          for (final x in reg.values) {
            if (!ids.contains(x['uid']) && D['mem'][x['uid']] == null && g.f(x)) M.add({...x, 'gone': 1});
          }
          M.sort((x, y) {
            final c = natCmp(str(x['flat']), str(y['flat']));
            return c != 0 ? c : str(x['name']).compareTo(str(y['name']));
          });
          final pres = M.where((x) => reg[x['uid']] != null).length;
          kids.add(Padding(padding: const EdgeInsets.only(bottom: 4), child: Text('${g.t} · $d0 · Present $pres of ${M.length}', style: meta())));
          if (M.isEmpty) kids.add(Empty('Nobody in ${g.t} yet.'));
          for (final x in M) {
            final rec = reg[x['uid']];
            final fl = str(x['flat']), i = fl.indexOf(' · ');
            final line = [g.k == '@T' ? fl : (i > 0 ? fl.substring(i + 3) : fl), rec != null ? ahr(rec) : 'Not checked in'].where((s) => s.isNotEmpty).join(' · ');
            Widget? act;
            if (sch && d0 == day && x['gone'] == null) {
              if (rec == null) {
                act = mini('Check in', () => _mark(x, 'in'), BtnKind.green);
              } else if (intv(rec['out']) == 0) {
                act = mini('Check out', () => _mark(x, 'out'));
              }
            }
            kids.add(Container(
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(border: Border(bottom: BorderSide(color: p.line.withOpacity(.7)))),
              child: Row(children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(str(x['name']).isEmpty ? 'Member' : str(x['name']), style: TextStyle(fontWeight: FontWeight.w600, color: p.text)),
                    Text(line, style: meta()),
                    const SizedBox(height: 4),
                    Wrap(spacing: 6, children: [
                      _tag('In ${atf(rec?['in'])}', intv(rec?['in']) > 0 ? p.green : null),
                      _tag('Out ${atf(rec?['out'])}', intv(rec?['out']) > 0 ? p.a : null),
                    ]),
                  ]),
                ),
                if (act != null) act,
              ]),
            ));
          }
          kids.add(Padding(padding: const EdgeInsets.only(top: 12), child: Btn.o('⬇️ Export CSV', small: true, onTap: () => attExport(context, g, d0))));
        }
        return AppCard(title: sch ? '📋 Attendance register' : '👥 ${S.K.person} attendance', children: [
          if (sch) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(S.isOwner ? 'Choose Teachers or a class to see everyone\'s check-in and check-out.' : 'Check-in and check-out of the students in your class.', style: meta())),
          Row2(
            SelectField('Group', g?.k, [for (final x in G) (x.k, x.l ?? x.t)], (v) {
              attGrp = v;
              _reg();
            }),
            DateField('Date', d0, (v) {
              attDay = v == day ? null : v;
              _reg();
            }, max: day),
          ),
          ...kids,
        ]);
      },
    );
  }

  Widget _tag(String t, Color? c) {
    final p = pal;
    return Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3), decoration: BoxDecoration(color: (c ?? p.muted).withOpacity(.12), borderRadius: BorderRadius.circular(8)), child: Text(t, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: c ?? p.muted)));
  }
}

void attExport(BuildContext context, AttGroup g, String d0) {
  sheet(context, (_) => _AttExport(g: g, d0: d0));
}

class _AttExport extends StatefulWidget {
  final AttGroup g;
  final String d0;
  const _AttExport({required this.g, required this.d0});
  @override
  State<_AttExport> createState() => _AttExportState();
}

class _AttExportState extends State<_AttExport> {
  late String f = widget.d0, t = widget.d0;
  void _set(DateTime a, DateTime b) {
    final n = DateTime.now();
    setState(() {
      f = ymd(a);
      t = ymd(b.isAfter(n) ? n : b);
    });
  }

  @override
  Widget build(BuildContext context) {
    final n = DateTime.now(), day = td();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      SheetTitle('⬇️ Export attendance', sub: '${widget.g.t} · choose the dates you want in the CSV file.'),
      Row2(DateField('From date', f, (v) => setState(() => f = v), max: day), DateField('To date', t, (v) => setState(() => t = v), max: day)),
      Chips([('t', 'Today'), ('7', 'Last 7 days'), ('m', 'This month'), ('l', 'Last month')], '', (k) {
        if (k == 't') _set(n, n);
        if (k == '7') _set(DateTime(n.year, n.month, n.day - 6), n);
        if (k == 'm') _set(DateTime(n.year, n.month, 1), n);
        if (k == 'l') _set(DateTime(n.year, n.month - 1, 1), DateTime(n.year, n.month, 0));
      }),
      Btn('⬇️ Export CSV', onTap: () async {
        if (f.isEmpty || t.isEmpty) {
          toast('⚠️', 'Choose both dates');
          return;
        }
        if (t.compareTo(f) < 0) {
          toast('⚠️', 'Check the dates', 'The To date is before the From date.');
          return;
        }
        final q = await col('attendance').where('date', isGreaterThanOrEqualTo: f).where('date', isLessThanOrEqualTo: t).get();
        final rows = q.docs.map((d) => d.data()).where((x) {
          final m = D['mem'][x['uid']];
          return widget.g.f(m != null && m['status'] == 'approved' ? m : x);
        }).toList()
          ..sort((x, y) {
            final c = str(x['date']).compareTo(str(y['date']));
            return c != 0 ? c : str(x['name']).compareTo(str(y['name']));
          });
        if (rows.isEmpty) {
          toast('ℹ️', 'Nothing to export', 'No check-ins for ${widget.g.t} in these dates.');
          return;
        }
        final K = S.K;
        final gl = K.grp != null ? K.grp!.one[0].toUpperCase() + K.grp!.one.substring(1) : 'Group';
        await exportCSV('attendance-${widget.g.t.replaceAll(RegExp(r'[^\w]+'), '-')}-${f == t ? f : '${f}_to_$t'}', ['Date', 'Name', gl, 'ID', 'Role', 'Check-in', 'Check-out', 'Hours'], [
          for (final x in rows)
            () {
              final m = D['mem'][x['uid']] ?? x;
              final fl = str(m['flat'] ?? x['flat']), i = fl.indexOf(' · ');
              return [x['date'], x['name'], i > 0 ? fl.substring(0, i) : fl, i > 0 ? fl.substring(i + 3) : '', S.roleLbl(m['role'] ?? x['role']), atf(x['in']), intv(x['out']) > 0 ? atf(x['out']) : '', ahr(x)];
            }()
        ], raw: true);
        toast('⬇️', 'Attendance exported', '${rows.length} row${rows.length == 1 ? '' : 's'} · ${f == t ? f : '$f → $t'}');
        if (context.mounted) Navigator.pop(context);
      }, busyDone: false),
    ]);
  }
}

