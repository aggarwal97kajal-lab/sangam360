import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../core/csv.dart';
import '../../core/files.dart';
import '../../core/fs.dart';
import '../../core/img.dart';
import '../../core/kinds.dart';
import '../../core/nav.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/anim.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/media.dart';
import '../../ui/pick.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import 'svc.dart';
import '../../l10n/l10n.dart';

const escH = 48;
bool isEsc(Doc c) => cst.indexOf(str(c['status'])) < 4 && now() - intv(c['ts']) > escH * 3600000;

class CompPage extends StatefulWidget {
  const CompPage({super.key});
  @override
  State<CompPage> createState() => _CompPageState();
}

class _CompPageState extends State<CompPage> {
  String? cat, sub, loc;
  String pri = 'Medium';
  final loc2 = TextEditingController(), desc = TextEditingController();
  String photo = '';

  Future<void> _photo() async {
    final f = await pickPhotoSheet(context);
    if (f == null) return;
    try {
      final b = await shrink(f.bytes, 900, .6);
      setState(() => photo = toDataUrl(b, 'image/jpeg'));
    } catch (e) {
      fail(e, tr('Could not read photo'));
    }
  }

  Future<void> _submit() async {
    if (cat == null || sub == null || loc == null) {
      toast('ℹ️', tr('Select category, sub-category and location'));
      return;
    }
    if (desc.text.trim().isEmpty) {
      toast('ℹ️', tr('Please describe the problem'));
      return;
    }
    final t0 = now();
    final b36 = t0.toRadixString(36);
    final cid = 'CMP-${b36.substring(b36.length - 5).toUpperCase()}${rid().substring(rid().length - 2).toUpperCase()}';
    await addDoc(col('complaints'), {
      'uid': S.uid,
      'name': S.me!['name'],
      'flat': S.me!['flat'],
      'category': cat,
      'sub': sub,
      'loc': loc! + (loc2.text.trim().isNotEmpty ? ' – ${loc2.text.trim()}' : ''),
      'cid': cid,
      'priority': pri,
      'title': '$sub · $loc',
      'desc': desc.text.trim(),
      'photo': photo,
      'status': 'Open',
      'note': '',
      'ts': t0,
      'history': [
        {'s': 'Open', 'ts': t0}
      ],
    });
    setState(() {
      cat = null;
      sub = null;
      loc = null;
      loc2.clear();
      desc.clear();
      photo = '';
    });
    fxDone(trf('Complaint {0} raised', [cid]), tr('Track it under your complaints below.'));
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    final tree = compTree(S.kind);
    return ListenableBuilder(
      listenable: D.on(['comp', 'mem', 'stf']),
      builder: (_, __) {
        final v = D['comp'].values.where((c) => S.isAdm || c['uid'] == S.uid).toList()..sort((a, b) => intv(b['ts']).compareTo(intv(a['ts'])));
        return svcBody([
          AppCard(title: 'Raise a complaint', children: [
            SelectField('Select category', cat, SelectField.same(tree.keys.toList()), (x) => setState(() {
                  cat = x;
                  sub = null;
                })),
            SelectField(cat == null ? 'Select sub-category' : 'Sub-category', sub, cat == null ? const [] : SelectField.same(tree[cat]!), cat == null ? null : (x) => setState(() => sub = x)),
            Row2(
              SelectField('Select location', loc, SelectField.same(compLoc[S.kind] ?? compLoc['society']!), (x) => setState(() => loc = x)),
              Field(loc2, 'Room / floor / bus no.', max: 40),
            ),
            Field(desc, 'Describe the problem…', lines: 3, max: 600),
            Row(children: [
              mini(tr('📷 Add photo'), _photo),
              const SizedBox(width: 10),
              if (photo.isNotEmpty) Text(tr('Photo added ✔'), style: meta(p.green)),
              if (photo.isNotEmpty) IconButton(onPressed: () => setState(() => photo = ''), icon: Icon(Icons.close_rounded, size: 18, color: p.muted)),
            ]),
            if (photo.isNotEmpty) PhotoThumb(photo, h: 140),
            const SizedBox(height: 12),
            SelectField('Priority', pri, SelectField.same(const ['Low', 'Medium', 'High']), (x) => setState(() => pri = x)),
            Btn(tr('Submit complaint'), onTap: _submit, busyDone: false),
          ]),
          if (v.isEmpty) const Empty('No complaints yet 🎉'),
          if (v.isNotEmpty && S.isAdm) _tools(v),
          for (final (i, c) in v.indexed) Enter(index: i, child: CompCard(c)),
        ]);
      },
    );
  }

  Widget _tools(List<Doc> v) {
    final n = v.where(isEsc).length;
    return AppCard(title: 'Complaint tools', children: [
      Text(n > 0 ? trf('🔥 {0} escalated (open for more than {1} hours)', [n, escH]) : tr('No escalated complaints'), style: meta()),
      const SizedBox(height: 10),
      Btn.o(tr('⬇️ Export complaints (CSV)'), small: true, onTap: () => exportCSV('complaints', const ['Date', 'Title', 'Category', 'Priority', 'Status', 'Flat', 'Resident', 'Assigned to', 'Escalated', 'Admin note'], [
            for (final x in v) [dtm(x['ts']), x['title'], x['category'], x['priority'], x['status'], x['flat'], x['name'], mapv(x['assignee'])['name'] ?? '', isEsc(x) ? 'Yes' : 'No', x['note'] ?? '']
          ])),
    ]);
  }
}

class CompCard extends StatelessWidget {
  final Doc c;
  const CompCard(this.c, {super.key});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    final i = cst.indexOf(str(c['status']));
    final tone = i >= 4
        ? Tone.g
        : i >= 1
            ? Tone.y
            : Tone.r;
    final ref = dref('complaints', str(c['id']));
    final H = listv(c['history']).isNotEmpty ? listv(c['history']).map(mapv).toList() : [<String, dynamic>{'s': 'Open', 'ts': c['ts']}];
    return Item(bar: toneColor(tone), children: [
      ItemHead(str(c['title']), badge: Pill(str(c['status']), tone: tone)),
      Steps(const ['Submitted', 'In Progress', 'Resolved'], i >= 4 ? 2 : i >= 2 ? 1 : 0, icons: const ['🟡', '🔵', '🟢']),
      Desc(str(c['desc']).isEmpty ? tr('No description') : str(c['desc'])),
      if (okImg(c['photo'])) PhotoThumb(str(c['photo'])),
      Meta(trf('{0}{1}{2}{3} · {4} priority · {5} ({6}) · {7}', [(str(c['cid']).isNotEmpty ? '${c['cid']} · ' : ''), str(c['category']), (str(c['sub']).isNotEmpty ? ' › ${c['sub']}' : ''), (str(c['loc']).isNotEmpty ? ' · 📍 ${c['loc']}' : ''), str(c['priority']), str(c['name']), str(c['flat']), dt(c['ts'])])),
      if (str(c['note']).isNotEmpty) Note(trf('💬 Admin: {0}', [c['note']])),
      if (c['assignee'] != null) Meta(trf('👷 Assigned to {0}', [str(mapv(c['assignee'])['name'])])),
      if (isEsc(c))
        Container(
          margin: const EdgeInsets.only(top: 8),
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          decoration: BoxDecoration(color: p.red, borderRadius: BorderRadius.circular(12)),
          child: Text(trf('🔥 Escalated — still open after {0} days', [((now() - intv(c['ts'])) / dayMs).floor().clamp(2, 100000)]), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
        ),
      const SizedBox(height: 8),
      for (final (k, h) in H.indexed)
        Padding(
          padding: const EdgeInsets.only(bottom: 4),
          child: Row(children: [
            Container(width: 10, height: 10, decoration: BoxDecoration(color: k == H.length - 1 ? p.a : p.line, shape: BoxShape.circle)),
            const SizedBox(width: 10),
            Expanded(child: Text(h['s'] == 'Open' ? tr('Submitted') : str(h['s']), style: TextStyle(fontSize: 13, fontWeight: k == H.length - 1 ? FontWeight.w700 : FontWeight.w500, color: p.text))),
            Text(dt(h['ts']), style: small()),
          ]),
        ),
      if (S.isAdm) ActRow([mini(tr('Update status'), () => _update(context, ref)), mini(tr('👷 Assign'), () => _assign(context, ref)), mini(tr('🗑 Delete'), () => _del(context, ref), BtnKind.red)]),
    ]);
  }

  Future<void> _update(BuildContext context, DocRef ref) async {
    await sheet(context, (ctx) => _UpdateSheet(c: c, ref: ref));
  }

  Future<void> _assign(BuildContext context, DocRef ref) async {
    final stf = [
      ...D['mem'].values.where((x) => x['status'] == 'approved' && const ['STAFF', 'SECURITY_GUARD', 'COMMITTEE_MEMBER', 'ACCOUNTANT'].contains(x['role'])).map((x) => {'id': str(x['id'] ?? x['uid']), 'name': str(x['name']), 'role': str(x['role'])}),
      ...D['stf'].values.map((x) => {'id': 'stf:${x['id']}', 'name': str(x['name']), 'role': str(x['role']).isEmpty ? 'Staff' : str(x['role'])}),
    ];
    if (stf.isEmpty) {
      if (S.isMgr) {
        final go = await confirmDlg(context, tr('No staff yet. Open People & set roles?'), ok: tr('👥 Open People'));
        if (go) nav.go('more');
      } else {
        toast('ℹ️', tr('No staff yet'));
      }
      return;
    }
    final id = await pickFromList(context, tr('Assign to staff'), [for (final x in stf) (x['id']!, '${x['name']} (${x['role']!.replaceFirst('_', ' ').toLowerCase()})')], str(mapv(c['assignee'])['uid']));
    if (id == null) return;
    final m = stf.firstWhere((x) => x['id'] == id);
    final ns = c['status'] == 'Open' ? 'Assigned' : str(c['status']);
    try {
      await updateDoc(ref, {
        'assignee': {'uid': id, 'name': m['name']},
        'status': ns,
        'history': FieldValue.arrayUnion([
          {'s': ns == 'Assigned' ? 'Assigned to ${m['name']}' : ns, 'ts': now()}
        ]),
      });
      toast('✅', trf('Assigned to {0}', [m['name']]));
    } catch (e) {
      fail(e);
    }
  }

  Future<void> _del(BuildContext context, DocRef ref) async {
    if (!await confirmDlg(context, tr('Delete this complaint permanently?'), ok: tr('Delete'), danger: true)) return;
    await ref.delete();
    toast('🗑️', tr('Complaint deleted'));
  }
}

class _UpdateSheet extends StatefulWidget {
  final Doc c;
  final DocRef ref;
  const _UpdateSheet({required this.c, required this.ref});
  @override
  State<_UpdateSheet> createState() => _UpdateSheetState();
}

class _UpdateSheetState extends State<_UpdateSheet> {
  late String st = cst.contains(widget.c['status']) ? str(widget.c['status']) : 'Open';
  late final n = TextEditingController(text: str(widget.c['note']));
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        SheetTitle('Update complaint', sub: str(widget.c['title'])),
        SelectField('Status', st, SelectField.same(cst), (v) => setState(() => st = v)),
        Field(n, 'Public response…', lines: 2, max: 300),
        Btn(tr('Update'), onTap: () async {
          await updateDoc(widget.ref, {
            'status': st,
            'note': n.text.trim(),
            'history': FieldValue.arrayUnion([
              {'s': st, 'ts': now()}
            ]),
          });
          if (context.mounted) Navigator.pop(context);
        }),
      ]);
}
