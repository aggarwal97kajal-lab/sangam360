import 'package:flutter/material.dart';

import '../../core/files.dart';
import '../../core/fs.dart';
import '../../core/img.dart';
import '../../core/kinds.dart';
import '../../core/plan.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/anim.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/media.dart';
import '../../ui/pick.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import 'svc.dart';

/* ============================== parcels ============================== */
class DelPage extends StatefulWidget {
  const DelPage({super.key});
  @override
  State<DelPage> createState() => _DelPageState();
}

class _DelPageState extends State<DelPage> {
  String dc = couriers.first;
  final dco = TextEditingController(), dr = TextEditingController();
  String? df;
  String photo = '';

  Future<void> _save() async {
    final cr = dc == 'Other' ? (dco.text.trim().isEmpty ? 'Other' : dco.text.trim()) : dc;
    final fl = flats();
    await addDoc(col('deliveries'), {'uid': S.uid, 'by': S.me!['name'], 'courier': cr, 'flat': df ?? (fl.isEmpty ? '' : fl.first), 'recipient': dr.text.trim(), 'photo': photo, 'status': 'Received', 'ts': now()});
    setState(() {
      photo = '';
      dr.clear();
    });
    toast('✅', 'Saved', 'Resident notified');
  }

  @override
  Widget build(BuildContext context) {
    final fl = flats();
    return ListenableBuilder(
      listenable: D.on(['del']),
      builder: (_, __) {
        final v = (D['del'].values.toList()..sort((a, b) => intv(b['ts']).compareTo(intv(a['ts'])))).take(60).toList();
        return svcBody([
          if (S.staff)
            AppCard(title: '📦 Record a parcel', children: [
              Row2(SelectField('Courier', dc, SelectField.same(couriers), (x) => setState(() => dc = x)), dc == 'Other' ? Field(dco, 'Courier name', max: 30) : const SizedBox()),
              SelectField(S.sk('Flat'), df ?? (fl.isEmpty ? null : fl.first), SelectField.same(fl), (x) => setState(() => df = x)),
              Field(dr, 'Recipient name (optional)', max: 40),
              Row(children: [
                mini('📷 Parcel photo', () async {
                  final f = await pickCamera();
                  if (f == null) return;
                  try {
                    final b = await shrink(f.bytes, 800, .55);
                    setState(() => photo = toDataUrl(b, 'image/jpeg'));
                  } catch (e) {
                    fail(e, 'Could not read photo');
                  }
                }),
                const SizedBox(width: 10),
                if (photo.isNotEmpty) Text('Photo added ✔', style: meta(pal.green)),
              ]),
              const SizedBox(height: 12),
              Btn(S.sk('Save & notify resident'), onTap: _save, busyDone: false),
            ]),
          if (v.isEmpty) const Empty('No parcels yet 📦'),
          for (final (i, p) in v.indexed) Enter(index: i, child: _card(context, p)),
        ]);
      },
    );
  }

  Widget _card(BuildContext context, Doc p) {
    final rec = p['status'] == 'Received';
    return Item(bar: toneColor(rec ? Tone.y : Tone.g), children: [
      ItemHead('📦 ${str(p['courier'])}', badge: Pill(str(p['status']), tone: p['status'] == 'Collected' ? Tone.g : Tone.y)),
      Meta('${str(p['flat'])}${str(p['recipient']).isNotEmpty ? ' · For ${p['recipient']}' : ''} · ${dt(p['ts'])} ${tm(p['ts'])}${p['collectedTs'] != null ? ' · Collected ${tm(p['collectedTs'])}' : ''}'),
      Steps(const ['Arrived', 'Security', 'Resident', 'Delivered'], p['status'] == 'Collected' ? 3 : 1, icons: const ['📦', '🏢', '🏠', '✓']),
      if (okImg(p['photo'])) PhotoThumb(str(p['photo'])),
      ActRow([
        if (rec)
          mini('Mark collected', () async {
            await updateDoc(dref('deliveries', str(p['id'])), {'status': 'Collected', 'collectedTs': now()});
            fxDone('Delivered', 'Parcel collected ✓', false, 1600);
          }, BtnKind.green),
        if (S.isAdm)
          mini('🗑 Delete parcel', () async {
            if (!await confirmDlg(context, 'Delete this parcel record permanently?', ok: 'Delete', danger: true)) return;
            await dref('deliveries', str(p['id'])).delete();
            rmFile(p['photo']);
            toast('🗑️', 'Parcel deleted');
          }, BtnKind.red),
      ]),
    ]);
  }
}

/* ============================== vehicles ============================== */
/// Only an admin adds a vehicle, for a resident chosen here. The vehicle carries that resident's uid, so it shows in their own app.
List<Doc> vehOwners() {
  final l = D['mem'].values.where((x) => x['status'] == 'approved' && str(x['flat']).isNotEmpty && !const ['SECURITY_GUARD', 'STAFF'].contains(x['role'])).toList();
  l.sort((a, b) {
    final c = natCmp(str(a['flat']), str(b['flat']));
    return c != 0 ? c : str(a['name']).compareTo(str(b['name']));
  });
  return l;
}

class VehPage extends StatefulWidget {
  const VehPage({super.key});
  @override
  State<VehPage> createState() => _VehPageState();
}

class _VehPageState extends State<VehPage> {
  String? vrs;
  final ven = TextEditingController(), vem = TextEditingController(), vec = TextEditingController(), vsr = TextEditingController();
  String vet = 'Car';

  Future<void> _add() async {
    if (!S.isAdm) {
      toast('ℹ️', 'Only an admin can add vehicles');
      return;
    }
    final res = D['mem'][vrs];
    if (res == null) {
      toast('ℹ️', S.sk('Select a flat / resident'), 'Choose whose vehicle this is.');
      return;
    }
    final n = nv(ven.text);
    if (n.length < 4) {
      toast('ℹ️', 'Enter a valid vehicle number');
      return;
    }
    final dup = D['veh'].values.where((x) => x['number'] == n).firstOrNull;
    if (dup != null && !await confirmDlg(context, '$n is already added for ${str(dup['owner']).isEmpty ? 'someone' : str(dup['owner'])} (${str(dup['flat'])}). Add it again?', ok: 'Add again')) return;
    await addDoc(col('vehicles'), {'uid': str(res['id'] ?? res['uid']), 'flat': res['flat'], 'owner': str(res['name']), 'number': n, 'type': vet, 'model': vem.text.trim(), 'color': vec.text.trim(), 'ts': now(), 'by': S.uid, 'byName': S.me!['name']});
    setState(() {
      ven.clear();
      vem.clear();
      vec.clear();
      vrs = null;
    });
    toast('✅', 'Vehicle added', '$n · ${str(res['flat'])} — ${str(res['name'])}');
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: D.on(['veh', 'park', 'mem']),
      builder: (_, __) {
        var v = D['veh'].values.toList()..sort((a, b) => intv(b['ts']).compareTo(intv(a['ts'])));
        final q = nv(vsr.text);
        if (S.staff && q.isNotEmpty) v = v.where((x) => str(x['number']).contains(q)).toList();
        v = v.take(60).toList();
        return svcBody([
          if (S.isAdm)
            AppCard(title: '🚗 Add a vehicle', children: [
              Text(S.sk('Only admins add vehicles. Choose the resident it belongs to; they see it in their app.'), style: meta()),
              const SizedBox(height: 10),
              SelectField(S.sk('— Select flat / resident —'), vrs, [for (final x in vehOwners()) (str(x['id'] ?? x['uid']), '${str(x['flat'])} — ${str(x['name'])}')], (x) => setState(() => vrs = x)),
              Row2(Field(ven, 'Number e.g. DL1CAB1234', max: 14, upper: true), SelectField('Type', vet, SelectField.same(const ['Car', 'Bike', 'Scooter', 'Other']), (x) => setState(() => vet = x))),
              Row2(Field(vem, 'Model', max: 30), Field(vec, 'Colour', max: 20)),
              Btn('Add vehicle', onTap: _add, busyDone: false),
            ]),
          if (S.staff) Field(vsr, '🔍 Search by vehicle number…', max: 14, upper: true, onChanged: (_) => setState(() {})),
          if (v.isEmpty) ...[
            Empty(S.staff && q.isNotEmpty
                ? 'No vehicle matches.'
                : S.staff
                    ? 'No vehicles added yet'
                    : 'No vehicle added for you yet', icon: '🚗'),
            if (!S.staff) Text(S.sk('Vehicles are added by your society admin. Ask them to add yours; it shows here as soon as it is added.'), style: meta()),
          ],
          for (final (i, x) in v.indexed)
            Enter(
              index: i,
              child: Builder(builder: (_) {
                final slot = D['park'].values.where((p) => p['vehicleNo'] == x['number'] || (p['flat'] == x['flat'] && p['kind'] == 'Resident' && str(p['vehicleNo']).isEmpty)).firstOrNull;
                final mc = [str(x['model']), str(x['color'])].where((s) => s.isNotEmpty).join(' · ');
                return Item(bar: pal.a, children: [
                  ItemHead('${x['type'] == 'Car' ? '🚗 ' : x['type'] == 'Bike' || x['type'] == 'Scooter' ? '🏍️ ' : '🚙 '}${str(x['number'])}', badge: Pill(str(x['type']))),
                  Meta('$mc${mc.isNotEmpty ? ' · ' : ''}Owner: ${str(x['owner'])} (${str(x['flat'])})${slot != null ? ' · Slot ${slot['slot']}' : ''}'),
                  if (str(x['byName']).isNotEmpty && S.isAdm) Meta('Added by ${x['byName']} · ${dt(x['ts'])}'),
                  if (S.isAdm)
                    ActRow([
                      mini('Remove', () async {
                        if (!await confirmDlg(context, 'Remove this vehicle?', ok: 'Remove', danger: true)) return;
                        await dref('vehicles', str(x['id'])).delete();
                      }, BtnKind.red)
                    ]),
                ]);
              }),
            ),
        ]);
      },
    );
  }
}

/* ============================== parking ============================== */
class ParkPage extends StatefulWidget {
  const ParkPage({super.key});
  @override
  State<ParkPage> createState() => _ParkPageState();
}

class _ParkPageState extends State<ParkPage> {
  final pn = TextEditingController();
  String pk = 'Resident';

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: D.on(['park']),
      builder: (_, __) {
        var v = D['park'].values.toList()..sort((a, b) => natCmp(str(a['slot']), str(b['slot'])));
        if (!S.isAdm) v = v.where((p) => p['flat'] == S.me?['flat']).toList();
        return svcBody([
          if (S.isAdm)
            AppCard(title: '🅿️ Add parking slot', children: [
              Row2(Field(pn, 'Slot e.g. P-01', max: 12, upper: true), SelectField('Kind', pk, SelectField.same(const ['Resident', 'Visitor']), (x) => setState(() => pk = x))),
              Btn('Add slot', onTap: () async {
                final n = pn.text.trim();
                if (n.isEmpty) return;
                await addDoc(col('parking'), {'slot': n, 'kind': pk, 'flat': '', 'vehicleNo': '', 'ts': now()});
                pn.clear();
              }),
            ]),
          if (v.isEmpty) Empty(S.isAdm ? 'No parking slots yet. Add one above.' : 'No parking slot is assigned to your flat yet.', icon: '🅿️'),
          for (final (i, p) in v.indexed)
            Enter(
              index: i,
              child: Item(bar: str(p['flat']).isNotEmpty ? pal.green : pal.faint, children: [
                ItemHead('🅿️ ${str(p['slot'])}', badge: Pill(str(p['flat']).isNotEmpty ? 'Assigned' : 'Free', tone: str(p['flat']).isNotEmpty ? Tone.g : Tone.a)),
                Meta('${str(p['kind'])} parking${str(p['flat']).isNotEmpty ? ' · ${p['flat']}' : ''}${str(p['vehicleNo']).isNotEmpty ? ' · ${p['vehicleNo']}' : ''}'),
                if (S.isAdm) ActRow([mini('Assign', () => sheet(context, (_) => _ParkSheet(p))), mini('Delete slot', () async {
                      if (!await confirmDlg(context, 'Delete this slot?', ok: 'Delete', danger: true)) return;
                      await dref('parking', str(p['id'])).delete();
                    }, BtnKind.red)]),
              ]),
            ),
        ]);
      },
    );
  }
}

class _ParkSheet extends StatefulWidget {
  final Doc p;
  const _ParkSheet(this.p);
  @override
  State<_ParkSheet> createState() => _ParkSheetState();
}

class _ParkSheetState extends State<_ParkSheet> {
  late String fl = str(widget.p['flat']).isEmpty ? '' : str(widget.p['flat']);
  late final vi = TextEditingController(text: str(widget.p['vehicleNo']));
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        SheetTitle('🅿️ ${str(widget.p['slot'])}'),
        SelectField(S.sk('Flat'), fl, [('', '— Unassigned —'), ...SelectField.same(flats())], (x) => setState(() => fl = x)),
        Field(vi, 'Vehicle number (optional)', max: 14, upper: true),
        Btn('Save', onTap: () async {
          await updateDoc(dref('parking', str(widget.p['id'])), {'flat': fl, 'vehicleNo': nv(vi.text)});
          if (context.mounted) Navigator.pop(context);
        }),
      ]);
}
