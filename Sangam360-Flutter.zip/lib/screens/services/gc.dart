import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../core/fs.dart';
import '../../core/kinds.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/anim.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import 'svc.dart';

/// Conduct (schools) / Grievances (companies): a concern about a person, seen only by the Principal / main admin
class GcPage extends StatefulWidget {
  const GcPage({super.key});
  @override
  State<GcPage> createState() => _GcPageState();
}

class _GcPageState extends State<GcPage> {
  static String gcf = 'all';
  String? sel;
  final ti = TextEditingController(), tx = TextEditingController();

  bool get sch => S.kind == 'school';
  String get tn => sch ? 'teacher' : 'manager';
  String get pn => sch ? 'student' : 'employee';
  String lab(dynamic r) => r == 'SOCIETY_ADMIN'
      ? (sch ? 'Principal' : 'Admin')
      : r == 'COMMITTEE_MEMBER'
          ? (sch ? 'Teacher' : 'Manager')
          : (sch ? 'Student' : 'Employee');

  List<Doc> _people() {
    final me = S.role;
    final l = D['dir'].values.where((p) {
      final u = str(p['uid'] ?? p['id']);
      if (u.isEmpty || u == S.uid) return false;
      if (p['role'] == 'SOCIETY_ADMIN') return false;
      return me == 'COMMITTEE_MEMBER' ? p['role'] != 'COMMITTEE_MEMBER' : p['role'] == 'COMMITTEE_MEMBER';
    }).toList()
      ..sort((x, y) => str(x['name']).compareTo(str(y['name'])));
    return l;
  }

  Future<void> _send(List<Doc> people) async {
    final aT = S.role == 'COMMITTEE_MEMBER' ? pn : tn;
    final t = ti.text.trim(), x = tx.text.trim();
    if (sel == null) {
      toast('⚠️', 'Choose a person', 'Select the $aT this is about.');
      return;
    }
    if (t.isEmpty || x.length < 10) {
      toast('⚠️', 'Add details', 'Write a title and at least a few words about what happened.');
      return;
    }
    final pp = people.firstWhere((q) => str(q['uid'] ?? q['id']) == sel, orElse: () => {});
    final ts = now();
    final anon = sch && S.isStu(S.me);
    await addDoc(col('gcomplaints'), {
      'uid': S.uid,
      'name': anon ? 'Anonymous student' : S.me!['name'],
      'role': S.role,
      'flat': anon ? '' : str(S.me!['flat']),
      if (anon) 'anon': true,
      'againstUid': sel,
      'againstName': str(pp['name']).isEmpty ? 'Member' : str(pp['name']),
      'againstRole': str(pp['role']),
      'againstFlat': str(pp['flat']),
      'title': t,
      'text': x,
      'status': 'Open',
      'ts': ts,
      'history': [
        {'s': 'Open', 'ts': ts}
      ],
    });
    setState(() {
      ti.clear();
      tx.clear();
      sel = null;
    });
    toast('✅', 'Sent', 'The ${sch ? 'principal' : 'admin'} will review it.');
  }

  @override
  Widget build(BuildContext context) {
    final owner = S.isOwner;
    return ListenableBuilder(
      listenable: D.on(['gc', 'dir']),
      builder: (_, __) {
        final L = D['gc'].values.toList()..sort((a, c) => intv(c['ts']).compareTo(intv(a['ts'])));
        final fv = owner ? gcf : 'all';
        final V = L.where((x) => fv == 'all' || (fv == 'T' && x['againstRole'] == 'COMMITTEE_MEMBER') || (fv == 'P' && x['againstRole'] != 'COMMITTEE_MEMBER') || (fv == 'open' && x['status'] != 'Resolved' && x['status'] != 'Dismissed')).toList();
        final people = _people();
        final aT = S.role == 'COMMITTEE_MEMBER' ? pn : tn;
        return svcBody([
          if (!owner)
            AppCard(title: '📣 Raise a concern about a $aT', children: [
              Text('Only the ${sch ? 'principal' : 'admin'} can see this. It is not shown to anyone else.', style: meta()),
              const SizedBox(height: 10),
              SelectField('Select a $aT', sel, [for (final p in people) (str(p['uid'] ?? p['id']), '${str(p['name']).isEmpty ? 'Member' : str(p['name'])}${str(p['flat']).isNotEmpty ? ' · ${p['flat']}' : ''}')], (v) => setState(() => sel = v)),
              Field(ti, 'Short title', max: 80),
              Field(tx, 'What happened? Please be specific and factual.', lines: 4, max: 600),
              Btn('Send to the ${sch ? 'principal' : 'admin'}', onTap: () => _send(people), busyDone: false),
            ]),
          AppCard(title: owner ? '📋 All complaints (${L.length})' : '🗂️ Your complaints (${L.length})', children: [
            if (owner) Chips([('all', 'All'), ('T', 'About ${tn}s'), ('P', 'About ${pn}s'), ('open', 'Still open')], gcf, (v) => setState(() => gcf = v)),
            if (V.isEmpty) Empty(owner ? 'Nothing here' : 'You have not raised any complaints'),
            for (final (i, x) in V.indexed)
              Enter(
                index: i,
                child: Builder(builder: (_) {
                  final st = str(x['status']).isEmpty ? 'Open' : str(x['status']);
                  return Item(bar: toneColor(st == 'Resolved' ? Tone.g : st == 'Open' ? Tone.r : Tone.y), children: [
                    ItemHead(str(x['title']), badge: Pill(st, tone: st == 'Resolved' ? Tone.g : st == 'Open' ? Tone.r : Tone.y)),
                    Meta('${owner ? (x['anon'] == true ? 'Anonymous student → ' : '${str(x['name'])} (${lab(x['role'])}${str(x['flat']).isNotEmpty ? ' · ${x['flat']}' : ''}) → ') : 'About '}${str(x['againstName'])} (${lab(x['againstRole'])}${str(x['againstFlat']).isNotEmpty ? ' · ${x['againstFlat']}' : ''}) · ${dt(x['ts'])}'),
                    Desc(str(x['text'])),
                    if (str(x['note']).isNotEmpty) Note('💬 ${sch ? 'Principal' : 'Admin'}: ${x['note']}'),
                    if (owner)
                      ActRow([
                        mini('Update', () => sheet(context, (_) => _GcUpd(x))),
                        mini('Delete', () async {
                          if (!await confirmDlg(context, 'Delete this complaint?', ok: 'Delete', danger: true)) return;
                          await dref('gcomplaints', str(x['id'])).delete();
                        }),
                      ]),
                  ]);
                }),
              ),
          ]),
        ]);
      },
    );
  }
}

class _GcUpd extends StatefulWidget {
  final Doc x;
  const _GcUpd(this.x);
  @override
  State<_GcUpd> createState() => _GcUpdState();
}

class _GcUpdState extends State<_GcUpd> {
  late String st = gcs.contains(widget.x['status']) ? str(widget.x['status']) : 'Open';
  late final n = TextEditingController(text: str(widget.x['note']));
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        SheetTitle('Update', sub: str(widget.x['title'])),
        SelectField('Status', st, SelectField.same(gcs), (v) => setState(() => st = v)),
        Field(n, 'Note for the record…', lines: 2, max: 300),
        Btn('Update', onTap: () async {
          await updateDoc(dref('gcomplaints', str(widget.x['id'])), {
            'status': st,
            'note': n.text.trim(),
            'history': FieldValue.arrayUnion([
              {'s': st, 'ts': now()}
            ]),
          });
          if (context.mounted) Navigator.pop(context);
        }),
      ]);
}
