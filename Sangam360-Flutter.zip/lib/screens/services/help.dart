import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../core/files.dart';
import '../../core/fs.dart';
import '../../core/img.dart';
import '../../core/kinds.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/anim.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/media.dart';
import '../../ui/pick.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import 'gate.dart';
import 'svc.dart';
import '../../l10n/l10n.dart';

String dk(DateTime d) => 'd${d.year}${p2(d.month)}${p2(d.day)}';
List<Doc> hToday(Doc h) => listv(mapv(h['att'])[dk(DateTime.now())]).map(mapv).toList();
bool hInside(Doc h) {
  final a = hToday(h);
  return a.isNotEmpty && a.last['out'] == null;
}

Future<void> hMark(Doc h, bool inn) async {
  final k = dk(DateTime.now());
  final a = hToday(h).map((x) => {...x}).toList();
  if (inn) {
    if (hInside(h)) return;
    a.add({'in': now(), 'by': S.me!['name']});
  } else {
    if (a.isEmpty || a.last['out'] != null) return;
    a.last['out'] = now();
  }
  await updateDoc(dref('helpers', str(h['id'])), {'att.$k': a});
}

class HelpPage extends StatefulWidget {
  const HelpPage({super.key});
  @override
  State<HelpPage> createState() => _HelpPageState();
}

class _HelpPageState extends State<HelpPage> {
  String? rsel;
  final n = TextEditingController(), mo = TextEditingController(), q = TextEditingController();
  String t = hTypes.first;
  PFile? ph;
  String? open;
  DateTime mon = DateTime(DateTime.now().year, DateTime.now().month, 1);

  Future<void> _add() async {
    final res = D['mem'][rsel];
    if (res == null) {
      toast('ℹ️', S.sk('Select a flat'), S.sk('Choose which flat this domestic help belongs to.'));
      return;
    }
    if (n.text.trim().isEmpty) {
      toast('ℹ️', tr('Enter a name'));
      return;
    }
    var p = '';
    if (ph != null) p = await up(await shrink(ph!.bytes, 480, .8, sq: true), 'helpers', 'h.jpg');
    await addDoc(col('helpers'), {'uid': str(res['id'] ?? res['uid']), 'flat': res['flat'], 'residentName': res['name'], 'name': n.text.trim(), 'type': t, 'mobile': mo.text.trim(), 'photo': p, 'rating': 0, 'att': {}, 'ts': now()});
    setState(() {
      n.clear();
      mo.clear();
      ph = null;
      rsel = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    return ListenableBuilder(
      listenable: D.on(['help', 'mem']),
      builder: (_, __) {
        final qq = S.staff ? q.text.trim().toLowerCase() : '';
        final v = D['help'].values.where((h) => qq.isEmpty || '${h['name']} ${h['flat']} ${h['type']}'.toLowerCase().contains(qq)).toList()
          ..sort((a, b) {
            final c = natCmp(str(a['flat']), str(b['flat']));
            return c != 0 ? c : str(a['name']).compareTo(str(b['name']));
          });
        return svcBody([
          if (S.isAdm)
            AppCard(title: '🧹 Add domestic help', children: [
              Text(S.sk('Only admins can add domestic help. Choose the flat it belongs to.'), style: meta()),
              const SizedBox(height: 10),
              SelectField(S.sk('— Select flat / resident —'), rsel, [for (final x in vehOwners()) (str(x['id'] ?? x['uid']), '${str(x['flat'])} — ${str(x['name'])}')], (x) => setState(() => rsel = x)),
              Field(n, 'Name', max: 40, kb: TextInputType.name),
              SelectField('Type', t, SelectField.same(hTypes), (x) => setState(() => t = x)),
              Field(mo, 'Mobile number', max: 15, kb: TextInputType.phone),
              Row(children: [
                mini(ph == null ? tr('📷 Photo (optional)') : '✓ ${cut(ph!.name, 22)}', () async {
                  final f = await pickPhotoSheet(context);
                  if (f != null) setState(() => ph = f);
                }),
              ]),
              const SizedBox(height: 12),
              Btn(tr('Add'), onTap: _add, busyDone: false),
            ]),
          if (S.staff) Field(q, '🔍 Search by name or flat', onChanged: (_) => setState(() {})),
          if (v.isEmpty) Empty(S.staff ? 'No domestic help registered' : 'No domestic help registered for your flat. Please ask the admin to add.', icon: '🧹'),
          for (final (i, h) in v.indexed)
            Enter(
              index: i,
              child: Builder(builder: (_) {
                final ins = hInside(h);
                final own = h['uid'] == S.uid;
                return Item(bar: ins ? p.green : p.faint, children: [
                  Row(children: [
                    Av(str(h['name']), str(h['photo']), size: 46),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(str(h['name']), style: h3()),
                        Text('${str(h['type'])} · ${str(h['flat'])}${str(h['mobile']).isNotEmpty ? ' · ${h['mobile']}' : ''}', style: meta()),
                        Text(ins ? trf('🟢 Inside since {0}', [tm(hToday(h).last['in'])]) : tr('⚪ Not in'), style: meta()),
                      ]),
                    ),
                  ]),
                  const SizedBox(height: 6),
                  Row(children: [
                    for (var s = 1; s <= 5; s++)
                      GestureDetector(
                        onTap: own ? () => updateDoc(dref('helpers', str(h['id'])), {'rating': s, 'ratedAt': now()}).catchError((x) => fail(x, tr('Could not save rating'))) : null,
                        child: Padding(padding: const EdgeInsets.only(right: 2), child: Text('★', style: TextStyle(fontSize: 22, color: intv(h['rating']) >= s ? p.amber : p.line))),
                      ),
                    if (own) Text(tr('  Tap to rate'), style: meta()),
                  ]),
                  ActRow([
                    if (S.staff) mini(ins ? tr('Mark OUT') : tr('Mark IN'), () => hMark(h, !ins), ins ? BtnKind.red : BtnKind.green),
                    mini(open == h['id'] ? tr('Hide attendance') : tr('📅 Attendance'), () => setState(() => open = open == h['id'] ? null : str(h['id']))),
                    if (S.isAdm)
                      mini(tr('Remove'), () async {
                        if (!await confirmDlg(context, trf('Remove {0}?', [str(h['name'])]), ok: tr('Remove'), danger: true)) return;
                        await dref('helpers', str(h['id'])).delete();
                        rmFile(h['photo']);
                      }, BtnKind.red),
                  ]),
                  if (open == h['id']) _cal(h),
                ]);
              }),
            ),
        ]);
      },
    );
  }

  Widget _cal(Doc h) {
    final p = pal;
    final y = mon.year, mo0 = mon.month;
    final first = DateTime(y, mo0, 1).weekday % 7, dim = DateTime(y, mo0 + 1, 0).day;
    var cnt = 0;
    final att = mapv(h['att']);
    final cells = <Widget>[for (final x in 'SMTWTFS'.split('')) Center(child: Text(x, style: small().copyWith(fontWeight: FontWeight.w800)))];
    for (var i = 0; i < first; i++) {
      cells.add(const SizedBox());
    }
    for (var d = 1; d <= dim; d++) {
      final a = listv(att['d$y${p2(mo0)}${p2(d)}']).map(mapv).toList();
      final on = a.isNotEmpty;
      if (on) cnt++;
      cells.add(Tooltip(
        message: a.map((x) => tm(x['in']) + (x['out'] != null ? ' – ${tm(x['out'])}' : '')).join(', '),
        child: Container(
          margin: const EdgeInsets.all(2),
          decoration: BoxDecoration(color: on ? p.green : p.card2, borderRadius: BorderRadius.circular(8)),
          alignment: Alignment.center,
          child: Text('$d', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: on ? Colors.white : p.text)),
        ),
      ));
    }
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Column(children: [
        Row(children: [
          IconBtn(Icons.chevron_left_rounded, size: 36, onTap: () => setState(() => mon = DateTime(y, mo0 - 1, 1))),
          Expanded(child: Text(DateFormat('MMMM yyyy').format(mon), textAlign: TextAlign.center, style: h3())),
          IconBtn(Icons.chevron_right_rounded, size: 36, onTap: () => setState(() => mon = DateTime(y, mo0 + 1, 1))),
        ]),
        const SizedBox(height: 8),
        GridView.count(crossAxisCount: 7, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), childAspectRatio: 1.1, children: cells),
        Padding(padding: const EdgeInsets.only(top: 6), child: Text(trf('Present {0} day{1} this month', [cnt, (cnt == 1 ? '' : 's')]), style: meta())),
      ]),
    );
  }
}
