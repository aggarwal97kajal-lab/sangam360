import 'package:flutter/material.dart';

import '../../core/files.dart';
import '../../core/fs.dart';
import '../../core/img.dart';
import '../../core/kinds.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/anim.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/media.dart';
import '../../ui/pick.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import '../comm/chat_ctl.dart';
import 'svc.dart';
import '../../l10n/l10n.dart';

class MktPage extends StatefulWidget {
  const MktPage({super.key});
  @override
  State<MktPage> createState() => _MktPageState();
}

class _MktPageState extends State<MktPage> {
  static String fil = 'All';
  String t = mktTypes.first;
  final ti = TextEditingController(), pr = TextEditingController(), ds = TextEditingController();
  PFile? ph;

  Future<void> _post() async {
    if (ti.text.trim().isEmpty) {
      toast('ℹ️', tr('Enter a title'));
      return;
    }
    var p = '';
    if (ph != null) p = await up(await shrink(ph!.bytes, 900, .8), 'classifieds', 'c.jpg');
    await addDoc(col('classifieds'), {'uid': S.uid, 'name': S.me!['name'], 'flat': S.me!['flat'], 'type': t, 'title': ti.text.trim(), 'desc': ds.text.trim(), 'price': t == 'Give away' ? 0 : (num.tryParse(pr.text) ?? 0), 'photo': p, 'status': 'Active', 'ts': now()});
    setState(() {
      ti.clear();
      pr.clear();
      ds.clear();
      ph = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    return ListenableBuilder(
      listenable: D.on(['cls']),
      builder: (_, __) {
        final v = D['cls'].values.where((c) => fil == 'All' || c['type'] == fil).toList()
          ..sort((a, b) {
            final c = (a['status'] == 'Closed' ? 1 : 0) - (b['status'] == 'Closed' ? 1 : 0);
            return c != 0 ? c : intv(b['ts']).compareTo(intv(a['ts']));
          });
        return svcBody([
          AppCard(title: '🛍️ Post a classified', children: [
            SelectField('Type', t, SelectField.same(mktTypes), (x) => setState(() => t = x)),
            Field(ti, 'What is it? e.g. Study table', max: 60),
            if (t != 'Give away') Field(pr, 'Price ₹', kb: TextInputType.number),
            Field(ds, 'Details…', lines: 3, max: 400),
            Row(children: [
              mini(ph == null ? tr('📷 Add photo') : '✓ ${cut(ph!.name, 22)}', () async {
                final f = await pickPhotoSheet(context);
                if (f != null) setState(() => ph = f);
              }),
            ]),
            const SizedBox(height: 12),
            Btn(tr('Post'), onTap: _post, busyDone: false),
          ]),
          Seg(const [('All', 'All'), ('Sell', 'Sell'), ('Buy', 'Buy'), ('Give away', 'Give away')], fil, (x) => setState(() => fil = x)),
          if (v.isEmpty) const Empty('Nothing posted yet', icon: '🛍️'),
          for (final (i, c) in v.indexed)
            Enter(
              index: i,
              child: Builder(builder: (_) {
                final cl = c['status'] == 'Closed';
                final ref = dref('classifieds', str(c['id']));
                return Item(
                    bar: cl
                        ? p.faint
                        : c['type'] == 'Sell'
                            ? p.green
                            : c['type'] == 'Buy'
                                ? p.a
                                : p.amber,
                    children: [
                      ItemHead(str(c['title']), badge: Pill(cl ? tr('Closed') : str(c['type']), tone: c['type'] == 'Give away' ? Tone.g : Tone.a)),
                      if (c['type'] != 'Give away' && numv(c['price']) > 0) Padding(padding: const EdgeInsets.only(top: 4), child: Text(rs(c['price']), style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: p.a))),
                      if (str(c['desc']).isNotEmpty) Desc(str(c['desc'])),
                      if (okImg(c['photo'])) PhotoThumb(str(c['photo'])),
                      Meta('${str(c['name'])} · ${str(c['flat'])} · ${dt(c['ts'])}'),
                      ActRow([
                        if (c['uid'] != S.uid && !cl) mini(tr('💬 Message'), () => Chat.openDM(str(c['uid'])), BtnKind.primary),
                        if (c['uid'] == S.uid && !cl) mini(c['type'] == 'Buy' ? tr('Mark found') : trf('Mark {0}', [(c['type'] == 'Sell' ? 'sold' : 'given')]), () => updateDoc(ref, {'status': 'Closed'})),
                        if (c['uid'] == S.uid || S.isAdm)
                          mini(tr('Delete'), () async {
                            if (!await confirmDlg(context, tr('Delete this post?'), ok: tr('Delete'), danger: true)) return;
                            await ref.delete();
                            rmFile(c['photo']);
                          }, BtnKind.red),
                      ]),
                    ]);
              }),
            ),
        ]);
      },
    );
  }
}
