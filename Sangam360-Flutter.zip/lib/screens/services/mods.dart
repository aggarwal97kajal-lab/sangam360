import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/files.dart';
import '../../core/fs.dart';
import '../../core/kinds.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/anim.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/media.dart';
import '../../ui/pick.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import 'svc.dart';
import '../../l10n/l10n.dart';

/// a field of a simple module: [key, kind (sel | date | time | txt | cls | file), label, options]
class MF {
  final String k, kind, l;
  final List<String> opts;
  const MF(this.k, this.kind, this.l, [this.opts = const []]);
}

class ModCfg {
  final String col, ic, t;
  final bool all, own, appr, adm, clash, cls, owner;
  final List<MF> f;
  final String Function(Doc x) line, sub;
  final bool Function(Doc x)? keep;
  final int Function(Doc a, Doc b) ord;
  const ModCfg({required this.col, required this.ic, required this.t, required this.f, required this.line, required this.sub, required this.ord, this.all = false, this.own = false, this.appr = false, this.adm = false, this.clash = false, this.cls = false, this.owner = false, this.keep});
}

final mods = <String, ModCfg>{
  'leave': ModCfg(
    col: 'leaves',
    ic: '🏖️',
    t: 'Leave',
    all: true,
    own: true,
    appr: true,
    f: const [MF('type', 'sel', 'Leave type', ['Casual', 'Sick', 'Earned', 'Other']), MF('from', 'date', 'From'), MF('to', 'date', 'To'), MF('reason', 'txt', 'Reason')],
    line: (x) => trf('{0} leave · {1} → {2}', [str(x['type']), str(x['from']), str(x['to'])]),
    sub: (x) => '${str(x['name'])} · ${str(x['reason'])}',
    ord: (a, b) => intv(b['ts']).compareTo(intv(a['ts'])),
  ),
  'room': ModCfg(
    col: 'rooms',
    ic: '🚪',
    t: 'Schedule a meeting',
    all: true,
    adm: true,
    clash: true,
    f: const [MF('room', 'sel', 'Room', ['Conference A', 'Conference B', 'Board room', 'Training room']), MF('date', 'date', 'Date'), MF('from', 'time', 'Start'), MF('to', 'time', 'End'), MF('reason', 'txt', 'Purpose')],
    line: (x) => '${str(x['room'])} · ${str(x['date'])} ${str(x['from'])}–${str(x['to'])}',
    sub: (x) => '${str(x['name'])} · ${str(x['reason'])}',
    keep: (x) => str(x['date']).compareTo(td()) >= 0,
    ord: (a, b) => (str(a['date']) + str(a['from'])).compareTo(str(b['date']) + str(b['from'])),
  ),
  'tt': ModCfg(
    col: 'timetable',
    ic: '🗓️',
    t: 'Add timetable slot',
    cls: true,
    f: const [MF('cls', 'cls', 'Class'), MF('day', 'sel', 'Day', weekDays), MF('from', 'time', 'Start time'), MF('subject', 'txt', 'Subject')],
    line: (x) => '${str(x['day'])} ${str(x['from'])} · ${str(x['subject'])}',
    sub: (x) => str(x['cls']),
    ord: (a, b) {
      final c = weekDays.indexOf(str(a['day'])) - weekDays.indexOf(str(b['day']));
      return c != 0 ? c : str(a['from']).compareTo(str(b['from']));
    },
  ),
  'hw': ModCfg(
    col: 'homework',
    ic: '📚',
    t: 'Assign homework',
    cls: true,
    f: const [MF('cls', 'cls', 'Class'), MF('subject', 'txt', 'Subject'), MF('title', 'txt', 'Homework'), MF('due', 'date', 'Due date'), MF('file', 'file', 'Attach a photo or PDF (optional)')],
    line: (x) => '${str(x['subject'])} · ${str(x['title'])}',
    sub: (x) => trf('{0} · due {1} · by {2}', [str(x['cls']), str(x['due']), str(x['name'])]),
    ord: (a, b) => str(a['due']).compareTo(str(b['due'])),
  ),
  'hol': ModCfg(
    col: 'holidays',
    ic: '🎉',
    t: 'Add a holiday',
    owner: true,
    f: const [MF('title', 'txt', 'Holiday name'), MF('date', 'date', 'Date'), MF('file', 'file', 'Attach the holiday list as photo or PDF (optional)')],
    line: (x) => str(x['title']),
    sub: (x) => str(x['date']),
    ord: (a, b) => str(a['date']).compareTo(str(b['date'])),
  ),
};

class ModPage extends StatefulWidget {
  final String k;
  const ModPage({super.key, required this.k});
  @override
  State<ModPage> createState() => _ModPageState();
}

class _ModPageState extends State<ModPage> {
  StreamSubscription? _s;
  List<Doc>? L;
  bool bad = false;
  final Map<String, TextEditingController> tc = {};
  final Map<String, String> sv = {};
  PFile? file;

  ModCfg get M => mods[widget.k]!;

  @override
  void initState() {
    super.initState();
    final c = col(M.col);
    final q = M.own && !S.isAdm ? c.where('uid', isEqualTo: S.uid).limit(300) : c.limit(300);
    _s = q.snapshots().listen((s) {
      if (mounted) setState(() => L = docsOf(s));
    }, onError: (_) {
      if (mounted) {
        setState(() {
          bad = true;
          L ??= [];
        });
      }
    });
    _reset();
  }

  void _reset() {
    for (final f in M.f) {
      if (f.kind == 'txt') tc[f.k] = TextEditingController();
      if (f.kind == 'cls') {
        sv[f.k] = S.isTeacher ? S.myCls : '';
      } else if (f.kind != 'txt' && f.kind != 'file') {
        sv[f.k] = '';
      }
    }
    file = null;
  }

  @override
  void dispose() {
    _s?.cancel();
    super.dispose();
  }

  bool get canAdd => M.owner ? S.isMgr : ((M.all && !(M.adm && !S.isAdm)) || S.isAdm);

  Future<void> _save() async {
    final o = <String, dynamic>{};
    for (final f in M.f) {
      if (f.kind == 'file') {
        if (file != null) {
          o['fileName'] = file!.name;
          o['file'] = await up(file!.bytes, 'docs', file!.name);
        }
        continue;
      }
      final v = (f.kind == 'txt' ? tc[f.k]!.text : (sv[f.k] ?? '')).trim();
      if (v.isEmpty) {
        toast('⚠️', trf('Please fill: {0}', [tr(f.l)]));
        return;
      }
      o[f.k] = v;
    }
    if (o['to'] != null && o['from'] != null && str(o['to']).compareTo(str(o['from'])) < 0 && widget.k == 'leave') {
      toast('⚠️', tr('End date is before start'));
      return;
    }
    if (M.clash && (str(o['to']).compareTo(str(o['from'])) <= 0 || (L ?? []).any((x) => x['room'] == o['room'] && x['date'] == o['date'] && str(x['from']).compareTo(str(o['to'])) < 0 && str(o['from']).compareTo(str(x['to'])) < 0))) {
      toast('⚠️', tr('Room not free then'), tr('Pick another time'));
      return;
    }
    await addDoc(col(M.col), {...o, 'uid': S.uid, 'name': S.me!['name'], 'status': M.appr ? 'Pending' : '', 'ts': now()});
    toast('✅', tr('Saved'));
    setState(_reset);
  }

  Widget _field(MF f) {
    switch (f.kind) {
      case 'sel':
        return SelectField(f.l, sv[f.k]!.isEmpty ? null : sv[f.k], SelectField.same(f.opts), (v) => setState(() => sv[f.k] = v));
      case 'cls':
        final opts = S.isTeacher ? [S.myCls] : S.schClasses();
        return SelectField(f.l, sv[f.k]!.isEmpty ? null : sv[f.k], SelectField.same(opts), (v) => setState(() => sv[f.k] = v));
      case 'date':
        return DateField(f.l, sv[f.k]!, (v) => setState(() => sv[f.k] = v));
      case 'time':
        return TimeField(f.l, sv[f.k]!, (v) => setState(() => sv[f.k] = v));
      case 'file':
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(tr(f.l), style: meta()),
            const SizedBox(height: 6),
            Row(children: [
              mini(file == null ? tr('📎 Choose file') : '✓ ${cut(file!.name, 24)}', () async {
                final x = await pickPhotoSheet(context, pdf: true, title: tr(f.l));
                if (x == null) return;
                final b = checkFile(x, max: 5 * 1048576);
                if (b != null) {
                  toast('⚠️', b);
                  return;
                }
                setState(() => file = x);
              }),
              if (file != null) IconButton(onPressed: () => setState(() => file = null), icon: Icon(Icons.close_rounded, color: pal.muted, size: 18)),
            ]),
          ]),
        );
    }
    return Field(tc[f.k]!, f.l, max: 80);
  }

  @override
  Widget build(BuildContext context) {
    final k = widget.k;
    final mc = str(S.me?['flat']).split(' · ').first;
    return ListenableBuilder(
      listenable: D.on(['mem']),
      builder: (_, __) {
        final V = (L ?? [])
            .where((x) => (!M.own || S.isAdm || x['uid'] == S.uid) && (k != 'leave' || !S.isTeacher || x['uid'] == S.uid || D['mem'][x['uid']] != null) && (!M.cls || (S.isAdm && !S.isTeacher) || mc.isEmpty || x['cls'] == mc) && (M.keep == null || M.keep!(x)))
            .toList()
          ..sort(M.ord);
        final title = k == 'leave'
            ? (S.isAdm ? tr('All leave requests') : tr('My requests'))
            : k == 'room'
                ? tr('Upcoming meetings')
                : k == 'tt'
                    ? 'Timetable'
                    : k == 'hol'
                        ? tr('Holiday list')
                        : 'Homework';
        return svcBody([
          if (bad) Note(tr("Couldn't load. Check your internet or Firestore rules."), tone: Tone.y, margin: const EdgeInsets.only(bottom: 12)),
          if (canAdd)
            AppCard(title: '${M.ic} ${tr(M.t)}', children: [
              for (final f in M.f) _field(f),
              Btn(M.appr ? tr('Send request') : tr('Save'), onTap: _save, busyDone: false),
            ]),
          AppCard(title: '${M.ic} $title', children: [
            if (L == null) const Skeleton(n: 2),
            if (L != null && V.isEmpty) Text(tr('Nothing here yet.'), style: meta()),
            for (final (i, x) in V.indexed)
              Enter(
                index: i,
                child: Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: pal.card2, borderRadius: BorderRadius.circular(14)),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Expanded(child: Text(M.line(x), style: h3())),
                      if (str(x['status']).isNotEmpty) Pill(str(x['status']), tone: x['status'] == 'Approved' ? Tone.g : x['status'] == 'Rejected' ? Tone.r : Tone.y),
                    ]),
                    Meta(M.sub(x)),
                    ActRow([
                      if (str(x['file']).isNotEmpty) mini('📎 ${str(x['fileName']).isEmpty ? tr('Attachment') : str(x['fileName'])}', () => openRef(context, str(x['file']), name: str(x['fileName']).isEmpty ? 'file' : str(x['fileName']))),
                      if (M.appr && S.isAdm && x['status'] == 'Pending') ...[
                        mini(tr('Approve'), () => updateDoc(dref(M.col, str(x['id'])), {'status': 'Approved'}), BtnKind.green),
                        mini(tr('Reject'), () => updateDoc(dref(M.col, str(x['id'])), {'status': 'Rejected'})),
                      ],
                      if (M.owner ? S.isMgr : (S.isAdm || x['uid'] == S.uid))
                        mini(tr('Delete'), () async {
                          if (!await confirmDlg(context, tr('Delete this?'), ok: tr('Delete'), danger: true)) return;
                          await dref(M.col, str(x['id'])).delete();
                        }),
                    ]),
                  ]),
                ),
              ),
          ]),
        ]);
      },
    );
  }
}
