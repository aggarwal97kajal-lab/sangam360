import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/nav.dart';
import '../../core/session.dart';
import '../../ui/theme.dart';
import 'att.dart';
import 'comp.dart';
import 'gate.dart';
import 'gc.dart';
import 'help.dart';
import 'mkt.dart';
import 'mods.dart';
import 'vis.dart';

/// the Services tab (Campus / Work for schools and companies): a row of pages and the page in use
class SvcTab extends StatelessWidget {
  const SvcTab({super.key});

  Widget _page(String k) {
    switch (k) {
      case 'comp':
        return const CompPage();
      case 'vis':
        return const VisPage();
      case 'del':
        return const DelPage();
      case 'veh':
        return const VehPage();
      case 'park':
        return const ParkPage();
      case 'help':
        return const HelpPage();
      case 'mkt':
        return const MktPage();
      case 'att':
        return const AttPage();
      case 'gc':
        return const GcPage();
    }
    return ModPage(k: k, key: ValueKey('mod$k'));
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: nav,
      builder: (_, __) {
        final L = nav.subList();
        final cur = L.contains(nav.sub) ? nav.sub : L.first;
        return Column(children: [
          if (!S.isGuard) SubChips(L, cur),
          Expanded(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 240),
              child: KeyedSubtree(key: ValueKey(cur), child: _page(cur)),
            ),
          ),
        ]);
      },
    );
  }
}

/// the pages of the tab as chips with a sliding highlight
class SubChips extends StatefulWidget {
  final List<String> L;
  final String cur;
  const SubChips(this.L, this.cur, {super.key});
  @override
  State<SubChips> createState() => _SubChipsState();
}

class _SubChipsState extends State<SubChips> {
  final _sc = ScrollController();
  final Map<String, GlobalKey> _k = {};

  @override
  void didUpdateWidget(SubChips o) {
    super.didUpdateWidget(o);
    if (o.cur != widget.cur) WidgetsBinding.instance.addPostFrameCallback((_) => _centre());
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _centre());
  }

  void _centre() {
    final c = _k[widget.cur]?.currentContext;
    if (c != null) Scrollable.ensureVisible(c, alignment: .5, duration: const Duration(milliseconds: 300), curve: Curves.easeOutCubic);
  }

  @override
  Widget build(BuildContext context) {
    final p = pal, sk = nav.subsK();
    return SizedBox(
      height: 52,
      child: ListView(
        controller: _sc,
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(14, 6, 14, 8),
        children: [
          for (final k in widget.L)
            Padding(
              key: _k[k] ??= GlobalKey(),
              padding: const EdgeInsets.only(right: 8),
              child: GestureDetector(
                onTap: () {
                  HapticFeedback.selectionClick();
                  nav.setSub(k);
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 260),
                  curve: Curves.easeOutCubic,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    gradient: k == widget.cur ? p.grad : null,
                    color: k == widget.cur ? null : p.card,
                    borderRadius: BorderRadius.circular(99),
                    border: Border.all(color: k == widget.cur ? Colors.transparent : p.line),
                    boxShadow: k == widget.cur ? [BoxShadow(color: p.a.withOpacity(.25), blurRadius: 12, offset: const Offset(0, 5))] : null,
                  ),
                  child: Text(S.sk(sk[k] ?? k), style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: k == widget.cur ? Colors.white : p.text)),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// the scrolling body of a Services page
Widget svcBody(List<Widget> children) => ListView(physics: const BouncingScrollPhysics(), padding: const EdgeInsets.fromLTRB(16, 4, 16, 110), children: children);
