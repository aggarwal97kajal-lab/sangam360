import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/files.dart';
import '../../core/fs.dart';
import '../../core/img.dart';
import '../../core/kinds.dart';
import '../../core/plan.dart';
import '../../core/session.dart';
import '../../core/store.dart';
import '../../core/toast.dart';
import '../../core/util.dart';
import '../../ui/anim.dart';
import '../../ui/fields.dart';
import '../../ui/kit.dart';
import '../../ui/media.dart';
import '../../ui/pick.dart';
import '../../ui/sheets.dart';
import '../../ui/theme.dart';
import '../fx/fx.dart';
import 'svc.dart';
import '../../l10n/l10n.dart';

/// a pass made by a resident reaches the admin / guard list only once it is verified at the gate
bool visShown(Doc x) => !(S.staff && x['status'] == 'Expected' && x['vfTs'] == null && x['uid'] != S.uid);

DocRef vref(String id) => dref('visitors', id);

void _queued() => toast('📶', tr('Saved on this phone'), tr('It will sync when your internet is back.'));

/// an optional visitor photo (square, small, kept inside the record)
Future<String> visPhoto(BuildContext context) async {
  final f = await pickPhotoSheet(context, title: tr('Visitor photo'));
  if (f == null) return '';
  try {
    return toDataUrl(await shrink(f.bytes, 480, .72, sq: true), 'image/jpeg');
  } catch (e) {
    fail(e, tr('Photo not added'));
    return '';
  }
}

class VisPage extends StatefulWidget {
  const VisPage({super.key});
  @override
  State<VisPage> createState() => _VisPageState();
}

class _VisPageState extends State<VisPage> {
  final vn = TextEditingController(), vm = TextEditingController(), vp = TextEditingController();
  String vt = vTypes.first, vd = td(), vtm = '', vph = '';
  final wn = TextEditingController(), wm = TextEditingController(), wp = TextEditingController();
  String wt = vTypes.first, wph = '';
  String? wf;
  final vcode = TextEditingController();
  Doc? vres;
  String vmsg = '';

  Future<void> _invite() async {
    final n = vn.text.trim();
    if (n.isEmpty || vd.isEmpty) {
      toast('ℹ️', tr('Enter visitor name and date'));
      return;
    }
    final v = <String, dynamic>{'uid': S.uid, 'residentName': S.me!['name'], 'flat': S.me!['flat'], 'name': n, 'mobile': vm.text.trim(), 'type': vt, 'purpose': vp.text.trim(), 'date': vd, 'time': vtm, 'code': code6(), 'status': 'Expected', 'ts': now(), 'photo': vph};
    await saveDoc(col('visitors'), v, onQueued: _queued);
    setState(() {
      vn.clear();
      vm.clear();
      vp.clear();
      vph = '';
    });
    if (mounted) passSheet(context, v);
  }

  Future<void> _walkIn() async {
    final n = wn.text.trim();
    if (n.isEmpty) {
      toast('ℹ️', tr('Enter visitor name'));
      return;
    }
    final fl = flats();
    await saveDoc(col('visitors'), {'uid': S.uid, 'guard': S.me!['name'], 'flat': wf ?? (fl.isEmpty ? '' : fl.first), 'name': n, 'mobile': wm.text.trim(), 'type': wt, 'purpose': wp.text.trim(), 'date': td(), 'time': '', 'code': code6(), 'status': 'Waiting', 'ts': now(), 'photo': wph}, onQueued: _queued);
    setState(() {
      wn.clear();
      wm.clear();
      wp.clear();
      wph = '';
    });
    toast('✅', tr('Resident notified'), tr('Waiting for approval'));
  }

  Future<void> _verify() async {
    final c = vcode.text.trim();
    setState(() {
      vres = null;
      vmsg = '';
    });
    if (!RegExp(r'^\d{6}$').hasMatch(c)) return;
    Doc? v = D['vis'].values.where((x) => x['code'] == c && (x['status'] == 'Expected' || x['status'] == 'Approved')).firstOrNull;
    if (v == null) {
      final s = await col('visitors').where('code', isEqualTo: c).limit(5).get();
      final a = docsOf(s);
      v = a.where((x) => x['status'] == 'Expected' || x['status'] == 'Approved').firstOrNull ?? a.firstOrNull;
    }
    if (v == null) {
      setState(() => vmsg = tr('No visitor found with this code.'));
      return;
    }
    if (S.staff && v['status'] == 'Expected' && v['vfTs'] == null) {
      final vf = {'vfTs': now(), 'vfBy': S.uid, 'vfName': str(S.me!['name'])};
      v = {...v, ...vf};
      D['vis'][v['id']]?.addAll(vf);
      updateDoc(vref(str(v['id'])), vf).catchError((e) => fail(e, tr('Could not mark the pass as verified')));
    }
    setState(() => vres = v);
    if (v['status'] == 'Expected' || v['status'] == 'Approved') fxDone(tr('Verified'), tr('QR pass is valid'), true, 1500);
  }

  void clearVres() => setState(() {
        vres = null;
        vcode.clear();
      });

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: D.on(['vis']),
      builder: (_, __) {
        if (vres != null) {
          final x = D['vis'][vres!['id']];
          if (x == null || !(x['status'] == 'Expected' || x['status'] == 'Approved')) {
            if (x != null && x['status'] != vres!['status']) WidgetsBinding.instance.addPostFrameCallback((_) => clearVres());
          }
        }
        final V = D['vis'].values.where(visShown).toList()..sort((a, b) => intv(b['vfTs'] ?? b['ts']).compareTo(intv(a['vfTs'] ?? a['ts'])));
        final groups = [
          ('⏳ Waiting for approval', (Doc x) => x['status'] == 'Waiting'),
          ('✅ Approved – let in', (Doc x) => x['status'] == 'Approved'),
          (S.staff ? '🔍 Pass verified – allow entry' : '🎟️ Expected', (Doc x) => x['status'] == 'Expected'),
          ('🟢 Inside now', (Doc x) => x['status'] == 'Inside'),
          ('🕘 History', (Doc x) => const ['Exited', 'Denied', 'Cancelled'].contains(x['status'])),
        ];
        final fl = flats();
        return svcBody([
          if (!S.isGuard)
            AppCard(title: '🎟️ Invite a visitor', children: [
              Field(vn, 'Visitor name', max: 40, kb: TextInputType.name),
              Row2(Field(vm, 'Mobile', max: 15, kb: TextInputType.phone), SelectField('Type', vt, SelectField.same(vTypes), (v) => setState(() => vt = v))),
              Row2(DateField(tr('Date'), vd, (v) => setState(() => vd = v), min: td()), TimeField('Time', vtm, (v) => setState(() => vtm = v))),
              Field(vp, 'Purpose (optional)', max: 60),
              _photoRow(vph, () async {
                final x = await visPhoto(context);
                if (x.isNotEmpty) setState(() => vph = x);
              }, () => setState(() => vph = '')),
              Btn(tr('Create visitor pass'), onTap: _invite, busyDone: false),
            ]),
          if (S.staff) ...[
            AppCard(title: '✅ Verify visitor pass', children: [
              Field(vcode, 'Enter 6-digit code', max: 6, kb: TextInputType.number, digitsOnly: true, center: true, spacing: 6, action: TextInputAction.done, onSubmit: (_) => _verify()),
              Row2(
                Btn(tr('Verify'), icon: Icons.check_rounded, onTap: _verify, small: true, busyDone: false),
                Btn.o(tr('Scan QR'), icon: Icons.qr_code_scanner_rounded, small: true, onTap: () async {
                  final c = await fxScan(context, tr('Scan visitor QR'));
                  if (c != null) {
                    vcode.text = c;
                    await _verify();
                  }
                }),
              ),
              if (vmsg.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: Empty(vmsg)),
              if (vres != null) Padding(padding: const EdgeInsets.only(top: 12), child: VisCard(D['vis'][vres!['id']] ?? vres!, onDone: clearVres)),
            ]),
            AppCard(title: '🚶 Walk-in visitor', children: [
              Field(wn, 'Visitor name', max: 40, kb: TextInputType.name),
              Row2(Field(wm, 'Mobile', max: 15, kb: TextInputType.phone), SelectField('Type', wt, SelectField.same(vTypes), (v) => setState(() => wt = v))),
              SelectField(S.sk('Flat'), wf ?? (fl.isEmpty ? null : fl.first), SelectField.same(fl), (v) => setState(() => wf = v)),
              Field(wp, 'Purpose', max: 60),
              _photoRow(wph, () async {
                final x = await visPhoto(context);
                if (x.isNotEmpty) setState(() => wph = x);
              }, () => setState(() => wph = '')),
              Btn(S.sk('Ask resident to approve'), onTap: _walkIn, busyDone: false),
            ]),
          ],
          if (V.isEmpty) Empty(S.staff ? 'No visitors yet. A visitor pass shows here after you scan its QR or enter its code.' : 'No visitors yet', icon: '🚪'),
          for (final g in groups)
            ...() {
              final a = V.where(g.$2).take(g.$1.contains('History') ? 20 : 50).toList();
              if (a.isEmpty) return <Widget>[];
              return [Sec('${g.$1} (${a.length})'), for (final (i, v) in a.indexed) Enter(index: i, child: VisCard(v))];
            }(),
        ]);
      },
    );
  }

  Widget _photoRow(String ph, VoidCallback pick, VoidCallback clear) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Row(children: [
          mini(tr('📷 Visitor photo (optional)'), pick),
          const SizedBox(width: 10),
          if (ph.isNotEmpty) ...[Av('V', ph, size: 44), IconButton(onPressed: clear, icon: Icon(Icons.close_rounded, color: pal.muted, size: 18))],
        ]),
      );
}

class VisCard extends StatelessWidget {
  final Doc v;
  final VoidCallback? onDone;
  const VisCard(this.v, {super.key, this.onDone});
  @override
  Widget build(BuildContext context) {
    final st = str(v['status']);
    final bar = const {'Inside': Tone.g, 'Waiting': Tone.y, 'Expected': Tone.a, 'Approved': Tone.g}[st] ?? Tone.m;
    final badge = const {'Inside': Tone.g, 'Approved': Tone.g, 'Denied': Tone.r, 'Cancelled': Tone.r, 'Waiting': Tone.y}[st] ?? Tone.a;
    final id = str(v['id']);
    final si = const {'Waiting': 1, 'Approved': 2, 'Inside': 3, 'Exited': 3}[st];
    final acts = <Widget>[];
    if (S.staff) {
      if (st == 'Expected' || st == 'Approved') {
        acts.add(mini(tr('Allow entry'), () async {
          await updateDoc(vref(id), {'status': 'Inside', 'entryTs': now()});
          onDone?.call();
        }, BtnKind.green));
      }
      if (st == 'Expected' && v['vfTs'] != null) {
        acts.add(mini(tr('Deny entry'), () async {
          if (!await confirmDlg(context, trf('Deny entry to {0}?', [str(v['name'])]), ok: tr('Deny'), danger: true)) return;
          await updateDoc(vref(id), {'status': 'Denied', 'decidedTs': now(), 'deniedBy': S.uid});
          onDone?.call();
        }, BtnKind.red));
      }
      if (st == 'Inside') {
        acts.add(mini(tr('Mark exit'), () async {
          await updateDoc(vref(id), {'status': 'Exited', 'exitTs': now()});
          onDone?.call();
        }, BtnKind.primary));
      }
    }
    if (v['uid'] == S.uid || (!S.staff && v['flat'] == S.me?['flat'])) {
      if (st == 'Waiting') {
        acts.add(mini(tr('Approve'), () async {
          await updateDoc(vref(id), {'status': 'Approved', 'decidedTs': now()});
          fxDone(tr('Approved'), trf('Visitor allowed — {0}', [str(v['name'])]));
        }, BtnKind.green));
        acts.add(mini(tr('Deny'), () => updateDoc(vref(id), {'status': 'Denied', 'decidedTs': now()}), BtnKind.red));
      }
      if (st == 'Expected' && !S.staff) {
        acts.add(mini(tr('Show pass'), () => passSheet(context, v)));
        acts.add(mini(tr('Cancel'), () => updateDoc(vref(id), {'status': 'Cancelled'}), BtnKind.red));
      }
    }
    if (!okImg(v['photo']) && const ['Waiting', 'Expected', 'Approved', 'Inside'].contains(st) && (S.staff || v['uid'] == S.uid)) {
      acts.add(mini(tr('📷 Add visitor photo'), () async {
        final u = await visPhoto(context);
        if (u.isEmpty) return;
        await updateDoc(vref(id), {'photo': u});
        toast('✅', tr('Photo added'), str(v['name']));
      }));
    }
    if (v['uid'] == S.uid || S.isAdm || S.isGuard) {
      acts.add(mini(tr('Delete entry'), () async {
        if (!await confirmDlg(context, tr('Delete this visitor entry?'), ok: tr('Delete'), danger: true)) return;
        await vref(id).delete();
        toast('🗑️', tr('Visitor entry deleted'));
      }, BtnKind.red));
    }
    return Item(bar: toneColor(bar), children: [
      Row(children: [
        GestureDetector(
          onTap: okImg(v['photo']) ? () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ImageViewer(ref: str(v['photo']), name: 'visitor.jpg'))) : null,
          child: Av(str(v['name']), okImg(v['photo']) ? str(v['photo']) : null, size: 56),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(str(v['name']), style: h3().copyWith(fontSize: 16)), Text(str(v['type']).isEmpty ? tr('Visitor') : str(v['type']), style: meta())])),
        Pill(st, tone: badge),
      ]),
      Meta('${str(v['flat'])}${str(v['purpose']).isNotEmpty ? ' · ${v['purpose']}' : ''} · ${str(v['date'])}${str(v['time']).isNotEmpty ? ' ${v['time']}' : ''}${str(v['mobile']).isNotEmpty ? ' · ${v['mobile']}' : ''}'),
      if (v['vfTs'] != null && const ['Expected', 'Approved', 'Inside', 'Exited', 'Denied'].contains(st)) Meta(trf('🔍 Pass verified{0} · {1}', [(str(v['vfName']).isNotEmpty ? trf(' by {0}', [v['vfName']]) : ''), tm(v['vfTs'])])),
      if (v['entryTs'] != null) Meta(trf('In: {0}{1}', [tm(v['entryTs']), (v['exitTs'] != null ? trf(' · Out: {0}', [tm(v['exitTs'])]) : '')])),
      if (st == 'Expected' && v['date'] != td() && S.staff) Note(trf('⚠️ This pass is for {0}, not today.', [str(v['date'])]), tone: Tone.y),
      if (si != null) Steps(const ['Arriving', 'Notified', 'Approved', 'Inside'], si, icons: const ['🚗', '🔔', '👤', '🟢']),
      ActRow(acts),
    ]);
  }
}

/// the visitor pass: QR, code, share on WhatsApp
void passSheet(BuildContext context, Doc v) {
  final txt = trf('Hi {0}, your visitor pass for {1} ({2}): code {3} on {4}{5}. Show this code at the gate.', [str(v['name']), (str(S.soc?['name'])), str(v['flat']), str(v['code']), str(v['date']), (str(v['time']).isNotEmpty ? ' ${v['time']}' : '')]);
  sheet(context, (ctx) {
    final p = pal;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      SheetTitle('🎟️ Visitor pass', sub: '${str(v['name'])} · ${str(v['type'])} · ${str(v['date'])}${str(v['time']).isNotEmpty ? ' ${v['time']}' : ''}'),
      Center(child: FxQR('SH-${str(v['code'])}', size: 190)),
      const SizedBox(height: 14),
      Text(str(v['code']), textAlign: TextAlign.center, style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: 8, color: p.a)),
      const SizedBox(height: 14),
      Btn.g(tr('Share pass on WhatsApp'), onTap: () => shareQR(v, txt)),
    ]);
  });
}

/// the QR of a pass as a picture + the text, to WhatsApp (or any app)
Future<void> shareQR(Doc v, String txt) async {
  try {
    final img = await QrPainter(data: 'SH-${str(v['code'])}', version: QrVersions.auto, gapless: true, eyeStyle: const QrEyeStyle(eyeShape: QrEyeShape.square, color: Color(0xFF111827)), dataModuleStyle: const QrDataModuleStyle(dataModuleShape: QrDataModuleShape.square, color: Color(0xFF111827))).toImage(600);
    final rec = ui.PictureRecorder();
    final cv = Canvas(rec);
    cv.drawRect(const Rect.fromLTWH(0, 0, 640, 640), Paint()..color = const Color(0xFFFFFFFF));
    cv.drawImage(img, const Offset(20, 20), Paint());
    final out = await rec.endRecording().toImage(640, 640);
    final png = await out.toByteData(format: ui.ImageByteFormat.png);
    final f = await tempFile('visitor-pass-${str(v['code'])}.png', png!.buffer.asUint8List());
    await Share.shareXFiles([XFile(f.path, mimeType: 'image/png')], text: txt);
  } catch (_) {
    final m = wa91(str(v['mobile']));
    await launchUrl(Uri.parse('https://wa.me/$m?text=${Uri.encodeComponent(txt)}'), mode: LaunchMode.externalApplication);
  }
}
