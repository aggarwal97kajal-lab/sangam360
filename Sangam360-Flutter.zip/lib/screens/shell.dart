import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/app.dart';
import '../core/kinds.dart';
import '../core/nav.dart';
import '../core/perms.dart';
import '../core/plan.dart';
import '../core/prefs.dart';
import '../core/push.dart';
import '../core/session.dart';
import '../core/store.dart';
import '../core/toast.dart';
import '../core/util.dart';
import '../ui/brand.dart';
import '../ui/kit.dart';
import '../ui/media.dart';
import '../ui/sheets.dart';
import '../ui/theme.dart';
import 'boot.dart';
import 'comm/chat_ctl.dart';
import 'comm/comm.dart';
import 'fin/fin.dart';
import 'fin/sub.dart';
import 'fx/fx.dart';
import 'home.dart';
import 'legal.dart';
import 'more/idrec.dart';
import 'more/more.dart';
import 'services/svc.dart';
import 'support.dart';

final shellKey = GlobalKey<ScaffoldState>();

/// the dashboard: header, the tab in use, the bottom bar, the side menu
class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> with WidgetsBindingObserver {
  Timer? _gate;
  bool? _lockWas;
  int _backAt = 0;

  @override
  void initState() {
    super.initState();
    nav.addListener(_re);
    nav.openFx = (k) => openFx(k);
    Push.onOpen = _pushOpen;
    _gate = Timer.periodic(const Duration(seconds: 30), (_) => _planGate());
    D.rev('soc').addListener(_planGate);
    Future.delayed(const Duration(milliseconds: 900), () {
      final c = navKey.currentContext;
      if (mounted && c != null) firstRunPerms(c);
    });
    _coach();
  }

  @override
  void dispose() {
    nav.removeListener(_re);
    D.rev('soc').removeListener(_planGate);
    _gate?.cancel();
    super.dispose();
  }

  void _re() {
    if (mounted) setState(() {});
  }

  void _planGate() {
    if (S.me == null || S.soc == null) return;
    final lk = PlanSt.locked;
    if (lk == _lockWas) return;
    final first = _lockWas == null;
    _lockWas = lk;
    if (first && !lk) return;
    if (lk) {
      final n = navKey.currentState;
      n?.popUntil((r) => r.isFirst);
    }
    nav.goTab(lk ? 'home' : nav.tab);
  }

  void _coach() {
    if (Prefs.get('sh-tip-menu').isNotEmpty) return;
    Future.delayed(const Duration(milliseconds: 2600), () {
      if (!mounted || nav.tab != 'home' || S.phase != Phase.main) return;
      Prefs.set('sh-tip-menu', '1');
      toast('☰', 'All features are in the menu', 'Tap ☰ at the top left. You can also slide from the left side of the screen.');
    });
  }

  Future<void> _pushOpen(String open, String sid) async {
    if (open.isEmpty || S.me == null) return;
    if (sid.isNotEmpty && sid != S.sid) {
      try {
        final ids = (await App.socIds()).$2;
        if (!ids.contains(sid)) return;
        await App.switchTo(sid);
        Future.delayed(const Duration(milliseconds: 900), () => _pushOpen(open, ''));
      } catch (_) {}
      return;
    }
    final p = open.split(':');
    navKey.currentState?.popUntil((r) => r.isFirst);
    if (p[0] == 'dm' && p.length > 2) {
      Chat.openDM(p[2], from: 'inbox', cid: p[1]);
      return;
    }
    if (p[0] == 'chat') {
      nav.goTab('comm');
      if (S.sch && p.length > 1) Chat.setRoom(p.sublist(1).join(':'));
      nav.setComm('chat');
      return;
    }
    if (open == 'ann') {
      nav.goTab('comm');
      nav.setComm('ann');
      return;
    }
    nav.go(open);
  }

  Future<bool> _back() async {
    final st = shellKey.currentState;
    if (st != null && st.isDrawerOpen) {
      st.closeDrawer();
      return false;
    }
    if (nav.tab == 'comm' && nav.dmc != null) {
      Chat.leaveDM();
      return false;
    }
    if (nav.tab == 'comm' && nav.comm != 'ann') {
      nav.setComm(nav.dmFrom == 'inbox' && nav.comm == 'chat' ? 'ann' : 'ann');
      return false;
    }
    if (nav.tab != 'home') {
      nav.goTab('home');
      return false;
    }
    final n = now();
    if (n - _backAt < 2000) return true;
    _backAt = n;
    toast('ℹ️', 'Press back again to exit');
    return false;
  }

  Widget _body() {
    switch (nav.tab) {
      case 'svc':
        return const SvcTab(key: ValueKey('svc'));
      case 'comm':
        return const CommTab(key: ValueKey('comm'));
      case 'fin':
        return const FinTab(key: ValueKey('fin'));
      case 'more':
        return const MoreTab(key: ValueKey('more'));
      case 'sub':
        return const SubTab(key: ValueKey('sub'));
    }
    return const HomeTab(key: ValueKey('home'));
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    final chatFull = nav.tab == 'comm' && (nav.comm == 'chat' || nav.dmc != null);
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (did, _) async {
        if (did) return;
        if (await _back()) SystemNavigator.pop();
      },
      child: Scaffold(
        key: shellKey,
        backgroundColor: p.bg,
        drawerEdgeDragWidth: chatFull ? 26 : MediaQuery.of(context).size.width * .2,
        drawer: const AppDrawer(),
        onDrawerChanged: (o) {
          if (o && PlanSt.locked) {
            shellKey.currentState?.closeDrawer();
            PlanSt.lockNudge();
          }
        },
        body: Stack(children: [
          Positioned(left: 0, right: 0, top: 0, height: 320, child: IgnorePointer(child: Aurora(strength: .55))),
          SafeArea(
            bottom: false,
            child: Column(children: [
              if (!chatFull) TopBar(),
              Expanded(
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 280),
                  switchInCurve: Curves.easeOutCubic,
                  transitionBuilder: (c, a) => FadeTransition(opacity: a, child: SlideTransition(position: Tween(begin: const Offset(0, .02), end: Offset.zero).animate(a), child: c)),
                  child: _body(),
                ),
              ),
            ]),
          ),
        ]),
        bottomNavigationBar: chatFull ? null : BottomBar(),
        floatingActionButton: (nav.tab == 'home' || nav.tab == 'more') && !PlanSt.locked ? const SupportFab() : null,
      ),
    );
  }
}

/* ============================== the header ============================== */
class TopBar extends StatelessWidget {
  const TopBar({super.key});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    final t = nav.navCfg().where((c) => c.$1.split(':').first == nav.tab).toList();
    final title = nav.tab == 'home' ? str(S.soc?['name']) : (t.isEmpty ? (nav.tab == 'sub' ? 'Plan' : '') : S.sk(t.first.$3));
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 6),
      child: Row(children: [
        IconBtn(Icons.menu_rounded, tip: 'Menu', onTap: () => shellKey.currentState?.openDrawer()),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: h2().copyWith(fontSize: 18)),
            Text(heroSub(), maxLines: 1, overflow: TextOverflow.ellipsis, style: small()),
          ]),
        ),
        ListenableBuilder(
          listenable: ThemeCtl.I,
          builder: (_, __) => IconBtn(ThemeCtl.I.dark ? Icons.dark_mode_rounded : Icons.light_mode_rounded, tip: 'Theme', onTap: () {
            HapticFeedback.selectionClick();
            ThemeCtl.I.toggle();
          }),
        ),
        const SizedBox(width: 8),
        ListenableBuilder(
          listenable: Bell.I,
          builder: (_, __) => IconBtn(
            Icons.notifications_none_rounded,
            tip: 'Notifications',
            onTap: () => bellSheet(context),
            badge: Bell.I.unread == 0 ? null : Container(padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1), decoration: BoxDecoration(color: p.red, borderRadius: BorderRadius.circular(9)), child: Text('${Bell.I.unread}', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800))),
          ),
        ),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: () => nav.go('more'),
          child: ListenableBuilder(listenable: D.on(['dir']), builder: (_, __) => Av(str(S.me?['name']), myPhoto(), size: 42)),
        ),
      ]),
    );
  }
}

/// "Flat 203 · resident" / "Principal"
String heroSub() {
  final me = S.me;
  if (me == null) return '';
  final rl = S.roleLbl(me['role']);
  if (S.kind == 'school') return str(me['flat']).toLowerCase() == rl.toLowerCase() ? rl : '${str(me['flat'])} · ${rl.toLowerCase()}';
  return '${str(me['flat'])} · ${str(me['role']).replaceFirst('_', ' ').toLowerCase()}';
}

void bellSheet(BuildContext context) {
  Bell.I.seen();
  sheet(context, (ctx) {
    final it = Bell.I.items;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const SheetTitle('🔔 Notifications'),
      if (it.isEmpty) const Empty('No notifications yet', icon: '🔕'),
      for (final n in it) Ex(str(n['t']), sub: [str(n['x']), ago(n['ts'])].where((x) => x.isNotEmpty).join(' · '), lead: Text(str(n['ic']), style: const TextStyle(fontSize: 22))),
    ]);
  });
}

/* ============================== the bottom bar ============================== */
class BottomBar extends StatelessWidget {
  const BottomBar({super.key});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    final cfg = nav.navCfg();
    final T = nav.tab == 'sub' && !S.isMgr ? 'more' : nav.tab;
    var on = cfg.indexWhere((c) {
      final k = c.$1.split(':');
      return k[0] == T && (k.length < 2 || k[1] == nav.sub);
    });
    if (on < 0) on = cfg.indexWhere((c) => c.$1.split(':')[0] == T);
    return SafeArea(
      top: false,
      child: Container(
        margin: const EdgeInsets.fromLTRB(12, 0, 12, 10),
        height: 66,
        decoration: BoxDecoration(
          color: p.card.withOpacity(p.dark ? .96 : .98),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: p.line),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(p.dark ? .3 : .08), blurRadius: 30, offset: const Offset(0, 10))],
        ),
        padding: const EdgeInsets.all(6),
        child: LayoutBuilder(builder: (_, c) {
          final w = c.maxWidth / cfg.length;
          return Stack(children: [
            if (on >= 0)
              AnimatedPositioned(
                duration: const Duration(milliseconds: 380),
                curve: Curves.easeOutBack,
                left: on * w + 3,
                top: 0,
                bottom: 0,
                width: w - 6,
                child: Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [p.a.withOpacity(.14), p.a2.withOpacity(.10)]), borderRadius: BorderRadius.circular(18))),
              ),
            Row(children: [
              for (final (i, cf) in cfg.indexed)
                Expanded(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () {
                      HapticFeedback.selectionClick();
                      nav.go(cf.$1);
                    },
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      AnimatedScale(scale: i == on ? 1.12 : 1, duration: const Duration(milliseconds: 260), child: Icon(cf.$2, size: 23, color: i == on ? p.a : p.muted)),
                      const SizedBox(height: 3),
                      Text(S.sk(cf.$3), maxLines: 1, overflow: TextOverflow.fade, softWrap: false, style: TextStyle(fontSize: 10.5, fontWeight: i == on ? FontWeight.w800 : FontWeight.w600, color: i == on ? p.a : p.muted)),
                    ]),
                  ),
                ),
            ]),
          ]);
        }),
      ),
    );
  }
}

/* ============================== the support button ============================== */
class SupportFab extends StatelessWidget {
  const SupportFab({super.key});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: GestureDetector(
        onTap: () => openSupport(context, true),
        child: Container(
          width: 54,
          height: 54,
          decoration: BoxDecoration(gradient: p.grad, shape: BoxShape.circle, boxShadow: [BoxShadow(color: p.a.withOpacity(.35), blurRadius: 18, offset: const Offset(0, 8))]),
          alignment: Alignment.center,
          child: const Icon(Icons.support_agent_rounded, color: Colors.white, size: 26),
        ),
      ),
    );
  }
}

/* ============================== the side menu ============================== */
const subIcons = {'comp': '🛠️', 'vis': '🚪', 'del': '📦', 'veh': '🚗', 'park': '🅿️', 'help': '🧹', 'mkt': '🛍️', 'att': '📝', 'leave': '🌴', 'room': '📅', 'tt': '🗓️', 'hol': '🎉', 'hw': '📚', 'gc': '⚖️'};

class AppDrawer extends StatefulWidget {
  const AppDrawer({super.key});
  @override
  State<AppDrawer> createState() => _AppDrawerState();
}

class _AppDrawerState extends State<AppDrawer> {
  late Set<String> shut;
  @override
  void initState() {
    super.initState();
    final j = Prefs.json('sh-drg');
    shut = {for (final x in (j is List ? j : const [])) x.toString()};
    App.swCheck();
  }

  void _tog(String t) {
    setState(() => shut.contains(t) ? shut.remove(t) : shut.add(t));
    Prefs.setJson('sh-drg', shut.toList());
  }

  @override
  Widget build(BuildContext context) {
    final p = pal, g = S.isGuard, adm = S.isAdm;
    final nv = {for (final c in nav.navCfg()) c.$1: c};
    final groups = <(String, List<Widget>)>[];
    void close() => Navigator.of(context).pop();
    Widget it(String ic, String t, VoidCallback fn, {bool on = false, int n = 0, bool nw = false, bool out = false}) => Material(
          color: on ? p.tint : Colors.transparent,
          borderRadius: BorderRadius.circular(14),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () {
              close();
              fn();
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
              child: Row(children: [
                SizedBox(width: 28, child: Text(ic, style: const TextStyle(fontSize: 18))),
                const SizedBox(width: 6),
                Expanded(child: Text(S.sk(t), style: TextStyle(fontSize: 14.5, fontWeight: on ? FontWeight.w800 : FontWeight.w600, color: out ? p.red : (on ? p.a : p.text)))),
                if (n > 0) Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2), decoration: BoxDecoration(color: p.red, borderRadius: BorderRadius.circular(9)), child: Text('$n', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800))),
                if (nw && n == 0) Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: p.a.withOpacity(.12), borderRadius: BorderRadius.circular(6)), child: Text('NEW', style: TextStyle(color: p.a, fontSize: 9.5, fontWeight: FontWeight.w800))),
              ]),
            ),
          ),
        );
    bool onC(String v) => nav.tab == 'comm' && nav.comm == v;
    final daily = <Widget>[it('🏠', 'Home', () => nav.go('home'), on: nav.tab == 'home')];
    if (!g) {
      daily.add(it('📢', 'Notices', () {
        nav.goTab('comm');
        nav.setComm('ann');
      }, on: onC('ann')));
      if (!S.noChat) {
        daily.add(it('💬', S.kind == 'company' ? 'Team chat' : 'Chat', () {
          nav.goTab('comm');
          nav.setComm('chat');
        }, on: onC('chat')));
      }
    }
    groups.add(('Daily', daily));
    final open = D['comp'].values.where((c) => adm && c['status'] == 'Open').length;
    final sk = nav.subsK();
    groups.add((
      g ? 'Gate' : (nv['svc'] != null ? nv['svc']!.$3 : 'Services'),
      [for (final k in nav.subList()) it(subIcons[k] ?? '•', sk[k] ?? k, () => nav.go('svc:$k'), on: nav.tab == 'svc' && nav.sub == k, n: k == 'comp' ? open : 0)]
    ));
    if (!g && nv['fin'] != null) {
      groups.add(('Money', [it(S.kind == 'society' ? '💰' : '🧾', nv['fin']!.$3, () => nav.go('fin'), on: nav.tab == 'fin')]));
    }
    final X = fxList().where(fxShown).toList();
    if (X.isNotEmpty) groups.add(('More tools', [for (final k in X) it(fxDefs[k]!.ic, fxDefs[k]!.title(), () => openFx(k), nw: true)]));
    if (adm) {
      final pend = D['mem'].values.where((x) => x['status'] == 'pending').length;
      groups.add((
        'Manage',
        [
          it('👥', 'People & approvals', () => nav.go('more'), on: nav.tab == 'more', n: pend),
          it('🪪', 'ID proof & photos', () => openIdPages(navKey.currentContext!)),
          if (S.isMgr) it('⭐', 'Plan', () => nav.go('sub'), on: nav.tab == 'sub'),
        ]
      ));
    }
    final rl = S.roleLbl(S.me?['role']), fl = str(S.me?['flat']);
    final st = PlanSt.state();
    String pi = '🎁', pt = 'Free trial';
    Color pc = p.a;
    if (st.kind == 'paid') {
      final tr = PlanSt.tier(st.p);
      pi = tr.$1;
      pc = tr.$2;
      pt = st.p != null ? '${st.p!.name} plan' : 'Active plan';
    } else if (st.kind == 'locked') {
      pi = '🔒';
      pc = p.red;
      pt = st.why == 'expired' ? 'Plan expired' : 'Trial ended';
    }
    return Drawer(
      backgroundColor: p.card,
      width: 310,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.horizontal(right: Radius.circular(28))),
      child: SafeArea(
        child: Column(children: [
          Container(
            margin: const EdgeInsets.fromLTRB(12, 12, 12, 6),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(gradient: LinearGradient(colors: [p.a.withOpacity(.12), p.a2.withOpacity(.06)], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(22)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Av(str(S.me?['name']), myPhoto(), size: 50),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(str(S.me?['name']), maxLines: 1, overflow: TextOverflow.ellipsis, style: h3().copyWith(fontSize: 16)),
                    const SizedBox(height: 4),
                    Wrap(spacing: 6, runSpacing: 4, children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(color: S.isOwner ? const Color(0xFFD97706).withOpacity(.14) : adm ? p.a.withOpacity(.14) : p.card2, borderRadius: BorderRadius.circular(8)),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          if (adm) Icon(Icons.verified_user_rounded, size: 12, color: S.isOwner ? const Color(0xFFD97706) : p.a),
                          if (adm) const SizedBox(width: 3),
                          Text(rl, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: S.isOwner ? const Color(0xFFD97706) : adm ? p.a : p.muted)),
                        ]),
                      ),
                      if (fl.isNotEmpty && fl.toLowerCase() != rl.toLowerCase()) Text(fl, style: small()),
                    ]),
                  ]),
                ),
              ]),
              if (S.kidMany)
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Btn.o('⇅ Switch student', small: true, onTap: () {
                    close();
                    kidSheet(navKey.currentContext!);
                  }),
                ),
              const SizedBox(height: 10),
              Row(children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                  decoration: BoxDecoration(color: pc.withOpacity(.12), borderRadius: BorderRadius.circular(99)),
                  child: Text('$pi $pt', style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: pc)),
                ),
              ]),
              const SizedBox(height: 10),
              Material(
                color: p.card,
                borderRadius: BorderRadius.circular(14),
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: S.swCan
                      ? () {
                          close();
                          sheet(navKey.currentContext!, (_) => const SocRows(title: true));
                        }
                      : null,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    child: Row(children: [
                      Expanded(child: Text('${S.K.ico} ${str(S.soc?['name'])}', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w700, color: p.text))),
                      if (S.swCan) Text('Switch ⇅', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: p.a)),
                    ]),
                  ),
                ),
              ),
            ]),
          ),
          Expanded(
            child: ListView(padding: const EdgeInsets.fromLTRB(10, 4, 10, 8), children: [
              for (final gr in groups) ...[
                InkWell(
                  borderRadius: BorderRadius.circular(10),
                  onTap: () => _tog(gr.$1),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(10, 12, 10, 6),
                    child: Row(children: [
                      Expanded(child: Text(S.sk(gr.$1).toUpperCase(), style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: .9, color: p.muted))),
                      AnimatedRotation(turns: shut.contains(gr.$1) ? -.25 : 0, duration: const Duration(milliseconds: 200), child: Icon(Icons.expand_more_rounded, size: 18, color: p.muted)),
                    ]),
                  ),
                ),
                AnimatedSize(duration: const Duration(milliseconds: 220), curve: Curves.easeOutCubic, child: shut.contains(gr.$1) ? const SizedBox(width: double.infinity) : Column(children: gr.$2)),
              ],
            ]),
          ),
          Divider(height: 1, color: p.line),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 6, 10, 6),
            child: Column(children: [
              it('👤', 'My profile', () => nav.go('more')),
              it('💜', '$brand Support', () => openSupport(navKey.currentContext!, true)),
              it('📄', 'Privacy Policy', () => openLegal(navKey.currentContext!, 'privacy')),
              it('📃', 'Terms & Conditions', () => openLegal(navKey.currentContext!, 'terms')),
              it('↩️', 'Log out', App.logout, out: true),
            ]),
          ),
        ]),
      ),
    );
  }
}

/// "Switch student" (a parent with more than one child in the school)
void kidSheet(BuildContext context) => sheet(context, (_) => const KidRows(title: true));

class KidRows extends StatelessWidget {
  final bool title;
  const KidRows({super.key, this.title = false});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    return ListenableBuilder(
      listenable: S,
      builder: (_, __) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        if (title) const SheetTitle('Switch student'),
        for (final k in S.myProfiles())
          Ex(
            str(k['name']),
            sub: str(k['flat']) + (k['status'] != null && k['status'] != 'approved' ? ' · ${k['status'] == 'pending' ? 'waiting for the class teacher' : str(k['status'])}' : ''),
            lead: Av(str(k['name']), k['id'] == S.uid ? photoOf(S.uid) : str(k['photoUrl']), size: 38),
            right: k['id'] == S.pidv
                ? Text('Active', style: TextStyle(color: p.green, fontWeight: FontWeight.w800))
                : k['status'] == 'approved'
                    ? mini('Switch', () {
                        final n = Navigator.of(context);
                        if (n.canPop()) n.pop();
                        Kids.switchKid(str(k['id']));
                      })
                    : null,
          ),
      ]),
    );
  }
}
