import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import '../core/api.dart';
import '../core/kb.dart';
import '../core/kinds.dart';
import '../core/nav.dart';
import '../core/plan.dart';
import '../core/session.dart';
import '../core/support_ctx.dart';
import '../core/toast.dart';
import '../core/util.dart';
import '../ui/theme.dart';
import 'fx/fx.dart';
import '../l10n/l10n.dart';

/* ===== Sangam360 Support: built-in answers first, the server's assistant for the rest, then e-mail ===== */

String _kbN(String k) {
  try {
    final c = nav.navCfg().where((x) => x.$1 == k);
    if (c.isNotEmpty) return c.first.$3;
  } catch (_) {}
  return const {'svc': 'Services', 'comm': 'Community', 'fin': 'Finance'}[k] ?? k;
}

SupportCtx spC() {
  final K = S.K;
  bool g(bool Function() f) {
    try {
      return S.me != null && f();
    } catch (_) {
      return false;
    }
  }

  final L = PlanSt.list();
  final u = S.kind == 'society'
      ? 'flats'
      : S.kind == 'company'
          ? 'employees'
          : 'users';
  final rows = L.where((p) => p.m > 0 || p.cu).map((p) => '• ${p.name}: ${p.cu ? 'custom' : trf('₹{0}/mo', [p.m])} · ${p.max >= 1e9 ? 'unlimited' : trf('up to {0}', [p.max.toInt()])} $u').join('\n');
  var payOn = false, tools = <String>[], navS = '';
  try {
    payOn = fxList().contains('pay') && fxShown('pay');
    tools = S.me == null ? [] : fxList().where(fxShown).map((k) => fxDefs[k]!.title()).toList();
    navS = S.me == null ? '' : nav.navCfg().map((x) => x.$3).join(', ');
  } catch (_) {}
  return SupportCtx(
    k: S.kind,
    card: K.card,
    org: K.word,
    per: K.person.toLowerCase(),
    Per: K.person,
    unit: K.unit.toLowerCase(),
    fee: K.fee,
    svc: _kbN('svc'),
    comm: _kbN('comm'),
    fin: _kbN('fin'),
    me: g(() => S.isAdm) ? 'People' : 'Me',
    boss: S.kind == 'school' ? 'Principal' : 'main admin',
    nav: navS,
    planRows: rows,
    sub: S.me == null ? {} : nav.subsK(),
    adm: g(() => S.isAdm),
    own: g(() => S.isOwner),
    grd: g(() => S.isGuard),
    soc: S.kind == 'society',
    com: S.kind == 'company',
    sch: S.kind == 'school',
    tch: g(() => S.isTeacher),
    stu: g(() => S.kind == 'school' && !S.isAdm && S.isStu(S.me)),
    drv: g(() => S.isDrv),
    acc: g(() => S.role == 'ACCOUNTANT'),
    payOn: payOn,
    tools: tools,
  );
}

List<(KbEntry, double)> spRank(String q) {
  final c = spC();
  final r = kbEntries.map((e) {
    var w = 1.0;
    try {
      if (e.on != null && !e.on!(c)) w = .45;
    } catch (_) {}
    return (e, spScore(q, e) * w);
  }).toList();
  r.sort((a, b) => b.$2.compareTo(a.$2));
  return r;
}

String spKnow(String q, int max) {
  final c = spC();
  var role = c.adm
      ? tr('an admin')
      : c.grd
          ? tr('a security guard')
          : 'a ${c.per}';
  try {
    role = c.own
        ? trf('the {0} (main admin)', [c.boss])
        : c.drv
            ? tr('a school bus driver')
            : c.stu
                ? tr('a student or the parent of one')
                : S.roleLbl(S.me?['role']).toLowerCase();
  } catch (_) {}
  final skip = {'Greeting', 'Thanks', tr('Contact support')};
  final arts = spRank(q).where((x) => !skip.contains(x.$1.t)).map((x) {
    var a = '';
    try {
      a = x.$1.a(c);
    } catch (_) {}
    return a.isEmpty ? '' : '[${x.$1.t}] ${a.replaceAll(RegExp(r'\s*\n\s*'), ' ').replaceFirst(RegExp(r'^[^A-Za-z0-9“"‘☰]+'), '')}';
  }).where((x) => x.isNotEmpty);
  var out = trf('This workspace is a {0} and the user is {1} ({2}s are the members). Bottom tabs: {3}. The ☰ button (top left) opens the side menu with every screen{4}. The HELP ARTICLES below describe every feature of the app for THIS user, most relevant first. Answer only from them, with the exact tab and button names. A feature described there exists in the app: never say it does not. If an article says a feature is for another kind of workspace or another role, say that. If something is in no article, say it is not in the app yet and suggest emailing support.\nHELP ARTICLES:\n', [c.org, role, c.per, (c.nav.isNotEmpty ? c.nav : 'Home, ${c.svc}, ${c.comm}, ${c.fin}, ${c.me}'), (c.tools.isNotEmpty ? trf('; its More tools section has: {0}', [c.tools.join(', ')]) : '')]);
  for (final a in arts) {
    if (out.length + a.length + 1 > max) break;
    out += '$a\n';
  }
  return out;
}

bool _aiNo = false;
bool spAiCan() {
  try {
    return payApi.isNotEmpty && S.sid != null && S.me != null && !_aiNo && !(S.kind == 'school' && S.isStu(S.me));
  } catch (_) {
    return false;
  }
}

Future<String?> freeAI(String q, bool haveKb) async {
  try {
    if (spAiCan()) {
      try {
        final g = await api('/v1/support/ask', {'sid': S.sid, 'profileId': S.pidv, 'q': cut(q, 300), 'context': spKnow(q, 22000)}, 20000);
        if (str(g['reply']).isNotEmpty) return cut(str(g['reply']), 1500);
      } catch (e) {
        if (e is AppError && ['ai-not-available', 'ai-off', 'ai-limit'].contains(e.code)) _aiNo = true;
      }
    }
    if (haveKb) return null;
    final sys = trf('You are Sangam360 Support, the assistant inside the {0} app for housing societies, companies and schools. Answer ONLY about this app, in the user language (Hindi, Hinglish or English), plain text, max 70 words, step by step with tab names. {1}', [brand, spKnow(q, 2300)]);
    final r = await http.get(Uri.parse('https://text.pollinations.ai/${Uri.encodeComponent(cut(q, 300))}?model=openai&system=${Uri.encodeComponent(sys)}')).timeout(const Duration(seconds: 12));
    if (r.statusCode != 200) return null;
    final x = r.body.trim();
    return x.isNotEmpty && x.length < 1500 ? x : null;
  } catch (_) {
    return null;
  }
}

List<String> _quick() => S.kind == 'company'
    ? ['Check in / out', 'Apply for leave', 'Raise an invoice', 'Pay a bill']
    : S.kind == 'school'
        ? ['Attendance', 'Timetable & homework', 'Pay a bill', 'Apply for leave']
        : ['Invite a visitor', 'Raise a complaint', 'Chat', 'Pay a bill'];

class _Msg {
  final String who; // u | b | chips | mail | typing
  final String text;
  final List<String> chips;
  _Msg(this.who, this.text, [this.chips = const []]);
}

/// the conversation lives as long as the app
final List<_Msg> _log = [];
final List<String> _plain = [];
int _spN = 0;

void openSupport(BuildContext context, [bool open = true]) {
  payWarm();
  Navigator.of(context).push(PageRouteBuilder(
    opaque: false,
    barrierColor: Colors.black38,
    barrierDismissible: true,
    transitionDuration: const Duration(milliseconds: 320),
    pageBuilder: (_, __, ___) => const SupportPage(),
    transitionsBuilder: (_, a, __, c) => SlideTransition(position: Tween(begin: const Offset(0, 1), end: Offset.zero).animate(CurvedAnimation(parent: a, curve: Curves.easeOutCubic)), child: c),
  ));
}

void _mailTo() {
  final b = trf('Hi Support,\n\n(Describe your problem here)\n\n---\nName: {0}\nFlat: {1}\nSociety: {2}\nApp: {3}\n\nChat with assistant:\n{4}', [(str(S.me?['name'])), (str(S.me?['flat'])), (str(S.soc?['name'])), brand, _tail(_plain.join('\n'), 1200)]);
  launchUrl(Uri.parse('mailto:$supportEmail?subject=${Uri.encodeComponent('$brand support request')}&body=${Uri.encodeComponent(b)}')).catchError((_) {
    toast('ℹ️', tr('No e-mail app'), supportEmail);
    return false;
  });
}

String _tail(String s, int n) => s.length > n ? s.substring(s.length - n) : s;

class SupportPage extends StatefulWidget {
  const SupportPage({super.key});
  @override
  State<SupportPage> createState() => _SupportPageState();
}

class _SupportPageState extends State<SupportPage> {
  final _t = TextEditingController();
  final _sc = ScrollController();

  @override
  void initState() {
    super.initState();
    if (_log.isEmpty) {
      _add(_Msg('b', trf('Hi{0}! 👋 I’m Sangam360 Support. Ask me anything about {1}.', [(S.me != null ? ' ${firstName(str(S.me!['name']))}' : ''), brand])));
      _add(_Msg('chips', '', _quick()));
    }
  }

  void _add(_Msg m) {
    _log.add(m);
    if (m.who == 'u' || m.who == 'b') _plain.add('${m.who == 'u' ? tr('Me: ') : tr('Bot: ')}${m.text}');
    if (mounted) setState(() {});
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_sc.hasClients) _sc.animateTo(_sc.position.maxScrollExtent + 200, duration: const Duration(milliseconds: 260), curve: Curves.easeOut);
    });
  }

  Future<void> _ask(String q0) async {
    final q = q0.trim();
    if (q.isEmpty) return;
    _log.removeWhere((m) => m.who == 'chips');
    _add(_Msg('u', q));
    if (q.startsWith('👍')) {
      _add(_Msg('b', tr('Glad I could help! 😊')));
      return;
    }
    if (q.startsWith('👎')) {
      _add(_Msg('b', tr('Sorry about that! Let our team help you directly.')));
      _add(_Msg('mail', ''));
      return;
    }
    final ty = _Msg('typing', '');
    _add(ty);
    String? r;
    KbEntry? m;
    String? kb;
    KbEntry? km;
    var sure = false;
    final rk = spRank(q);
    if (rk.isNotEmpty && rk.first.$2 >= 2) {
      km = rk.first.$1;
      try {
        kb = km.a(spC());
      } catch (_) {
        kb = null;
      }
      if (kb != null && hingRe.hasMatch(spNorm(q))) kb = trf('👍 Ye raha jawab:\n{0}', [kb]);
      sure = rk.first.$2 >= 4 || spNorm(q).split(' ').length <= 3 || !spAiCan();
    }
    if (kb != null && sure) {
      r = kb;
      m = km;
      await Future.delayed(Duration(milliseconds: 450 + Random().nextInt(350)));
    }
    if (r == null) {
      r = await freeAI(q, kb != null);
      if (r == null && kb != null) {
        r = kb;
        m = km;
      }
    }
    _log.remove(ty);
    if (r != null) {
      _spN = 0;
      _add(_Msg('b', r));
      if (m != null && m.m) {
        _add(_Msg('mail', ''));
      } else {
        _add(_Msg('chips', '', ['👍 Helpful', '👎 Not helpful']));
      }
    } else {
      _spN++;
      final alt = spRank(q).where((x) => x.$2 > 0).take(3).map((x) => x.$1.t).toList();
      _add(_Msg('b', tr('I’m not sure about that one yet — did you mean one of these?')));
      _add(_Msg('chips', '', alt.isNotEmpty ? alt : _quick()));
      if (_spN >= 2) _add(_Msg('mail', ''));
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    final h = MediaQuery.of(context).size.height;
    return Align(
      alignment: Alignment.bottomCenter,
      child: Material(
        color: p.card,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        clipBehavior: Clip.antiAlias,
        child: SizedBox(
          height: h * .86,
          child: Padding(
            padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
            child: Column(children: [
              Container(
                padding: const EdgeInsets.fromLTRB(16, 16, 8, 14),
                decoration: BoxDecoration(gradient: LinearGradient(colors: [const Color(0xFF3B5BFD), const Color(0xFF9A4DFF).withOpacity(.95)])),
                child: Row(children: [
                  Container(width: 42, height: 42, decoration: BoxDecoration(color: Colors.white.withOpacity(.2), shape: BoxShape.circle), alignment: Alignment.center, child: const Icon(Icons.auto_awesome_rounded, color: Colors.white)),
                  const SizedBox(width: 12),
                   Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(tr('Sangam360 Support'), style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16)),
                      Text(tr('Usually answers instantly'), style: TextStyle(color: Colors.white70, fontSize: 12)),
                    ]),
                  ),
                  IconButton(tooltip: tr('Email support'), onPressed: _mailTo, icon: const Icon(Icons.mail_outline_rounded, color: Colors.white)),
                  IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close_rounded, color: Colors.white)),
                ]),
              ),
              Expanded(
                child: ListView.builder(
                  controller: _sc,
                  padding: const EdgeInsets.all(14),
                  itemCount: _log.length,
                  itemBuilder: (_, i) {
                    final m = _log[i];
                    if (m.who == 'typing') {
                      return Align(alignment: Alignment.centerLeft, child: Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12), decoration: BoxDecoration(color: p.card2, borderRadius: BorderRadius.circular(18)), child: const _TypingDots()));
                    }
                    if (m.who == 'chips') {
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Wrap(spacing: 8, runSpacing: 8, children: [
                          for (final c in m.chips)
                            ActionChip(
                              label: Text(c, style: TextStyle(fontWeight: FontWeight.w600, color: p.a)),
                              backgroundColor: p.tint,
                              side: BorderSide(color: p.a.withOpacity(.2)),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(99)),
                              onPressed: () => _ask(c),
                            ),
                        ]),
                      );
                    }
                    if (m.who == 'mail') {
                      return Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(color: p.card2, borderRadius: BorderRadius.circular(18)),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                          Text(tr('Not solved? Our team will help you personally 💌'), style: body()),
                          const SizedBox(height: 10),
                          FilledButton.icon(onPressed: _mailTo, icon: const Icon(Icons.mail_rounded, size: 18), label:  Text(trf('Email {0}', [supportEmail]))),
                          const SizedBox(height: 6),
                          OutlinedButton.icon(
                              onPressed: () {
                                Clipboard.setData(const ClipboardData(text: supportEmail));
                                toast('📋', tr('Email copied'));
                              },
                              icon: const Icon(Icons.copy_rounded, size: 18),
                              label:  Text(tr('Copy email address'))),
                        ]),
                      );
                    }
                    final mine = m.who == 'u';
                    return Align(
                      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .8),
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        decoration: BoxDecoration(
                          gradient: mine ? p.grad : null,
                          color: mine ? null : p.card2,
                          borderRadius: BorderRadius.only(topLeft: const Radius.circular(18), topRight: const Radius.circular(18), bottomLeft: Radius.circular(mine ? 18 : 4), bottomRight: Radius.circular(mine ? 4 : 18)),
                        ),
                        child: SelectableText(m.text, style: TextStyle(color: mine ? Colors.white : p.text, fontSize: 14.5, height: 1.45)),
                      ),
                    );
                  },
                ),
              ),
              SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
                  child: Row(children: [
                    Expanded(
                      child: TextField(
                        controller: _t,
                        textInputAction: TextInputAction.send,
                        onSubmitted: (v) {
                          _t.clear();
                          _ask(v);
                        },
                        decoration: InputDecoration(hintText: tr('Type your question…'), border: OutlineInputBorder(borderRadius: BorderRadius.circular(99), borderSide: BorderSide(color: p.line)), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(99), borderSide: BorderSide(color: p.line))),
                      ),
                    ),
                    const SizedBox(width: 8),
                    GestureDetector(
                      onTap: () {
                        final v = _t.text;
                        _t.clear();
                        _ask(v);
                      },
                      child: Container(width: 48, height: 48, decoration: BoxDecoration(gradient: p.grad, shape: BoxShape.circle), child: const Icon(Icons.send_rounded, color: Colors.white, size: 21)),
                    ),
                  ]),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

class _TypingDots extends StatefulWidget {
  const _TypingDots();
  @override
  State<_TypingDots> createState() => _TypingDotsState();
}

class _TypingDotsState extends State<_TypingDots> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat();
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _c,
        builder: (_, __) => Row(
            mainAxisSize: MainAxisSize.min,
            children: List.generate(3, (i) {
              final t = (_c.value - i * .2) % 1.0;
              return Container(margin: const EdgeInsets.symmetric(horizontal: 2.5), width: 7, height: 7, decoration: BoxDecoration(color: pal.muted.withOpacity(.3 + .7 * (t < .5 ? t * 2 : (1 - t) * 2)), shape: BoxShape.circle));
            })),
      );
}
