import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/toast.dart';
import 'theme.dart';

/// shakes its child whenever [trigger] changes (wrong input)
class Shake extends StatefulWidget {
  final Widget child;
  final int trigger;
  const Shake({super.key, required this.child, required this.trigger});
  @override
  State<Shake> createState() => _ShakeState();
}

class _ShakeState extends State<Shake> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 420));
  @override
  void didUpdateWidget(Shake o) {
    super.didUpdateWidget(o);
    if (o.trigger != widget.trigger) {
      HapticFeedback.mediumImpact();
      _c.forward(from: 0);
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _c,
        builder: (_, child) => Transform.translate(offset: Offset(sin(_c.value * pi * 6) * 9 * (1 - _c.value), 0), child: child),
        child: widget.child,
      );
}

/// the "done" moment: a check that draws itself, title, text and confetti; goes by itself (fx of the earlier app)
void fxDone(String title, [String sub = '', bool confetti = true, int ms = 2200, String? icon]) {
  final ov = navKey.currentState?.overlay;
  if (ov == null) return;
  late OverlayEntry e;
  var gone = false;
  void close() {
    if (gone) return;
    gone = true;
    e.remove();
  }

  e = OverlayEntry(builder: (_) => _FxDone(title: title, sub: sub, confetti: confetti, icon: icon, onClose: close));
  ov.insert(e);
  HapticFeedback.mediumImpact();
  Future.delayed(Duration(milliseconds: ms), close);
}

class _FxDone extends StatefulWidget {
  final String title, sub;
  final bool confetti;
  final String? icon;
  final VoidCallback onClose;
  const _FxDone({required this.title, required this.sub, required this.confetti, required this.onClose, this.icon});
  @override
  State<_FxDone> createState() => _FxDoneState();
}

class _FxDoneState extends State<_FxDone> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..forward();
  final _r = Random();
  late final List<List<double>> _bits = List.generate(28, (i) => [_r.nextDouble(), _r.nextDouble() * .35, _r.nextDouble() * 140 - 70, _r.nextDouble() * 12, i.toDouble()]);
  static const _cols = [Color(0xFF5B3DF5), Color(0xFFFF8A1F), Color(0xFF10B981), Color(0xFFF43F5E), Color(0xFF3B82F6)];
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    return GestureDetector(
      onTap: widget.onClose,
      child: Material(
        color: Colors.black.withOpacity(.25),
        child: AnimatedBuilder(
          animation: _c,
          builder: (_, __) {
            final t = _c.value;
            final pop = Curves.easeOutBack.transform((t * 2.5).clamp(0.0, 1.0));
            final sz = MediaQuery.of(context).size;
            return Stack(children: [
              if (widget.confetti)
                for (final b in _bits)
                  Builder(builder: (_) {
                    final k = ((t - b[1]) / (1 - b[1])).clamp(0.0, 1.0);
                    return Positioned(
                      left: b[0] * sz.width + b[2] * k,
                      top: -20 + k * sz.height * .9,
                      child: Transform.rotate(angle: b[3] * k, child: Opacity(opacity: 1 - k * .6, child: Container(width: 8, height: 13, decoration: BoxDecoration(color: _cols[b[4].toInt() % 5], borderRadius: BorderRadius.circular(2))))),
                    );
                  }),
              Center(
                child: Transform.scale(
                  scale: .6 + .4 * pop,
                  child: Opacity(
                    opacity: pop.clamp(0.0, 1.0),
                    child: Container(
                      width: 270,
                      padding: const EdgeInsets.fromLTRB(22, 26, 22, 22),
                      decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(28), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.18), blurRadius: 40, offset: const Offset(0, 16))]),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        widget.icon != null
                            ? Text(widget.icon!, style: const TextStyle(fontSize: 54))
                            : SizedBox(width: 72, height: 72, child: CustomPaint(painter: _Check((t * 1.8).clamp(0.0, 1.0), p.green))),
                        const SizedBox(height: 14),
                        Text(widget.title, textAlign: TextAlign.center, style: h2().copyWith(fontSize: 19)),
                        if (widget.sub.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(widget.sub, textAlign: TextAlign.center, style: meta().copyWith(fontSize: 13.5))),
                      ]),
                    ),
                  ),
                ),
              ),
            ]);
          },
        ),
      ),
    );
  }
}

class _Check extends CustomPainter {
  final double t;
  final Color c;
  _Check(this.t, this.c);
  @override
  void paint(Canvas cv, Size s) {
    final p = Paint()
      ..color = c
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4.5
      ..strokeCap = StrokeCap.round;
    final r = Rect.fromLTWH(4, 4, s.width - 8, s.height - 8);
    cv.drawArc(r, -pi / 2, 2 * pi * (t / .6).clamp(0.0, 1.0), false, p);
    cv.drawCircle(r.center, r.width / 2, Paint()..color = c.withOpacity(.08 * t));
    final k = ((t - .55) / .45).clamp(0.0, 1.0);
    if (k > 0) {
      final a = Offset(s.width * .28, s.height * .52), b = Offset(s.width * .44, s.height * .67), d = Offset(s.width * .74, s.height * .36);
      final path = Path()..moveTo(a.dx, a.dy);
      if (k < .4) {
        final q = Offset.lerp(a, b, k / .4)!;
        path.lineTo(q.dx, q.dy);
      } else {
        path.lineTo(b.dx, b.dy);
        final q = Offset.lerp(b, d, (k - .4) / .6)!;
        path.lineTo(q.dx, q.dy);
      }
      cv.drawPath(path, p);
    }
  }

  @override
  bool shouldRepaint(_Check o) => o.t != t;
}

/// a ring that fills (percent 0..1)
class Ring extends StatelessWidget {
  final double value;
  final double size, stroke;
  final Color? color;
  final Widget? center;
  const Ring(this.value, {super.key, this.size = 84, this.stroke = 9, this.color, this.center});
  @override
  Widget build(BuildContext context) => TweenAnimationBuilder<double>(
        tween: Tween(begin: 0, end: value.clamp(0, 1)),
        duration: const Duration(milliseconds: 1100),
        curve: Curves.easeOutCubic,
        builder: (_, v, __) => SizedBox(
          width: size,
          height: size,
          child: CustomPaint(
            painter: _RingP(v, color ?? pal.a, pal.card2, stroke),
            child: Center(child: center),
          ),
        ),
      );
}

class _RingP extends CustomPainter {
  final double v, w;
  final Color c, bg;
  _RingP(this.v, this.c, this.bg, this.w);
  @override
  void paint(Canvas cv, Size s) {
    final r = Rect.fromLTWH(w / 2, w / 2, s.width - w, s.height - w);
    cv.drawArc(r, 0, 2 * pi, false, Paint()
      ..color = bg
      ..style = PaintingStyle.stroke
      ..strokeWidth = w);
    cv.drawArc(r, -pi / 2, 2 * pi * v, false, Paint()
      ..color = c
      ..style = PaintingStyle.stroke
      ..strokeWidth = w
      ..strokeCap = StrokeCap.round);
  }

  @override
  bool shouldRepaint(_RingP o) => o.v != v || o.c != c;
}
