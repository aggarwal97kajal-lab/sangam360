import 'dart:math';
import 'dart:ui';

import 'package:flutter/material.dart';

import '../core/kinds.dart';
import 'theme.dart';
import '../l10n/l10n.dart';
import '../screens/lang.dart';

/// "Sangam360" with the coloured digits of the logo
class BrandText extends StatelessWidget {
  final double size;
  final Color? color;
  const BrandText({super.key, this.size = 28, this.color});
  @override
  Widget build(BuildContext context) {
    final c = color ?? pal.text;
    final st = TextStyle(fontSize: size, fontWeight: FontWeight.w800, letterSpacing: -.6, color: c, fontFamily: fontFam);
    return Text.rich(TextSpan(style: st, children:  [
      TextSpan(text: tr('Sangam')),
      TextSpan(text: '3', style: TextStyle(color: Color(0xFF19D3A0))),
      TextSpan(text: '6', style: TextStyle(color: Color(0xFF2F9BFF))),
      TextSpan(text: '0', style: TextStyle(color: Color(0xFFFFA41B))),
    ]));
  }
}

class Logo extends StatelessWidget {
  final double size;
  const Logo({super.key, this.size = 44});
  @override
  Widget build(BuildContext context) => ClipRRect(
        borderRadius: BorderRadius.circular(size * .28),
        child: Image.asset('assets/images/mark.png', width: size, height: size, fit: BoxFit.cover, errorBuilder: (_, __, ___) => SizedBox(width: size, height: size)),
      );
}

/// logo + name + a line under it
class BrandHead extends StatelessWidget {
  final String? sub;
  final String? title;
  const BrandHead({super.key, this.sub, this.title});
  @override
  Widget build(BuildContext context) => Column(children: [
        const Logo(size: 64),
        const SizedBox(height: 14),
        title == null ? const BrandText(size: 30) : Text(title!, textAlign: TextAlign.center, style: h1()),
        if (sub != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text(sub!, textAlign: TextAlign.center, style: meta().copyWith(fontSize: 14))),
      ]);
}

/// slowly drifting soft colour orbs behind the content (the light-minimal hero look)
class Aurora extends StatefulWidget {
  final Widget? child;
  final double strength;
  final List<Color>? colors;
  final bool animate;
  const Aurora({super.key, this.child, this.strength = 1, this.colors, this.animate = true});
  @override
  State<Aurora> createState() => _AuroraState();
}

class _AuroraState extends State<Aurora> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 18), value: .3);
  @override
  void initState() {
    super.initState();
    if (widget.animate) _c.repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    final cols = widget.colors ?? [p.a, p.a2, p.rc];
    return Stack(children: [
      Positioned.fill(
        child: RepaintBoundary(
          child: AnimatedBuilder(
            animation: _c,
            builder: (_, __) => CustomPaint(painter: _OrbPainter(_c.value, cols, p.dark, widget.strength)),
          ),
        ),
      ),
      if (widget.child != null) widget.child!,
    ]);
  }
}

class _OrbPainter extends CustomPainter {
  final double t, k;
  final List<Color> c;
  final bool dark;
  _OrbPainter(this.t, this.c, this.dark, this.k);
  @override
  void paint(Canvas canvas, Size s) {
    final a = t * 2 * pi;
    final orbs = [
      (Offset(s.width * (.15 + .1 * sin(a)), s.height * (.18 + .08 * cos(a))), s.width * .55, c[0]),
      (Offset(s.width * (.85 + .08 * cos(a * 1.3)), s.height * (.12 + .1 * sin(a * .8))), s.width * .5, c[1 % c.length]),
      (Offset(s.width * (.6 + .12 * sin(a * .7)), s.height * (.75 + .06 * cos(a * 1.1))), s.width * .6, c[2 % c.length]),
    ];
    for (final o in orbs) {
      final paint = Paint()
        ..shader = RadialGradient(colors: [o.$3.withOpacity((dark ? .28 : .20) * k), o.$3.withOpacity(0)]).createShader(Rect.fromCircle(center: o.$1, radius: o.$2));
      canvas.drawCircle(o.$1, o.$2, paint);
    }
  }

  @override
  bool shouldRepaint(_OrbPainter o) => o.t != t || o.dark != dark;
}

/// a frosted panel (used on top of the aurora)
class Glass extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  const Glass({super.key, required this.child, this.padding = const EdgeInsets.all(20), this.radius = 26});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          color: p.card.withOpacity(p.dark ? .94 : .96),
          borderRadius: BorderRadius.circular(radius),
          border: Border.all(color: p.dark ? Colors.white.withOpacity(.06) : Colors.white.withOpacity(.9)),
          boxShadow: p.shadow,
        ),
        child: child,
      ),
    );
  }
}

/// the screens before the dashboard (landing, sign-in, create, join, waiting)
class BootPage extends StatelessWidget {
  final List<Widget> children;
  final Widget? head;
  final bool glass;
  const BootPage({super.key, required this.children, this.head, this.glass = true});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    return Scaffold(
      backgroundColor: p.bg,
      body: Aurora(
        child: SafeArea(
          child: Stack(children: [
            Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(18, 40, 18, 30),
                physics: const BouncingScrollPhysics(),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 480),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    if (head != null) ...[head!, const SizedBox(height: 22)],
                    glass ? Glass(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: children)) : Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: children),
                  ]),
                ),
              ),
            ),
            // the language can be changed before logging in
            const Positioned(top: 2, right: 6, child: LangChip()),
          ]),
        ),
      ),
    );
  }
}

/// a red line under a form
class ErrText extends StatelessWidget {
  final String text;
  const ErrText(this.text, {super.key});
  @override
  Widget build(BuildContext context) => AnimatedSize(
        duration: const Duration(milliseconds: 200),
        child: text.isEmpty
            ? const SizedBox(width: double.infinity)
            : Padding(padding: const EdgeInsets.only(top: 10), child: Text(text, textAlign: TextAlign.center, style: TextStyle(color: text.contains('✔') ? pal.green : pal.red, fontSize: 13.5, fontWeight: FontWeight.w600, height: 1.4))),
      );
}

/// a text link
class Lnk extends StatelessWidget {
  final String text;
  final VoidCallback? onTap;
  final Color? color;
  const Lnk(this.text, {super.key, this.onTap, this.color});
  @override
  Widget build(BuildContext context) => Center(
        child: TextButton(onPressed: onTap, child: Text(text, style: TextStyle(color: color ?? pal.a, fontWeight: FontWeight.w700, fontSize: 14))),
      );
}

const tagLine = tagline;
