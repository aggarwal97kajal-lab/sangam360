import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import '../core/session.dart';
import '../core/util.dart';
import 'sheets.dart';
import 'theme.dart';
import '../l10n/l10n.dart';

/// A text field with a floating label, an eye for passwords, a character counter for long fields and a live
/// "formatted" echo for phone numbers and amounts (the value itself is never changed).
class Field extends StatefulWidget {
  final TextEditingController c;
  final String label;
  final String? hint;
  final int? max;
  final int lines;
  final TextInputType? kb;
  final bool password, upper, enabled, autofocus, center, digitsOnly;
  final ValueChanged<String>? onChanged;
  final ValueChanged<String>? onSubmit;
  final double? spacing;
  final EdgeInsets margin;
  final Widget? suffix;
  final FocusNode? focus;
  final TextInputAction? action;
  const Field(this.c, this.label,
      {super.key,
      this.hint,
      this.max,
      this.lines = 1,
      this.kb,
      this.password = false,
      this.upper = false,
      this.enabled = true,
      this.autofocus = false,
      this.center = false,
      this.digitsOnly = false,
      this.onChanged,
      this.onSubmit,
      this.spacing,
      this.margin = const EdgeInsets.only(bottom: 12),
      this.suffix,
      this.focus,
      this.action});
  @override
  State<Field> createState() => _FieldState();
}

class _FieldState extends State<Field> {
  bool _show = false;
  @override
  void initState() {
    super.initState();
    widget.c.addListener(_l);
  }

  @override
  void didUpdateWidget(Field old) {
    super.didUpdateWidget(old);
    if (old.c != widget.c) {
      old.c.removeListener(_l);
      widget.c.addListener(_l);
    }
  }

  @override
  void dispose() {
    widget.c.removeListener(_l);
    super.dispose();
  }

  void _l() {
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    final lab = S.sk(widget.label), lo = '$lab ${widget.hint ?? ''}'.toLowerCase();
    final isTel = widget.kb == TextInputType.phone || RegExp('mobile|phone').hasMatch(lo);
    final isAmt = widget.kb == TextInputType.number && RegExp(r'amount|₹|price|rent|salary|deposit|charge|fine').hasMatch(lo);
    String echo = '';
    final v = widget.c.text;
    if (isTel) {
      final d = v.replaceAll(RegExp(r'\D'), '');
      echo = d.length >= 6 ? '📞 ${flPhone(d)}' : '';
    } else if (isAmt) {
      final a = num.tryParse(v);
      echo = v.isNotEmpty && a != null && a > 0 ? rs(a) : '';
    }
    final showCount = widget.max != null && (widget.lines > 1 || widget.max! >= 60) && !widget.password;
    return Padding(
      padding: widget.margin,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
        TextField(
          controller: widget.c,
          focusNode: widget.focus,
          enabled: widget.enabled,
          autofocus: widget.autofocus,
          obscureText: widget.password && !_show,
          maxLines: widget.password ? 1 : widget.lines,
          minLines: widget.lines > 1 ? 2 : 1,
          maxLength: widget.max,
          keyboardType: widget.lines > 1 ? TextInputType.multiline : widget.kb,
          textInputAction: widget.action ?? (widget.lines > 1 ? TextInputAction.newline : TextInputAction.next),
          textCapitalization: widget.upper ? TextCapitalization.characters : TextCapitalization.sentences,
          textAlign: widget.center ? TextAlign.center : TextAlign.start,
          inputFormatters: [
            if (widget.upper) _Upper(),
            if (widget.digitsOnly) FilteringTextInputFormatter.digitsOnly,
          ],
          style: TextStyle(fontSize: 15, color: p.text, letterSpacing: widget.spacing, fontWeight: widget.spacing != null ? FontWeight.w700 : FontWeight.w500),
          onChanged: widget.onChanged,
          onSubmitted: widget.onSubmit,
          decoration: InputDecoration(
            labelText: lab,
            hintText: widget.hint,
            counterText: showCount ? null : '',
            alignLabelWithHint: widget.lines > 1,
            suffixIcon: widget.password
                ? IconButton(icon: Icon(_show ? Icons.visibility_off_rounded : Icons.visibility_rounded, color: p.muted), onPressed: () => setState(() => _show = !_show))
                : widget.suffix,
          ),
        ),
        if (echo.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4, left: 6), child: Text(echo, style: TextStyle(fontSize: 12.5, color: p.a, fontWeight: FontWeight.w600))),
      ]),
    );
  }
}

class _Upper extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(TextEditingValue o, TextEditingValue n) => n.copyWith(text: n.text.toUpperCase());
}

/// a field-like button (dropdowns, dates)
class _Box extends StatelessWidget {
  final String label, text;
  final bool ph;
  final IconData icon;
  final VoidCallback? onTap;
  final EdgeInsets margin;
  const _Box({required this.label, required this.text, required this.ph, required this.icon, this.onTap, this.margin = const EdgeInsets.only(bottom: 12)});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    return Padding(
      padding: margin,
      child: Material(
        color: p.card,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Container(
            constraints: const BoxConstraints(minHeight: 54),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), border: Border.all(color: p.line)),
            child: Row(children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                  if (!ph && label.isNotEmpty) Text(label, style: TextStyle(fontSize: 11.5, color: p.muted, fontWeight: FontWeight.w600)),
                  Text(ph ? label : text, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 15, color: ph ? p.faint : p.text, fontWeight: ph ? FontWeight.w400 : FontWeight.w500)),
                ]),
              ),
              Icon(icon, size: 20, color: onTap == null ? p.faint : p.a),
            ]),
          ),
        ),
      ),
    );
  }
}

/// a dropdown that opens a sheet (with search when there are many choices)
class SelectField extends StatelessWidget {
  final String label;
  final String? value;
  final List<(String, String)> opts;
  final ValueChanged<String>? onChanged;
  final EdgeInsets margin;
  final String? title;
  const SelectField(this.label, this.value, this.opts, this.onChanged, {super.key, this.margin = const EdgeInsets.only(bottom: 12), this.title});

  static List<(String, String)> same(List<String> l) => [for (final x in l) (x, x)];

  @override
  Widget build(BuildContext context) {
    final cur = opts.where((o) => o.$1 == value);
    final lab = S.sk(label);
    return _Box(
      label: lab,
      text: cur.isEmpty ? '' : S.sk(cur.first.$2),
      ph: cur.isEmpty,
      icon: Icons.expand_more_rounded,
      margin: margin,
      onTap: onChanged == null
          ? null
          : () async {
              final v = await pickFromList(context, title ?? lab, opts, value);
              if (v != null) onChanged!(v);
            },
    );
  }
}

Future<String?> pickFromList(BuildContext context, String title, List<(String, String)> opts, String? cur) {
  return sheet<String>(context, (ctx) => _PickList(title: title, opts: opts, cur: cur));
}

class _PickList extends StatefulWidget {
  final String title;
  final List<(String, String)> opts;
  final String? cur;
  const _PickList({required this.title, required this.opts, this.cur});
  @override
  State<_PickList> createState() => _PickListState();
}

class _PickListState extends State<_PickList> {
  final _q = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final p = pal;
    final q = _q.text.trim().toLowerCase();
    final L = widget.opts.where((o) => q.isEmpty || o.$2.toLowerCase().contains(q) || S.sk(o.$2).toLowerCase().contains(q)).toList();
    return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      SheetTitle(widget.title),
      if (widget.opts.length > 8)
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: TextField(controller: _q, onChanged: (_) => setState(() {}), decoration:  InputDecoration(prefixIcon: Icon(Icons.search_rounded), hintText: tr('Search'))),
        ),
      if (L.isEmpty) Padding(padding: const EdgeInsets.all(20), child: Text(tr('No matches'), textAlign: TextAlign.center, style: meta())),
      for (final o in L)
        InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () => Navigator.pop(context, o.$1),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
            decoration: BoxDecoration(color: o.$1 == widget.cur ? p.tint : null, borderRadius: BorderRadius.circular(12)),
            child: Row(children: [
              Expanded(child: Text(S.sk(o.$2), style: TextStyle(fontSize: 15, fontWeight: o.$1 == widget.cur ? FontWeight.w700 : FontWeight.w500, color: p.text))),
              if (o.$1 == widget.cur) Icon(Icons.check_rounded, color: p.a, size: 20),
            ]),
          ),
        ),
    ]);
  }
}

/// "2026-10-05" date field
class DateField extends StatelessWidget {
  final String label;
  final String value;
  final String? min, max;
  final ValueChanged<String> onChanged;
  final EdgeInsets margin;
  const DateField(this.label, this.value, this.onChanged, {super.key, this.min, this.max, this.margin = const EdgeInsets.only(bottom: 12)});
  @override
  Widget build(BuildContext context) {
    final d = parseYmd(value);
    return _Box(
      label: S.sk(label),
      text: d == null ? '' : DateFormat('d MMM yyyy').format(d),
      ph: d == null,
      icon: Icons.calendar_today_rounded,
      margin: margin,
      onTap: () async {
        final lo = parseYmd(min ?? '') ?? DateTime(2000), hi = parseYmd(max ?? '') ?? DateTime(2100);
        var init = d ?? DateTime.now();
        if (init.isBefore(lo)) init = lo;
        if (init.isAfter(hi)) init = hi;
        final r = await showDatePicker(context: context, initialDate: init, firstDate: lo, lastDate: hi);
        if (r != null) onChanged(ymd(r));
      },
    );
  }
}

/// "09:30" time field
class TimeField extends StatelessWidget {
  final String label;
  final String value;
  final ValueChanged<String> onChanged;
  final EdgeInsets margin;
  const TimeField(this.label, this.value, this.onChanged, {super.key, this.margin = const EdgeInsets.only(bottom: 12)});
  @override
  Widget build(BuildContext context) {
    final m = RegExp(r'^(\d{1,2}):(\d{2})').firstMatch(value);
    return _Box(
      label: S.sk(label),
      text: m == null ? '' : fxT12(value),
      ph: m == null,
      icon: Icons.schedule_rounded,
      margin: margin,
      onTap: () async {
        final t0 = m == null ? TimeOfDay.now() : TimeOfDay(hour: int.parse(m.group(1)!), minute: int.parse(m.group(2)!));
        final r = await showTimePicker(context: context, initialTime: t0);
        if (r != null) onChanged('${p2(r.hour)}:${p2(r.minute)}');
      },
    );
  }
}

/// "2026-10" month field
class MonthField extends StatelessWidget {
  final String label;
  final String value;
  final ValueChanged<String> onChanged;
  final String? max;
  final EdgeInsets margin;
  const MonthField(this.label, this.value, this.onChanged, {super.key, this.max, this.margin = const EdgeInsets.only(bottom: 12)});
  @override
  Widget build(BuildContext context) {
    final ok = RegExp(r'^\d{4}-\d{2}$').hasMatch(value);
    return _Box(
      label: S.sk(label),
      text: ok ? mname(value) : '',
      ph: !ok,
      icon: Icons.calendar_month_rounded,
      margin: margin,
      onTap: () async {
        final r = await sheet<String>(context, (ctx) => _MonthPick(value: ok ? value : mKey(DateTime.now()), max: max));
        if (r != null) onChanged(r);
      },
    );
  }
}

class _MonthPick extends StatefulWidget {
  final String value;
  final String? max;
  const _MonthPick({required this.value, this.max});
  @override
  State<_MonthPick> createState() => _MonthPickState();
}

class _MonthPickState extends State<_MonthPick> {
  late int y = int.parse(widget.value.split('-')[0]);
  @override
  Widget build(BuildContext context) {
    final p = pal;
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Row(children: [
        IconButton(onPressed: () => setState(() => y--), icon: const Icon(Icons.chevron_left_rounded)),
        Expanded(child: Text('$y', textAlign: TextAlign.center, style: h2())),
        IconButton(onPressed: () => setState(() => y++), icon: const Icon(Icons.chevron_right_rounded)),
      ]),
      const SizedBox(height: 8),
      GridView.count(
        crossAxisCount: 3,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        childAspectRatio: 2.4,
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
        children: [
          for (var m = 1; m <= 12; m++)
            Builder(builder: (_) {
              final k = '$y-${p2(m)}', on = k == widget.value, off = widget.max != null && k.compareTo(widget.max!) > 0;
              return Opacity(
                opacity: off ? .35 : 1,
                child: Material(
                  color: on ? p.a : p.card2,
                  borderRadius: BorderRadius.circular(12),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: off ? null : () => Navigator.pop(context, k),
                    child: Center(child: Text(DateFormat('MMM').format(DateTime(y, m)), style: TextStyle(fontWeight: FontWeight.w700, color: on ? Colors.white : p.text))),
                  ),
                ),
              );
            }),
        ],
      ),
      const SizedBox(height: 8),
    ]);
  }
}
