import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/session.dart';
import '../core/toast.dart';
import '../core/util.dart';
import 'theme.dart';

/* ====================================== the building blocks of every screen ====================================== */

enum BtnKind { primary, outline, green, red, ghost, soft }

/// A button that runs an async job: dots while it runs, "✓ Done" for a moment when it worked, the error as a pop-up when not.
class Btn extends StatefulWidget {
  final String label;
  final FutureOr<void> Function()? onTap;
  final BtnKind kind;
  final bool small, full, busyDone;
  final IconData? icon;
  final Color? color;
  const Btn(this.label, {super.key, this.onTap, this.kind = BtnKind.primary, this.small = false, this.full = true, this.icon, this.color, this.busyDone = true});
  const Btn.o(this.label, {super.key, this.onTap, this.small = false, this.full = true, this.icon, this.color, this.busyDone = true}) : kind = BtnKind.outline;
  const Btn.g(this.label, {super.key, this.onTap, this.small = false, this.full = true, this.icon, this.color, this.busyDone = true}) : kind = BtnKind.green;
  const Btn.r(this.label, {super.key, this.onTap, this.small = false, this.full = true, this.icon, this.color, this.busyDone = true}) : kind = BtnKind.red;
  @override
  State<Btn> createState() => _BtnState();
}

class _BtnState extends State<Btn> with SingleTickerProviderStateMixin {
  bool _busy = false, _ok = false;
  double _scale = 1;

  Future<void> _go() async {
    if (_busy || widget.onTap == null) return;
    setState(() => _busy = true);
    var good = true;
    try {
      await widget.onTap!();
    } catch (e) {
      good = false;
      fail(e);
    }
    if (!mounted) return;
    setState(() {
      _busy = false;
      _ok = good && widget.busyDone;
    });
    if (_ok) {
      await Future.delayed(const Duration(milliseconds: 900));
      if (mounted) setState(() => _ok = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = pal, k = widget.kind;
    final enabled = widget.onTap != null;
    Color bg, fg;
    Border? br;
    Gradient? gr;
    switch (k) {
      case BtnKind.primary:
        bg = widget.color ?? p.a;
        fg = Colors.white;
        if (widget.color == null) gr = LinearGradient(colors: [p.a, Color.lerp(p.a, p.a2, .55)!]);
        break;
      case BtnKind.green:
        bg = p.green;
        fg = Colors.white;
        break;
      case BtnKind.red:
        bg = p.red;
        fg = Colors.white;
        break;
      case BtnKind.outline:
        bg = p.card;
        fg = widget.color ?? p.text;
        br = Border.all(color: widget.color?.withOpacity(.5) ?? p.line);
        break;
      case BtnKind.soft:
        bg = p.tint;
        fg = p.a;
        break;
      case BtnKind.ghost:
        bg = Colors.transparent;
        fg = widget.color ?? p.a;
        break;
    }
    if (_ok) {
      bg = p.green;
      fg = Colors.white;
      gr = null;
      br = null;
    }
    final h = widget.small ? 40.0 : 50.0;
    Widget inner;
    if (_busy) {
      inner = _Dots(color: fg);
    } else {
      inner = Row(mainAxisSize: MainAxisSize.min, mainAxisAlignment: MainAxisAlignment.center, children: [
        if (widget.icon != null && !_ok) ...[Icon(widget.icon, size: widget.small ? 17 : 19, color: fg), const SizedBox(width: 8)],
        Flexible(
          child: Text(_ok ? '✓ Done' : widget.label,
              maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: TextStyle(color: fg, fontWeight: FontWeight.w700, fontSize: widget.small ? 13.5 : 15, fontFamily: fontFam)),
        ),
      ]);
    }
    final btn = AnimatedScale(
      scale: _scale,
      duration: const Duration(milliseconds: 120),
      child: Opacity(
        opacity: enabled ? 1 : .5,
        child: Container(
          height: h,
          width: widget.full ? double.infinity : null,
          padding: EdgeInsets.symmetric(horizontal: widget.small ? 14 : 18),
          decoration: BoxDecoration(
            color: gr == null ? bg : null,
            gradient: gr,
            borderRadius: BorderRadius.circular(widget.small ? 12 : 15),
            border: br,
            boxShadow: (k == BtnKind.primary && !_ok && enabled && !p.dark) ? [BoxShadow(color: p.a.withOpacity(.25), blurRadius: 14, offset: const Offset(0, 6))] : null,
          ),
          alignment: Alignment.center,
          child: inner,
        ),
      ),
    );
    return GestureDetector(
      onTapDown: enabled ? (_) => setState(() => _scale = .97) : null,
      onTapCancel: () => setState(() => _scale = 1),
      onTapUp: (_) => setState(() => _scale = 1),
      onTap: enabled
          ? () {
              HapticFeedback.selectionClick();
              _go();
            }
          : null,
      child: btn,
    );
  }
}

class _Dots extends StatefulWidget {
  final Color color;
  const _Dots({required this.color});
  @override
  State<_Dots> createState() => _DotsState();
}

class _DotsState extends State<_Dots> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat();
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _c,
        builder: (_, __) => Row(
            mainAxisSize: MainAxisSize.min,
            children: List.generate(3, (i) {
              final t = ((_c.value - i * .18) % 1.0);
              final s = t < .5 ? t * 2 : (1 - t) * 2;
              return Container(margin: const EdgeInsets.symmetric(horizontal: 3), width: 7, height: 7, decoration: BoxDecoration(color: widget.color.withOpacity(.35 + .65 * s), shape: BoxShape.circle));
            })),
      );
}

/// a small round icon button
class IconBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  final String? tip;
  final Color? color, bg;
  final double size;
  final Widget? badge;
  const IconBtn(this.icon, {super.key, this.onTap, this.tip, this.color, this.bg, this.size = 42, this.badge});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    final w = Material(
      color: bg ?? p.card,
      shape: CircleBorder(side: BorderSide(color: p.line)),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(width: size, height: size, child: Icon(icon, size: size * .5, color: color ?? p.text)),
      ),
    );
    final s = badge == null ? w : Stack(clipBehavior: Clip.none, children: [w, Positioned(right: -2, top: -2, child: badge!)]);
    return tip == null ? s : Tooltip(message: tip!, child: s);
  }
}

/// a white card with a hairline border and a soft shadow
class AppCard extends StatelessWidget {
  final Widget? child;
  final List<Widget>? children;
  final String? title;
  final Widget? trailing;
  final EdgeInsets padding, margin;
  final VoidCallback? onTap;
  final Color? color, borderColor;
  final Gradient? gradient;
  const AppCard({super.key, this.child, this.children, this.title, this.trailing, this.padding = const EdgeInsets.all(16), this.margin = const EdgeInsets.only(bottom: 14), this.onTap, this.color, this.borderColor, this.gradient});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    final content = child ??
        Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          if (title != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Row(children: [Expanded(child: Text(S.sk(title!), style: h2())), if (trailing != null) trailing!]),
            ),
          ...?children,
        ]);
    final box = Container(
      margin: margin,
      decoration: BoxDecoration(color: gradient == null ? (color ?? p.card) : null, gradient: gradient, borderRadius: BorderRadius.circular(20), border: Border.all(color: borderColor ?? p.line), boxShadow: p.shadow),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(20),
        clipBehavior: Clip.antiAlias,
        child: onTap == null ? Padding(padding: padding, child: content) : InkWell(onTap: onTap, child: Padding(padding: padding, child: content)),
      ),
    );
    return box;
  }
}

/// a list item inside a card (colored bar on the left)
class Item extends StatelessWidget {
  final List<Widget> children;
  final Color? bar;
  final VoidCallback? onTap;
  const Item({super.key, required this.children, this.bar, this.onTap});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(18), border: Border.all(color: p.line), boxShadow: p.shadow),
      clipBehavior: Clip.antiAlias,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          child: IntrinsicHeight(
            child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              if (bar != null) Container(width: 4, color: bar),
              Expanded(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children))),
            ]),
          ),
        ),
      ),
    );
  }
}

enum Tone { g, r, y, b, m, a }

Color toneColor(Tone t) {
  final p = pal;
  switch (t) {
    case Tone.g:
      return p.green;
    case Tone.r:
      return p.red;
    case Tone.y:
      return p.amber;
    case Tone.b:
      return p.blue;
    case Tone.m:
      return p.muted;
    case Tone.a:
      return p.a;
  }
}

Tone toneOf(String c) => const {'g': Tone.g, 'r': Tone.r, 'y': Tone.y, 'a': Tone.y, 'b': Tone.b, 'm': Tone.m}[c] ?? Tone.a;

class Pill extends StatelessWidget {
  final String text;
  final Tone tone;
  final bool solid;
  const Pill(this.text, {super.key, this.tone = Tone.a, this.solid = false});
  @override
  Widget build(BuildContext context) {
    final c = toneColor(tone);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: solid ? c : c.withOpacity(.12), borderRadius: BorderRadius.circular(99)),
      child: Text(text, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: solid ? Colors.white : c)),
    );
  }
}

/// title + badge on one line
class ItemHead extends StatelessWidget {
  final String title;
  final Widget? badge;
  const ItemHead(this.title, {super.key, this.badge});
  @override
  Widget build(BuildContext context) => Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: Text(title, style: h3())),
        if (badge != null) ...[const SizedBox(width: 8), badge!],
      ]);
}

class Meta extends StatelessWidget {
  final String text;
  final EdgeInsets pad;
  const Meta(this.text, {super.key, this.pad = const EdgeInsets.only(top: 4)});
  @override
  Widget build(BuildContext context) => Padding(padding: pad, child: Text(text, style: meta()));
}

class Desc extends StatelessWidget {
  final String text;
  const Desc(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(top: 6), child: Text(text, style: body(pal.text.withOpacity(.85))));
}

/// a highlighted line of information
class Note extends StatelessWidget {
  final String text;
  final Tone tone;
  final EdgeInsets margin;
  const Note(this.text, {super.key, this.tone = Tone.a, this.margin = const EdgeInsets.only(top: 8)});
  @override
  Widget build(BuildContext context) {
    final c = toneColor(tone);
    return Container(
      margin: margin,
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(color: c.withOpacity(.09), borderRadius: BorderRadius.circular(12), border: Border.all(color: c.withOpacity(.18))),
      child: Text(text, style: TextStyle(fontSize: 13, color: pal.text, height: 1.4)),
    );
  }
}

/// a key / value line (left: title + subtitle, right: a widget)
class Ex extends StatelessWidget {
  final String title;
  final String? sub;
  final Widget? right;
  final VoidCallback? onTap;
  final Widget? lead;
  final bool dim;
  const Ex(this.title, {super.key, this.sub, this.right, this.onTap, this.lead, this.dim = false});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    return Opacity(
      opacity: dim ? .55 : 1,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 11),
          decoration: BoxDecoration(border: Border(bottom: BorderSide(color: p.line.withOpacity(.7)))),
          child: Row(children: [
            if (lead != null) ...[lead!, const SizedBox(width: 12)],
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600, color: p.text)),
                if (sub != null && sub!.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 2), child: Text(sub!, style: meta())),
              ]),
            ),
            if (right != null) ...[const SizedBox(width: 10), right!],
          ]),
        ),
      ),
    );
  }
}

/// label / value rows as in a receipt
class KvRow extends StatelessWidget {
  final String k, v;
  final VoidCallback? onTap;
  final Color? vColor;
  const KvRow(this.k, this.v, {super.key, this.onTap, this.vColor});
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(border: Border(bottom: BorderSide(color: pal.line.withOpacity(.7)))),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(flex: 4, child: Text(k, style: meta())),
            const SizedBox(width: 10),
            Expanded(flex: 6, child: Text(v.isEmpty ? '—' : v, textAlign: TextAlign.right, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: vColor ?? pal.text))),
          ]),
        ),
      );
}

class Empty extends StatelessWidget {
  final String text;
  final String icon;
  const Empty(this.text, {super.key, this.icon = ''});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20),
      decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(18), border: Border.all(color: p.line)),
      child: Column(children: [
        if (icon.isNotEmpty) Text(icon, style: const TextStyle(fontSize: 34)),
        if (icon.isNotEmpty) const SizedBox(height: 8),
        Text(S.sk(text), textAlign: TextAlign.center, style: meta().copyWith(fontSize: 13.5)),
      ]),
    );
  }
}

class Sec extends StatelessWidget {
  final String text;
  const Sec(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(2, 14, 2, 8),
        child: Text(S.sk(text).toUpperCase(), style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, letterSpacing: .8, color: pal.muted)),
      );
}

/// grey placeholder cards while data loads
class Skeleton extends StatefulWidget {
  final int n;
  const Skeleton({super.key, this.n = 3});
  @override
  State<Skeleton> createState() => _SkeletonState();
}

class _SkeletonState extends State<Skeleton> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..repeat(reverse: true);
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final c = Color.lerp(p.card2, p.line, _c.value)!;
        Widget bar(double w) => Container(height: 12, width: w, margin: const EdgeInsets.only(bottom: 10), decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(6)));
        return Column(
            children: List.generate(
                widget.n,
                (_) => Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(18), border: Border.all(color: p.line)),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [bar(180), bar(260), bar(120)]),
                    )));
      },
    );
  }
}

/// steps with icons (Submitted → In Progress → Resolved ...)
class Steps extends StatelessWidget {
  final List<String> labels;
  final int idx;
  final List<String>? icons;
  const Steps(this.labels, this.idx, {super.key, this.icons});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(children: [
        for (var i = 0; i < labels.length; i++) ...[
          Expanded(
            child: Column(children: [
              AnimatedContainer(
                duration: Duration(milliseconds: 300 + i * 120),
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  color: i < idx ? p.green : i == idx ? p.a : p.card2,
                  shape: BoxShape.circle,
                  boxShadow: i == idx ? [BoxShadow(color: p.a.withOpacity(.3), blurRadius: 10)] : null,
                ),
                alignment: Alignment.center,
                child: Text(i < idx ? '✓' : (icons != null && i < icons!.length ? icons![i] : '${i + 1}'), style: TextStyle(fontSize: 12.5, color: i <= idx ? Colors.white : p.muted, fontWeight: FontWeight.w700)),
              ),
              const SizedBox(height: 4),
              Text(labels[i], textAlign: TextAlign.center, style: TextStyle(fontSize: 10.5, color: i <= idx ? p.text : p.muted, fontWeight: i == idx ? FontWeight.w700 : FontWeight.w500)),
            ]),
          ),
          if (i < labels.length - 1) Expanded(child: Container(height: 2, margin: const EdgeInsets.only(bottom: 18), color: i < idx ? p.green : p.line)),
        ]
      ]),
    );
  }
}

/// a row of choices that scrolls sideways
class Chips extends StatelessWidget {
  final List<(String, String)> opts;
  final String cur;
  final ValueChanged<String> onPick;
  final EdgeInsets pad;
  const Chips(this.opts, this.cur, this.onPick, {super.key, this.pad = const EdgeInsets.only(bottom: 12)});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    return Padding(
      padding: pad,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        child: Row(children: [
          for (final o in opts)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: GestureDetector(
                onTap: () {
                  HapticFeedback.selectionClick();
                  onPick(o.$1);
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                  decoration: BoxDecoration(
                    color: o.$1 == cur ? p.a : p.card,
                    borderRadius: BorderRadius.circular(99),
                    border: Border.all(color: o.$1 == cur ? p.a : p.line),
                  ),
                  child: Text(o.$2, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: o.$1 == cur ? Colors.white : p.text)),
                ),
              ),
            ),
        ]),
      ),
    );
  }
}

/// segmented control with a sliding pill
class Seg extends StatelessWidget {
  final List<(String, String)> opts;
  final String cur;
  final ValueChanged<String> onPick;
  final EdgeInsets margin;
  const Seg(this.opts, this.cur, this.onPick, {super.key, this.margin = const EdgeInsets.only(bottom: 14)});
  @override
  Widget build(BuildContext context) {
    final p = pal;
    final i = opts.indexWhere((o) => o.$1 == cur);
    return Container(
      margin: margin,
      height: 46,
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(color: p.card2, borderRadius: BorderRadius.circular(14)),
      child: LayoutBuilder(builder: (_, c) {
        final w = c.maxWidth / opts.length;
        return Stack(children: [
          AnimatedPositioned(
            duration: const Duration(milliseconds: 260),
            curve: Curves.easeOutCubic,
            left: (i < 0 ? 0 : i) * w,
            top: 0,
            bottom: 0,
            width: w,
            child: Container(decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(11), boxShadow: p.shadow)),
          ),
          Row(children: [
            for (final o in opts)
              Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () {
                    HapticFeedback.selectionClick();
                    onPick(o.$1);
                  },
                  child: Center(child: Text(S.sk(o.$2), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: o.$1 == cur ? p.text : p.muted))),
                ),
              ),
          ]),
        ]);
      }),
    );
  }
}

/// a label + switch line
class ToggleRow extends StatelessWidget {
  final String label;
  final String? hint;
  final bool value;
  final ValueChanged<bool>? onChanged;
  const ToggleRow(this.label, this.value, this.onChanged, {super.key, this.hint});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(children: [
          Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600, color: pal.text)),
            if (hint != null && hint!.isNotEmpty) Text(hint!, style: meta()),
          ])),
          Switch(
              value: value,
              onChanged: onChanged == null
                  ? null
                  : (v) {
                      HapticFeedback.selectionClick();
                      onChanged!(v);
                    }),
        ]),
      );
}

/// spacing helpers
const gap4 = SizedBox(height: 4, width: 4);
const gap8 = SizedBox(height: 8, width: 8);
const gap12 = SizedBox(height: 12, width: 12);
const gap16 = SizedBox(height: 16, width: 16);

/// two widgets side by side
class Row2 extends StatelessWidget {
  final Widget a, b;
  final double gap;
  const Row2(this.a, this.b, {super.key, this.gap = 10});
  @override
  Widget build(BuildContext context) => Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: a), SizedBox(width: gap), Expanded(child: b)]);
}

/// wrap of small buttons under an item
class ActRow extends StatelessWidget {
  final List<Widget> children;
  const ActRow(this.children, {super.key});
  @override
  Widget build(BuildContext context) => children.isEmpty ? const SizedBox.shrink() : Padding(padding: const EdgeInsets.only(top: 10), child: Wrap(spacing: 8, runSpacing: 8, children: children));
}

/// a small button that sizes to its text (for action rows)
Widget mini(String t, FutureOr<void> Function() fn, [BtnKind k = BtnKind.outline]) => Btn(t, onTap: fn, kind: k, small: true, full: false);

/// a fade + slide entrance, index = position in a list (staggered)
class Enter extends StatefulWidget {
  final Widget child;
  final int index;
  const Enter({super.key, required this.child, this.index = 0});
  @override
  State<Enter> createState() => _EnterState();
}

class _EnterState extends State<Enter> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 420));
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: (widget.index.clamp(0, 12)) * 45), () {
      if (mounted) _c.forward();
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _c,
        builder: (_, child) {
          final t = Curves.easeOutCubic.transform(_c.value);
          return Opacity(opacity: t, child: Transform.translate(offset: Offset(0, (1 - t) * 14), child: child));
        },
        child: widget.child,
      );
}

/// a number that counts up when it first appears / changes
class CountUp extends StatefulWidget {
  final num value;
  final bool money;
  final TextStyle? style;
  final String prefix, suffix;
  const CountUp(this.value, {super.key, this.money = false, this.style, this.prefix = '', this.suffix = ''});
  @override
  State<CountUp> createState() => _CountUpState();
}

class _CountUpState extends State<CountUp> with SingleTickerProviderStateMixin {
  late AnimationController _c;
  num _from = 0;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: Duration(milliseconds: (520 + widget.value.abs() * 10).clamp(0, 1100).toInt()))..forward();
  }

  @override
  void didUpdateWidget(CountUp old) {
    super.didUpdateWidget(old);
    if (old.value != widget.value) {
      _from = old.value;
      _c.duration = Duration(milliseconds: (520 + (widget.value - _from).abs() * 10).clamp(0, 1100).toInt());
      _c.forward(from: 0);
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _c,
        builder: (_, __) {
          final e = Curves.easeOutCubic.transform(_c.value);
          final v = _c.value >= 1 ? widget.value : (_from + (widget.value - _from) * e).round();
          return Text('${widget.prefix}${widget.money ? rs(v) : v}${widget.suffix}', style: widget.style);
        },
      );
}
