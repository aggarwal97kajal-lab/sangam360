import 'dart:typed_data';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';

import '../core/files.dart';
import '../core/img.dart';
import '../core/session.dart';
import '../core/store.dart';
import '../core/toast.dart';
import '../core/util.dart';
import 'theme.dart';

/// the picture of a person: the directory's (everyone can read it), my own sign-up photo, or the member record's
String? photoOf(String? u) {
  if (u == null) return null;
  final d = D['dir'][u]?['photo'];
  if (okImg(d)) return d as String;
  if (u == S.uid && okImg(S.me?['photoUrl'])) return S.me!['photoUrl'] as String;
  final m = D['mem'][u]?['photoUrl'];
  return okImg(m) ? m as String : null;
}

/// my own picture: the login's public one, or on the 2nd / 3rd student of a login that student's own photo
String? myPhoto() => S.pid != null && S.pid != S.uid ? (okImg(S.me?['photoUrl']) ? S.me!['photoUrl'] as String : null) : photoOf(S.uid);

/// an image kept as data:, rtdb:, r2: or https:
class RefImage extends StatefulWidget {
  final String ref;
  final BoxFit fit;
  final double? width, height;
  final Widget? placeholder;
  final Widget? error;
  const RefImage(this.ref, {super.key, this.fit = BoxFit.cover, this.width, this.height, this.placeholder, this.error});
  @override
  State<RefImage> createState() => _RefImageState();
}

class _RefImageState extends State<RefImage> {
  Future<FileLink>? _f;
  @override
  void initState() {
    super.initState();
    _f = resolveRef(widget.ref);
  }

  @override
  void didUpdateWidget(RefImage o) {
    super.didUpdateWidget(o);
    if (o.ref != widget.ref) _f = resolveRef(widget.ref);
  }

  @override
  Widget build(BuildContext context) {
    final ph = widget.placeholder ?? Container(width: widget.width, height: widget.height, color: pal.card2);
    return FutureBuilder<FileLink>(
      future: _f,
      builder: (_, s) {
        if (s.hasError) return widget.error ?? Container(width: widget.width, height: widget.height, color: pal.card2, alignment: Alignment.center, child: Icon(Icons.broken_image_outlined, color: pal.faint));
        if (!s.hasData) return ph;
        final l = s.data!;
        if (l.bytes != null) return Image.memory(l.bytes!, fit: widget.fit, width: widget.width, height: widget.height, gaplessPlayback: true);
        return CachedNetworkImage(
          imageUrl: l.url!,
          cacheKey: widget.ref.startsWith('http') ? null : widget.ref,
          fit: widget.fit,
          width: widget.width,
          height: widget.height,
          fadeInDuration: const Duration(milliseconds: 180),
          placeholder: (_, __) => ph,
          errorWidget: (_, __, ___) => widget.error ?? Container(width: widget.width, height: widget.height, color: pal.card2),
        );
      },
    );
  }
}

/// a round picture with the first letter as fallback
class Av extends StatelessWidget {
  final String? name;
  final String? photo;
  final double size;
  final Widget? badge;
  const Av(this.name, this.photo, {super.key, this.size = 42, this.badge});
  @override
  Widget build(BuildContext context) {
    final n = str(name);
    final c = colOf(n);
    final letter = Container(
      width: size,
      height: size,
      decoration: BoxDecoration(gradient: LinearGradient(colors: [c, Color.lerp(c, Colors.black, .12)!], begin: Alignment.topLeft, end: Alignment.bottomRight), shape: BoxShape.circle),
      alignment: Alignment.center,
      child: Text(n.isEmpty ? '?' : n[0].toUpperCase(), style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: size * .42, fontFamily: fontFam)),
    );
    final w = okImg(photo) ? ClipOval(child: SizedBox(width: size, height: size, child: RefImage(photo!, width: size, height: size, placeholder: letter, error: letter))) : letter;
    if (badge == null) return w;
    return Stack(clipBehavior: Clip.none, children: [w, Positioned(right: -1, bottom: -1, child: badge!)]);
  }
}

/// a green dot (online)
Widget onlineDot([double s = 12]) => Container(width: s, height: s, decoration: BoxDecoration(color: pal.green, shape: BoxShape.circle, border: Border.all(color: pal.card, width: 2)));

/// opens a stored file: PDF in the viewer, a picture in the image viewer, anything else is downloaded
Future<void> openRef(BuildContext context, String ref, {String name = 'file', String mime = ''}) async {
  try {
    final nav = Navigator.of(context);
    final isPdf = mime == 'application/pdf' || name.toLowerCase().endsWith('.pdf');
    final isImg = mime.startsWith('image/') || RegExp(r'\.(jpe?g|png|webp|gif)$', caseSensitive: false).hasMatch(name) || ref.startsWith('data:image/');
    if (isImg && !isPdf) {
      nav.push(MaterialPageRoute(builder: (_) => ImageViewer(ref: ref, name: name)));
      return;
    }
    toast('ℹ️', 'Opening…', name);
    final b = await refBytes(ref);
    final t = b.$2.isNotEmpty ? b.$2 : mimeOf(name, b.$1);
    if (isPdf || t == 'application/pdf' || sniff(b.$1) == 'pdf') {
      nav.push(MaterialPageRoute(builder: (_) => PdfViewer(bytes: b.$1, name: name.toLowerCase().endsWith('.pdf') ? name : '$name.pdf')));
      return;
    }
    if (t.startsWith('image/')) {
      nav.push(MaterialPageRoute(builder: (_) => ImageViewer(bytes: b.$1, name: name)));
      return;
    }
    await saveBytes(name, b.$1, t);
  } catch (e) {
    fail(e, "Couldn't open file");
  }
}

/// a picture full screen: pinch to zoom, download, share
class ImageViewer extends StatelessWidget {
  final String? ref;
  final Uint8List? bytes;
  final String name;
  const ImageViewer({super.key, this.ref, this.bytes, this.name = 'photo.jpg'});

  Future<(Uint8List, String)> _bytes() async => bytes != null ? (bytes!, mimeOf(name, bytes!)) : await refBytes(ref!);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(name, style: const TextStyle(color: Colors.white, fontSize: 16)),
        actions: [
          IconButton(
            tooltip: 'Share',
            icon: const Icon(Icons.share_rounded),
            onPressed: () async {
              try {
                final b = await _bytes();
                final f = await tempFile(name.contains('.') ? name : '$name.jpg', b.$1);
                await Share.shareXFiles([XFile(f.path)]);
              } catch (e) {
                fail(e);
              }
            },
          ),
          IconButton(
            tooltip: 'Download',
            icon: const Icon(Icons.download_rounded),
            onPressed: () async {
              try {
                final b = await _bytes();
                await saveBytes(name.contains('.') ? name : '$name.jpg', b.$1, b.$2.isEmpty ? 'image/jpeg' : b.$2);
              } catch (e) {
                fail(e, 'Could not save the file');
              }
            },
          ),
        ],
      ),
      body: Center(
        child: InteractiveViewer(
          minScale: 1,
          maxScale: 6,
          child: bytes != null ? Image.memory(bytes!, fit: BoxFit.contain) : RefImage(ref!, fit: BoxFit.contain, placeholder: const Center(child: CircularProgressIndicator(color: Colors.white))),
        ),
      ),
    );
  }
}

/// a PDF inside the app (pages drawn as pictures) with Download and Share
class PdfViewer extends StatefulWidget {
  final Uint8List bytes;
  final String name;
  const PdfViewer({super.key, required this.bytes, required this.name});
  @override
  State<PdfViewer> createState() => _PdfViewerState();
}

class _PdfViewerState extends State<PdfViewer> {
  final List<Uint8List> pages = [];
  bool done = false;
  String err = '';
  @override
  void initState() {
    super.initState();
    _render();
  }

  Future<void> _render() async {
    try {
      await for (final r in Printing.raster(widget.bytes, dpi: 130)) {
        final png = await r.toPng();
        if (!mounted) return;
        setState(() => pages.add(png));
      }
    } catch (e) {
      if (mounted) setState(() => err = "Couldn't show this PDF here. Use Download to open it in another app.");
    }
    if (mounted) setState(() => done = true);
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    return Scaffold(
      backgroundColor: p.dark ? const Color(0xFF0B0D14) : const Color(0xFFE9ECF2),
      appBar: AppBar(
        title: Text(widget.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16)),
        actions: [
          IconButton(
            tooltip: 'Share',
            icon: const Icon(Icons.share_rounded),
            onPressed: () async {
              try {
                final f = await tempFile(widget.name, widget.bytes);
                await Share.shareXFiles([XFile(f.path, mimeType: 'application/pdf')]);
              } catch (e) {
                fail(e);
              }
            },
          ),
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: FilledButton.icon(onPressed: () => saveBytes(widget.name, widget.bytes, 'application/pdf'), icon: const Icon(Icons.download_rounded, size: 18), label: const Text('Download')),
          ),
        ],
      ),
      body: err.isNotEmpty
          ? Center(child: Padding(padding: const EdgeInsets.all(30), child: Text(err, textAlign: TextAlign.center, style: body())))
          : pages.isEmpty
              ? Center(child: CircularProgressIndicator(color: p.a))
              : InteractiveViewer(
                  minScale: 1,
                  maxScale: 4,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: pages.length + (done ? 0 : 1),
                    itemBuilder: (_, i) => i >= pages.length
                        ? Padding(padding: const EdgeInsets.all(20), child: Center(child: CircularProgressIndicator(color: p.a)))
                        : Container(margin: const EdgeInsets.only(bottom: 12), decoration: BoxDecoration(color: Colors.white, boxShadow: [BoxShadow(color: Colors.black.withOpacity(.12), blurRadius: 12)]), child: Image.memory(pages[i], fit: BoxFit.fitWidth)),
                  ),
                ),
    );
  }
}

/// a small picture of a stored image that opens full screen
class PhotoThumb extends StatelessWidget {
  final String ref;
  final double w, h;
  final String name;
  const PhotoThumb(this.ref, {super.key, this.w = double.infinity, this.h = 170, this.name = 'photo.jpg'});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ImageViewer(ref: ref, name: name))),
        child: Container(
          margin: const EdgeInsets.only(top: 10),
          width: w,
          height: h,
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), color: pal.card2),
          child: Hero(tag: 'img-$ref-${identityHashCode(this)}', child: RefImage(ref, width: w, height: h)),
        ),
      );
}
