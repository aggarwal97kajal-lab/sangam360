import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../core/api.dart';
import '../core/files.dart';
import '../core/img.dart';
import '../core/perms.dart';
import '../core/toast.dart';
import '../core/util.dart';
import 'kit.dart';
import 'sheets.dart';
import 'theme.dart';
import '../l10n/l10n.dart';

/// a chosen file
class PFile {
  final Uint8List bytes;
  final String name;
  final String mime;
  const PFile(this.bytes, this.name, this.mime);
  int get size => bytes.length;
  bool get isImg => mime.startsWith('image/');
  bool get isPdf => mime == 'application/pdf';
}

final _ip = ImagePicker();

Future<PFile?> pickCamera({bool front = false}) async {
  if (!await askPerm('cam')) return null;
  try {
    final x = await _ip.pickImage(source: ImageSource.camera, preferredCameraDevice: front ? CameraDevice.front : CameraDevice.rear, maxWidth: 2560, maxHeight: 2560, imageQuality: 92);
    if (x == null) return null;
    final b = await x.readAsBytes();
    return PFile(b, x.name.isEmpty ? 'photo.jpg' : x.name, mimeOf(x.name, b));
  } catch (e) {
    fail(e, tr("Couldn't open the camera"));
    return null;
  }
}

Future<PFile?> pickGallery() async {
  try {
    final x = await _ip.pickImage(source: ImageSource.gallery, maxWidth: 2560, maxHeight: 2560, imageQuality: 92);
    if (x == null) return null;
    final b = await x.readAsBytes();
    return PFile(b, x.name.isEmpty ? 'photo.jpg' : x.name, mimeOf(x.name, b));
  } catch (e) {
    fail(e, tr("Couldn't open your photos"));
    return null;
  }
}

Future<List<PFile>> pickGalleryMany({int max = 10}) async {
  try {
    final l = await _ip.pickMultiImage(maxWidth: 2560, maxHeight: 2560, imageQuality: 92, limit: max);
    final r = <PFile>[];
    for (final x in l.take(max)) {
      final b = await x.readAsBytes();
      r.add(PFile(b, x.name, mimeOf(x.name, b)));
    }
    if (l.length > max) toast('ℹ️', trf('Up to {0} photos at a time', [max]), trf('The first {0} were added.', [max]));
    return r;
  } catch (e) {
    fail(e, tr("Couldn't open your photos"));
    return [];
  }
}

Future<PFile?> pickVideo() async {
  try {
    final x = await _ip.pickVideo(source: ImageSource.gallery, maxDuration: const Duration(minutes: 3));
    if (x == null) return null;
    final b = await x.readAsBytes();
    return PFile(b, x.name, mimeOf(x.name, b));
  } catch (e) {
    fail(e);
    return null;
  }
}

/// any document (or only some extensions)
Future<PFile?> pickDoc({List<String>? ext}) async {
  try {
    final r = await FilePicker.platform.pickFiles(type: ext == null ? FileType.any : FileType.custom, allowedExtensions: ext, withData: true);
    if (r == null || r.files.isEmpty) return null;
    final f = r.files.first;
    final b = f.bytes;
    if (b == null) {
      toast('⚠️', tr("Couldn't read this file"), tr('Please choose it again.'));
      return null;
    }
    return PFile(b, f.name, mimeOf(f.name, b));
  } catch (e) {
    fail(e, tr("Couldn't open the file"));
    return null;
  }
}

/// camera / gallery (/ PDF) as a small sheet
Future<PFile?> pickPhotoSheet(BuildContext context, {bool pdf = false, bool front = false, String title = 'Add a photo', bool video = false}) async {
  final k = await sheet<String>(context, (ctx) {
    Widget row(String ic, String t, String v) => Ex(t, lead: Text(ic, style: const TextStyle(fontSize: 22)), onTap: () => Navigator.pop(ctx, v), right: Icon(Icons.chevron_right_rounded, color: pal.faint));
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      SheetTitle(title),
      row('📷', tr('Take a photo'), 'cam'),
      row('🖼️', tr('Choose from gallery'), 'gal'),
      if (video) row('🎬', tr('Choose a video'), 'vid'),
      if (pdf) row('📄', tr('Choose a PDF'), 'pdf'),
    ]);
  });
  if (k == 'cam') return pickCamera(front: front);
  if (k == 'gal') return pickGallery();
  if (k == 'vid') return pickVideo();
  if (k == 'pdf') return pickDoc(ext: ['pdf']);
  return null;
}

/// checks a chosen file like the earlier app: type and size
String? checkFile(PFile f, {List<String> ext = const ['jpg', 'jpeg', 'png', 'pdf'], int max = 10 * 1048576}) {
  final s = sniff(f.bytes);
  final e = f.name.split('.').last.toLowerCase();
  final ok = ext.contains(e) || (s == 'jpg' && ext.contains('jpg')) || (s == 'png' && ext.contains('png')) || (s == 'pdf' && ext.contains('pdf')) || (f.isImg && (ext.contains('jpg') || ext.contains('png')));
  if (!ok) return trf('This type of file is not allowed. Use {0}.', [ext.map((x) => x.toUpperCase()).join(', ')]);
  if (s == 'heic') return tr('HEIC photos are not supported. Please choose a JPG or PNG.');
  if (f.size > max) return trf('File is too large (max {0} MB).', [max ~/ 1048576]);
  if (f.size < 100) return tr('This file looks empty. Please choose another one.');
  return null;
}

/// a required document that is uploaded as soon as it is chosen (ID proof, photo):
/// checking → uploading % → ✓ uploaded, or the error with Retry
class FileSlot extends StatefulWidget {
  final String label, icon;
  final bool pdf, front;
  final Future<String> Function(PFile f) upload;
  final ValueChanged<String?> onRef;
  const FileSlot({super.key, required this.label, required this.icon, required this.upload, required this.onRef, this.pdf = false, this.front = false});
  @override
  State<FileSlot> createState() => _FileSlotState();
}

class _FileSlotState extends State<FileSlot> {
  PFile? f;
  String st = ''; // '' | up | ok | err
  String msg = '';
  int pct = 0;
  late final void Function(String, int) _pl = (l, p) {
    if (mounted && st == 'up' && p >= 0) setState(() => pct = p);
  };

  @override
  void initState() {
    super.initState();
    Up.progress.listen(_pl);
  }

  @override
  void dispose() {
    Up.progress.unlisten(_pl);
    super.dispose();
  }

  Future<void> _choose() async {
    final x = await pickPhotoSheet(context, pdf: widget.pdf, front: widget.front, title: widget.label);
    if (x == null) return;
    final bad = checkFile(x, ext: widget.pdf ? const ['jpg', 'jpeg', 'png', 'pdf'] : const ['jpg', 'jpeg', 'png']);
    if (bad != null) {
      setState(() {
        f = null;
        st = 'err';
        msg = bad;
      });
      widget.onRef(null);
      return;
    }
    f = x;
    await _send();
  }

  Future<void> _send() async {
    if (f == null) return;
    setState(() {
      st = 'up';
      pct = 0;
      msg = '';
    });
    widget.onRef(null);
    try {
      final r = await widget.upload(f!);
      if (!mounted) return;
      setState(() => st = 'ok');
      widget.onRef(r);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        st = 'err';
        msg = fr(e);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = pal;
    final c = st == 'ok'
        ? p.green
        : st == 'err'
            ? p.red
            : p.a;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: c.withOpacity(.06), borderRadius: BorderRadius.circular(16), border: Border.all(color: c.withOpacity(st.isEmpty ? .15 : .35))),
      child: Row(children: [
        Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: p.line)),
          clipBehavior: Clip.antiAlias,
          alignment: Alignment.center,
          child: f != null && f!.isImg ? Image.memory(f!.bytes, fit: BoxFit.cover, width: 52, height: 52) : Text(f != null ? '📄' : widget.icon, style: const TextStyle(fontSize: 24)),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.label, style: h3()),
            const SizedBox(height: 2),
            if (st == 'up') ...[
              Text(trf('Uploading… {0}%', [pct]), style: meta(p.a)),
              const SizedBox(height: 4),
              ClipRRect(borderRadius: BorderRadius.circular(9), child: LinearProgressIndicator(value: pct / 100, minHeight: 5, backgroundColor: p.card2)),
            ] else if (st == 'ok')
              Text(trf('✓ Uploaded{0}', [(f != null ? ' · ${fuSize(f!.size)}' : '')]), style: meta(p.green))
            else if (st == 'err')
              Text(msg, style: meta(p.red))
            else
              Text(widget.pdf ? tr('Photo or PDF · required') : tr('Photo · required'), style: meta()),
          ]),
        ),
        const SizedBox(width: 8),
        if (st == 'err' && f != null) mini(tr('Retry'), _send) else if (st != 'up') mini(st == 'ok' ? tr('Change') : tr('Choose'), _choose),
      ]),
    );
  }
}
