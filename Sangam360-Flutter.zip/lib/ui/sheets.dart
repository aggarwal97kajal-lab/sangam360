import 'package:flutter/material.dart';

import '../core/session.dart';
import '../core/toast.dart';
import 'theme.dart';
import '../l10n/l10n.dart';

BuildContext? get rootCtx => navKey.currentContext;

/// A bottom sheet: rounded, with a handle, scrolls, moves up with the keyboard.
Future<T?> sheet<T>(BuildContext context, Widget Function(BuildContext) builder, {bool closeLink = false}) {
  final p = pal;
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: p.card,
    barrierColor: Colors.black.withOpacity(.45),
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
    builder: (ctx) => Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * .92),
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(18, 10, 18, 22),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Center(child: Container(width: 42, height: 5, margin: const EdgeInsets.only(bottom: 14), decoration: BoxDecoration(color: p.line, borderRadius: BorderRadius.circular(9)))),
            Builder(builder: builder),
            if (closeLink) TextButton(onPressed: () => Navigator.pop(ctx), child: Text(tr('Close'), style: TextStyle(color: p.muted))),
          ]),
        ),
      ),
    ),
  );
}

class SheetTitle extends StatelessWidget {
  final String title;
  final String? sub;
  const SheetTitle(this.title, {super.key, this.sub});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(S.sk(title), style: h2().copyWith(fontSize: 19)),
          if (sub != null && sub!.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(S.sk(sub!), style: meta().copyWith(fontSize: 13.5))),
        ]),
      );
}

Future<bool> confirmDlg(BuildContext context, String text, {String ok = 'OK', bool danger = false, String? title}) async {
  final p = pal;
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: title == null ? null : Text(title, style: h2()),
      content: Text(text, style: body()),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tr('Cancel'), style: TextStyle(color: p.muted))),
        TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(ok, style: TextStyle(color: danger ? p.red : p.a, fontWeight: FontWeight.w700))),
      ],
    ),
  );
  return r == true;
}

Future<String?> promptDlg(BuildContext context, String text, {String initial = '', String ok = 'OK', int max = 300}) async {
  final c = TextEditingController(text: initial);
  final p = pal;
  final r = await showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(text, style: body()),
        const SizedBox(height: 12),
        TextField(controller: c, autofocus: true, maxLength: max, maxLines: 3, minLines: 1),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: Text(tr('Cancel'), style: TextStyle(color: p.muted))),
        TextButton(onPressed: () => Navigator.pop(ctx, c.text), child: Text(ok, style: TextStyle(color: p.a, fontWeight: FontWeight.w700))),
      ],
    ),
  );
  return r;
}
