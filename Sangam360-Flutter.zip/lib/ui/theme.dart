import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/prefs.dart';
import '../core/session.dart';

/// Light minimal design: soft off-white background, white cards with hairline borders, one accent colour
/// (the colour of the kind of workspace), generous spacing and Plus Jakarta Sans.
class Pal {
  final bool dark;
  final Color a, a2, rc;
  const Pal(this.dark, this.a, this.a2, this.rc);

  Color get bg => dark ? const Color(0xFF0B0D14) : const Color(0xFFF6F7FB);
  Color get card => dark ? const Color(0xFF141824) : Colors.white;
  Color get card2 => dark ? const Color(0xFF1A1F2E) : const Color(0xFFF2F4F9);
  Color get line => dark ? const Color(0xFF242A3B) : const Color(0xFFE8EBF2);
  Color get text => dark ? const Color(0xFFE9EBF3) : const Color(0xFF0F172A);
  Color get muted => dark ? const Color(0xFF8E96AB) : const Color(0xFF64748B);
  Color get faint => dark ? const Color(0xFF5B6377) : const Color(0xFF94A3B8);
  Color get green => const Color(0xFF10B981);
  Color get red => const Color(0xFFEF4444);
  Color get amber => const Color(0xFFF59E0B);
  Color get blue => const Color(0xFF3B82F6);
  Color get tint => a.withOpacity(dark ? .22 : .10);
  Color get chat => dark ? const Color(0xFF0F1320) : const Color(0xFFF1F3F8);
  Color get bub => dark ? const Color(0xFF1C2232) : Colors.white;
  List<BoxShadow> get shadow => dark
      ? const []
      : [BoxShadow(color: const Color(0xFF0F172A).withOpacity(.05), blurRadius: 24, offset: const Offset(0, 8)), BoxShadow(color: const Color(0xFF0F172A).withOpacity(.03), blurRadius: 3, offset: const Offset(0, 1))];
  LinearGradient get grad => LinearGradient(colors: [a, a2], begin: Alignment.topLeft, end: Alignment.bottomRight);
}

class ThemeCtl extends ChangeNotifier {
  static final ThemeCtl I = ThemeCtl._();
  ThemeCtl._() {
    final t = Prefs.get('sh-theme');
    mode = t == 'dark' ? ThemeMode.dark : t == 'light' ? ThemeMode.light : ThemeMode.system;
  }
  ThemeMode mode = ThemeMode.system;
  Brightness platform = WidgetsBinding.instance.platformDispatcher.platformBrightness;
  bool get dark => mode == ThemeMode.dark || (mode == ThemeMode.system && platform == Brightness.dark);
  void toggle() {
    mode = dark ? ThemeMode.light : ThemeMode.dark;
    Prefs.set('sh-theme', dark ? 'dark' : 'light');
    notifyListeners();
  }

  void platformChanged() {
    platform = WidgetsBinding.instance.platformDispatcher.platformBrightness;
    notifyListeners();
  }
}

Pal get pal => Pal(ThemeCtl.I.dark, S.K.c1, S.K.c2, S.K.rc);

const fontFam = 'Jakarta';

ThemeData buildTheme(Pal p) {
  final base = ThemeData(
    useMaterial3: true,
    brightness: p.dark ? Brightness.dark : Brightness.light,
    fontFamily: fontFam,
    colorScheme: ColorScheme.fromSeed(seedColor: p.a, brightness: p.dark ? Brightness.dark : Brightness.light, primary: p.a, surface: p.card),
    scaffoldBackgroundColor: p.bg,
    splashFactory: InkSparkle.splashFactory,
  );
  return base.copyWith(
    textTheme: base.textTheme.apply(bodyColor: p.text, displayColor: p.text, fontFamily: fontFam),
    dividerColor: p.line,
    appBarTheme: AppBarTheme(
      backgroundColor: p.bg,
      foregroundColor: p.text,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleTextStyle: TextStyle(fontFamily: fontFam, fontSize: 18, fontWeight: FontWeight.w700, color: p.text),
      systemOverlayStyle: p.dark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: p.card,
      isDense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      labelStyle: TextStyle(color: p.muted, fontSize: 14),
      floatingLabelStyle: TextStyle(color: p.a, fontWeight: FontWeight.w600),
      hintStyle: TextStyle(color: p.faint, fontSize: 14),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: p.line)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: p.line)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: p.a, width: 1.6)),
      errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: p.red)),
    ),
    bottomSheetTheme: BottomSheetThemeData(backgroundColor: p.card, surfaceTintColor: Colors.transparent, showDragHandle: false, modalBackgroundColor: p.card),
    dialogTheme: DialogTheme(backgroundColor: p.card, surfaceTintColor: Colors.transparent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22))),
    snackBarTheme: SnackBarThemeData(behavior: SnackBarBehavior.floating, backgroundColor: p.text, contentTextStyle: TextStyle(color: p.bg)),
    checkboxTheme: CheckboxThemeData(fillColor: WidgetStateProperty.resolveWith((s) => s.contains(WidgetState.selected) ? p.a : null), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5))),
    switchTheme: SwitchThemeData(thumbColor: WidgetStateProperty.resolveWith((s) => s.contains(WidgetState.selected) ? Colors.white : null), trackColor: WidgetStateProperty.resolveWith((s) => s.contains(WidgetState.selected) ? p.a : null)),
    progressIndicatorTheme: ProgressIndicatorThemeData(color: p.a),
    pageTransitionsTheme: const PageTransitionsTheme(builders: {TargetPlatform.android: ZoomPageTransitionsBuilder()}),
  );
}

/* text styles */
TextStyle h1([Color? c]) => TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: c ?? pal.text, letterSpacing: -.4, height: 1.15);
TextStyle h2([Color? c]) => TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: c ?? pal.text, letterSpacing: -.2);
TextStyle h3([Color? c]) => TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: c ?? pal.text);
TextStyle body([Color? c]) => TextStyle(fontSize: 14.5, color: c ?? pal.text, height: 1.45);
TextStyle meta([Color? c]) => TextStyle(fontSize: 12.5, color: c ?? pal.muted, height: 1.4);
TextStyle small([Color? c]) => TextStyle(fontSize: 11.5, color: c ?? pal.muted);
