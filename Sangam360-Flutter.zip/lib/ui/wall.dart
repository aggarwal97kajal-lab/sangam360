import 'dart:math' as math;
import 'package:flutter/material.dart';

/// WhatsApp-style doodle wallpaper for chats: a soft, repeating pattern of
/// small line icons tinted from the wallpaper colour.
class ChatWall extends StatelessWidget {
  final Color color;
  final bool dark;
  final Widget child;
  const ChatWall({super.key, required this.color, required this.dark, required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Positioned.fill(
        child: RepaintBoundary(
          child: CustomPaint(painter: _Doodle(color, dark), isComplex: true, willChange: false),
        ),
      ),
      child,
    ]);
  }
}

const _icons = <IconData>[
  Icons.chat_bubble_outline_rounded, Icons.favorite_border_rounded, Icons.star_border_rounded,
  Icons.home_outlined, Icons.music_note_outlined, Icons.camera_alt_outlined, Icons.coffee_outlined,
  Icons.local_florist_outlined, Icons.emoji_emotions_outlined, Icons.pets_outlined, Icons.cake_outlined,
  Icons.call_outlined, Icons.wb_sunny_outlined, Icons.cloud_outlined, Icons.headphones_outlined,
  Icons.directions_bike_outlined, Icons.school_outlined, Icons.lightbulb_outline_rounded,
  Icons.icecream_outlined, Icons.sports_soccer_outlined, Icons.umbrella_outlined, Icons.book_outlined,
  Icons.nightlight_outlined, Icons.card_giftcard_outlined, Icons.eco_outlined, Icons.anchor_outlined,
];

class _Doodle extends CustomPainter {
  final Color wall;
  final bool dark;
  _Doodle(this.wall, this.dark);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = wall);
    final tint = dark ? Color.lerp(wall, Colors.white, .07)! : Color.lerp(wall, Colors.black, .075)!;
    const cell = 58.0;
    final cols = (size.width / cell).ceil() + 1, rows = (size.height / cell).ceil() + 1;
    final tp = TextPainter(textDirection: TextDirection.ltr);
    for (var r = 0; r < rows; r++) {
      for (var c = 0; c < cols; c++) {
        // stable pseudo-random per cell, so the pattern never jumps
        final h = ((r * 73856093) ^ (c * 19349663)) & 0x7fffffff;
        final ic = _icons[h % _icons.length];
        final sz = 18.0 + (h >> 5) % 8;
        final rot = (((h >> 9) % 60) - 30) * math.pi / 180;
        final dx = c * cell + ((h >> 3) % 14) - 7 + (r.isOdd ? cell / 2 : 0);
        final dy = r * cell + ((h >> 7) % 14) - 7;
        tp.text = TextSpan(text: String.fromCharCode(ic.codePoint), style: TextStyle(fontSize: sz, fontFamily: ic.fontFamily, package: ic.fontPackage, color: tint));
        tp.layout();
        canvas.save();
        canvas.translate(dx, dy);
        canvas.rotate(rot);
        tp.paint(canvas, Offset(-tp.width / 2, -tp.height / 2));
        canvas.restore();
      }
    }
  }

  @override
  bool shouldRepaint(_Doodle o) => o.wall != wall || o.dark != dark;
}

/// small preview tile of the wallpaper for the theme picker
class WallTile extends StatelessWidget {
  final Color color;
  final bool dark;
  final Widget child;
  final BorderRadius radius;
  const WallTile({super.key, required this.color, required this.dark, required this.child, required this.radius});
  @override
  Widget build(BuildContext context) => ClipRRect(borderRadius: radius, child: ChatWall(color: color, dark: dark, child: child));
}
