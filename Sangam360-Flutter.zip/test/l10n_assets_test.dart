import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:intl/intl.dart';
import 'package:sangam360/l10n/l10n.dart';

/// the real bundled catalogues, loaded the way the app loads them
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('the app loads every language from its bundled files and switches instantly', () async {
    await L10n.I.init('');
    expect(L10n.I.code, 'en');
    expect(L10n.I.totalCount, greaterThan(1000));
    expect(tr('Check in'), 'Check in');
    for (final l in langs.where((l) => l.code != 'en')) {
      await L10n.I.set(l.code);
      expect(L10n.I.code, l.code);
      expect(L10n.I.translatedCount, greaterThan(0), reason: '${l.code} has no translations');
      // dates use the language's names with 0-9 digits
      final d = DateFormat('d MMM yyyy').format(DateTime(2026, 10, 5));
      expect(RegExp(r'5').hasMatch(d) && RegExp(r'2026').hasMatch(d), isTrue, reason: '${l.code}: $d');
    }
    await L10n.I.set('en');
    expect(tr('Check in'), 'Check in');
  });

  test('the ARB files are valid assets', () async {
    for (final l in langs) {
      final s = await rootBundle.loadString('assets/l10n/app_${l.code}.arb');
      expect(s.contains('"@@locale": "${l.code}"'), isTrue);
    }
  });
}
