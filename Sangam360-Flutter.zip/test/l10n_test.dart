import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sangam360/l10n/l10n.dart';

Map<String, String> _arb(String code) {
  final m = jsonDecode(File('assets/l10n/app_$code.arb').readAsStringSync()) as Map<String, dynamic>;
  return {for (final e in m.entries) if (!e.key.startsWith('@')) e.key: e.value as String};
}

void main() {
  final en = _arb('en');

  test('every supported language has a catalogue file', () {
    for (final l in langs) {
      expect(File('assets/l10n/app_${l.code}.arb').existsSync(), isTrue, reason: 'missing app_${l.code}.arb');
    }
  });

  test('keys of the English source are stable (slug + hash of the text)', () {
    for (final e in en.entries) {
      expect(L10n.keyFor(e.value), e.key, reason: e.value);
    }
  });

  test('no translation breaks a placeholder or uses an unknown key', () {
    final ph = RegExp(r'\{\d+\}');
    List<String> p(String s) => (ph.allMatches(s).map((m) => m.group(0)!).toSet().toList()..sort());
    for (final l in langs.where((l) => l.code != 'en')) {
      final t = _arb(l.code);
      for (final e in t.entries) {
        expect(en.containsKey(e.key), isTrue, reason: '${l.code}: unknown key ${e.key}');
        expect(e.value.trim(), isNotEmpty, reason: '${l.code}: empty ${e.key}');
        // a translation may drop a placeholder (an English plural "s"), but never add one
        expect(p(en[e.key]!).toSet().containsAll(p(e.value)), isTrue, reason: '${l.code}: placeholders of "${en[e.key]}"');
      }
    }
  });

  test('tr() translates, falls back to English, and leaves unknown text alone', () {
    L10n.I.debugLoad('hi', {'check_in_1': 'Check in', 'paid_x': 'Paid {0} of {1}'}, {'check_in_1': 'चेक इन', 'paid_x': '{1} में से {0} भुगतान'});
    expect(tr('Check in'), 'चेक इन');
    expect(trf('Paid {0} of {1}', [2, 5]), '5 में से 2 भुगतान');
    // what people write is never in the catalogue, so it stays as written
    expect(tr('Water supply off tomorrow'), 'Water supply off tomorrow');
    L10n.I.debugLoad('hi', {'check_in_1': 'Check in'}, {});
    expect(tr('Check in'), 'Check in', reason: 'missing translation falls back to English');
  });

  test('English is forced while a PDF is made', () async {
    L10n.I.debugLoad('hi', {'k': 'Total'}, {'k': 'कुल'});
    expect(tr('Total'), 'कुल');
    final inside = await L10n.I.english(() async => tr('Total'));
    expect(inside, 'Total');
    expect(tr('Total'), 'कुल');
  });

  testWidgets('switching the language rebuilds the screen without a restart', (t) async {
    L10n.I.debugLoad('en', {'a': 'Hello', 'b': 'Settings'}, {});
    await t.pumpWidget(MaterialApp(
      home: ListenableBuilder(listenable: L10n.I, builder: (_, __) => Column(children: [Text(tr('Hello')), Text(tr('Settings'))])),
    ));
    expect(find.text('Hello'), findsOneWidget);
    L10n.I.debugLoad('mr', {'a': 'Hello', 'b': 'Settings'}, {'a': 'नमस्कार', 'b': 'सेटिंग्ज'});
    await t.pump();
    expect(find.text('नमस्कार'), findsOneWidget);
    expect(find.text('सेटिंग्ज'), findsOneWidget);
    L10n.I.debugLoad('en', {'a': 'Hello', 'b': 'Settings'}, {});
    await t.pump();
    expect(find.text('Hello'), findsOneWidget);
  });

  test('the language list is complete and every Material locale is one Flutter ships', () {
    expect(langs.map((l) => l.code).toList(), ['en', 'hi', 'mr', 'bn', 'pa', 'gu', 'ta', 'te', 'kn', 'ml', 'or', 'mai']);
    const shipped = {'en', 'hi', 'mr', 'bn', 'pa', 'gu', 'ta', 'te', 'kn', 'ml', 'or'};
    for (final l in langs) {
      expect(shipped.contains(l.material), isTrue, reason: l.code);
    }
  });
}
