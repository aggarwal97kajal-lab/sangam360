import 'package:flutter_test/flutter_test.dart';
import 'package:sangam360/core/kinds.dart';
import 'package:sangam360/l10n/l10n.dart';
import 'package:sangam360/screens/fin/invoice.dart';

/// behaviour that existed before languages were added must not change
void main() {
  setUp(() => L10n.I.debugLoad('en', {}, {}));

  test('GST invoice amounts and words (Indian numbering, English on the PDF)', () {
    expect(inr(1234567.5), '12,34,567.50');
    expect(amountWords(1500), 'ONE THOUSAND FIVE HUNDRED RUPEES ONLY');
    expect(amountWords(250000.25), 'TWO LAKH FIFTY THOUSAND RUPEES AND TWENTY-FIVE PAISA ONLY');
  });

  test('workspace labels stay the same in English', () {
    expect(kinds['society']!.person, 'Resident');
    expect(kinds['company']!.unit, 'Desk');
    expect(kinds['school']!.word, 'school');
    expect(kinds['company']!.grp!.t, 'Departments');
  });

  test('workspace labels follow the language, and stay English for PDFs', () async {
    L10n.I.debugLoad('hi', {'r': 'Resident'}, {'r': 'निवासी'});
    expect(kinds['society']!.person, 'निवासी');
    expect(kinds['society']!.personE, 'Resident');
    expect(await L10n.I.english(() async => kinds['society']!.person), 'Resident');
  });

  test('stored values are not translated (only what is shown)', () {
    // categories and statuses are saved in English; the list itself must stay English
    expect(incCats.first, 'Maintenance');
    expect(plansSoc.first.nameE, 'Starter');
    L10n.I.debugLoad('hi', {'s': 'Starter'}, {'s': 'स्टार्टर'});
    expect(plansSoc.first.id, 'free');
    expect(plansSoc.first.name, 'स्टार्टर');
    expect(incCats.first, 'Maintenance');
  });
}
