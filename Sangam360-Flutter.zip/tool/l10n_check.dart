// Translation completeness check.
//
//   dart run tool/l10n_check.dart            report per language
//   dart run tool/l10n_check.dart --strict   also fail when a language is missing texts
//
// Always fails (exit 1) when a translation breaks the app: an unknown key, a {0} placeholder
// that the English text does not have, or an empty value.
import 'dart:convert';
import 'dart:io';

void main(List<String> args) {
  final strict = args.contains('--strict');
  final dir = Directory('assets/l10n');
  final en = _load(File('${dir.path}/app_en.arb'));
  final keys = en.keys.where((k) => !k.startsWith('@')).toList();
  var broken = 0, missingAll = 0;
  final files = dir.listSync().whereType<File>().where((f) => RegExp(r'app_[a-z]+\.arb$').hasMatch(f.path) && !f.path.endsWith('app_en.arb')).toList()
    ..sort((a, b) => a.path.compareTo(b.path));
  stdout.writeln('English source: ${keys.length} texts');
  for (final f in files) {
    final code = RegExp(r'app_([a-z]+)\.arb$').firstMatch(f.path)!.group(1);
    final m = _load(f);
    final missing = <String>[], bad = <String>[];
    for (final k in keys) {
      final v = m[k];
      if (v == null) {
        missing.add(k);
        continue;
      }
      if (v is! String || v.trim().isEmpty) {
        bad.add('$k: empty');
        continue;
      }
      // a translation may leave out a placeholder (e.g. an English plural "s"), but never invent one
      final a = _ph(en[k] as String), b = _ph(v);
      final extra = b.where((x) => !a.contains(x)).toList();
      if (extra.isNotEmpty) bad.add('$k: unknown placeholder ${extra.join(',')}');
    }
    for (final k in m.keys) {
      if (!k.startsWith('@') && !en.containsKey(k)) bad.add('$k: not in app_en.arb');
    }
    final pct = (100 * (keys.length - missing.length) / keys.length).toStringAsFixed(1);
    stdout.writeln('$code: $pct% (${keys.length - missing.length}/${keys.length})${bad.isEmpty ? '' : ' · ${bad.length} broken'}');
    for (final b in bad.take(20)) {
      stdout.writeln('   ✗ $b');
    }
    if (missing.isNotEmpty) {
      stdout.writeln('   missing e.g.: ${missing.take(5).map((k) => en[k]).join(' | ')}');
    }
    broken += bad.length;
    missingAll += missing.length;
  }
  if (broken > 0 || (strict && missingAll > 0)) exit(1);
}

Map<String, dynamic> _load(File f) => jsonDecode(f.readAsStringSync()) as Map<String, dynamic>;
List<String> _ph(String s) => (RegExp(r'\{\d+\}').allMatches(s).map((m) => m.group(0)!).toSet().toList()..sort());
